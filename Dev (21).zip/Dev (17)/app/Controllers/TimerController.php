<?php
/**
 * Server-authoritative timer and time entries.
 *
 * Start/stop/status are JSON-friendly so the global bar and data-timer-start
 * buttons stay in sync. Manual entries go through CSRF and duration validation.
 */

declare(strict_types=1);

final class TimerController extends Controller
{
    private Timer $timers;
    private TimeEntry $entries;
    private Project $projects;
    private Task $tasks;

    public function __construct()
    {
        parent::__construct(true);
        FeatureFlagsHelper::requireTracker();
        $this->timers   = new Timer();
        $this->entries  = new TimeEntry();
        $this->projects = new Project();
        $this->tasks    = new Task();
    }

    /** GET /time */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled();

        $userId  = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('time.view_all');
        $browseOthers = $viewAll || WorkspacePolicy::canBrowseOthersTime();

        $from = $this->dateOrEmpty((string) $request->input('from', ''));
        $to   = $this->dateOrEmpty((string) $request->input('to', ''));
        $requestedUser = (int) $request->input('user_id', 0);

        if ($requestedUser > 0 && $requestedUser !== $userId && !$browseOthers) {
            $this->forbidden();
        }

        $filters = [
            'from'       => $from,
            'to'         => $to,
            'project_id' => (int) $request->input('project_id', 0),
            'task_id'    => (int) $request->input('task_id', 0),
            'billable'   => (string) $request->input('billable', ''),
            'status'     => (string) $request->input('status', ''),
            'user_id'    => $browseOthers ? $requestedUser : $userId,
            'viewer_id'  => $userId,
            'regular_visibility' => !$viewAll && WorkspacePolicy::appliesRegularTimeVisibility(),
        ];

        if (!$browseOthers) {
            $filters['user_id'] = $userId;
        }

        $emptyResult = [
            'items'    => [],
            'total'    => 0,
            'page'     => 1,
            'per_page' => 25,
            'pages'    => 1,
            'totals'   => ['seconds' => 0, 'billable_seconds' => 0, 'count' => 0],
        ];

        try {
            $result = $this->entries->listFiltered($filters, (int) $request->input('page', 1), 25);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $result = $emptyResult;
        }

        try {
            $projects = $this->entries->trackableProjects($userId, PermissionHelper::has('projects.view_all'));
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $projects = [];
        }

        try {
            $filterProjects = $this->filterProjects($userId, $viewAll);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $filterProjects = [];
        }

        try {
            $tasks = $filters['project_id'] > 0 ? $this->entries->tasksForProject($filters['project_id'], $userId, $viewAll) : [];
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $tasks = [];
        }

        try {
            $people = $browseOthers ? $this->activePeople() : [];
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $people = [];
        }

        try {
            $submittable = class_exists('Timesheet') && Timesheet::installed()
                ? (new Timesheet())->submittableEntries($userId)
                : [];
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $submittable = [];
        }

        $this->render('timer/index', [
            'pageTitle'     => 'Time',
            'result'        => $result,
            'filters'       => $filters,
            'projects'      => $projects,
            'filterProjects'=> $filterProjects,
            'tasks'         => $tasks,
            'people'        => $people,
            'viewAll'       => $browseOthers,
            'canTrack'      => PermissionHelper::has('time.track'),
            'canManual'     => FeatureFlagsHelper::allowManual() && PermissionHelper::has('time.edit_own'),
            'canDelete'     => PermissionHelper::has('time.edit_own'),
            'canEditAll'    => WorkspacePolicy::canEditTimeForOthers(),
            'activeTimer'   => $this->safeActiveTimer($userId),
            'showManual'    => (string) $request->input('manual', '') === '1',
            'submittable'   => $submittable,
            'capacityHours' => WorkspacePolicy::dailyCapacityHours(),
            'usedTodaySeconds' => $this->entries->secondsOnLocalDay($userId, gmdate('Y-m-d H:i:s')),
        ]);
    }

    /** GET /time/status  GET /timer/status */
    public function status(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled(true);

        $userId = (int) AuthHelper::id();
        AuthHelper::releaseSession();

        $timer = $this->timers->getActive($userId);
        $idle = $timer !== null
            ? IdleDetectionService::checkTimer($userId, (int) $timer['id'], false)
            : [
                'enabled' => WorkspacePolicy::string('idle_detection_enabled', '0') === '1',
                'agent_connected' => false, 'agent_required' => false, 'warning' => false,
                'event_id' => null, 'idle_seconds' => 0,
                'threshold_seconds' => WorkspacePolicy::int('idle_threshold_minutes', 10) * 60,
                'warning_seconds' => WorkspacePolicy::int('idle_warning_seconds', 60), 'auto_paused' => false,
            ];

        $this->json([
            'ok'         => true,
            'timer'      => $timer === null ? null : $this->timerPayload($timer),
            'idle'       => $idle,
            'server_now' => time(),
        ]);
    }

    /** GET /time/active
     *
     * Lightweight live feed used by the Time page. It intentionally returns
     * server elapsed seconds, while the browser interpolates those seconds
     * locally between polls so the displayed clock ticks every second.
     */
    public function active(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled(true);

        $viewerId = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('time.view_all');
        $requestedUser = (int) $request->input('user_id', 0);
        if ($requestedUser > 0 && $requestedUser !== $viewerId && !WorkspacePolicy::canBrowseOthersTime()) {
            $this->forbidden();
        }
        $userId = ($viewAll || WorkspacePolicy::canBrowseOthersTime()) && $requestedUser > 0 ? $requestedUser : null;

        AuthHelper::releaseSession();

        $timers = $this->timers->getVisibleActive($viewerId, $viewAll, $userId);
        $payload = array_map(fn (array $timer): array => $this->liveTimerPayload($timer), $timers);

        $this->json([
            'ok' => true,
            'timers' => $payload,
            'server_now' => time(),
        ]);
    }

    /** POST /time/start  POST /timer/start */
    public function start(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        $this->timers->cleanupExpired((int) AuthHelper::id());

        $projectId   = (int) $request->input('project_id', 0);
        $taskId      = (int) $request->input('task_id', 0);
        $description = trim((string) $request->input('description', ''));
        $billableIn  = $request->input('is_billable', $request->input('billable', null));

        $now = gmdate('Y-m-d H:i:s', time());
        try {
            $checked = TimeTrackingRules::assertCanTrack(
                (int) AuthHelper::id(),
                $projectId,
                $taskId > 0 ? $taskId : null,
                $now,
                TimeTrackingRules::CONTEXT_START
            );
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        }
        $project = $checked['project'];
        $task = $checked['task'];
        if ($task === null) {
            $taskId = 0;
        }

        $isBillable = $billableIn === null
            ? (int) $project['is_billable'] === 1
            : in_array($billableIn, [1, '1', true, 'true', 'on', 'yes'], true);

        try {
            $timer = $this->timers->start(
                (int) AuthHelper::id(),
                $projectId,
                $taskId > 0 ? $taskId : null,
                $description,
                $isBillable
            );
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.started', 'timer', (int) $timer['id'], [
            'project_id' => $projectId,
            'task_id'    => $taskId > 0 ? $taskId : null,
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'timer' => $this->timerPayload($timer),
            ]);
        }

        $label = (string) $project['name'];
        if ($task !== null) {
            $label .= ' / ' . $task['name'];
        }
        $this->flash('success', 'Timer started on ' . $label . '.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/pause  POST /timer/pause */
    public function pause(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        try {
            $timer = $this->timers->pause((int) AuthHelper::id());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.paused', 'timer', (int) $timer['id']);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'timer' => $this->timerPayload($timer),
            ]);
        }

        $this->flash('success', 'Timer paused.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/resume  POST /timer/resume */
    public function resume(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        try {
            $timer = $this->timers->resume((int) AuthHelper::id());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.resumed', 'timer', (int) $timer['id']);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'timer' => $this->timerPayload($timer),
            ]);
        }

        $this->flash('success', 'Timer resumed.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/stop  POST /timer/stop */
    public function stop(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        $userId = (int) AuthHelper::id();
        $resolution = strtolower(trim((string) $request->input('resolution', '')));

        if ($resolution !== '') {
            try {
                $entry = $this->timers->resolveStop($userId, $resolution);
            } catch (HttpException $e) {
                $this->failTimer($e->getMessage(), $e->status());
            } catch (InvalidArgumentException|RuntimeException $e) {
                $this->failTimer($e->getMessage(), 409);
            }

            if ($resolution === 'discard') {
                LoggerHelper::audit('timer.discarded_after_overlap', 'timer', 0, ['user_id' => $userId]);
                if ($request->wantsJson() || $request->isAjax()) {
                    $this->json(['ok' => true, 'entry' => null, 'timer' => null, 'resolution' => 'discard']);
                }
                $this->flash('warning', 'The conflicting timer was discarded without saving a time entry.');
                $this->redirect($this->backPath('/time'));
            }

            if (!is_array($entry)) {
                $this->failTimer('The timer could not be resolved. Please refresh and try again.', 409);
            }

            LoggerHelper::audit('timer.stopped_trimmed', 'time_entry', (int) $entry['id'], [
                'project_id'       => (int) $entry['project_id'],
                'duration_seconds' => (int) $entry['duration_seconds'],
            ]);

            if ($request->wantsJson() || $request->isAjax()) {
                $this->json([
                    'ok'         => true,
                    'entry'      => $this->entryPayload($entry),
                    'timer'      => null,
                    'resolution' => 'trim',
                ]);
            }

            $this->flash('success', 'Timer trimmed before the conflicting entry and saved.');
            $this->redirect($this->backPath('/time'));
        }

        try {
            $entry = $this->timers->stop($userId);
        } catch (InvalidArgumentException $e) {
            $conflict = $this->timers->getStopConflict($userId);
            if ($conflict !== null && ($request->wantsJson() || $request->isAjax())) {
                $conflictRow = $conflict['conflict'];
                $timer = $conflict['timer'];
                $start = (string) ($timer['created_at'] ?? $timer['started_at'] ?? '');
                $end = gmdate('Y-m-d H:i:s', time());
                $trimEndTs = strtotime((string) ($conflictRow['start_time'] ?? '') . ' UTC');
                $startTs = strtotime($start . ' UTC');

                $this->json([
                    'ok' => false,
                    'message' => 'The timer overlaps an existing time entry. Choose how to resolve it.',
                    'resolution_required' => true,
                    'can_trim' => $trimEndTs !== false && $startTs !== false && $trimEndTs > $startTs,
                    'conflict' => [
                        'start_time' => (string) $conflictRow['start_time'],
                        'end_time'   => (string) $conflictRow['end_time'],
                    ],
                    'timer' => [
                        'start_time' => $start,
                        'end_time'   => $end,
                    ],
                ], 409);
            }

            $this->failTimer($e->getMessage(), 409);
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.stopped', 'time_entry', (int) $entry['id'], [
            'project_id'       => (int) $entry['project_id'],
            'duration_seconds' => (int) $entry['duration_seconds'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'entry' => $this->entryPayload($entry),
                'timer' => null,
            ]);
        }

        $this->flash('success', 'Timer stopped. ' . FormatHelper::duration((int) $entry['duration_seconds']) . ' saved.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/ping  POST /timer/ping */
    public function ping(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled(true);

        $userId = (int) AuthHelper::id();
        $this->timers->cleanupExpired($userId);
        $ok = $this->timers->ping($userId);
        $timer = $this->timers->getActive($userId);
        if ($timer !== null && empty($timer['paused_at'])) {
            IdleDetectionService::checkTimer($userId, (int) $timer['id'], true);
        }
        AuthHelper::releaseSession();

        $this->json(['ok' => $ok]);
    }

    /** POST /time/idle-response */
    public function idleResponse(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled(true);

        $eventId = (int) $request->input('event_id', 0);
        $response = (string) $request->input('response', '');
        if ($eventId < 1) {
            $this->json(['ok' => false, 'error' => ['message' => 'Idle prompt is invalid.']], 422);
        }

        try {
            $result = IdleDetectionService::respond((int) AuthHelper::id(), $eventId, $response);
        } catch (RuntimeException|InvalidArgumentException $e) {
            $this->json(['ok' => false, 'error' => ['message' => $e->getMessage()]], 409);
        }

        $timer = $this->timers->getActive((int) AuthHelper::id());
        AuthHelper::releaseSession();
        $this->json([
            'ok' => true,
            'response' => $result['response'] ?? $response,
            'timer' => $timer === null ? null : $this->timerPayload($timer),
        ]);
    }

    /** POST /time/manual */
    public function manualStore(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled($request->wantsJson());

        FeatureFlagsHelper::requireManual();

        $failPath = '/time?manual=1';

        $data = $this->validate([
            'project_id'    => 'required|int|exists:projects,id',
            'task_id'       => 'nullable|int',
            'start_time'    => 'required|datetime',
            'end_time'      => 'required|datetime',
            'break_minutes' => 'nullable|int|min:0|max:1440',
            'description'   => 'nullable|string|max:255',
            'is_billable'   => 'nullable|boolean',
        ], $failPath, [
            'project_id'    => 'Project',
            'task_id'       => 'Task',
            'start_time'    => 'Start',
            'end_time'      => 'End',
            'break_minutes' => 'Break',
            'description'   => 'Description',
        ]);

        $startUtc = FormatHelper::toUtc((string) $data['start_time']);
        $endUtc   = FormatHelper::toUtc((string) $data['end_time']);

        if ($startUtc === null || $endUtc === null) {
            $this->failTimerFields($failPath, ['start_time' => 'Start and end must be valid date and time.']);
        }

        $taskId = (int) ($data['task_id'] ?? 0);
        try {
            $checked = TimeTrackingRules::assertCanTrack(
                (int) AuthHelper::id(),
                (int) $data['project_id'],
                $taskId > 0 ? $taskId : null,
                $startUtc,
                TimeTrackingRules::CONTEXT_MANUAL
            );
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        }
        $project = $checked['project'];
        if ($checked['task'] === null) {
            $taskId = 0;
        }

        $break = (int) ($data['break_minutes'] ?? 0);

        try {
            TimeEntry::computeDuration($startUtc, $endUtc, $break);
        } catch (InvalidArgumentException $e) {
            $this->failTimerFields($failPath, ['end_time' => $e->getMessage()]);
        }

        $isBillable = $data['is_billable'] === null
            ? (int) $project['is_billable'] === 1
            : (int) $data['is_billable'] === 1;

        try {
            $entry = $this->entries->createEntry([
                'user_id'       => (int) AuthHelper::id(),
                'project_id'    => (int) $project['id'],
                'task_id'       => $taskId > 0 ? $taskId : null,
                'start_time'    => $startUtc,
                'end_time'      => $endUtc,
                'break_minutes' => $break,
                'description'   => $data['description'] ?? null,
                'is_billable'   => $isBillable ? 1 : 0,
                'billable_rate' => (float) $project['hourly_rate'],
            ]);
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        } catch (InvalidArgumentException $e) {
            $this->failTimerFields($failPath, ['end_time' => $e->getMessage()]);
        }

        LoggerHelper::audit('time_entry.created', 'time_entry', (int) $entry['id'], [
            'project_id'       => (int) $entry['project_id'],
            'duration_seconds' => (int) $entry['duration_seconds'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'entry' => $this->entryPayload($entry)]);
        }

        $this->flash('success', 'Time entry of ' . FormatHelper::duration((int) $entry['duration_seconds']) . ' was saved.');
        $this->redirect('/time');
    }

    /** POST /time/{id} */
    public function updateEntry(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled($request->wantsJson());

        $id    = (int) ($params['id'] ?? 0);
        $entry = $this->entries->findWithRelations($id);
        if ($entry === null) {
            $this->notFound();
        }

        WorkspacePolicy::assertCanMutateTimeEntry((int) $entry['user_id']);

        $failPath = $this->backPath('/time');

        $data = $this->validate([
            'project_id'    => 'required|int|exists:projects,id',
            'task_id'       => 'nullable|int',
            'start_time'    => 'required|datetime',
            'end_time'      => 'required|datetime',
            'break_minutes' => 'nullable|int|min:0|max:1440',
            'description'   => 'nullable|string|max:255',
            'is_billable'   => 'nullable|boolean',
        ], $failPath, [
            'project_id'    => 'Project',
            'task_id'       => 'Task',
            'start_time'    => 'Start',
            'end_time'      => 'End',
            'break_minutes' => 'Break',
            'description'   => 'Description',
        ]);

        $startUtc = FormatHelper::toUtc((string) $data['start_time']);
        $endUtc   = FormatHelper::toUtc((string) $data['end_time']);

        if ($startUtc === null || $endUtc === null) {
            $this->failTimerFields($failPath, ['start_time' => 'Start and end must be valid date and time.']);
        }

        $taskId = (int) ($data['task_id'] ?? 0);
        try {
            $checked = TimeTrackingRules::assertCanTrack(
                (int) $entry['user_id'],
                (int) $data['project_id'],
                $taskId > 0 ? $taskId : null,
                $startUtc,
                TimeTrackingRules::CONTEXT_EDIT
            );
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        }
        $project = $checked['project'];
        if ($checked['task'] === null) {
            $taskId = 0;
        }

        $break = (int) ($data['break_minutes'] ?? 0);
        $isBillable = $data['is_billable'] === null
            ? (int) $entry['is_billable'] === 1
            : (int) $data['is_billable'] === 1;

        try {
            $updated = $this->entries->updateEntry($id, [
                'project_id'    => (int) $project['id'],
                'task_id'       => $taskId > 0 ? $taskId : null,
                'start_time'    => $startUtc,
                'end_time'      => $endUtc,
                'break_minutes' => $break,
                'description'   => $data['description'] ?? null,
                'is_billable'   => $isBillable ? 1 : 0,
                'billable_rate' => (int) $project['id'] === (int) $entry['project_id']
                    ? (float) ($entry['billable_rate'] ?? $project['hourly_rate'])
                    : (float) $project['hourly_rate'],
            ]);
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        } catch (InvalidArgumentException $e) {
            $this->failTimerFields($failPath, ['end_time' => $e->getMessage()]);
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('time_entry.updated', 'time_entry', $id, [
            'project_id'       => (int) $updated['project_id'],
            'duration_seconds' => (int) $updated['duration_seconds'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'entry' => $this->entryPayload($updated)]);
        }

        $this->flash('success', 'Time entry was updated.');
        $this->redirect($failPath);
    }

    /** POST /time/{id}/delete */
    public function deleteEntry(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled($request->wantsJson());

        $id    = (int) ($params['id'] ?? 0);
        $entry = $this->entries->findWithRelations($id);
        if ($entry === null) {
            $this->notFound();
        }

        WorkspacePolicy::assertCanMutateTimeEntry((int) $entry['user_id']);

        try {
            $this->entries->deleteEntry($id, $entry);
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('time_entry.deleted', 'time_entry', $id, [
            'project_id' => (int) $entry['project_id'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true]);
        }

        $this->flash('success', 'Time entry was deleted.');
        $this->redirect($this->backPath('/time'));
    }

    /**
     * POST /time/{id}/description
     * Inline note edit. Body: description, optional ids[] to apply the same note
     * to every chunk of a grouped row. Locked entries are skipped and reported.
     */
    public function updateDescription(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled(true);

        $id = (int) ($params['id'] ?? 0);
        $description = trim((string) $request->input('description', ''));
        if (mb_strlen($description, 'UTF-8') > 255) {
            $this->json(['ok' => false, 'message' => 'Description must be 255 characters or fewer.'], 422);
        }

        $ids = $request->input('ids', []);
        $ids = is_array($ids) ? array_map('intval', $ids) : [];
        $ids[] = $id;
        $ids = array_values(array_unique(array_filter($ids, static fn (int $v): bool => $v > 0)));
        if (count($ids) > 200) {
            $this->json(['ok' => false, 'message' => 'Too many entries.'], 422);
        }

        $saved = [];
        $locked = [];
        foreach ($ids as $entryId) {
            $entry = $this->entries->findWithRelations($entryId);
            if ($entry === null) {
                $this->json(['ok' => false, 'message' => 'Time entry was not found.'], 404);
            }
            try {
                WorkspacePolicy::assertCanMutateTimeEntry((int) $entry['user_id']);
            } catch (HttpException $e) {
                $this->json(['ok' => false, 'message' => 'You cannot edit this entry.'], $e->status());
            }

            try {
                $this->entries->updateDescription($entryId, $description);
                $saved[] = $entryId;
            } catch (HttpException) {
                $locked[] = $entryId;
            } catch (RuntimeException) {
                $locked[] = $entryId;
            }
        }

        if ($saved === []) {
            $this->json(['ok' => false, 'message' => 'These entries are locked on a submitted or approved timesheet.', 'locked' => $locked], 409);
        }

        LoggerHelper::audit('time_entry.description_updated', 'time_entry', $saved[0], ['count' => count($saved)]);

        $this->json(['ok' => true, 'description' => $description, 'saved' => $saved, 'locked' => $locked]);
    }

    /** GET /time/tasks?project_id= */
    public function tasksJson(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled(true);

        $projectId = (int) $request->input('project_id', 0);
        $this->assertTrackableProject($projectId);

        $userId = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('projects.view_all');
        $this->json(['ok' => true, 'tasks' => $this->entries->tasksForProject($projectId, $userId, $viewAll)]);
    }

    private function requireInstalled(bool $asJson = false): void
    {
        if (Timer::installed() && TimeEntry::installed()) {
            return;
        }

        if ($asJson || $this->request->wantsJson()) {
            $this->json(['ok' => false, 'error' => ['status' => 503, 'message' => 'Time tracking is not installed yet.']], 503);
        }

        $this->flash('warning', 'Time tracking tables are not installed. Import database/phase6.sql.');
        $this->redirect('/dashboard');
    }

    /** @return array<string, mixed> */
    private function assertTrackableProject(int $projectId): array
    {
        if ($projectId < 1) {
            $this->failTimer('Choose a project.', 422);
        }

        $now = gmdate('Y-m-d H:i:s', time());
        try {
            $checked = TimeTrackingRules::assertCanTrack(
                (int) AuthHelper::id(),
                $projectId,
                null,
                $now,
                TimeTrackingRules::CONTEXT_START
            );
        } catch (HttpException $e) {
            $this->failTimer($e->getMessage(), $e->status());
        }

        return $checked['project'];
    }

    private function failTimer(string $message, int $status = 422): never
    {
        if ($this->request->wantsJson() || $this->request->isAjax()) {
            $this->json(['ok' => false, 'message' => $message], $status);
        }

        $this->flash($status >= 500 ? 'danger' : 'warning', $message);
        $this->redirect($this->backPath('/time'));
    }

    /** @param array<string, string> $errors */
    private function failTimerFields(string $failPath, array $errors): never
    {
        if ($this->request->wantsJson() || $this->request->isAjax()) {
            $this->json(['ok' => false, 'errors' => $errors, 'message' => (string) reset($errors)], 422);
        }

        $this->backWithErrors($failPath, $errors);
    }

    private function backPath(string $default): string
    {
        $referer = $this->request->header('referer');
        if ($referer === null || $referer === '') {
            return $default;
        }

        $path = (string) parse_url($referer, PHP_URL_PATH);
        $base = Request::basePath();
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base)) ?: '/';
        }

        if ($path === '' || $path[0] !== '/' || str_starts_with($path, '//')) {
            return $default;
        }

        return $path;
    }

    private function dateOrEmpty(string $value): string
    {
        $value = trim($value);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) === 1 ? $value : '';
    }

    private function allowManual(): bool
    {
        return FeatureFlagsHelper::allowManual();
    }

    /**
     * @param array<string, mixed> $timer
     * @return array<string, mixed>
     */
    private function timerPayload(array $timer): array
    {
        $started = (string) ($timer['created_at'] ?? $timer['started_at']);
        $iso     = (new DateTimeImmutable($started, new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');

        return [
            'id'               => (int) $timer['id'],
            'project_id'       => (int) $timer['project_id'],
            'task_id'          => $timer['task_id'] !== null ? (int) $timer['task_id'] : null,
            'project_name'     => (string) ($timer['project_name'] ?? ''),
            'task_name'        => (string) ($timer['task_name'] ?? ''),
            'description'      => (string) ($timer['description'] ?? ''),
            'is_billable'      => (int) $timer['is_billable'] === 1,
            'started_at'       => $started,
            'started_at_iso'   => $iso,
            'elapsed_seconds'  => (int) $timer['elapsed_seconds'],
            'elapsed_display'  => (string) ($timer['elapsed_display'] ?? FormatHelper::duration((int) $timer['elapsed_seconds'])),
            'paused'           => !empty($timer['paused_at']),
            'paused_at'        => !empty($timer['paused_at']) ? (string) $timer['paused_at'] : null,
            'server_now'       => time(),
        ];
    }

    /**
     * @param array<string, mixed> $entry
     * @return array<string, mixed>
     */
    private function entryPayload(array $entry): array
    {
        return [
            'id'               => (int) $entry['id'],
            'project_id'       => (int) $entry['project_id'],
            'task_id'          => $entry['task_id'] !== null ? (int) $entry['task_id'] : null,
            'project_name'     => (string) ($entry['project_name'] ?? ''),
            'task_name'        => (string) ($entry['task_name'] ?? ''),
            'start_time'       => (string) $entry['start_time'],
            'end_time'         => (string) $entry['end_time'],
            'duration_seconds' => (int) $entry['duration_seconds'],
            'duration_display' => FormatHelper::duration((int) $entry['duration_seconds']),
            'break_minutes'    => (int) $entry['break_minutes'],
            'description'      => (string) ($entry['description'] ?? ''),
            'is_billable'      => (int) $entry['is_billable'] === 1,
            'status'           => (string) ($entry['timesheet_status'] ?? 'unsubmitted'),
        ];
    }

    /** @param array<string, mixed> $timer */
    private function liveTimerPayload(array $timer): array
    {
        $started = (string) ($timer['started_at'] ?? $timer['created_at'] ?? '');
        $iso = '';
        if ($started !== '') {
            try {
                $iso = (new DateTimeImmutable($started, new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');
            } catch (Exception) {
                $iso = '';
            }
        }

        return [
            'id' => (int) $timer['id'],
            'user_id' => (int) $timer['user_id'],
            'user_name' => (string) ($timer['user_name'] ?? ''),
            'project_id' => (int) $timer['project_id'],
            'project_name' => (string) ($timer['project_name'] ?? ''),
            'task_id' => $timer['task_id'] !== null ? (int) $timer['task_id'] : null,
            'task_name' => (string) ($timer['task_name'] ?? ''),
            'description' => (string) ($timer['description'] ?? ''),
            'started_at_iso' => $iso,
            'elapsed_seconds' => (int) ($timer['elapsed_seconds'] ?? 0),
            'paused' => !empty($timer['paused_at']),
            'server_now' => time(),
        ];
    }

    /** @return list<array<string, mixed>> */
    private function filterProjects(int $userId, bool $viewAll): array
    {
        $viewAllProjects = $viewAll || PermissionHelper::has('projects.view_all');

        return Database::fetchAll(
            'SELECT p.id, p.name, p.project_code
             FROM projects p
             WHERE p.status <> \'Archived\'' .
            ($viewAllProjects ? '' : ' AND (p.manager_id = :uid_m OR p.created_by = :uid_c OR EXISTS (
                 SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :uid_u
             )' . (Project::extrasReady() ? ' OR p.is_public = 1' : '') . ')') . '
             ORDER BY p.name ASC',
            $viewAllProjects ? [] : [
                'uid_m' => $userId,
                'uid_c' => $userId,
                'uid_u' => $userId,
            ]
        );
    }

    /** @return list<array<string, mixed>> */
    private function activePeople(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        );
    }

    /** @return array<string, mixed>|null */
    private function safeActiveTimer(int $userId): ?array
    {
        try {
            return $this->timers->getActive($userId);
        } catch (Throwable $e) {
            LoggerHelper::debug('Active timer lookup failed', ['error' => $e->getMessage()]);
            return null;
        }
    }
}
