# TimeTrack database migration order

## Fresh install
1. `database/install.sql` — final schema through the current application phases, including Step 19 report permissions objects only where they are structural. Run `database/seed.sql` separately if demo accounts/data are wanted.
2. Optional: `database/phase14_step19_reports.sql` is idempotent and is included for upgrade clarity; it may be run after install or on an existing database.

## Existing installation upgrade
Use the migration level actually present in the live database. For the supplied project, the intended order is:

1. Existing Phase 1–10 consolidated baseline: `database/schema.sql` is the structural baseline; on an older live DB use the historical `phase2.sql`, `phase4.sql`, `phase5.sql`, `phase6.sql`, `phase7.sql`, `phase8.sql`, `phase9.sql`, `phase10.sql` in that order.
2. `database/phase11.sql`
3. `database/phase12.sql`
4. Phase 13 structural/data migrations in this order:
   - `database/phase13/03_timer_auto_stopped.sql`
   - `database/phase13/05_schedule_recurrence_parent.sql`
   - `database/phase13/06_settings_workspace_ownership.sql`
   - `database/phase13/08_remove_role_schema_duplicates.sql`
    - `database/phase13/15_enable_scheduling.sql`
    - `database/phase13/05_allow_multiple_submission_batches.sql`
5. Only after inspecting known bad schedule rows, optionally run `database/phase13/05_schedule_bad_rows.preview.sql` then `database/phase13/05_schedule_bad_rows.cleanup.sql`.
6. `database/phase14_step19_reports.sql`
7. `database/phase15_imports.sql`
8. `database/phase16_desktop_idle.sql`
9. `phase17_sync_live_schema.sql` — live dump 2026-10-03 catch-up (permissions, auto_stopped, assigned_to copy/drop, record_id drop)

Do not run historical seed/demo INSERTs against production as an upgrade.

## Verification limitation
Compared against `u897128490_timetrack_fixed.sql` (dump 2026-10-03). See `docs/LIVE_SCHEMA_DIFF.md`. Re-export the live database before applying `phase17_sync_live_schema.sql` drops.

## Step 21 — CSV data import
Run `database/phase15_imports.sql` once on an existing installation. Fresh installs already include the `imports.manage` permission in `install.sql`.


### Phase 16 — Windows desktop activity / idle timer policy
Run `database/phase16_desktop_idle.sql` once. It adds Windows agent devices/pairing, idle prompt events, and workspace settings `idle_detection_enabled`, `idle_threshold_minutes`, and `idle_warning_seconds`. Recommended cron: run `tools/cron_auto_stop.php` every minute; it now also enforces expired idle warnings.
