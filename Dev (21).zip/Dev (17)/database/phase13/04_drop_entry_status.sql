-- TimeTrack Phase 13 / Step 10
-- Copy leftover time_entries.status = 'Approved' rows into the timesheet model
-- when they are not already on an Approved timesheet, then drop status /
-- approved_by / approved_at. The only lock is timesheet_entries membership.
-- Preview the SELECT counts first. Idempotent on MariaDB 11.8.

SET @db_name := DATABASE();

SELECT COUNT(*) AS approved_entries_not_on_approved_sheet
FROM time_entries te
WHERE te.status = 'Approved'
  AND NOT EXISTS (
      SELECT 1 FROM timesheet_entries tse
      INNER JOIN timesheets t ON t.id = tse.timesheet_id
      WHERE tse.time_entry_id = te.id AND t.status = 'Approved'
  );

-- One weekly sheet per user covering those leftover Approved entries.
INSERT INTO timesheets (user_id, start_date, end_date, submission_token, total_seconds, billable_seconds, status, submitted_at, approved_by, approved_at, created_at, updated_at)
SELECT
    te.user_id,
    DATE(DATE_SUB(te.started_at, INTERVAL WEEKDAY(te.started_at) DAY)) AS start_date,
    DATE(DATE_ADD(DATE_SUB(te.started_at, INTERVAL WEEKDAY(te.started_at) DAY), INTERVAL 6 DAY)) AS end_date,
    CONCAT('migrated-04-', te.user_id, '-', DATE(DATE_SUB(te.started_at, INTERVAL WEEKDAY(te.started_at) DAY))),
    0, 0, 'Approved', UTC_TIMESTAMP(), te.approved_by, COALESCE(te.approved_at, UTC_TIMESTAMP()), UTC_TIMESTAMP(), UTC_TIMESTAMP()
FROM time_entries te
WHERE te.status = 'Approved'
  AND NOT EXISTS (
      SELECT 1 FROM timesheet_entries tse
      INNER JOIN timesheets t ON t.id = tse.timesheet_id
      WHERE tse.time_entry_id = te.id AND t.status = 'Approved'
  )
GROUP BY te.user_id, DATE(DATE_SUB(te.started_at, INTERVAL WEEKDAY(te.started_at) DAY))
ON DUPLICATE KEY UPDATE updated_at = UTC_TIMESTAMP();

INSERT IGNORE INTO timesheet_entries (timesheet_id, time_entry_id, created_at)
SELECT t.id, te.id, UTC_TIMESTAMP()
FROM time_entries te
INNER JOIN timesheets t
    ON t.user_id = te.user_id
   AND t.start_date = DATE(DATE_SUB(te.started_at, INTERVAL WEEKDAY(te.started_at) DAY))
   AND t.end_date = DATE(DATE_ADD(DATE_SUB(te.started_at, INTERVAL WEEKDAY(te.started_at) DAY), INTERVAL 6 DAY))
   AND t.status = 'Approved'
WHERE te.status = 'Approved';

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_schema = @db_name
          AND table_name = 'time_entries'
          AND constraint_name = 'fk_time_entries_approved_by'
    ),
    'ALTER TABLE `time_entries` DROP FOREIGN KEY `fk_time_entries_approved_by`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'time_entries'
          AND index_name = 'idx_time_entries_approved_by'
    ),
    'ALTER TABLE `time_entries` DROP INDEX `idx_time_entries_approved_by`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'time_entries'
          AND index_name = 'idx_time_entries_status'
    ),
    'ALTER TABLE `time_entries` DROP INDEX `idx_time_entries_status`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name AND table_name = 'time_entries' AND column_name = 'approved_at'
    ),
    'ALTER TABLE `time_entries` DROP COLUMN `approved_at`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name AND table_name = 'time_entries' AND column_name = 'approved_by'
    ),
    'ALTER TABLE `time_entries` DROP COLUMN `approved_by`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name AND table_name = 'time_entries' AND column_name = 'status'
    ),
    'ALTER TABLE `time_entries` DROP COLUMN `status`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
