-- TimeTrack import module
INSERT INTO permissions (name,display_name,module,description) VALUES
('imports.manage','Import data','imports','Import CSV data into users, clients, projects, tasks, time and schedules.')
ON DUPLICATE KEY UPDATE display_name=VALUES(display_name),module=VALUES(module),description=VALUES(description);
INSERT INTO role_permissions (role_id,permission_id)
SELECT r.id,p.id FROM roles r CROSS JOIN permissions p
WHERE r.name IN ('admin','manager') AND p.name='imports.manage'
ON DUPLICATE KEY UPDATE role_id=VALUES(role_id),permission_id=VALUES(permission_id);
