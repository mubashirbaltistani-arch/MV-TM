<?php
/**
 * Timesheet approval hierarchy.
 *
 *   Admin
 *   └── Project  ── Project Manager            (projects.manager_id)
 *        └── Team Manager                      (teams.manager_id)
 *             └── Team ── Team Lead + Members  (teams.lead_id, team_members)
 *
 * A submission goes ONLY to the people above the submitter:
 *   - team member  -> team lead, team manager, project manager, admins
 *   - team lead    -> team manager, project manager, admins
 *   - team manager -> project manager, admins
 *   - project mgr  -> admins
 *   - admin        -> other admins
 *
 * The chain is resolved PER PROJECT. A submission carries the projects of its time entries, and
 * only the lead / team manager / project manager of THOSE projects are approvers. Somebody who is
 * in several projects or teams therefore never routes work to the manager of a project the work
 * was not logged against.
 *
 * People who are not in any team of the project they logged work on fall back to
 * that project's manager plus admins. Being a manager/admin by ROLE alone never grants
 * approval rights over somebody; only a place in the chain does.
 *
 * One request = one snapshot of users, projects and teams (a handful of small queries), so the
 * sidebar badge, queue and permission checks always agree with each other.
 */

declare(strict_types=1);

final class ApprovalChainHelper
{
    public const LABEL_LEAD    = 'Team lead';
    public const LABEL_MANAGER = 'Team manager';
    public const LABEL_PROJECT = 'Project manager';
    public const LABEL_ADMIN   = 'Admin';

    /** @var array<string, mixed>|null */
    private static ?array $snapshot = null;

    /** @var array<string, array<int, list<string>>> "submitter|projects" => approver id => labels */
    private static array $detailCache = [];

    /** @var array<int, list<int>> approver id => submitter ids */
    private static array $subordinateCache = [];

    /** Forget cached data (after teams are edited within the same request). */
    public static function reset(): void
    {
        self::$snapshot         = null;
        self::$detailCache      = [];
        self::$subordinateCache = [];
    }

    /**
     * Per-request hierarchy snapshot. Shared with TaskPolicy so positions and
     * timesheet approval never disagree.
     *
     * @return array<string, mixed>
     */
    public static function snapshot(): array
    {
        return self::load();
    }

    public static function teamsReady(): bool
    {
        return SchemaHelper::tableExists('teams') && SchemaHelper::tableExists('team_members');
    }

    /**
     * Active people who can decide this person's timesheet (never the submitter).
     * Pass the project ids of the submitted work to limit the chain to those projects;
     * null means "every project the person belongs to" (used when a submission has no entries).
     *
     * @param list<int>|null $projectIds
     * @return list<int>
     */
    public static function approversFor(int $submitterId, ?array $projectIds = null): array
    {
        return array_map('intval', array_keys(self::detailFor($submitterId, $projectIds)));
    }

    /** True when $approverId sits above $submitterId in the hierarchy (or is another admin). */
    public static function canDecide(int $approverId, int $submitterId, ?array $projectIds = null): bool
    {
        if ($approverId < 1 || $submitterId < 1 || $approverId === $submitterId) {
            return false;
        }

        return isset(self::detailFor($submitterId, $projectIds)[$approverId]);
    }

    /**
     * Project-by-project coverage of a non-admin approver: project id => submitter ids whose work
     * on THAT project this person may decide. Drives the approval queue and the sidebar badge.
     *
     * @return array<int, list<int>>
     */
    public static function coverageFor(int $approverId): array
    {
        $snap = self::load();
        $out  = [];
        foreach (array_keys($snap['projects']) as $projectId) {
            $projectId = (int) $projectId;
            foreach (array_keys($snap['users']) as $userId) {
                $userId = (int) $userId;
                if ($userId !== $approverId && isset(self::detailFor($userId, [$projectId])[$approverId])) {
                    $out[$projectId][] = $userId;
                }
            }
        }

        return $out;
    }

    /**
     * Everyone whose timesheets this approver may review (admins: everybody except themselves).
     *
     * @return list<int>
     */
    public static function subordinateIds(int $approverId): array
    {
        if (isset(self::$subordinateCache[$approverId])) {
            return self::$subordinateCache[$approverId];
        }

        $out = [];
        foreach (array_keys(self::load()['users']) as $userId) {
            $userId = (int) $userId;
            if ($userId !== $approverId && isset(self::detailFor($userId)[$approverId])) {
                $out[] = $userId;
            }
        }

        return self::$subordinateCache[$approverId] = $out;
    }

    /**
     * True when this person holds an approving position: team lead, team manager or project manager.
     * (Admins are handled by role.) Used to open the Approvals page for people whose ROLE is employee.
     */
    public static function isApprover(int $userId): bool
    {
        if ($userId < 1) {
            return false;
        }

        $snap = self::load();
        if (in_array($userId, $snap['projectManagers'], true)) {
            return true;
        }

        foreach ($snap['teams'] as $team) {
            if ($team['lead_id'] === $userId || $team['manager_id'] === $userId) {
                return true;
            }
        }

        return false;
    }

    /** Opens the Approvals page / actions: the time.approve permission OR a place in the chain. */
    public static function canAccessApprovals(int $userId): bool
    {
        return PermissionHelper::has('time.approve') || self::isApprover($userId);
    }

    /**
     * Approvers for a submitter with the position(s) they hold, for display.
     *
     * @param list<int>|null $projectIds
     * @return list<array{id: int, name: string, labels: list<string>}>
     */
    public static function describe(int $submitterId, ?array $projectIds = null): array
    {
        $detail = self::detailFor($submitterId, $projectIds);
        if ($detail === []) {
            return [];
        }

        $ids  = array_map('intval', array_keys($detail));
        $in   = implode(',', $ids);
        $rows = Database::fetchAll("SELECT id, name FROM users WHERE id IN ({$in})");
        $names = [];
        foreach ($rows as $row) {
            $names[(int) $row['id']] = (string) $row['name'];
        }

        $order = [self::LABEL_LEAD => 0, self::LABEL_MANAGER => 1, self::LABEL_PROJECT => 2, self::LABEL_ADMIN => 3];
        $out   = [];
        foreach ($detail as $id => $labels) {
            usort($labels, static fn (string $a, string $b): int => ($order[$a] ?? 9) <=> ($order[$b] ?? 9));
            $out[] = ['id' => (int) $id, 'name' => $names[(int) $id] ?? ('User #' . $id), 'labels' => $labels];
        }

        usort($out, static function (array $a, array $b) use ($order): int {
            return [$order[$a['labels'][0]] ?? 9, $a['name']] <=> [$order[$b['labels'][0]] ?? 9, $b['name']];
        });

        return $out;
    }

    /* ------------------------------------------------------------------ internals */

    /**
     * approver id => labels, for one submitter.
     *
     * @return array<int, list<string>>
     */
    private static function detailFor(int $submitterId, ?array $projectIds = null): array
    {
        $projectSet = null;
        if ($projectIds !== null) {
            $projectIds = array_values(array_unique(array_filter(array_map('intval', $projectIds), static fn (int $id): bool => $id > 0)));
            sort($projectIds);
            $projectSet = array_flip($projectIds);
        }

        $cacheKey = $submitterId . '|' . ($projectIds === null ? '*' : implode(',', $projectIds));
        if (isset(self::$detailCache[$cacheKey])) {
            return self::$detailCache[$cacheKey];
        }

        $snap   = self::load();
        $detail = [];
        $add    = static function (int $id, string $label) use (&$detail, $snap, $submitterId): void {
            if ($id < 1 || $id === $submitterId || !isset($snap['active'][$id])) {
                return;
            }
            if (!isset($detail[$id]) || !in_array($label, $detail[$id], true)) {
                $detail[$id][] = $label;
            }
        };

        if (!isset($snap['users'][$submitterId])) {
            return self::$detailCache[$cacheKey] = [];
        }

        foreach ($snap['admins'] as $adminId) {
            $add($adminId, self::LABEL_ADMIN);
        }

        // Admins are reviewed by other admins only.
        if (isset($snap['adminSet'][$submitterId])) {
            return self::$detailCache[$cacheKey] = $detail;
        }

        foreach ($snap['teamRoles'][$submitterId] ?? [] as $teamId => $rank) {
            $team = $snap['teams'][$teamId] ?? null;
            if ($team === null) {
                continue;
            }
            // Project scope: ignore teams of projects the submitted work does not belong to.
            if ($projectSet !== null && !isset($projectSet[$team['project_id']])) {
                continue;
            }
            $projectManager = (int) ($snap['projectManager'][$team['project_id']] ?? 0);

            if ($rank === 'member') {
                $add($team['lead_id'], self::LABEL_LEAD);
                $add($team['manager_id'], self::LABEL_MANAGER);
                $add($projectManager, self::LABEL_PROJECT);
            } elseif ($rank === 'lead') {
                $add($team['manager_id'], self::LABEL_MANAGER);
                $add($projectManager, self::LABEL_PROJECT);
            } elseif ($rank === 'manager') {
                $add($projectManager, self::LABEL_PROJECT);
            }
            // rank 'pm': only admins above, already added.
        }

        // Projects where the person is not in any team go to that project's manager.
        // Scoped: only the projects of the submitted work. Unscoped: every project they are a member of.
        $fallbackProjects = $projectSet !== null
            ? array_keys($projectSet)
            : ($snap['projectMembers'][$submitterId] ?? []);
        foreach ($fallbackProjects as $projectId) {
            $projectId = (int) $projectId;
            if (isset($snap['teamProjects'][$submitterId][$projectId])) {
                continue;
            }
            $add((int) ($snap['projectManager'][$projectId] ?? 0), self::LABEL_PROJECT);
        }

        return self::$detailCache[$cacheKey] = $detail;
    }

    /** @return array<string, mixed> */
    private static function load(): array
    {
        if (self::$snapshot !== null) {
            return self::$snapshot;
        }

        $snap = [
            'users'              => [],
            'userNames'          => [],
            'active'             => [],
            'admins'             => [],
            'adminSet'           => [],
            'projects'           => [],
            'projectManager'     => [],
            'projectManagers'    => [],
            'projectMembers'     => [],
            'projectMemberSet'   => [],
            'projectMemberRoles' => [],
            'teams'              => [],
            'teamNames'          => [],
            'teamRoles'          => [],
            'teamProjects'       => [],
            'teamMemberIds'      => [],
        ];

        try {
            foreach (Database::fetchAll(
                'SELECT u.id, u.name, u.status, r.name AS role
                 FROM users u INNER JOIN roles r ON r.id = u.role_id'
            ) as $row) {
                $id = (int) $row['id'];
                $snap['users'][$id]     = true;
                $snap['userNames'][$id] = (string) $row['name'];
                if ((string) $row['status'] === 'active') {
                    $snap['active'][$id] = true;
                    if ((string) $row['role'] === 'admin') {
                        $snap['admins'][]    = $id;
                        $snap['adminSet'][$id] = true;
                    }
                }
            }

            foreach (Database::fetchAll('SELECT id, manager_id FROM projects') as $row) {
                $snap['projects'][(int) $row['id']] = true;
                if ($row['manager_id'] !== null) {
                    $snap['projectManager'][(int) $row['id']] = (int) $row['manager_id'];
                }
            }
            $snap['projectManagers'] = array_values(array_unique(array_map('intval', array_values($snap['projectManager']))));

            foreach (Database::fetchAll('SELECT project_id, user_id, project_role FROM project_members') as $row) {
                $userId    = (int) $row['user_id'];
                $projectId = (int) $row['project_id'];
                $snap['projectMembers'][$userId][] = $projectId;
                $snap['projectMemberSet'][$userId][$projectId] = true;
                $snap['projectMemberRoles'][$userId][$projectId] = strtolower((string) ($row['project_role'] ?? 'member'));
            }

            if (self::teamsReady()) {
                self::loadTeams($snap);
            }
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        return self::$snapshot = $snap;
    }

    /** @param array<string, mixed> $snap */
    private static function loadTeams(array &$snap): void
    {
        $priority = ['member' => 1, 'lead' => 2, 'manager' => 3, 'pm' => 4];
        $assign = static function (array &$snap, int $userId, int $teamId, int $projectId, string $rank) use ($priority): void {
            if ($userId < 1) {
                return;
            }
            $current = $snap['teamRoles'][$userId][$teamId] ?? null;
            if ($current === null || $priority[$rank] > $priority[$current]) {
                $snap['teamRoles'][$userId][$teamId] = $rank;
            }
            $snap['teamProjects'][$userId][$projectId] = true;
        };

        foreach (Database::fetchAll(
            "SELECT id, project_id, name, manager_id, lead_id FROM teams WHERE status = 'active' OR status IS NULL"
        ) as $row) {
            $teamId    = (int) $row['id'];
            $projectId = (int) $row['project_id'];
            $snap['teams'][$teamId] = [
                'project_id' => $projectId,
                'manager_id' => (int) ($row['manager_id'] ?? 0),
                'lead_id'    => (int) ($row['lead_id'] ?? 0),
            ];
            $snap['teamNames'][$teamId] = (string) ($row['name'] ?? '');

            $assign($snap, (int) ($row['manager_id'] ?? 0), $teamId, $projectId, 'manager');
            $assign($snap, (int) ($row['lead_id'] ?? 0), $teamId, $projectId, 'lead');
            $assign($snap, (int) ($snap['projectManager'][$projectId] ?? 0), $teamId, $projectId, 'pm');
        }

        if ($snap['teams'] === []) {
            return;
        }

        foreach (Database::fetchAll('SELECT team_id, user_id FROM team_members') as $row) {
            $teamId = (int) $row['team_id'];
            if (!isset($snap['teams'][$teamId])) {
                continue;
            }
            $userId = (int) $row['user_id'];
            $assign($snap, $userId, $teamId, $snap['teams'][$teamId]['project_id'], 'member');
            $snap['teamMemberIds'][$teamId][] = $userId;
        }
    }
}
