-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 05, 2026 at 06:02 PM
-- Server version: 11.8.9-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u897128490_timetrack`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_timers`
--

CREATE TABLE `active_timers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `started_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `paused_at` datetime DEFAULT NULL,
  `accumulated_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `active_timers`
--

INSERT INTO `active_timers` (`id`, `user_id`, `project_id`, `task_id`, `started_at`, `last_activity_at`, `paused_at`, `accumulated_seconds`, `description`, `is_billable`, `created_at`) VALUES
(22, 16, 1, 1, '2026-10-05 12:49:01', '2026-10-05 13:13:22', NULL, 0, NULL, 0, '2026-10-05 12:49:01');

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(60) DEFAULT NULL,
  `entity_type` varchar(60) DEFAULT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `ip_address`, `user_agent`, `old_value`, `new_value`, `meta`, `created_at`) VALUES
(1, 1, 'data.reset', 'workspace', 'workspace', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"rows_before\":{\"time\":52,\"schedule\":5,\"tasks\":10,\"projects\":19,\"clients\":3,\"logs\":231}}', '{\"rows_deleted\":{\"timer_idle_events\":0,\"timesheet_entries\":10,\"timesheets\":6,\"active_timers\":0,\"time_entries\":36,\"schedule_recurrences\":0,\"schedules\":5,\"task_assignees\":5,\"tasks\":5,\"project_favorites\":0,\"project_members\":15,\"projects\":4,\"clients\":3,\"notifications\":22,\"activity_logs\":209}}', '{\"groups\":[\"time\",\"schedule\",\"tasks\",\"projects\",\"clients\",\"logs\"]}', '2026-10-04 09:23:57'),
(2, 1, 'user.deleted', 'user', 'user', 6, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Ali Khan\",\"email\":\"ali@example.com\"}', NULL, NULL, '2026-10-04 09:24:43'),
(3, 1, 'user.deleted', 'user', 'user', 9, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Ayesha Noor\",\"email\":\"ayesha@example.com\"}', NULL, NULL, '2026-10-04 09:24:58'),
(4, 1, 'user.deleted', 'user', 'user', 12, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Bilal Ahmed\",\"email\":\"bilal@example.com\"}', NULL, NULL, '2026-10-04 09:25:01'),
(5, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:34:17'),
(6, 1, 'client.created', 'client', 'client', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"AFIC\"}', '2026-10-04 09:34:48'),
(7, 1, 'client.created', 'client', 'client', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Nova Care\"}', '2026-10-04 09:35:18'),
(8, 1, 'client.created', 'client', 'client', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Al Shifa Trust\"}', '2026-10-04 09:36:07'),
(9, 1, 'project.created', 'project', 'project', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Al Shifa Trust Eye Hospital\",\"code\":\"PRJ-0001\"}', NULL, '2026-10-04 09:40:47'),
(10, 1, 'project.created', 'project', 'project', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Citadel 7 Novacare Hospital\",\"code\":\"PRJ-0002\"}', NULL, '2026-10-04 09:41:37'),
(11, 1, 'project.created', 'project', 'project', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Expansion of AFIC\",\"code\":\"PRJ-0003\"}', NULL, '2026-10-04 09:42:20'),
(12, 1, 'task.created', 'task', 'task', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"name\":\"CON - Building Envelope\"}', '2026-10-04 09:42:46'),
(13, 1, 'task.created', 'task', 'task', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"name\":\"CON - Building Services (MEP)\"}', '2026-10-04 09:42:54'),
(14, 1, 'task.created', 'task', 'task', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"name\":\"CON - Commissioning Handover & Close-out\"}', '2026-10-04 09:43:03'),
(15, 1, 'task.created', 'task', 'task', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"name\":\"CON - Enabling & Substructure\"}', '2026-10-04 09:43:17'),
(16, 1, 'task.created', 'task', 'task', 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"name\":\"CON - Building Systems\"}', '2026-10-04 09:43:40'),
(17, 1, 'task.created', 'task', 'task', 6, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"name\":\"CON - Fitouts\"}', '2026-10-04 09:43:49'),
(18, 1, 'task.created', 'task', 'task', 7, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"name\":\"CON - Joinery\"}', '2026-10-04 09:43:57'),
(19, 1, 'task.created', 'task', 'task', 8, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"name\":\"Concept Design\"}', '2026-10-04 09:44:04'),
(20, 1, 'task.created', 'task', 'task', 9, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"name\":\"Detailed Design\"}', '2026-10-04 09:44:13'),
(21, 1, 'task.created', 'task', 'task', 10, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"name\":\"CON - Building Envelope\"}', '2026-10-04 09:44:37'),
(22, 1, 'task.created', 'task', 'task', 11, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"name\":\"CON - Building Services (MEP)\"}', '2026-10-04 09:44:44'),
(23, 1, 'task.created', 'task', 'task', 12, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"name\":\"CON - Commissioning Handover & Close-out\"}', '2026-10-04 09:44:52'),
(24, 1, 'task.created', 'task', 'task', 13, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"name\":\"CON - Enabling & Substructure\"}', '2026-10-04 09:44:58'),
(25, 1, 'timer.started', 'timer', 'timer', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-04 09:45:21'),
(26, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:45:28'),
(27, 3, 'auth.login', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:45:32'),
(28, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:45:35'),
(29, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:45:39'),
(30, 3, 'auth.login', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:45:44'),
(31, 4, 'auth.login', 'user', 'user', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:45:52'),
(32, 4, 'auth.logout', 'user', 'user', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:46:24'),
(33, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:46:29'),
(34, 3, 'auth.login', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:46:38'),
(35, 3, 'auth.logout', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:46:57'),
(36, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:47:02'),
(37, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:47:10'),
(38, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:47:45'),
(39, NULL, 'auth.login_failed', 'user', 'user', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"morganlee@timetrack.local\",\"reason\":\"bad_credentials\"}', '2026-10-04 09:47:56'),
(40, NULL, 'auth.login_failed', 'user', 'user', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"morgan@timetrack.local\",\"reason\":\"bad_credentials\"}', '2026-10-04 09:48:08'),
(41, 2, 'auth.login', 'user', 'user', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:48:23'),
(42, 2, 'auth.login', 'user', 'user', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:48:31'),
(43, 2, 'auth.logout', 'user', 'user', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:50:08'),
(44, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:50:24'),
(45, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:54:26'),
(46, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:54:32'),
(47, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:54:34'),
(48, 1, 'timer.stopped', 'time_entry', 'time_entry', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":558}', '2026-10-04 09:54:39'),
(49, 1, 'timer.started', 'timer', 'timer', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"task_id\":10}', '2026-10-04 09:55:11'),
(50, 1, 'timer.stopped', 'time_entry', 'time_entry', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"duration_seconds\":5}', '2026-10-04 09:55:16'),
(51, 1, 'timer.started', 'timer', 'timer', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"task_id\":11}', '2026-10-04 09:55:25'),
(52, 1, 'timer.stopped', 'time_entry', 'time_entry', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"duration_seconds\":25}', '2026-10-04 09:55:50'),
(53, 1, 'timer.started', 'timer', 'timer', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":6}', '2026-10-04 09:55:57'),
(54, 1, 'timer.stopped', 'time_entry', 'time_entry', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":14}', '2026-10-04 09:56:11'),
(55, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:57:57'),
(56, 3, 'auth.login', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 09:58:02'),
(57, 3, 'auth.logout', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:03:43'),
(58, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:03:48'),
(59, 1, 'project.visibility_changed', 'project', 'project', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"public\":1}', '2026-10-04 10:04:14'),
(60, 1, 'project.members_added', 'project', 'project', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-04 10:04:50'),
(61, 1, 'project.visibility_changed', 'project', 'project', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"public\":1}', '2026-10-04 10:05:08'),
(62, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:05:17'),
(63, 3, 'auth.login', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:05:22'),
(64, 3, 'timer.started', 'timer', 'timer', 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":6}', '2026-10-04 10:05:41'),
(65, 3, 'auth.logout', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:05:44'),
(66, 4, 'auth.login', 'user', 'user', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:05:50'),
(67, 4, 'auth.logout', 'user', 'user', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:17:59'),
(68, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-04 10:18:05'),
(69, 1, 'timer.started', 'timer', 'timer', 6, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":2}', '2026-10-04 10:22:05'),
(70, 1, 'timer.stopped', 'time_entry', 'time_entry', 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":5}', '2026-10-04 10:22:10'),
(71, 1, 'timer.started', 'timer', 'timer', 7, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-04 11:14:10'),
(72, 1, 'timer.stopped', 'time_entry', 'time_entry', 6, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":70}', '2026-10-04 11:15:20'),
(73, 1, 'project.visibility_changed', 'project', 'project', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"public\":0}', '2026-10-04 11:26:42'),
(74, 1, 'project.visibility_changed', 'project', 'project', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"public\":1}', '2026-10-04 11:26:43'),
(75, 1, 'project.visibility_changed', 'project', 'project', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"public\":0}', '2026-10-04 11:26:50'),
(76, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 02:59:12'),
(77, 1, 'timer.started', 'timer', 'timer', 8, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-05 04:18:26'),
(78, 1, 'timer.stopped', 'time_entry', 'time_entry', 8, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":4}', '2026-10-05 04:18:30'),
(79, 1, 'timer.started', 'timer', 'timer', 9, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":3}', '2026-10-05 04:19:27'),
(80, 1, 'timer.paused', 'timer', 'timer', 9, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:19:36'),
(81, 1, 'timer.resumed', 'timer', 'timer', 9, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:19:38'),
(82, 1, 'timer.stopped', 'time_entry', 'time_entry', 9, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":75}', '2026-10-05 04:20:42'),
(83, 1, 'user.created', 'user', 'user', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Rummish Saleem\",\"email\":\"rummishsaleem@mavenprojects.com\",\"role\":\"employee\",\"status\":\"active\"}', NULL, '2026-10-05 04:23:11'),
(84, 16, 'auth.login', 'user', 'user', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:24:10'),
(85, 16, 'auth.password_changed', 'user', 'user', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:24:49'),
(86, 1, 'project.members_added', 'project', 'project', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-05 04:26:01'),
(87, 16, 'timer.started', 'timer', 'timer', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":2}', '2026-10-05 04:26:15'),
(88, 1, 'project.members_added', 'project', 'project', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-05 04:26:15'),
(89, 16, 'time_entry.created', 'time_entry', 'time_entry', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":3780}', '2026-10-05 04:27:02'),
(90, 16, 'timer.paused', 'timer', 'timer', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:27:15'),
(91, 16, 'timer.resumed', 'timer', 'timer', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:27:16'),
(92, 1, 'timer.started', 'timer', 'timer', 11, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":5}', '2026-10-05 04:34:21'),
(93, 1, 'timer.stopped', 'time_entry', 'time_entry', 11, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":319}', '2026-10-05 04:39:40'),
(94, 16, 'timer.paused', 'timer', 'timer', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:41:21'),
(95, 16, 'timer.resumed', 'timer', 'timer', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:41:22'),
(96, 16, 'timer.paused', 'timer', 'timer', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 04:41:22'),
(97, 1, 'schedule.created', 'schedule', 'schedule', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":16,\"project_id\":1,\"overridden\":false}', '2026-10-05 04:46:22'),
(98, 16, 'auth.login', 'user', 'user', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:11:59'),
(99, 16, 'timer.resumed', 'timer', 'timer', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:12:15'),
(100, 16, 'timer.stopped', 'time_entry', 'time_entry', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":963}', '2026-10-05 06:12:18'),
(101, 1, 'timer.started', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-05 06:13:21'),
(102, 1, 'timer.paused', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:13:26'),
(103, 16, 'timer.started', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-05 06:16:47'),
(104, 16, 'timer.paused', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:18:00'),
(105, 16, 'timer.resumed', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:18:13'),
(106, 1, 'timer.resumed', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:21:14'),
(107, 1, 'timer.paused', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:21:19'),
(108, 16, 'timer.paused', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:21:26'),
(109, 16, 'timer.resumed', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:21:29'),
(110, 16, 'timer.paused', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:21:35'),
(111, 16, 'timer.resumed', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:21:37'),
(112, 1, 'timer.resumed', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:21:51'),
(113, 1, 'timer.paused', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:07'),
(114, 1, 'timer.resumed', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:09'),
(115, 1, 'timer.paused', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:11'),
(116, 1, 'timer.resumed', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:13'),
(117, 1, 'timer.paused', 'timer', 'timer', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:15'),
(118, 16, 'timer.paused', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:24'),
(119, 16, 'timer.resumed', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:33'),
(120, 16, 'timer.paused', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:40'),
(121, 16, 'timer.resumed', 'timer', 'timer', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 06:22:51'),
(122, 1, 'timer.stopped', 'time_entry', 'time_entry', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":72}', '2026-10-05 08:21:33'),
(123, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 08:36:02'),
(124, 1, 'settings.smtp_updated', 'settings', 'settings', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"host\":\"smtp.hostinger.com\",\"port\":465,\"encryption\":\"tls\",\"enabled\":\"1\",\"password_changed\":\"1\"}', NULL, '2026-10-05 08:39:02'),
(125, 1, 'settings.smtp_updated', 'settings', 'settings', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"host\":\"smtp.hostinger.com\",\"port\":465,\"encryption\":\"ssl\",\"enabled\":\"1\",\"password_changed\":\"1\"}', NULL, '2026-10-05 08:46:09'),
(126, 1, 'mail.test_sent', 'mail', 'mail', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"ok\":\"1\"}', NULL, '2026-10-05 08:46:27'),
(127, 1, 'user.updated', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"role\":\"admin\",\"status\":\"active\"}', '{\"role\":\"admin\",\"status\":\"active\",\"name\":\"System Admin\"}', NULL, '2026-10-05 08:49:27'),
(128, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 08:49:49'),
(129, NULL, 'auth.password_reset_requested', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email_domain\":\"gmail.com\"}', '2026-10-05 08:50:08'),
(130, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:06:38'),
(131, 1, 'mail.test_sent', 'mail', 'mail', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"ok\":\"1\",\"to_domain\":\"gmail.com\"}', NULL, '2026-10-05 09:07:13'),
(132, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:08:22'),
(133, NULL, 'auth.password_reset_requested', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email_domain\":\"gmail.com\"}', '2026-10-05 09:08:29'),
(134, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:09:38'),
(135, 1, 'invitation.created', 'invite', 'invite', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\",\"role\":\"employee\",\"projects\":2,\"tasks\":0}', NULL, '2026-10-05 09:10:38'),
(136, 1, 'invitation.sent', 'invite', 'invite', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\"}', NULL, '2026-10-05 09:10:41'),
(137, 1, 'invitation.resent', 'invite', 'invite', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"status\":\"sent\"}', '{\"status\":\"pending\"}', NULL, '2026-10-05 09:28:43'),
(138, 1, 'invitation.sent', 'invite', 'invite', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\"}', NULL, '2026-10-05 09:28:46'),
(139, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:29:23'),
(140, NULL, 'project.member_assigned', 'project', 'project', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"user_id\":17}', NULL, '2026-10-05 09:30:07'),
(141, NULL, 'project.member_assigned', 'project', 'project', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"user_id\":17}', NULL, '2026-10-05 09:30:07'),
(142, NULL, 'invitation.accepted', 'invite', 'invite', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"status\":\"sent\"}', '{\"status\":\"accepted\",\"user_id\":17}', NULL, '2026-10-05 09:30:07'),
(143, NULL, 'user.created', 'user', 'user', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Mubashir Hassan\",\"email\":\"mubashirbaltistani@gmail.com\",\"role\":\"employee\",\"via\":\"invitation\"}', NULL, '2026-10-05 09:30:07'),
(144, 17, 'auth.login', 'user', 'user', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:30:45'),
(145, 17, 'auth.logout', 'user', 'user', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:31:53'),
(146, 4, 'auth.login', 'user', 'user', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:32:02'),
(147, 4, 'auth.logout', 'user', 'user', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:32:04'),
(148, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:32:19'),
(149, 1, 'invitation.created', 'invite', 'invite', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"mavenprojects.com\",\"role\":\"admin\",\"projects\":3,\"tasks\":13}', NULL, '2026-10-05 09:42:30'),
(150, 1, 'invitation.sent', 'invite', 'invite', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"mavenprojects.com\"}', NULL, '2026-10-05 09:42:32'),
(151, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:51:39'),
(152, 17, 'auth.login', 'user', 'user', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:51:48'),
(153, 17, 'timer.started', 'timer', 'timer', 14, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":2}', '2026-10-05 09:52:02'),
(154, 17, 'timer.stopped', 'time_entry', 'time_entry', 14, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":69}', '2026-10-05 09:53:11'),
(155, 17, 'timer.started', 'timer', 'timer', 15, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":6}', '2026-10-05 09:53:19'),
(156, 17, 'timer.stopped', 'time_entry', 'time_entry', 15, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":7}', '2026-10-05 09:53:26'),
(157, 17, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":2,\"total_seconds\":76}', '2026-10-05 09:53:34'),
(158, 17, 'auth.logout', 'user', 'user', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:58:46'),
(159, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 09:58:52'),
(160, 1, 'settings.branding_updated', 'settings', 'settings', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"brand_color\":\"\",\"brand_logo\":\"\"}', '{\"brand_color\":\"\",\"brand_logo\":\"logo-7487ffbf0acd801f.png\"}', NULL, '2026-10-05 10:00:05'),
(161, 1, 'settings.updated', 'settings', 'settings', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"app_name\":\"TimeTrack\",\"company_email\":\"hello@timetrack.local\",\"date_format\":\"M j, Y\",\"time_format\":\"H:i\",\"currency\":\"USD\",\"currency_symbol\":\"$\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"timer_max_hours\":\"12\",\"timer_reminder_minutes\":\"10\",\"allow_manual_time_entries\":\"1\",\"notifications_enabled\":\"1\",\"maintenance_mode\":\"0\",\"brand_color\":\"\",\"brand_logo\":\"logo-7487ffbf0acd801f.png\",\"login_headline\":\"See where every hour goes.\",\"login_subtext\":\"Track time against projects, keep budgets honest, and hand clients numbers they can trust.\"}', '{\"app_name\":\"TimeTrack\",\"company_email\":\"hello@timetrack.local\",\"date_format\":\"M j, Y\",\"time_format\":\"H:i\",\"currency_symbol\":\"-\",\"currency\":\"USD\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"timer_max_hours\":\"12\",\"timer_reminder_minutes\":\"10\",\"allow_manual_time_entries\":\"1\",\"notifications_enabled\":\"1\",\"maintenance_mode\":\"0\"}', NULL, '2026-10-05 10:01:17'),
(162, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 10:14:00'),
(163, 17, 'auth.login', 'user', 'user', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 10:14:07'),
(164, 17, 'timer.started', 'timer', 'timer', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":3}', '2026-10-05 10:16:23'),
(165, 17, 'timer.stopped', 'time_entry', 'time_entry', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":6}', '2026-10-05 10:16:29'),
(166, 17, 'timer.started', 'timer', 'timer', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":7}', '2026-10-05 10:17:17'),
(167, 17, 'timer.stopped', 'time_entry', 'time_entry', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":14}', '2026-10-05 10:17:31'),
(168, 17, 'timer.started', 'timer', 'timer', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":8}', '2026-10-05 10:28:37'),
(169, 17, 'timer.stopped', 'time_entry', 'time_entry', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":18}', '2026-10-05 10:28:55'),
(170, 17, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":3,\"total_seconds\":82}', '2026-10-05 10:29:09'),
(171, 17, 'timer.started', 'timer', 'timer', 19, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":3}', '2026-10-05 10:29:18'),
(172, 17, 'timer.stopped', 'time_entry', 'time_entry', 19, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":167}', '2026-10-05 10:32:05'),
(173, 17, 'auth.logout', 'user', 'user', 17, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 10:32:07'),
(174, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 10:32:17'),
(175, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 10:55:24'),
(176, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 11:03:00'),
(177, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 11:28:03'),
(178, 2, 'auth.login', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 11:28:11'),
(179, 2, 'auth.logout', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 11:28:21'),
(180, 2, 'auth.login', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 11:50:22'),
(181, 2, 'auth.logout', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 11:50:28'),
(182, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 11:50:34'),
(183, 1, 'team.created', 'team', 'team', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Design Services\",\"project_id\":1,\"manager_id\":10,\"lead_id\":11,\"members\":5}', '2026-10-05 12:00:26'),
(184, 1, 'team.updated', 'team', 'team', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Design Services\",\"project_id\":1,\"manager_id\":10,\"lead_id\":11,\"members\":5}', '2026-10-05 12:00:47'),
(185, 1, 'team.created', 'team', 'team', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"MEP\",\"project_id\":1,\"manager_id\":1,\"lead_id\":16,\"members\":7}', '2026-10-05 12:01:57'),
(186, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:03:04'),
(187, 2, 'auth.login', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:03:10'),
(188, NULL, 'auth.login_failed', 'user', 'user', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"rummishsaleem@mavenprojects.com\",\"reason\":\"bad_credentials\"}', '2026-10-05 12:03:16'),
(189, 16, 'auth.login', 'user', 'user', 16, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:03:44'),
(190, 16, 'timer.stopped_trimmed', 'time_entry', 'time_entry', 20, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":11233}', '2026-10-05 12:04:00'),
(191, 16, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":1,\"total_seconds\":11233}', '2026-10-05 12:05:13'),
(192, 2, 'auth.logout', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:05:27'),
(193, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:05:41'),
(194, 16, 'timer.started', 'timer', 'timer', 20, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":3}', '2026-10-05 12:35:16'),
(195, 16, 'timer.stopped', 'time_entry', 'time_entry', 21, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":5}', '2026-10-05 12:35:21'),
(196, 1, 'timer.started', 'timer', 'timer', 21, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":2}', '2026-10-05 12:36:43'),
(197, 1, 'timer.stopped', 'time_entry', 'time_entry', 22, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":4}', '2026-10-05 12:36:47'),
(198, 1, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 6, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":1,\"total_seconds\":4}', '2026-10-05 12:36:54');
INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `ip_address`, `user_agent`, `old_value`, `new_value`, `meta`, `created_at`) VALUES
(199, 16, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 8, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":1,\"total_seconds\":5}', '2026-10-05 12:44:02'),
(200, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:44:13'),
(201, 2, 'auth.login', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:44:17'),
(202, 16, 'timesheet.rejected', 'timesheet', 'timesheet', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":17,\"start_date\":\"2026-10-05\",\"reason\":\"Do it Again\"}', '2026-10-05 12:44:21'),
(203, 2, 'auth.logout', 'user', 'user', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:44:28'),
(204, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 12:44:35'),
(205, 16, 'timer.started', 'timer', 'timer', 22, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":1}', '2026-10-05 12:49:01'),
(206, 1, 'timer.started', 'timer', 'timer', 23, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":6}', '2026-10-05 13:24:57'),
(207, 1, 'timer.paused', 'timer', 'timer', 23, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 13:26:35'),
(208, 1, 'timer.resumed', 'timer', 'timer', 23, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 13:26:39'),
(209, 1, 'timer.paused', 'timer', 'timer', 23, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 13:26:44'),
(210, 1, 'timer.resumed', 'timer', 'timer', 23, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 13:26:46'),
(211, 1, 'timer.stopped', 'time_entry', 'time_entry', 23, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":117}', '2026-10-05 13:26:54'),
(212, 1, 'timer.started', 'timer', 'timer', 24, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"task_id\":2}', '2026-10-05 13:31:07'),
(213, 1, 'timer.paused', 'timer', 'timer', 24, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 13:31:48'),
(214, 1, 'timer.resumed', 'timer', 'timer', 24, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 13:31:51'),
(215, 1, 'timer.stopped', 'time_entry', 'time_entry', 24, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":1,\"duration_seconds\":89}', '2026-10-05 13:32:36'),
(216, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 17:45:25'),
(217, 1, 'timer.started', 'timer', 'timer', 25, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"task_id\":13}', '2026-10-05 17:46:06'),
(218, 1, 'project.created', 'project', 'project', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Support Services Hub Novacare Hospital\",\"code\":\"PRJ-0004\"}', NULL, '2026-10-05 17:48:09'),
(219, 1, 'task.created', 'task', 'task', 14, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"name\":\"TP - MEP + HVAC\"}', '2026-10-05 17:48:34'),
(220, 1, 'task.created', 'task', 'task', 15, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"name\":\"TP - Finishes & Fit-outs\"}', '2026-10-05 17:48:42'),
(221, 1, 'task.created', 'task', 'task', 16, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"name\":\"TP - Facade\"}', '2026-10-05 17:48:50'),
(222, 1, 'task.created', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"name\":\"TP - External Development & Landscapping\"}', '2026-10-05 17:48:57'),
(223, 1, 'user.updated', 'user', 'user', 10, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"role\":\"manager\",\"status\":\"active\"}', '{\"role\":\"manager\",\"status\":\"active\",\"name\":\"Hamza Raza\"}', NULL, '2026-10-05 17:49:53'),
(224, 1, 'timer.stopped', 'time_entry', 'time_entry', 25, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":3,\"duration_seconds\":236}', '2026-10-05 17:50:02'),
(225, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":1}', '2026-10-05 17:56:29'),
(226, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":17,\"project_id\":4}', NULL, '2026-10-05 17:56:29'),
(227, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":2}', '2026-10-05 17:56:37'),
(228, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:56:37'),
(229, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":17,\"project_id\":4}', NULL, '2026-10-05 17:56:37'),
(230, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":3}', '2026-10-05 17:56:44'),
(231, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:56:44'),
(232, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":17,\"project_id\":4}', NULL, '2026-10-05 17:56:44'),
(233, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":2}', '2026-10-05 17:56:45'),
(234, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:56:45'),
(235, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":3}', '2026-10-05 17:56:55'),
(236, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:56:55'),
(237, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:56:55'),
(238, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":2}', '2026-10-05 17:56:57'),
(239, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:56:57'),
(240, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":3}', '2026-10-05 17:57:00'),
(241, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:57:00'),
(242, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:57:00'),
(243, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":4}', '2026-10-05 17:57:03'),
(244, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":11,\"project_id\":4}', NULL, '2026-10-05 17:57:03'),
(245, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:57:03'),
(246, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:57:03'),
(247, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":5}', '2026-10-05 17:57:04'),
(248, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":14,\"project_id\":4}', NULL, '2026-10-05 17:57:04'),
(249, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":11,\"project_id\":4}', NULL, '2026-10-05 17:57:04'),
(250, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:57:04'),
(251, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:57:04'),
(252, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":6}', '2026-10-05 17:57:06'),
(253, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":10,\"project_id\":4}', NULL, '2026-10-05 17:57:06'),
(254, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":14,\"project_id\":4}', NULL, '2026-10-05 17:57:06'),
(255, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":11,\"project_id\":4}', NULL, '2026-10-05 17:57:06'),
(256, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:57:06'),
(257, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:57:06'),
(258, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":5}', '2026-10-05 17:57:07'),
(259, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":14,\"project_id\":4}', NULL, '2026-10-05 17:57:07'),
(260, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":11,\"project_id\":4}', NULL, '2026-10-05 17:57:07'),
(261, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:57:07'),
(262, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:57:07'),
(263, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":4}', '2026-10-05 17:57:07'),
(264, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":11,\"project_id\":4}', NULL, '2026-10-05 17:57:07'),
(265, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:57:07'),
(266, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:57:07'),
(267, 1, 'task.updated', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"TP - External Development & Landscapping\",\"assignees\":3}', '2026-10-05 17:57:08'),
(268, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":13,\"project_id\":4}', NULL, '2026-10-05 17:57:08'),
(269, 1, 'task.assigned', 'task', 'task', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"task\":\"TP - External Development & Landscapping\",\"assignee\":3,\"project_id\":4}', NULL, '2026-10-05 17:57:08'),
(270, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 17:57:30'),
(271, 17, 'auth.login', 'user', 'user', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-05 17:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `agent_pair_attempts`
--

CREATE TABLE `agent_pair_attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(45) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `audit_logs`
-- (See below for the actual view)
--
CREATE TABLE `audit_logs` (
`id` bigint(20) unsigned
,`user_id` int(10) unsigned
,`action` varchar(100)
,`module` varchar(60)
,`entity_type` varchar(60)
,`entity_id` int(10) unsigned
,`ip_address` varchar(45)
,`user_agent` varchar(255)
,`meta` longtext
,`old_value` longtext
,`new_value` longtext
,`created_at` datetime
);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `email`, `phone`, `address`, `status`, `created_at`, `updated_at`) VALUES
(1, 'AFIC', 'test1@gmail.com', '3115121515', 'RWP', 'active', '2026-10-04 09:34:48', '2026-10-04 09:34:48'),
(2, 'Nova Care', 'test2@gmail.com', '055121542', 'ISB', 'active', '2026-10-04 09:35:18', '2026-10-04 09:35:18'),
(3, 'Al Shifa Trust', 'test3@gmail.com', '15215215', 'RWP', 'active', '2026-10-04 09:36:07', '2026-10-04 09:36:07');

-- --------------------------------------------------------

--
-- Table structure for table `client_users`
--

CREATE TABLE `client_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `desktop_agent_devices`
--

CREATE TABLE `desktop_agent_devices` (
  `id` int(10) UNSIGNED NOT NULL,
  `workspace_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `device_id` varchar(120) NOT NULL,
  `device_name` varchar(160) NOT NULL DEFAULT 'Windows PC',
  `token_hash` char(64) NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `agent_version` varchar(40) NOT NULL DEFAULT 'unknown',
  `status` enum('active','revoked') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `desktop_agent_devices`
--

INSERT INTO `desktop_agent_devices` (`id`, `workspace_id`, `user_id`, `device_id`, `device_name`, `token_hash`, `last_seen_at`, `last_activity_at`, `is_locked`, `agent_version`, `status`, `created_at`, `updated_at`) VALUES
(4, 1, 1, 'fe8a171fac224769a03ba906d024d00b', 'MUBASHIR', '61ecfc0127f6292032694717ff0689a233fddc19d407a23bd21d2c78d7d8c9af', '2026-10-05 11:48:59', '2026-10-05 11:48:58', 0, '1.0.0', 'active', '2026-10-05 04:31:58', '2026-10-05 11:48:59');

-- --------------------------------------------------------

--
-- Table structure for table `desktop_agent_pairing_codes`
--

CREATE TABLE `desktop_agent_pairing_codes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `workspace_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `desktop_agent_pairing_codes`
--

INSERT INTO `desktop_agent_pairing_codes` (`id`, `workspace_id`, `user_id`, `code_hash`, `expires_at`, `used_at`, `attempts`, `created_at`) VALUES
(4, 1, 1, '476c07697633043a9ed3ed5a506c5cea2e65a864a68672003a69ee5bea68ba08', '2026-10-03 13:06:23', '2026-10-03 12:56:30', 0, '2026-10-03 12:56:23'),
(5, 1, 1, '7f5fe5dd48b6117a8d564107d1dbc36f847095fdf4c3d7e7ae343b43eda768a2', '2026-10-03 13:46:40', '2026-10-03 13:36:54', 0, '2026-10-03 13:36:40'),
(6, 1, 1, '77de3d4a247897c62919cd84b1182814da5cac847b95e51e1f66faf358ee54f7', '2026-10-03 15:20:28', '2026-10-03 15:10:41', 0, '2026-10-03 15:10:28'),
(7, 1, 1, '10d1b0613b1988751bb2064729809e517e8146224d8dd3e5979f1f480df21b7a', '2026-10-05 04:41:44', '2026-10-05 04:31:58', 0, '2026-10-05 04:31:44');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT 'info',
  `title` varchar(160) NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `message`, `link`, `is_read`, `read_at`, `created_at`) VALUES
(1, 3, 'warning', 'Timer stopped automatically', 'Your timer ran for the maximum of 12 hours and was stopped. Please review the time entry.', '/time', 0, NULL, '2026-10-04 22:06:01'),
(2, 16, 'info', 'Welcome to TimeTrack', 'Your account is ready. Change the temporary password from your profile.', '/profile', 0, NULL, '2026-10-05 04:23:11'),
(3, 16, 'info', 'Schedule changed', 'Your planned work for Al Shifa Trust Eye Hospital moved to Oct 5, 11:32.', '/schedule/my', 1, '2026-10-05 06:16:43', '2026-10-05 04:46:22'),
(4, 16, 'info', 'Upcoming scheduled work', 'You have planned work on Al Shifa Trust Eye Hospital starting at Oct 5, 06:32.', '/schedule/my#block-1', 1, '2026-10-05 12:48:59', '2026-10-05 06:16:44'),
(5, 1, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/1', 0, NULL, '2026-10-05 09:53:34'),
(6, 2, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/1', 0, NULL, '2026-10-05 09:53:34'),
(7, 7, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/1', 0, NULL, '2026-10-05 09:53:34'),
(8, 10, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/1', 0, NULL, '2026-10-05 09:53:34'),
(9, 15, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/1', 0, NULL, '2026-10-05 09:53:34'),
(10, 1, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/2', 0, NULL, '2026-10-05 10:29:09'),
(11, 2, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/2', 0, NULL, '2026-10-05 10:29:09'),
(12, 7, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/2', 0, NULL, '2026-10-05 10:29:09'),
(13, 10, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/2', 0, NULL, '2026-10-05 10:29:09'),
(14, 15, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/2', 0, NULL, '2026-10-05 10:29:09'),
(15, 1, 'info', 'Work submitted for approval', 'Rummish Saleem submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/3', 0, NULL, '2026-10-05 12:05:13'),
(16, 10, 'info', 'Work submitted for approval', 'Rummish Saleem submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/3', 0, NULL, '2026-10-05 12:05:13'),
(17, 11, 'info', 'Work submitted for approval', 'Rummish Saleem submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/3', 0, NULL, '2026-10-05 12:05:13'),
(18, 2, 'info', 'Work submitted for approval', 'Rummish Saleem submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/3', 0, NULL, '2026-10-05 12:05:13'),
(19, 1, 'info', 'Work submitted for approval', 'Rummish Saleem submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/8', 0, NULL, '2026-10-05 12:44:02'),
(20, 10, 'info', 'Work submitted for approval', 'Rummish Saleem submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/8', 0, NULL, '2026-10-05 12:44:02'),
(21, 11, 'info', 'Work submitted for approval', 'Rummish Saleem submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/8', 0, NULL, '2026-10-05 12:44:02'),
(22, 17, 'warning', 'Timesheet needs changes', 'Your timesheet for Oct 5 – Oct 11, 2026 was rejected. Do it Again', '/timesheets/1', 0, NULL, '2026-10-05 12:44:21'),
(23, 17, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:29'),
(24, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:37'),
(25, 17, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:37'),
(26, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:44'),
(27, 17, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:44'),
(28, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:45'),
(29, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:55'),
(30, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:55'),
(31, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:56:57'),
(32, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:00'),
(33, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:00'),
(34, 11, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:03'),
(35, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:03'),
(36, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:03'),
(37, 14, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:04'),
(38, 11, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:04'),
(39, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:04'),
(40, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:04'),
(41, 10, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:06'),
(42, 14, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:06'),
(43, 11, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:06'),
(44, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:06'),
(45, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:06'),
(46, 14, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:07'),
(47, 11, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:07'),
(48, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:07'),
(49, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:07'),
(50, 11, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:07'),
(51, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:07'),
(52, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:07'),
(53, 13, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:08'),
(54, 3, 'info', 'New task assigned', 'You were assigned \"TP - External Development & Landscapping\" on Support Services Hub Novacare Hospital.', '/projects/4?tab=tasks', 0, NULL, '2026-10-05 17:57:08');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_reset_tokens`
--

INSERT INTO `password_reset_tokens` (`id`, `user_id`, `token_hash`, `expires_at`, `used_at`, `created_at`) VALUES
(1, 1, 'a054715bf78bd558190a667f4385edc7797f2f194b4b1127937e6aec3bf45a4f', '2026-10-05 10:50:08', '2026-10-05 09:08:29', '2026-10-05 08:50:08'),
(2, 1, 'd68e333411bf09271f0ad5c1e5c63ffd9d3a6be3290477104484f31bfd5f84a7', '2026-10-05 11:08:29', NULL, '2026-10-05 09:08:29');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `module` varchar(40) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`) VALUES
(1, 'dashboard.view', 'View dashboard', 'dashboard', 'Open the dashboard.', '2026-10-01 08:55:54'),
(2, 'notifications.view', 'View notifications', 'notifications', 'See own notifications.', '2026-10-01 08:55:54'),
(3, 'users.view', 'View users', 'users', 'See the user directory.', '2026-10-01 08:55:54'),
(4, 'users.create', 'Create users', 'users', 'Add new users.', '2026-10-01 08:55:54'),
(5, 'users.edit', 'Edit users', 'users', 'Change user details, roles and status.', '2026-10-01 08:55:54'),
(6, 'users.delete', 'Delete users', 'users', 'Remove users.', '2026-10-01 08:55:54'),
(7, 'roles.manage', 'Manage roles', 'users', 'Edit roles and their permissions.', '2026-10-01 08:55:54'),
(8, 'clients.view', 'View clients', 'clients', 'See the client list.', '2026-10-01 08:55:54'),
(9, 'clients.create', 'Create clients', 'clients', 'Add new clients.', '2026-10-01 08:55:54'),
(10, 'clients.edit', 'Edit clients', 'clients', 'Change client details.', '2026-10-01 08:55:54'),
(11, 'clients.delete', 'Delete clients', 'clients', 'Remove clients.', '2026-10-01 08:55:54'),
(12, 'projects.view', 'View projects', 'projects', 'See projects the user is assigned to.', '2026-10-01 08:55:54'),
(13, 'projects.view_all', 'View all projects', 'projects', 'See every project, assigned or not.', '2026-10-01 08:55:54'),
(14, 'projects.create', 'Create projects', 'projects', 'Add new projects.', '2026-10-01 08:55:54'),
(15, 'projects.edit', 'Edit projects', 'projects', 'Change project details.', '2026-10-01 08:55:54'),
(16, 'projects.delete', 'Delete projects', 'projects', 'Remove projects.', '2026-10-01 08:55:54'),
(17, 'projects.archive', 'Archive projects', 'projects', 'Archive and restore projects.', '2026-10-01 08:55:54'),
(18, 'projects.manage_members', 'Manage project members', 'projects', 'Assign and remove project members.', '2026-10-01 08:55:54'),
(19, 'tasks.view', 'View tasks', 'tasks', 'See tasks on assigned projects.', '2026-10-01 08:55:54'),
(20, 'tasks.create', 'Create tasks', 'tasks', 'Add tasks to projects.', '2026-10-01 08:55:54'),
(21, 'tasks.edit', 'Edit tasks', 'tasks', 'Change tasks.', '2026-10-01 08:55:54'),
(22, 'tasks.delete', 'Delete tasks', 'tasks', 'Remove tasks.', '2026-10-01 08:55:54'),
(23, 'tasks.assign', 'Assign tasks', 'tasks', 'Assign tasks to people.', '2026-10-01 08:55:54'),
(24, 'time.track', 'Track time', 'time', 'Start and stop timers.', '2026-10-01 08:55:54'),
(25, 'time.view_own', 'View own time', 'time', 'See own time entries.', '2026-10-01 08:55:54'),
(26, 'time.view_all', 'View all time', 'time', 'See everyone\'s time entries.', '2026-10-01 08:55:54'),
(27, 'time.edit_own', 'Edit own time', 'time', 'Add and edit own time entries.', '2026-10-01 08:55:54'),
(28, 'time.edit_all', 'Edit all time', 'time', 'Edit anyone\'s time entries.', '2026-10-01 08:55:54'),
(29, 'time.approve', 'Approve timesheets', 'time', 'Approve or reject submitted timesheets.', '2026-10-01 08:55:54'),
(33, 'activity.view', 'View activity log', 'system', 'Read the audit trail.', '2026-10-01 08:55:54'),
(34, 'settings.manage', 'Manage settings', 'system', 'Change system settings.', '2026-10-01 08:55:54'),
(35, 'schedule.view', 'View schedule', 'schedule', 'See planned work on assigned projects.', '2026-10-01 10:28:52'),
(36, 'schedule.create', 'Create schedule', 'schedule', 'Add planned work blocks.', '2026-10-01 10:28:52'),
(37, 'schedule.edit', 'Edit schedule', 'schedule', 'Change planned work blocks.', '2026-10-01 10:28:52'),
(38, 'schedule.delete', 'Delete schedule', 'schedule', 'Remove planned work blocks.', '2026-10-01 10:28:52'),
(39, 'schedule.view_team', 'View team schedule', 'schedule', 'See planned work for the whole team.', '2026-10-01 10:28:52'),
(57, 'workspace.manage', 'Manage workspace', 'workspace', 'Change workspace identity, policies and workspace permissions.', '2026-10-02 08:51:16'),
(61, 'imports.manage', 'Import data', 'imports', 'Import CSV data into users, clients, projects, tasks, time and schedules.', '2026-10-03 11:06:04'),
(62, 'reports.view', 'View reports', 'reports', 'Open reports.', '2026-10-04 05:03:32'),
(63, 'reports.export', 'Export reports', 'reports', 'Download reports as CSV.', '2026-10-04 05:03:32'),
(64, 'reports.billing', 'View billing figures', 'reports', 'See rates and billable amounts.', '2026-10-04 05:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `project_code` varchar(50) NOT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('Planning','Active','On Hold','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Planning',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `budget` decimal(14,2) NOT NULL DEFAULT 0.00,
  `hourly_rate` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#03A9F4',
  `estimate_type` enum('none','time','budget') NOT NULL DEFAULT 'none',
  `manager_id` int(10) UNSIGNED DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `client_id`, `project_code`, `name`, `description`, `start_date`, `due_date`, `status`, `priority`, `estimated_hours`, `budget`, `hourly_rate`, `is_billable`, `is_public`, `color`, `estimate_type`, `manager_id`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 3, 'PRJ-0001', 'Al Shifa Trust Eye Hospital', NULL, NULL, NULL, 'Active', 'Medium', 154.00, 0.00, 0.00, 0, 0, '#03A9F4', 'none', 10, 1, '2026-10-04 09:40:47', '2026-10-04 09:40:47'),
(2, 2, 'PRJ-0002', 'Citadel 7 Novacare Hospital', NULL, NULL, NULL, 'Active', 'High', 0.00, 0.00, 0.00, 1, 0, '#03A9F4', 'none', 2, 1, '2026-10-04 09:41:37', '2026-10-04 11:26:50'),
(3, 1, 'PRJ-0003', 'Expansion of AFIC', NULL, NULL, NULL, 'Active', 'Medium', 120.00, 0.00, 0.00, 0, 1, '#03A9F4', 'none', 1, 1, '2026-10-04 09:42:20', '2026-10-04 10:05:08'),
(4, 2, 'PRJ-0004', 'Support Services Hub Novacare Hospital', NULL, NULL, NULL, 'Active', 'Urgent', 0.00, 0.00, 0.00, 0, 0, '#03A9F4', 'none', 10, 1, '2026-10-05 17:48:09', '2026-10-05 17:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `project_favorites`
--

CREATE TABLE `project_favorites` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_members`
--

CREATE TABLE `project_members` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_role` varchar(60) NOT NULL DEFAULT 'member',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_members`
--

INSERT INTO `project_members` (`id`, `project_id`, `user_id`, `project_role`, `created_at`) VALUES
(1, 1, 14, 'member', '2026-10-04 09:40:47'),
(2, 1, 11, 'member', '2026-10-04 09:40:47'),
(3, 1, 3, 'member', '2026-10-04 09:40:47'),
(4, 1, 15, 'manager', '2026-10-04 09:40:47'),
(5, 1, 2, 'member', '2026-10-04 09:40:47'),
(6, 1, 7, 'member', '2026-10-04 09:40:47'),
(7, 1, 4, 'member', '2026-10-04 09:40:47'),
(8, 1, 1, 'member', '2026-10-04 09:40:47'),
(9, 1, 8, 'member', '2026-10-04 09:40:47'),
(10, 1, 10, 'manager', '2026-10-04 09:40:47'),
(11, 2, 2, 'manager', '2026-10-04 09:41:37'),
(12, 2, 1, 'member', '2026-10-04 09:41:37'),
(13, 3, 1, 'manager', '2026-10-04 09:42:20'),
(14, 2, 3, 'manager', '2026-10-04 10:04:50'),
(15, 1, 16, 'member', '2026-10-05 04:26:01'),
(16, 2, 16, 'member', '2026-10-05 04:26:15'),
(17, 1, 17, 'member', '2026-10-05 09:30:07'),
(18, 2, 17, 'member', '2026-10-05 09:30:07'),
(19, 4, 14, 'member', '2026-10-05 17:48:09'),
(20, 4, 11, 'member', '2026-10-05 17:48:09'),
(21, 4, 10, 'manager', '2026-10-05 17:48:09'),
(22, 4, 13, 'member', '2026-10-05 17:48:09'),
(23, 4, 3, 'member', '2026-10-05 17:48:09'),
(24, 4, 17, 'member', '2026-10-05 17:48:09'),
(25, 4, 1, 'member', '2026-10-05 17:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `report_access`
--

CREATE TABLE `report_access` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `access_level` enum('own','all') NOT NULL DEFAULT 'own',
  `can_export` tinyint(1) NOT NULL DEFAULT 0,
  `can_billing` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `report_access`
--

INSERT INTO `report_access` (`user_id`, `access_level`, `can_export`, `can_billing`, `updated_by`, `updated_at`) VALUES
(2, 'all', 1, 1, NULL, '2026-10-04 10:44:48'),
(3, 'own', 0, 0, NULL, '2026-10-04 10:44:48'),
(4, 'own', 0, 0, NULL, '2026-10-04 10:44:48'),
(7, 'all', 1, 1, NULL, '2026-10-04 10:44:48'),
(8, 'own', 0, 0, NULL, '2026-10-04 10:44:48'),
(10, 'all', 1, 1, NULL, '2026-10-04 10:44:48'),
(11, 'own', 0, 0, NULL, '2026-10-04 10:44:48'),
(13, 'own', 0, 0, NULL, '2026-10-04 10:44:48'),
(14, 'own', 0, 0, NULL, '2026-10-04 10:44:48'),
(15, 'all', 1, 1, NULL, '2026-10-04 10:44:48'),
(16, 'own', 0, 0, NULL, '2026-10-05 08:21:15'),
(17, 'own', 0, 0, NULL, '2026-10-05 11:51:09');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `display_name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', 'Full access to every module and setting.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(2, 'manager', 'Manager', 'Manages clients, projects, teams and approvals.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(3, 'employee', 'Employee', 'Tracks time on the projects they are assigned to.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(4, 'client', 'Client', 'Read-only view of their own projects and reports.', '2026-10-01 08:55:54', '2026-10-01 08:55:54');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `created_at`) VALUES
(1, 1, '2026-10-01 08:55:54'),
(1, 2, '2026-10-01 08:55:54'),
(1, 3, '2026-10-01 08:55:54'),
(1, 4, '2026-10-01 08:55:54'),
(1, 5, '2026-10-01 08:55:54'),
(1, 6, '2026-10-01 08:55:54'),
(1, 7, '2026-10-01 08:55:54'),
(1, 8, '2026-10-01 08:55:54'),
(1, 9, '2026-10-01 08:55:54'),
(1, 10, '2026-10-01 08:55:54'),
(1, 11, '2026-10-01 08:55:54'),
(1, 12, '2026-10-01 08:55:54'),
(1, 13, '2026-10-01 08:55:54'),
(1, 14, '2026-10-01 08:55:54'),
(1, 15, '2026-10-01 08:55:54'),
(1, 16, '2026-10-01 08:55:54'),
(1, 17, '2026-10-01 08:55:54'),
(1, 18, '2026-10-01 08:55:54'),
(1, 19, '2026-10-01 08:55:54'),
(1, 20, '2026-10-01 08:55:54'),
(1, 21, '2026-10-01 08:55:54'),
(1, 22, '2026-10-01 08:55:54'),
(1, 23, '2026-10-01 08:55:54'),
(1, 24, '2026-10-01 08:55:54'),
(1, 25, '2026-10-01 08:55:54'),
(1, 26, '2026-10-01 08:55:54'),
(1, 27, '2026-10-01 08:55:54'),
(1, 28, '2026-10-01 08:55:54'),
(1, 29, '2026-10-01 08:55:54'),
(1, 33, '2026-10-01 08:55:54'),
(1, 34, '2026-10-01 08:55:54'),
(1, 35, '2026-10-01 10:28:52'),
(1, 36, '2026-10-01 10:28:52'),
(1, 37, '2026-10-01 10:28:52'),
(1, 38, '2026-10-01 10:28:52'),
(1, 39, '2026-10-01 10:28:52'),
(1, 57, '2026-10-02 08:51:16'),
(1, 61, '2026-10-03 11:06:04'),
(1, 62, '2026-10-04 05:03:32'),
(1, 63, '2026-10-04 05:03:32'),
(1, 64, '2026-10-04 05:03:32'),
(2, 1, '2026-10-01 08:55:54'),
(2, 2, '2026-10-01 08:55:54'),
(2, 3, '2026-10-01 08:55:54'),
(2, 8, '2026-10-01 08:55:54'),
(2, 9, '2026-10-01 08:55:54'),
(2, 10, '2026-10-01 08:55:54'),
(2, 12, '2026-10-01 08:55:54'),
(2, 14, '2026-10-01 08:55:54'),
(2, 15, '2026-10-01 08:55:54'),
(2, 17, '2026-10-01 08:55:54'),
(2, 18, '2026-10-01 08:55:54'),
(2, 19, '2026-10-01 08:55:54'),
(2, 20, '2026-10-01 08:55:54'),
(2, 21, '2026-10-01 08:55:54'),
(2, 22, '2026-10-01 08:55:54'),
(2, 23, '2026-10-01 08:55:54'),
(2, 24, '2026-10-01 08:55:54'),
(2, 25, '2026-10-01 08:55:54'),
(2, 26, '2026-10-01 08:55:54'),
(2, 27, '2026-10-01 08:55:54'),
(2, 29, '2026-10-01 08:55:54'),
(2, 33, '2026-10-01 08:55:54'),
(2, 35, '2026-10-01 10:28:52'),
(2, 36, '2026-10-01 10:28:52'),
(2, 37, '2026-10-01 10:28:52'),
(2, 38, '2026-10-01 10:28:52'),
(2, 39, '2026-10-01 10:28:52'),
(2, 61, '2026-10-03 11:06:04'),
(2, 62, '2026-10-04 05:03:32'),
(2, 63, '2026-10-04 05:03:32'),
(2, 64, '2026-10-04 05:03:32'),
(3, 1, '2026-10-01 08:55:54'),
(3, 2, '2026-10-01 08:55:54'),
(3, 12, '2026-10-01 08:55:54'),
(3, 19, '2026-10-01 08:55:54'),
(3, 21, '2026-10-01 08:55:54'),
(3, 24, '2026-10-01 08:55:54'),
(3, 25, '2026-10-01 08:55:54'),
(3, 27, '2026-10-01 08:55:54'),
(3, 35, '2026-10-01 10:28:52'),
(3, 36, '2026-10-01 10:28:52'),
(3, 37, '2026-10-01 10:28:52'),
(3, 62, '2026-10-04 05:03:32'),
(4, 1, '2026-10-01 08:55:54'),
(4, 2, '2026-10-01 08:55:54'),
(4, 12, '2026-10-01 08:55:54'),
(4, 62, '2026-10-04 05:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `recurrence_parent_id` int(10) UNSIGNED DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `estimated_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `status` enum('Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
  `notes` text DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`id`, `project_id`, `task_id`, `user_id`, `recurrence_parent_id`, `start_datetime`, `end_datetime`, `estimated_hours`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 16, NULL, '2026-10-05 06:32:00', '2026-10-05 08:32:00', 2.00, 'In Progress', NULL, 1, '2026-10-05 04:46:22', '2026-10-05 04:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `schedule_recurrences`
--

CREATE TABLE `schedule_recurrences` (
  `id` int(10) UNSIGNED NOT NULL,
  `schedule_id` int(10) UNSIGNED NOT NULL,
  `recurrence_type` enum('daily','weekly','weekdays','custom') NOT NULL DEFAULT 'weekly',
  `repeat_until` date DEFAULT NULL,
  `days_of_week` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','int','bool','json') NOT NULL DEFAULT 'string',
  `setting_group` varchar(40) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`, `updated_at`) VALUES
(1, 'app_name', 'TimeTrack', 'string', 'general', 'Name shown in the header and emails.', '2026-10-05 10:01:17'),
(3, 'company_email', 'hello@timetrack.local', 'string', 'general', 'Contact address for system emails.', '2026-10-05 10:01:17'),
(4, 'default_timezone', 'UTC', 'string', 'general', 'Timezone used when a user has not chosen one.', '2026-10-05 10:01:17'),
(5, 'date_format', 'M j, Y', 'string', 'general', 'PHP date() format for dates.', '2026-10-05 10:01:17'),
(6, 'time_format', 'H:i', 'string', 'general', 'PHP date() format for times.', '2026-10-05 10:01:17'),
(8, 'currency', 'USD', 'string', 'billing', 'ISO currency code for rates and budgets.', '2026-10-05 10:01:17'),
(9, 'default_hourly_rate', '0', 'string', 'billing', 'Rate applied to billable projects without their own rate.', '2026-10-05 10:01:17'),
(11, 'allow_manual_time_entries', '1', 'bool', 'time', 'Let employees add time entries by hand.', '2026-10-05 10:01:17'),
(13, 'timer_max_hours', '12', 'int', 'time', 'Stop a running timer automatically after this many hours.', '2026-10-05 10:01:17'),
(14, 'notifications_enabled', '1', 'bool', 'system', 'Create in-app notifications.', '2026-10-05 10:01:17'),
(15, 'maintenance_mode', '0', 'bool', 'system', 'Block non-admin sign-ins while maintenance is under way.', '2026-10-05 10:01:17'),
(16, 'currency_symbol', '-', 'string', 'billing', 'Symbol shown next to money amounts.', '2026-10-05 10:01:17'),
(47, 'smtp_enabled', '1', 'bool', 'mail', 'Send mail through SMTP', '2026-10-05 08:46:09'),
(48, 'smtp_host', 'smtp.hostinger.com', 'string', 'mail', 'SMTP host', '2026-10-05 08:46:09'),
(49, 'smtp_port', '465', 'int', 'mail', 'SMTP port', '2026-10-05 08:46:09'),
(50, 'smtp_username', 'admin@akhoonzadaholdings.com', 'string', 'mail', 'SMTP username', '2026-10-05 08:46:09'),
(51, 'smtp_password', 'v1:igkHgCztDGBvZIB+Tbf+ZO2c2IVoOdndfbP92oBeDzFOWlmnhHpxmA==', 'string', 'mail', 'SMTP password (encrypted by the app)', '2026-10-05 08:46:09'),
(52, 'smtp_encryption', 'ssl', 'string', 'mail', 'SMTP encryption: tls, ssl or none', '2026-10-05 08:46:09'),
(53, 'smtp_from_name', 'Maven', 'string', 'mail', 'From name', '2026-10-05 08:46:09'),
(54, 'smtp_from_email', 'admin@akhoonzadaholdings.com', 'string', 'mail', 'From email', '2026-10-05 08:46:09'),
(55, 'smtp_reply_to', '', 'string', 'mail', 'Reply-To email', '2026-10-05 08:46:09'),
(56, 'invite_expiry_days', '7', 'int', 'mail', 'Invitation link lifetime in days', '2026-10-05 08:46:09'),
(77, 'brand_color', '', 'string', 'general', NULL, '2026-10-05 10:00:05'),
(78, 'brand_logo', 'logo-7487ffbf0acd801f.png', 'string', 'general', NULL, '2026-10-05 10:00:05'),
(79, 'login_headline', 'See where every hour goes.', 'string', 'general', NULL, '2026-10-05 10:00:05'),
(80, 'login_subtext', 'Track time against projects, keep budgets honest, and hand clients numbers they can trust.', 'string', 'general', NULL, '2026-10-05 10:00:05'),
(90, 'timer_reminder_minutes', '10', 'int', 'time', NULL, '2026-10-05 10:01:17');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `parent_task_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('To Do','In Progress','On Hold','Review','Completed','Cancelled') NOT NULL DEFAULT 'To Do',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `completion_percent` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `parent_task_id`, `name`, `description`, `status`, `priority`, `estimated_hours`, `completion_percent`, `start_date`, `due_date`, `is_billable`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, 'CON - Building Envelope', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:42:46', '2026-10-04 09:42:46'),
(2, 1, NULL, 'CON - Building Services (MEP)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:42:54', '2026-10-04 09:42:54'),
(3, 1, NULL, 'CON - Commissioning Handover & Close-out', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:43:03', '2026-10-04 09:43:03'),
(4, 1, NULL, 'CON - Enabling & Substructure', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:43:17', '2026-10-04 09:43:17'),
(5, 2, NULL, 'CON - Building Systems', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 1, 1, '2026-10-04 09:43:40', '2026-10-04 09:43:40'),
(6, 2, NULL, 'CON - Fitouts', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 1, 1, '2026-10-04 09:43:49', '2026-10-04 09:43:49'),
(7, 2, NULL, 'CON - Joinery', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 1, 1, '2026-10-04 09:43:57', '2026-10-04 09:43:57'),
(8, 2, NULL, 'Concept Design', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 1, 1, '2026-10-04 09:44:04', '2026-10-04 09:44:04'),
(9, 2, NULL, 'Detailed Design', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 1, 1, '2026-10-04 09:44:13', '2026-10-04 09:44:13'),
(10, 3, NULL, 'CON - Building Envelope', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:44:37', '2026-10-04 09:44:37'),
(11, 3, NULL, 'CON - Building Services (MEP)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:44:44', '2026-10-04 09:44:44'),
(12, 3, NULL, 'CON - Commissioning Handover & Close-out', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:44:52', '2026-10-04 09:44:52'),
(13, 3, NULL, 'CON - Enabling & Substructure', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-04 09:44:58', '2026-10-04 09:44:58'),
(14, 4, NULL, 'TP - MEP + HVAC', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-05 17:48:34', '2026-10-05 17:48:34'),
(15, 4, NULL, 'TP - Finishes & Fit-outs', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-05 17:48:42', '2026-10-05 17:48:42'),
(16, 4, NULL, 'TP - Facade', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-05 17:48:50', '2026-10-05 17:48:50'),
(17, 4, NULL, 'TP - External Development & Landscapping', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, '2026-10-05 17:48:57', '2026-10-05 17:48:57');

-- --------------------------------------------------------

--
-- Table structure for table `task_assignees`
--

CREATE TABLE `task_assignees` (
  `id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `task_assignees`
--

INSERT INTO `task_assignees` (`id`, `task_id`, `user_id`, `created_at`) VALUES
(41, 17, 13, '2026-10-05 17:57:08'),
(42, 17, 3, '2026-10-05 17:57:08'),
(43, 17, 1, '2026-10-05 17:57:08');

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(120) NOT NULL,
  `manager_id` int(10) UNSIGNED DEFAULT NULL,
  `lead_id` int(10) UNSIGNED DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `project_id`, `name`, `manager_id`, `lead_id`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Design Services', 10, 11, 'active', 1, '2026-10-05 12:00:26', '2026-10-05 12:00:47'),
(2, 1, 'MEP', 1, 16, 'active', 1, '2026-10-05 12:01:57', '2026-10-05 12:01:57');

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `team_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`team_id`, `user_id`, `created_at`) VALUES
(1, 3, '2026-10-05 12:00:47'),
(1, 7, '2026-10-05 12:00:47'),
(1, 13, '2026-10-05 12:00:47'),
(1, 14, '2026-10-05 12:00:47'),
(1, 16, '2026-10-05 12:00:47'),
(2, 4, '2026-10-05 12:01:57'),
(2, 7, '2026-10-05 12:01:57'),
(2, 11, '2026-10-05 12:01:57'),
(2, 13, '2026-10-05 12:01:57'),
(2, 14, '2026-10-05 12:01:57'),
(2, 15, '2026-10-05 12:01:57'),
(2, 17, '2026-10-05 12:01:57');

-- --------------------------------------------------------

--
-- Table structure for table `timer_idle_events`
--

CREATE TABLE `timer_idle_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `timer_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `warning_at` datetime NOT NULL,
  `response` enum('continued','manual_pause','auto_paused') DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timesheets`
--

CREATE TABLE `timesheets` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `submission_token` varchar(64) DEFAULT NULL,
  `total_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `billable_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` enum('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
  `submitted_at` datetime DEFAULT NULL,
  `approved_by` int(10) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `rejection_reason` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timesheets`
--

INSERT INTO `timesheets` (`id`, `user_id`, `start_date`, `end_date`, `submission_token`, `total_seconds`, `billable_seconds`, `status`, `submitted_at`, `approved_by`, `approved_at`, `rejection_reason`, `created_at`, `updated_at`) VALUES
(1, 17, '2026-10-05', '2026-10-11', '4085772829606323964eddbedf55c077', 82, 7, 'Rejected', '2026-10-05 09:53:34', 16, '2026-10-05 12:44:21', 'Do it Again', '2026-10-05 09:53:34', '2026-10-05 12:44:21'),
(3, 16, '2026-10-05', '2026-10-11', '3ac8ad8a450f62aa8b763753f6f31694', 11233, 0, 'Submitted', '2026-10-05 12:05:13', NULL, NULL, NULL, '2026-10-05 12:05:13', '2026-10-05 12:05:13'),
(6, 1, '2026-10-05', '2026-10-11', 'd21bd36506c263d54c98b625b7027255', 4, 0, 'Submitted', '2026-10-05 12:36:54', NULL, NULL, NULL, '2026-10-05 12:36:54', '2026-10-05 12:36:54'),
(8, 16, '2026-10-05', '2026-10-11', '72f5b621e479a27075cf23978412917a', 5, 0, 'Submitted', '2026-10-05 12:44:02', NULL, NULL, NULL, '2026-10-05 12:44:02', '2026-10-05 12:44:02');

-- --------------------------------------------------------

--
-- Table structure for table `timesheet_entries`
--

CREATE TABLE `timesheet_entries` (
  `timesheet_id` int(10) UNSIGNED NOT NULL,
  `time_entry_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timesheet_entries`
--

INSERT INTO `timesheet_entries` (`timesheet_id`, `time_entry_id`, `created_at`) VALUES
(3, 20, '2026-10-05 12:05:13'),
(6, 22, '2026-10-05 12:36:54'),
(8, 21, '2026-10-05 12:44:02');

-- --------------------------------------------------------

--
-- Table structure for table `time_entries`
--

CREATE TABLE `time_entries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `schedule_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `started_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `duration_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `break_minutes` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `billable_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `auto_stopped` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Dumping data for table `time_entries`
--

INSERT INTO `time_entries` (`id`, `project_id`, `task_id`, `schedule_id`, `user_id`, `started_at`, `ended_at`, `duration_seconds`, `break_minutes`, `is_billable`, `billable_rate`, `auto_stopped`, `description`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, 1, '2026-10-04 09:45:21', '2026-10-04 09:54:39', 558, 0, 0, 0.00, 0, NULL, '2026-10-04 09:54:39', '2026-10-04 09:54:39'),
(2, 3, 10, NULL, 1, '2026-10-04 09:55:11', '2026-10-04 09:55:16', 5, 0, 0, 0.00, 0, NULL, '2026-10-04 09:55:16', '2026-10-04 09:55:16'),
(3, 3, 11, NULL, 1, '2026-10-04 09:55:25', '2026-10-04 09:55:50', 25, 0, 0, 0.00, 0, NULL, '2026-10-04 09:55:50', '2026-10-04 09:55:50'),
(4, 2, 6, NULL, 1, '2026-10-04 09:55:57', '2026-10-04 09:56:11', 14, 0, 1, 0.00, 0, NULL, '2026-10-04 09:56:11', '2026-10-04 09:56:11'),
(5, 1, 2, NULL, 1, '2026-10-04 10:22:05', '2026-10-04 10:22:10', 5, 0, 0, 0.00, 0, NULL, '2026-10-04 10:22:10', '2026-10-04 10:22:10'),
(6, 1, 1, NULL, 1, '2026-10-04 11:14:10', '2026-10-04 11:15:20', 70, 0, 0, 0.00, 0, NULL, '2026-10-04 11:15:20', '2026-10-04 11:15:20'),
(7, 2, 6, NULL, 3, '2026-10-04 10:05:41', '2026-10-04 22:05:41', 43200, 0, 1, 0.00, 1, NULL, '2026-10-04 22:06:01', '2026-10-04 22:06:01'),
(8, 1, 1, NULL, 1, '2026-10-05 04:18:26', '2026-10-05 04:18:30', 4, 0, 0, 0.00, 0, NULL, '2026-10-05 04:18:30', '2026-10-05 04:18:30'),
(9, 1, 3, NULL, 1, '2026-10-05 04:19:27', '2026-10-05 04:20:42', 75, 0, 0, 0.00, 0, NULL, '2026-10-05 04:20:42', '2026-10-05 04:20:42'),
(10, 2, 6, NULL, 16, '2026-10-05 09:24:00', '2026-10-05 10:27:00', 3780, 0, 1, 0.00, 0, NULL, '2026-10-05 04:27:02', '2026-10-05 04:27:02'),
(11, 2, 5, NULL, 1, '2026-10-05 04:34:21', '2026-10-05 04:39:40', 319, 0, 1, 0.00, 0, NULL, '2026-10-05 04:39:40', '2026-10-05 04:39:40'),
(12, 1, 2, NULL, 16, '2026-10-05 04:26:15', '2026-10-05 06:12:18', 963, 90, 0, 0.00, 0, NULL, '2026-10-05 06:12:18', '2026-10-05 06:12:18'),
(13, 1, 1, NULL, 1, '2026-10-05 06:13:21', '2026-10-05 08:21:33', 72, 127, 0, 0.00, 0, NULL, '2026-10-05 08:21:33', '2026-10-05 08:21:33'),
(14, 1, 2, NULL, 17, '2026-10-05 09:52:02', '2026-10-05 09:53:11', 69, 0, 0, 0.00, 0, NULL, '2026-10-05 09:53:11', '2026-10-05 09:53:11'),
(15, 2, 6, NULL, 17, '2026-10-05 09:53:19', '2026-10-05 09:53:26', 7, 0, 1, 0.00, 0, NULL, '2026-10-05 09:53:26', '2026-10-05 09:53:26'),
(16, 1, 3, NULL, 17, '2026-10-05 10:16:23', '2026-10-05 10:16:29', 6, 0, 0, 0.00, 0, NULL, '2026-10-05 10:16:29', '2026-10-05 10:16:29'),
(17, 2, 7, NULL, 17, '2026-10-05 10:17:17', '2026-10-05 10:17:31', 14, 0, 1, 0.00, 0, NULL, '2026-10-05 10:17:31', '2026-10-05 10:17:31'),
(18, 2, 8, NULL, 17, '2026-10-05 10:28:37', '2026-10-05 10:28:55', 18, 0, 1, 0.00, 0, NULL, '2026-10-05 10:28:55', '2026-10-05 10:28:55'),
(19, 1, 3, NULL, 17, '2026-10-05 10:29:18', '2026-10-05 10:32:05', 167, 0, 0, 0.00, 0, NULL, '2026-10-05 10:32:05', '2026-10-05 10:32:05'),
(20, 1, 1, NULL, 16, '2026-10-05 06:16:47', '2026-10-05 09:24:00', 11233, 0, 0, 0.00, 0, NULL, '2026-10-05 12:04:00', '2026-10-05 12:04:00'),
(21, 1, 3, NULL, 16, '2026-10-05 12:35:16', '2026-10-05 12:35:21', 5, 0, 0, 0.00, 0, NULL, '2026-10-05 12:35:21', '2026-10-05 12:35:21'),
(22, 1, 2, NULL, 1, '2026-10-05 12:36:43', '2026-10-05 12:36:47', 4, 0, 0, 0.00, 0, NULL, '2026-10-05 12:36:47', '2026-10-05 12:36:47'),
(23, 2, 6, NULL, 1, '2026-10-05 13:24:57', '2026-10-05 13:26:54', 117, 0, 1, 0.00, 0, NULL, '2026-10-05 13:26:54', '2026-10-05 13:26:54'),
(24, 1, 2, NULL, 1, '2026-10-05 13:31:07', '2026-10-05 13:32:36', 89, 0, 0, 0.00, 0, NULL, '2026-10-05 13:32:36', '2026-10-05 13:32:36'),
(25, 3, 13, NULL, 1, '2026-10-05 17:46:06', '2026-10-05 17:50:02', 236, 0, 0, 0.00, 0, NULL, '2026-10-05 17:50:02', '2026-10-05 17:50:02');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `role` enum('admin','manager','employee','client') NOT NULL DEFAULT 'employee',
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timezone` varchar(64) NOT NULL DEFAULT 'UTC',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `failed_login_attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `role`, `name`, `email`, `password`, `phone`, `job_title`, `hourly_rate`, `timezone`, `status`, `failed_login_attempts`, `locked_until`, `last_login_at`, `last_login_ip`, `password_changed_at`, `must_change_password`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'System Admin', 'mubashirjco@gmail.com', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Administrator', 0.00, 'Asia/Karachi', 'active', 0, NULL, '2026-10-05 17:45:25', '58.65.217.235', '2026-10-01 08:55:54', 0, '2026-10-01 08:55:54', '2026-10-05 17:45:25'),
(2, 2, 'manager', 'Morgan Lee', 'manager@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Project Manager', 0.00, 'Asia/Karachi', 'active', 0, NULL, '2026-10-05 12:44:17', '103.87.194.250', '2026-10-01 08:55:54', 0, '2026-10-01 08:55:54', '2026-10-05 12:44:17'),
(3, 3, 'employee', 'John Carter', 'john@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Developer', 0.00, 'Asia/Karachi', 'active', 0, NULL, '2026-10-04 10:05:22', '58.65.217.235', '2026-10-01 08:55:54', 0, '2026-10-01 08:55:54', '2026-10-04 10:05:22'),
(4, 3, 'employee', 'Sarah Khan', 'sarah@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', NULL, 'Designer', 0.00, 'Asia/Karachi', 'active', 0, NULL, '2026-10-05 09:32:02', '103.87.194.250', '2026-10-01 08:55:54', 0, '2026-10-01 08:55:54', '2026-10-05 09:32:02'),
(7, 2, 'manager', 'Sara Ahmed', 'sara@example.com', '$2y$12$URzGrAe9PsyqPn0wuhV1KeskHMB78/RwrlwHROm/8NKfRAYMs2n42', '3007654321', 'Project Manager', 3000.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-03 11:16:15', '2026-10-03 11:16:15'),
(8, 3, 'employee', 'Usman Malik', 'usman@example.com', '$2y$12$ZH201jfwFKqjGUKURAJ8seYGikn0qnWoej.NQJD.vsPWYsxh/ZkzK', '3001122334', 'Developer', 2200.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-03 11:16:16', '2026-10-03 11:16:16'),
(10, 2, 'manager', 'Hamza Raza', 'aylinnoore@gmail.com', '$2y$12$mCU.WYQJjxq169XJ7/BpRecMZXN/Et6QUCNrL0kV4VQdm6BuIcQea', '30099887', 'Team Lead', 3500.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-03 11:16:16', '2026-10-05 17:49:53'),
(11, 3, 'employee', 'Fatima Shah', 'fatima@example.com', '$2y$12$KaIi6ERohJxLVeD0rAANQ.kQ4Sl2lQ9Gq8szKaZLAEbmheyNkUf/W', '3004455667', 'Content Writer', 1600.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-03 11:16:16', '2026-10-03 11:16:16'),
(13, 3, 'employee', 'Hira Ali', 'hira@example.com', '$2y$12$VyC1c/D2dl1CGQjTUWK/OOrszz3zJ5VLKVtX2cEr.r3tj253OVSle', '3006677889', 'QA Engineer', 2000.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-03 11:16:17', '2026-10-03 11:16:17'),
(14, 3, 'employee', 'Danish Khan', 'danish@example.com', '$2y$12$lmE1tXnbe2CFywEF1jPnVONRHTvCBAckm9T9nIMymT/lat66Sclya', '3003344556', 'Frontend Developer', 2300.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-03 11:16:17', '2026-10-03 11:16:17'),
(15, 2, 'manager', 'Maham Iqbal', 'maham@example.com', '$2y$12$7hFgZFim3wOSWzMKArLSWeBeZajOKL88yD905Srr66dijaGXum8vG', '3007788990', 'Operations Manager', 3200.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-03 11:16:17', '2026-10-03 11:16:17'),
(16, 3, 'employee', 'Rummish Saleem', 'rummishsaleem@mavenprojects.com', '$2y$12$f6VHhCB8W9YoZzVjn4mJvuebbT70dIrq6s8RgBGtUX1H1bWTFhEJG', '0544521', NULL, 0.00, 'UTC', 'active', 0, NULL, '2026-10-05 12:03:44', '103.87.194.250', '2026-10-05 04:24:49', 0, '2026-10-05 04:23:11', '2026-10-05 12:03:44'),
(17, 3, 'employee', 'Mubashir Hassan', 'mubashirbaltistani@gmail.com', '$2y$12$DgGG2/ysFse9rHQtd07sieK.IZ4QJNn0MG7Ajr5lqsg5bCJkZFT5O', NULL, NULL, 0.00, 'UTC', 'active', 0, NULL, '2026-10-05 17:57:36', '58.65.217.235', '2026-10-05 09:30:07', 0, '2026-10-05 09:30:07', '2026-10-05 17:57:36');

-- --------------------------------------------------------

--
-- Table structure for table `user_invitations`
--

CREATE TABLE `user_invitations` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `name` varchar(120) NOT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `account_status` varchar(20) NOT NULL DEFAULT 'active',
  `invited_by` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `sent_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `send_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_invitations`
--

INSERT INTO `user_invitations` (`id`, `email`, `name`, `job_title`, `phone`, `account_status`, `invited_by`, `role_id`, `user_id`, `token_hash`, `expires_at`, `status`, `sent_at`, `accepted_at`, `cancelled_at`, `last_sent_at`, `send_count`, `created_at`, `updated_at`) VALUES
(1, 'mubashirbaltistani@gmail.com', 'Mubashir Hassan', NULL, NULL, 'active', 1, 3, 17, 'a6c7a3bc1cccda287ca7d9f7c0db6328fde3435397640fdc6a8c7f946b7cfc06', '2026-10-12 09:28:43', 'accepted', '2026-10-05 09:10:41', '2026-10-05 09:30:07', NULL, '2026-10-05 09:28:46', 2, '2026-10-05 09:10:38', '2026-10-05 09:30:07'),
(2, 'ahmerashfaq@mavenprojects.com', 'Ahmer Ashfaq', NULL, NULL, 'active', 1, 1, NULL, 'e01c5832c8cd7e5bf90a0cc156bf6ce3c634976c5a45da2b0260507da8645175', '2026-10-12 09:42:30', 'sent', '2026-10-05 09:42:32', NULL, NULL, '2026-10-05 09:42:32', 1, '2026-10-05 09:42:30', '2026-10-05 09:42:32');

-- --------------------------------------------------------

--
-- Table structure for table `user_invitation_projects`
--

CREATE TABLE `user_invitation_projects` (
  `invitation_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_invitation_projects`
--

INSERT INTO `user_invitation_projects` (`invitation_id`, `project_id`) VALUES
(1, 1),
(2, 1),
(1, 2),
(2, 2),
(2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `user_invitation_tasks`
--

CREATE TABLE `user_invitation_tasks` (
  `invitation_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_invitation_tasks`
--

INSERT INTO `user_invitation_tasks` (`invitation_id`, `task_id`) VALUES
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(2, 9),
(2, 10),
(2, 11),
(2, 12),
(2, 13);

-- --------------------------------------------------------

--
-- Table structure for table `user_invitation_teams`
--

CREATE TABLE `user_invitation_teams` (
  `invitation_id` int(10) UNSIGNED NOT NULL,
  `team_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `workspaces`
--

CREATE TABLE `workspaces` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `logo_path` varchar(500) DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workspaces`
--

INSERT INTO `workspaces` (`id`, `name`, `logo_path`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Maven Projects LLP.', '/uploads/workspace/logo-a14157ace63e7d5fb1f9.png', 1, '2026-10-02 08:51:16', '2026-10-02 17:39:24');

-- --------------------------------------------------------

--
-- Table structure for table `workspace_settings`
--

CREATE TABLE `workspace_settings` (
  `workspace_id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` varchar(1000) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workspace_settings`
--

INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'activity_monitoring_enabled', '1', '2026-10-03 06:29:26'),
(1, 'approval_period', 'weekly', '2026-10-05 04:45:43'),
(1, 'audit_log_enabled', '1', '2026-10-03 06:29:26'),
(1, 'billable_hours_enabled', '1', '2026-10-03 06:29:26'),
(1, 'breaks_enabled', '1', '2026-10-03 06:29:26'),
(1, 'daily_capacity', '8', '2026-10-05 04:45:43'),
(1, 'default_project_visibility', 'private', '2026-10-05 04:45:43'),
(1, 'duration_format', 'clock_seconds', '2026-10-03 06:29:26'),
(1, 'edit_time_others_policy', 'admins_team_managers', '2026-10-05 04:45:43'),
(1, 'expense_approval_enabled', '0', '2026-10-03 06:29:26'),
(1, 'expenses_enabled', '0', '2026-10-03 06:29:26'),
(1, 'favorite_entries_enabled', '1', '2026-10-03 06:29:26'),
(1, 'favorites_enabled', '1', '2026-10-03 06:29:26'),
(1, 'force_timer', '0', '2026-10-05 04:45:43'),
(1, 'gps_enabled', '1', '2026-10-03 06:29:26'),
(1, 'hide_projects', '0', '2026-10-05 04:45:43'),
(1, 'hide_reports', '0', '2026-10-05 04:45:43'),
(1, 'hide_team', '0', '2026-10-05 04:45:43'),
(1, 'hide_tracker', '0', '2026-10-05 04:45:43'),
(1, 'idle_detection_enabled', '1', '2026-10-05 04:45:43'),
(1, 'idle_threshold_minutes', '1', '2026-10-05 04:45:43'),
(1, 'idle_warning_seconds', '60', '2026-10-05 04:45:43'),
(1, 'invoice_manager_policy', 'admins', '2026-10-03 06:29:26'),
(1, 'invoicing_enabled', '0', '2026-10-03 06:29:26'),
(1, 'kiosk_enabled', '1', '2026-10-03 06:29:26'),
(1, 'lock_time_enabled', '0', '2026-10-05 04:45:43'),
(1, 'organize_time_by', 'project_task', '2026-10-03 06:29:26'),
(1, 'project_creation_policy', 'admins_project_managers', '2026-10-05 04:45:43'),
(1, 'project_status_visibility', 'anyone', '2026-10-03 06:29:26'),
(1, 'regular_user_time_visibility', 'own', '2026-10-05 04:45:43'),
(1, 'required_fields', '', '2026-10-03 06:29:26'),
(1, 'scheduling_enabled', '1', '2026-10-05 04:45:43'),
(1, 'screenshots_enabled', '1', '2026-10-03 06:29:26'),
(1, 'tag_creation_policy', 'anyone', '2026-10-03 06:29:26'),
(1, 'task_creation_policy', 'admins_project_managers', '2026-10-05 04:45:43'),
(1, 'time_approval_enabled', '1', '2026-10-05 04:45:43'),
(1, 'time_off_enabled', '1', '2026-10-03 06:29:26'),
(1, 'time_rounding_minutes', '1', '2026-10-05 04:45:43'),
(1, 'timesheet_approver_policy', 'admins_team_managers', '2026-10-03 06:29:26'),
(1, 'timesheet_enabled', '1', '2026-10-05 04:45:43'),
(1, 'week_start', 'monday', '2026-10-05 04:45:43'),
(1, 'working_days', 'Mon,Tue,Wed,Thu,Fri', '2026-10-03 06:29:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_timers`
--
ALTER TABLE `active_timers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_active_timers_user` (`user_id`),
  ADD KEY `idx_active_timers_project` (`project_id`),
  ADD KEY `idx_active_timers_task` (`task_id`);

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_activity_user` (`user_id`),
  ADD KEY `idx_activity_action` (`action`),
  ADD KEY `idx_activity_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_activity_created` (`created_at`);

--
-- Indexes for table `agent_pair_attempts`
--
ALTER TABLE `agent_pair_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_agent_pair_attempts_ip_created` (`ip`,`created_at`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_clients_name` (`name`),
  ADD KEY `idx_clients_email` (`email`),
  ADD KEY `idx_clients_status` (`status`);

--
-- Indexes for table `client_users`
--
ALTER TABLE `client_users`
  ADD PRIMARY KEY (`user_id`,`client_id`),
  ADD UNIQUE KEY `uq_client_users_user_client` (`user_id`,`client_id`),
  ADD KEY `idx_client_users_client` (`client_id`);

--
-- Indexes for table `desktop_agent_devices`
--
ALTER TABLE `desktop_agent_devices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_desktop_agent_token` (`token_hash`),
  ADD UNIQUE KEY `uq_desktop_agent_user_device` (`user_id`,`device_id`),
  ADD KEY `idx_desktop_agent_user_status` (`user_id`,`status`),
  ADD KEY `idx_desktop_agent_seen` (`last_seen_at`),
  ADD KEY `fk_desktop_agent_workspace` (`workspace_id`);

--
-- Indexes for table `desktop_agent_pairing_codes`
--
ALTER TABLE `desktop_agent_pairing_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_agent_pair_expiry` (`expires_at`,`used_at`),
  ADD KEY `idx_agent_pair_user` (`user_id`,`created_at`),
  ADD KEY `fk_agent_pair_workspace` (`workspace_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_password_reset_tokens_hash` (`token_hash`),
  ADD KEY `idx_password_reset_tokens_user` (`user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_permissions_name` (`name`),
  ADD KEY `idx_permissions_module` (`module`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_projects_code` (`project_code`),
  ADD KEY `idx_projects_client` (`client_id`),
  ADD KEY `idx_projects_status` (`status`),
  ADD KEY `idx_projects_manager` (`manager_id`),
  ADD KEY `idx_projects_due` (`due_date`),
  ADD KEY `fk_projects_created_by` (`created_by`);

--
-- Indexes for table `project_favorites`
--
ALTER TABLE `project_favorites`
  ADD PRIMARY KEY (`user_id`,`project_id`),
  ADD KEY `idx_project_favorites_project` (`project_id`);

--
-- Indexes for table `project_members`
--
ALTER TABLE `project_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_project_members_project_user` (`project_id`,`user_id`),
  ADD KEY `idx_project_members_user` (`user_id`);

--
-- Indexes for table `report_access`
--
ALTER TABLE `report_access`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_roles_name` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `idx_role_permissions_permission` (`permission_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_schedules_user_time` (`user_id`,`start_datetime`,`end_datetime`),
  ADD KEY `idx_schedules_project` (`project_id`),
  ADD KEY `idx_schedules_task` (`task_id`),
  ADD KEY `idx_schedules_status` (`status`),
  ADD KEY `idx_schedules_created_by` (`created_by`),
  ADD KEY `idx_schedules_recurrence_parent` (`recurrence_parent_id`);

--
-- Indexes for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_recurrence_schedule` (`schedule_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_settings_key` (`setting_key`),
  ADD KEY `idx_settings_group` (`setting_group`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tasks_project` (`project_id`),
  ADD KEY `idx_tasks_parent` (`parent_task_id`),
  ADD KEY `idx_tasks_status` (`status`),
  ADD KEY `idx_tasks_priority` (`priority`),
  ADD KEY `idx_tasks_due` (`due_date`),
  ADD KEY `fk_tasks_created_by` (`created_by`);

--
-- Indexes for table `task_assignees`
--
ALTER TABLE `task_assignees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_task_assignees` (`task_id`,`user_id`),
  ADD KEY `idx_task_assignees_user` (`user_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_teams_project_name` (`project_id`,`name`),
  ADD KEY `idx_teams_manager` (`manager_id`),
  ADD KEY `idx_teams_lead` (`lead_id`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`team_id`,`user_id`),
  ADD KEY `idx_team_members_user` (`user_id`);

--
-- Indexes for table `timer_idle_events`
--
ALTER TABLE `timer_idle_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_idle_timer_open` (`timer_id`,`response`,`id`),
  ADD KEY `idx_idle_user_created` (`user_id`,`created_at`);

--
-- Indexes for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_timesheets_submission_token` (`submission_token`),
  ADD KEY `idx_timesheets_status` (`status`),
  ADD KEY `idx_timesheets_submitted` (`submitted_at`),
  ADD KEY `idx_timesheets_approved_by` (`approved_by`),
  ADD KEY `idx_timesheets_user_period` (`user_id`,`start_date`,`end_date`);

--
-- Indexes for table `timesheet_entries`
--
ALTER TABLE `timesheet_entries`
  ADD PRIMARY KEY (`timesheet_id`,`time_entry_id`),
  ADD UNIQUE KEY `uq_timesheet_entries_entry` (`time_entry_id`),
  ADD KEY `idx_timesheet_entries_timesheet` (`timesheet_id`);

--
-- Indexes for table `time_entries`
--
ALTER TABLE `time_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_time_entries_project` (`project_id`),
  ADD KEY `idx_time_entries_task` (`task_id`),
  ADD KEY `idx_time_entries_user` (`user_id`),
  ADD KEY `idx_time_entries_running` (`user_id`,`ended_at`),
  ADD KEY `idx_time_entries_schedule` (`schedule_id`),
  ADD KEY `idx_time_entries_billable` (`is_billable`),
  ADD KEY `idx_time_entries_user_started` (`user_id`,`started_at`),
  ADD KEY `idx_time_entries_project_started` (`project_id`,`started_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `idx_users_role_id` (`role_id`),
  ADD KEY `idx_users_role_status` (`role`,`status`);

--
-- Indexes for table `user_invitations`
--
ALTER TABLE `user_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_user_invitations_token_hash` (`token_hash`),
  ADD KEY `idx_user_invitations_email` (`email`),
  ADD KEY `idx_user_invitations_status_expires` (`status`,`expires_at`),
  ADD KEY `idx_user_invitations_invited_by` (`invited_by`),
  ADD KEY `idx_user_invitations_user` (`user_id`),
  ADD KEY `fk_user_invitations_role` (`role_id`);

--
-- Indexes for table `user_invitation_projects`
--
ALTER TABLE `user_invitation_projects`
  ADD PRIMARY KEY (`invitation_id`,`project_id`),
  ADD KEY `idx_user_invitation_projects_project` (`project_id`);

--
-- Indexes for table `user_invitation_tasks`
--
ALTER TABLE `user_invitation_tasks`
  ADD PRIMARY KEY (`invitation_id`,`task_id`),
  ADD KEY `idx_user_invitation_tasks_task` (`task_id`);

--
-- Indexes for table `user_invitation_teams`
--
ALTER TABLE `user_invitation_teams`
  ADD PRIMARY KEY (`invitation_id`,`team_id`),
  ADD KEY `idx_user_invitation_teams_team` (`team_id`);

--
-- Indexes for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_workspaces_created_by` (`created_by`);

--
-- Indexes for table `workspace_settings`
--
ALTER TABLE `workspace_settings`
  ADD PRIMARY KEY (`workspace_id`,`setting_key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `active_timers`
--
ALTER TABLE `active_timers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=272;

--
-- AUTO_INCREMENT for table `agent_pair_attempts`
--
ALTER TABLE `agent_pair_attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `desktop_agent_devices`
--
ALTER TABLE `desktop_agent_devices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `desktop_agent_pairing_codes`
--
ALTER TABLE `desktop_agent_pairing_codes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `project_members`
--
ALTER TABLE `project_members`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `task_assignees`
--
ALTER TABLE `task_assignees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `timer_idle_events`
--
ALTER TABLE `timer_idle_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timesheets`
--
ALTER TABLE `timesheets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `time_entries`
--
ALTER TABLE `time_entries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_invitations`
--
ALTER TABLE `user_invitations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `workspaces`
--
ALTER TABLE `workspaces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

-- --------------------------------------------------------

--
-- Structure for view `audit_logs`
--
DROP TABLE IF EXISTS `audit_logs`;

CREATE ALGORITHM=UNDEFINED DEFINER=`u897128490_timetracker`@`127.0.0.1` SQL SECURITY INVOKER VIEW `audit_logs`  AS SELECT `activity_logs`.`id` AS `id`, `activity_logs`.`user_id` AS `user_id`, `activity_logs`.`action` AS `action`, `activity_logs`.`module` AS `module`, `activity_logs`.`entity_type` AS `entity_type`, `activity_logs`.`entity_id` AS `entity_id`, `activity_logs`.`ip_address` AS `ip_address`, `activity_logs`.`user_agent` AS `user_agent`, `activity_logs`.`meta` AS `meta`, `activity_logs`.`old_value` AS `old_value`, `activity_logs`.`new_value` AS `new_value`, `activity_logs`.`created_at` AS `created_at` FROM `activity_logs` ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `active_timers`
--
ALTER TABLE `active_timers`
  ADD CONSTRAINT `fk_active_timers_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_active_timers_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_active_timers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `client_users`
--
ALTER TABLE `client_users`
  ADD CONSTRAINT `fk_client_users_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_client_users_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `desktop_agent_devices`
--
ALTER TABLE `desktop_agent_devices`
  ADD CONSTRAINT `fk_desktop_agent_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_desktop_agent_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `desktop_agent_pairing_codes`
--
ALTER TABLE `desktop_agent_pairing_codes`
  ADD CONSTRAINT `fk_agent_pair_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_agent_pair_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD CONSTRAINT `fk_password_reset_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `fk_projects_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_projects_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_projects_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `project_favorites`
--
ALTER TABLE `project_favorites`
  ADD CONSTRAINT `fk_project_favorites_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_project_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_members`
--
ALTER TABLE `project_members`
  ADD CONSTRAINT `fk_project_members_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_project_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `report_access`
--
ALTER TABLE `report_access`
  ADD CONSTRAINT `fk_report_access_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `fk_schedules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_recurrence_parent` FOREIGN KEY (`recurrence_parent_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  ADD CONSTRAINT `fk_recurrence_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `fk_tasks_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_parent` FOREIGN KEY (`parent_task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `task_assignees`
--
ALTER TABLE `task_assignees`
  ADD CONSTRAINT `fk_task_assignees_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_task_assignees_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `fk_teams_lead` FOREIGN KEY (`lead_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_teams_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_teams_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `team_members`
--
ALTER TABLE `team_members`
  ADD CONSTRAINT `fk_team_members_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_team_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timer_idle_events`
--
ALTER TABLE `timer_idle_events`
  ADD CONSTRAINT `fk_idle_timer` FOREIGN KEY (`timer_id`) REFERENCES `active_timers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_idle_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD CONSTRAINT `fk_timesheets_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_timesheets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheet_entries`
--
ALTER TABLE `timesheet_entries`
  ADD CONSTRAINT `fk_timesheet_entries_entry` FOREIGN KEY (`time_entry_id`) REFERENCES `time_entries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_timesheet_entries_timesheet` FOREIGN KEY (`timesheet_id`) REFERENCES `timesheets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_entries`
--
ALTER TABLE `time_entries`
  ADD CONSTRAINT `fk_time_entries_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_time_entries_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_time_entries_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_time_entries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `user_invitations`
--
ALTER TABLE `user_invitations`
  ADD CONSTRAINT `fk_user_invitations_invited_by` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitations_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitations_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `user_invitation_projects`
--
ALTER TABLE `user_invitation_projects`
  ADD CONSTRAINT `fk_user_invitation_projects_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitation_projects_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_invitation_tasks`
--
ALTER TABLE `user_invitation_tasks`
  ADD CONSTRAINT `fk_user_invitation_tasks_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitation_tasks_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_invitation_teams`
--
ALTER TABLE `user_invitation_teams`
  ADD CONSTRAINT `fk_user_invitation_teams_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitation_teams_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD CONSTRAINT `fk_workspaces_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `workspace_settings`
--
ALTER TABLE `workspace_settings`
  ADD CONSTRAINT `fk_workspace_settings_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
