<?php
/**
 * Base controller. RBAC is enforced HERE, in the constructor, so a controller cannot
 * be reached without passing the checks no matter what the UI shows or hides.
 *
 *   final class ProjectController extends Controller
 *   {
 *       public function __construct()
 *       {
 *           parent::__construct(true, [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER]);
 *       }
 *   }
 *
 * Public pages (login) pass requireAuth = false and no roles.
 */

declare(strict_types=1);

abstract class Controller
{
    protected Request $request;

    /** @param list<string> $allowedRoles Empty list = any authenticated user */
    public function __construct(bool $requireAuth = true, array $allowedRoles = [])
    {
        $this->request = Request::current();

        if ($requireAuth) {
            (new AuthMiddleware())->handle();

            if ($allowedRoles !== []) {
                (new RoleMiddleware($allowedRoles))->handle();
            }
        } elseif ($allowedRoles !== []) {
            throw new LogicException('Roles can only be required together with authentication.');
        }
    }

    /** @param array<string, mixed> $data */
    protected function render(string $view, array $data = [], string $layout = 'app'): void
    {
        View::render($view, $data, $layout);
    }

    /** @param array<string, mixed> $payload */
    protected function json(array $payload, int $status = 200): never
    {
        Response::json($payload, $status);
    }

    protected function redirect(string $path, int $status = 302): never
    {
        Response::redirect($path, $status);
    }

    /** Queue a one-time message for the next page. $type is a Bootstrap contextual class. */
    protected function flash(string $type, string $message): void
    {
        if (!in_array($type, ['success', 'danger', 'warning', 'info'], true)) {
            $type = 'info';
        }

        $_SESSION['_flash'][$type][] = $message;
    }

    /**
     * Send the user back to a form with their input and per-field errors.
     * Passwords and tokens are never flashed back into the form.
     *
     * @param array<string, string> $errors
     */
    protected function backWithErrors(string $path, array $errors): never
    {
        $input = array_filter(
            $this->request->body(),
            static fn ($value, $key): bool => is_string($value)
                && !in_array($key, ['_csrf', '_method'], true)
                && !str_contains(strtolower((string) $key), 'password'),
            ARRAY_FILTER_USE_BOTH
        );

        $_SESSION['_old']    = $input;
        $_SESSION['_errors'] = $errors;

        $this->redirect($path);
    }

    /**
     * Validate request input. On failure: JSON 422 for AJAX, otherwise redirect back to $failPath.
     * Returns only the fields that have rules.
     *
     * @param array<string, string|list<string>> $rules
     * @param array<string, string>              $labels
     * @return array<string, mixed>
     */
    protected function validate(array $rules, string $failPath, array $labels = []): array
    {
        $validator = ValidatorHelper::make($this->request->all(), $rules, $labels);

        if ($validator->fails()) {
            if ($this->request->wantsJson()) {
                $this->json(['ok' => false, 'errors' => $validator->errors()], 422);
            }
            $this->backWithErrors($failPath, $validator->errors());
        }

        return $validator->validated();
    }

    /** Stop with 404 when a record the caller asked for does not exist (or is not theirs to see). */
    protected function notFound(): never
    {
        throw new HttpException(404);
    }

    /** Stop with 403. Use for record-level checks, e.g. an employee opening someone else's timesheet. */
    protected function forbidden(): never
    {
        throw new HttpException(403);
    }
}
