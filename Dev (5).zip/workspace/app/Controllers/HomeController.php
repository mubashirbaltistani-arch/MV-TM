<?php
/**
 * Entry route "/": sends visitors to the dashboard or the login page.
 * (Both screens are delivered in Phase 3; until then they return 404.)
 */

declare(strict_types=1);

final class HomeController extends Controller
{
    public function __construct()
    {
        parent::__construct(false); // public: no authentication required
    }

    /** @param array<string, string> $params */
    public function index(Request $request, array $params): void
    {
        $this->redirect(AuthHelper::check() ? '/dashboard' : '/login');
    }
}
