<?php
/**
 * Read-only configuration registry with dot-notation access.
 *
 *   Config::get('session.idle_timeout', 1800);
 */

declare(strict_types=1);

final class Config
{
    /** @var array<string, mixed> */
    private static array $items = [];

    /** Merge a config array under a top-level key (e.g. "database"). */
    public static function set(string $key, array $values): void
    {
        self::$items[$key] = $values;
    }

    /** Merge several top-level sections at once (used for config.php). */
    public static function load(array $sections): void
    {
        foreach ($sections as $key => $values) {
            self::$items[$key] = $values;
        }
    }

    public static function get(string $path, mixed $default = null): mixed
    {
        $value = self::$items;

        foreach (explode('.', $path) as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }

        return $value;
    }
}
