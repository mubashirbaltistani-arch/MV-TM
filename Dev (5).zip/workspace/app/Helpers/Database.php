<?php
/**
 * Single PDO connection plus thin prepared-statement helpers.
 *
 * SECURITY: values are ALWAYS sent as bound parameters (real server-side prepares,
 * emulation off), so user input can never alter the SQL structure. Identifiers
 * (table/column names) cannot be bound; callers must only pass hard-coded or
 * allow-listed identifiers (Model enforces this).
 */

declare(strict_types=1);

final class Database
{
    private static ?PDO $pdo = null;

    /** Lazily open the connection. Failures are logged without credentials and rethrown generically. */
    public static function connection(): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $cfg = Config::get('database');

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $cfg['host'],
            $cfg['port'],
            $cfg['name'],
            $cfg['charset']
        );

        try {
            $pdo = new PDO($dsn, (string) $cfg['user'], (string) $cfg['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::ATTR_STRINGIFY_FETCHES  => false,
            ]);

            // UTC session time zone makes UTC_TIMESTAMP() and TIMESTAMP columns consistent;
            // strict mode turns silent data truncation into errors.
            $pdo->exec(
                "SET time_zone = '+00:00', "
                . "sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'"
            );
        } catch (PDOException $e) {
            // The PDOException message can contain the DSN/user, so log only the driver error code.
            LoggerHelper::error('Database connection failed', ['code' => (string) $e->getCode()]);
            throw new RuntimeException('Database connection failed.');
        }

        return self::$pdo = $pdo;
    }

    /**
     * Prepare and execute a statement.
     * Params may be positional (list) or named (['id' => 5] with :id in the SQL).
     *
     * @param array<int|string, mixed> $params
     */
    public static function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = self::connection()->prepare($sql);

        foreach ($params as $key => $value) {
            $placeholder = is_int($key) ? $key + 1 : ':' . ltrim((string) $key, ':');
            $stmt->bindValue($placeholder, $value, self::pdoType($value));
        }

        $stmt->execute();

        return $stmt;
    }

    /**
     * @param array<int|string, mixed> $params
     * @return array<string, mixed>|null
     */
    public static function fetchOne(string $sql, array $params = []): ?array
    {
        $row = self::query($sql, $params)->fetch();

        return $row === false ? null : $row;
    }

    /**
     * @param array<int|string, mixed> $params
     * @return list<array<string, mixed>>
     */
    public static function fetchAll(string $sql, array $params = []): array
    {
        return self::query($sql, $params)->fetchAll();
    }

    /** @param array<int|string, mixed> $params */
    public static function fetchValue(string $sql, array $params = []): mixed
    {
        $value = self::query($sql, $params)->fetchColumn();

        return $value === false ? null : $value;
    }

    /** Execute INSERT/UPDATE/DELETE and return the number of affected rows. */
    public static function execute(string $sql, array $params = []): int
    {
        return self::query($sql, $params)->rowCount();
    }

    public static function lastInsertId(): int
    {
        return (int) self::connection()->lastInsertId();
    }

    /**
     * Run $callback inside a transaction; commit on success, roll back on any Throwable.
     * If a transaction is already open the callback simply joins it, so the OUTERMOST
     * caller decides commit/rollback. Use SELECT ... FOR UPDATE inside for row locks.
     *
     * @template T
     * @param callable(PDO): T $callback
     * @return T
     */
    public static function transaction(callable $callback): mixed
    {
        $pdo = self::connection();

        if ($pdo->inTransaction()) {
            return $callback($pdo);
        }

        $pdo->beginTransaction();

        try {
            $result = $callback($pdo);
            $pdo->commit();

            return $result;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    private static function pdoType(mixed $value): int
    {
        return match (true) {
            is_int($value), is_bool($value) => PDO::PARAM_INT,
            $value === null                 => PDO::PARAM_NULL,
            default                         => PDO::PARAM_STR,
        };
    }
}
