<?php
/**
 * Permission checks backed by the roles / permissions / role_permissions tables.
 *
 *   if (PermissionHelper::has('projects.create')) { ... }
 *
 * The role comes from the session, which AuthMiddleware refreshes from the database
 * on every authenticated request. Permission names are loaded once per request.
 *
 * Like AuthHelper::hasRole(), this is also used to show or hide UI, but the real
 * enforcement must always happen again in the controller.
 */

declare(strict_types=1);

final class PermissionHelper
{
    /** @var array<string, array<string, true>> role name => set of permission names */
    private static array $cache = [];

    /** True when the logged-in user's role has ALL the given permissions. */
    public static function has(string ...$permissions): bool
    {
        $role = AuthHelper::role();

        if ($role === null || $permissions === []) {
            return false;
        }

        $granted = self::forRole($role);

        foreach ($permissions as $permission) {
            if (!isset($granted[$permission])) {
                return false;
            }
        }

        return true;
    }

    /** True when the logged-in user's role has AT LEAST ONE of the given permissions. */
    public static function hasAny(string ...$permissions): bool
    {
        foreach ($permissions as $permission) {
            if (self::has($permission)) {
                return true;
            }
        }

        return false;
    }

    /** Stop with HTTP 403 unless the user has every listed permission. */
    public static function require(string ...$permissions): void
    {
        if (!self::has(...$permissions)) {
            LoggerHelper::warning('Permission denied', [
                'user_id'    => AuthHelper::id(),
                'permission' => implode(',', $permissions),
            ]);

            throw new HttpException(403);
        }
    }

    /** @return list<string> every permission name granted to the logged-in user's role */
    public static function all(): array
    {
        $role = AuthHelper::role();

        return $role === null ? [] : array_keys(self::forRole($role));
    }

    /** @return array<string, true> */
    private static function forRole(string $role): array
    {
        if (!isset(self::$cache[$role])) {
            $rows = Database::fetchAll(
                'SELECT p.name
                 FROM role_permissions rp
                 INNER JOIN roles r       ON r.id = rp.role_id
                 INNER JOIN permissions p ON p.id = rp.permission_id
                 WHERE r.name = :role',
                ['role' => $role]
            );

            self::$cache[$role] = array_fill_keys(array_column($rows, 'name'), true);
        }

        return self::$cache[$role];
    }
}
