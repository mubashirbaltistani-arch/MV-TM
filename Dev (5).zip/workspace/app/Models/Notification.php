<?php
/**
 * In-app notifications (Phase 9).
 *
 * Writes go through NotificationHelper so that the "notifications_enabled"
 * system setting and length limits are applied consistently. This model is the
 * data access layer used by both the helper and the notification controller.
 */

declare(strict_types=1);

final class Notification extends Model
{
    public const TYPES = ['info', 'success', 'warning', 'danger'];

    public const TYPE_INFO    = 'info';
    public const TYPE_SUCCESS = 'success';
    public const TYPE_WARNING = 'warning';
    public const TYPE_DANGER  = 'danger';

    protected string $table = 'notifications';

    protected bool $timestamps = false;

    protected array $columns = [
        'id', 'user_id', 'type', 'title', 'message', 'link', 'is_read', 'read_at', 'created_at',
    ];

    protected array $fillable = ['user_id', 'type', 'title', 'message', 'link', 'is_read', 'read_at'];

    /** True when the notifications table is present. */
    public static function installed(): bool
    {
        static $installed = null;

        if ($installed === null) {
            try {
                $installed = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = 'notifications'"
                ) > 0;
            } catch (Throwable) {
                $installed = false;
            }
        }

        return $installed;
    }

    /**
     * Insert one notification and return its id (0 on failure).
     * Failures are swallowed: a notification must never break the business action.
     */
    public function createFor(int $userId, string $type, string $title, string $message, string $link = ''): int
    {
        if ($userId < 1 || !self::installed()) {
            return 0;
        }

        if (!in_array($type, self::TYPES, true)) {
            $type = self::TYPE_INFO;
        }

        try {
            Database::execute(
                'INSERT INTO notifications (user_id, type, title, message, link, is_read, created_at)
                 VALUES (:user_id, :type, :title, :message, :link, 0, UTC_TIMESTAMP())',
                [
                    'user_id' => $userId,
                    'type'    => $type,
                    'title'   => mb_substr(trim($title), 0, 160, 'UTF-8'),
                    'message' => mb_substr(trim($message), 0, 500, 'UTF-8'),
                    'link'    => mb_substr(trim($link), 0, 255, 'UTF-8'),
                ]
            );

            return Database::lastInsertId();
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            return 0;
        }
    }

    public function unreadCount(int $userId): int
    {
        try {
            return (int) Database::fetchValue(
                'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
                ['id' => $userId]
            );
        } catch (Throwable) {
            return 0;
        }
    }

    /**
     * Newest notifications for the header dropdown (read and unread).
     *
     * @return list<array<string, mixed>>
     */
    public function recent(int $userId, int $limit = 8): array
    {
        $limit = min(50, max(1, $limit));

        try {
            return Database::fetchAll(
                "SELECT id, type, title, message, link, is_read, created_at
                 FROM notifications
                 WHERE user_id = :id
                 ORDER BY is_read ASC, created_at DESC, id DESC
                 LIMIT {$limit}",
                ['id' => $userId]
            );
        } catch (Throwable) {
            return [];
        }
    }

    /**
     * Paginated history for the full notifications page.
     *
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int}
     */
    public function paginateFor(int $userId, int $page = 1, int $perPage = 20): array
    {
        $perPage = min(100, max(1, $perPage));

        try {
            $total = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM notifications WHERE user_id = :id',
                ['id' => $userId]
            );
        } catch (Throwable) {
            $total = 0;
        }

        $pages  = max(1, (int) ceil($total / $perPage));
        $page   = min(max(1, $page), $pages);
        $offset = ($page - 1) * $perPage;

        $items = Database::fetchAll(
            "SELECT id, type, title, message, link, is_read, read_at, created_at
             FROM notifications
             WHERE user_id = :id
             ORDER BY created_at DESC, id DESC
             LIMIT {$perPage} OFFSET {$offset}",
            ['id' => $userId]
        );

        return ['items' => $items, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'pages' => $pages];
    }

    /** Mark a single notification as read. Only the owner can do so (user_id guard). */
    public function markRead(int $id, int $userId): bool
    {
        if ($id < 1 || $userId < 1) {
            return false;
        }

        return Database::execute(
            'UPDATE notifications
             SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE id = :id AND user_id = :user_id AND is_read = 0',
            ['id' => $id, 'user_id' => $userId]
        ) > 0;
    }

    /** Mark every unread notification of a user as read; returns the number changed. */
    public function markAllRead(int $userId): int
    {
        if ($userId < 1) {
            return 0;
        }

        return Database::execute(
            'UPDATE notifications
             SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE user_id = :user_id AND is_read = 0',
            ['user_id' => $userId]
        );
    }

    public function findForUser(int $id, int $userId): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM notifications WHERE id = :id AND user_id = :user_id LIMIT 1',
            ['id' => $id, 'user_id' => $userId]
        );
    }
}
