<?php
/**
 * My profile: personal details, timezone and password change.
 *
 * @var array<string, mixed> $account   id, name, email, phone, job_title, timezone, last_login_at,
 *                                      password_changed_at, created_at, role_name
 * @var list<string>         $timezones
 */

// After a failed validation the flashed input wins over the stored value.
$val = static fn (string $key): string => old($key, (string) ($account[$key] ?? ''));
$selectedZone = old('timezone', (string) $account['timezone']);
?>
<div class="row g-4">
    <div class="col-xl-8">
        <section class="panel mb-4" aria-labelledby="details-title">
            <div class="panel-head">
                <h2 id="details-title" class="panel-title">Personal details</h2>
            </div>
            <form method="post" action="<?= e(url('/profile')) ?>" novalidate data-single-submit class="panel-body">
                <?= csrf_field() ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Full name</label>
                        <input type="text" id="name" name="name" maxlength="120" required autocomplete="name"
                               class="form-control<?= field_error('name') ? ' is-invalid' : '' ?>" value="<?= e($val('name')) ?>">
                        <?php if (field_error('name')): ?><div class="invalid-feedback"><?= e(field_error('name')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" class="form-control" value="<?= e($account['email']) ?>" disabled aria-describedby="email-help">
                        <div id="email-help" class="form-text">Your sign-in address. An administrator can change it.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="job_title" class="form-label">Job title</label>
                        <input type="text" id="job_title" name="job_title" maxlength="100" autocomplete="organization-title"
                               class="form-control<?= field_error('job_title') ? ' is-invalid' : '' ?>" value="<?= e($val('job_title')) ?>">
                        <?php if (field_error('job_title')): ?><div class="invalid-feedback"><?= e(field_error('job_title')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="tel" id="phone" name="phone" maxlength="30" autocomplete="tel"
                               class="form-control<?= field_error('phone') ? ' is-invalid' : '' ?>" value="<?= e($val('phone')) ?>">
                        <?php if (field_error('phone')): ?><div class="invalid-feedback"><?= e(field_error('phone')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-12">
                        <label for="timezone" class="form-label">Timezone</label>
                        <select id="timezone" name="timezone" class="form-select<?= field_error('timezone') ? ' is-invalid' : '' ?>" required aria-describedby="tz-help">
                            <?php foreach ($timezones as $zone): ?>
                                <option value="<?= e($zone) ?>"<?= $zone === $selectedZone ? ' selected' : '' ?>><?= e(str_replace('_', ' ', $zone)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('timezone')): ?><div class="invalid-feedback"><?= e(field_error('timezone')) ?></div><?php endif; ?>
                        <div id="tz-help" class="form-text">Dates and times across the app are shown in this timezone. Stored data stays in UTC.</div>
                    </div>
                </div>
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </section>

        <section class="panel" aria-labelledby="password-title">
            <div class="panel-head">
                <h2 id="password-title" class="panel-title">Change password</h2>
            </div>
            <form method="post" action="<?= e(url('/profile/password')) ?>" novalidate data-single-submit class="panel-body">
                <?= csrf_field() ?>
                <div class="row g-3">
                    <div class="col-12">
                        <label for="current_password" class="form-label">Current password</label>
                        <input type="password" id="current_password" name="current_password" required autocomplete="current-password"
                               class="form-control<?= field_error('current_password') ? ' is-invalid' : '' ?>">
                        <?php if (field_error('current_password')): ?><div class="invalid-feedback"><?= e(field_error('current_password')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="password" class="form-label">New password</label>
                        <input type="password" id="password" name="password" required autocomplete="new-password" aria-describedby="password-help"
                               class="form-control<?= field_error('password') ? ' is-invalid' : '' ?>" data-password-meter="#password-meter">
                        <?php if (field_error('password')): ?><div class="invalid-feedback"><?= e(field_error('password')) ?></div><?php endif; ?>
                        <div class="strength" id="password-meter" aria-live="polite"><span class="strength-bar"></span><span class="strength-text"></span></div>
                        <div id="password-help" class="form-text">10 to 72 characters with upper-case, lower-case and a number.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="password_confirmation" class="form-label">Confirm new password</label>
                        <input type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password"
                               class="form-control<?= field_error('password') ? ' is-invalid' : '' ?>">
                    </div>
                </div>
                <div class="mt-4">
                    <button type="submit" class="btn btn-primary">Update password</button>
                </div>
            </form>
        </section>
    </div>

    <div class="col-xl-4">
        <section class="panel" aria-labelledby="account-title">
            <div class="panel-head">
                <h2 id="account-title" class="panel-title">Account</h2>
            </div>
            <dl class="facts panel-body">
                <div><dt>Role</dt><dd><span class="role-pill role-<?= e(strtolower((string) $account['role_name'])) ?>"><?= e($account['role_name']) ?></span></dd></div>
                <div><dt>Member since</dt><dd><?= e(FormatHelper::date($account['created_at'])) ?></dd></div>
                <div><dt>Last sign-in</dt><dd><?= $account['last_login_at'] ? e(FormatHelper::datetime($account['last_login_at'], 'M j, Y \a\t H:i')) : 'This is your first sign-in' ?></dd></div>
                <div><dt>Password changed</dt><dd><?= $account['password_changed_at'] ? e(FormatHelper::date($account['password_changed_at'])) : 'Never' ?></dd></div>
            </dl>
        </section>
    </div>
</div>
