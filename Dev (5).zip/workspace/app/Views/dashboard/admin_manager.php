<?php
declare(strict_types=1);

/**
 * Admin / manager dashboard, laid out like Clockify's team dashboard:
 * summary strip, stacked daily chart, project donut + ranking, team activities table.
 * All numbers come from WeekDashboardHelper (real tracked time, nothing fabricated).
 *
 * @var array<string, mixed> $week
 * @var bool $canTrack
 * @var bool $canApprove
 * @var int $pendingApprovals
 * @var int $unread
 * @var list<array<string, mixed>> $notifications
 */

$dur = static fn (int $s): string => FormatHelper::duration($s);
$dashUrl = static fn (array $q): string => url('/dashboard') . '?' . http_build_query($q);
$who = !empty($week['only_me']) ? 'me' : 'team';

// Chart payload: one dataset per project, one value (hours) per weekday.
$labels   = [];
$totals   = [];
foreach ($week['days'] as $day) {
    $labels[] = $day['label'];
    $totals[] = (int) $day['seconds'];
}
$datasets = [];
foreach ($week['projects'] as $p) {
    $series = [];
    foreach ($week['days'] as $day) {
        $series[] = round(((int) ($day['projects'][$p['id']] ?? 0)) / 3600, 4);
    }
    $datasets[] = ['label' => $p['name'], 'color' => $p['color'], 'data' => $series];
}
$donut = [
    'labels' => array_map(static fn (array $p): string => $p['name'], $week['projects']),
    'data'   => array_map(static fn (array $p): int => (int) $p['seconds'], $week['projects']),
    'colors' => array_map(static fn (array $p): string => $p['color'], $week['projects']),
];
$json = static fn (mixed $v): string => e((string) json_encode($v, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));

$maxPerson = 0;
foreach ($week['people'] as $person) {
    $maxPerson = max($maxPerson, (int) $person['total']);
}
?>
<div class="wk-head">
    <h2 class="wk-title">Dashboard</h2>
    <div class="wk-controls">
        <?php if (!empty($canApprove) && (int) $pendingApprovals > 0): ?>
            <a class="wk-pill" href="<?= e(url('/timesheets/team')) ?>"><i class="fa-solid fa-clipboard-check" aria-hidden="true"></i> <?= (int) $pendingApprovals ?> pending approval<?= (int) $pendingApprovals === 1 ? '' : 's' ?></a>
        <?php endif; ?>

        <div class="dropdown">
            <button class="wk-select dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?= $who === 'me' ? 'Only me' : 'Team' ?>
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item<?= $who === 'team' ? ' active' : '' ?>" href="<?= e($dashUrl(['week' => $week['week_start'], 'who' => 'team'])) ?>">Team</a></li>
                <li><a class="dropdown-item<?= $who === 'me' ? ' active' : '' ?>" href="<?= e($dashUrl(['week' => $week['week_start'], 'who' => 'me'])) ?>">Only me</a></li>
            </ul>
        </div>

        <div class="wk-range">
            <span class="wk-range-label"><i class="fa-regular fa-calendar" aria-hidden="true"></i>
                <?= !empty($week['is_current']) ? 'This week' : e($week['range_label']) ?></span>
            <a class="wk-range-btn" href="<?= e($dashUrl(['week' => $week['prev_week'], 'who' => $who])) ?>" aria-label="Previous week"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></a>
            <a class="wk-range-btn" href="<?= e($dashUrl(['week' => $week['next_week'], 'who' => $who])) ?>" aria-label="Next week"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a>
        </div>
    </div>
</div>

<section class="wk-card">
    <div class="wk-summary">
        <div>
            <span class="wk-summary-label">Total time</span>
            <strong><?= e($dur((int) $week['total'])) ?></strong>
        </div>
        <div>
            <span class="wk-summary-label">Top Project</span>
            <strong class="text-truncate"><?= e($week['top_project']['name'] ?? '—') ?></strong>
        </div>
        <div>
            <span class="wk-summary-label">Top Client</span>
            <strong class="text-truncate"><?= e($week['top_client']['name'] ?? '—') ?></strong>
        </div>
    </div>

    <div class="wk-chart-wrap">
        <canvas id="weekStackChart"
                data-labels="<?= $json($labels) ?>"
                data-datasets="<?= $json($datasets) ?>"
                data-totals="<?= $json($totals) ?>"></canvas>
    </div>

    <div class="wk-breakdown">
        <div class="wk-donut-wrap">
            <?php if ($week['projects'] !== []): ?>
                <canvas id="weekDonutChart" data-donut="<?= $json($donut) ?>"></canvas>
                <div class="wk-donut-center"><?= e($dur((int) $week['total'])) ?></div>
            <?php else: ?>
                <div class="wk-empty">No time tracked in this period.</div>
            <?php endif; ?>
        </div>

        <ul class="wk-rank">
            <?php foreach ($week['projects'] as $p): ?>
                <li>
                    <span class="wk-rank-name">
                        <a href="<?= e(url('/projects/' . (int) $p['id'])) ?>"><?= e($p['name']) ?></a>
                        <?php if ($p['client'] !== ''): ?><span class="wk-rank-client"> - <?= e($p['client']) ?></span><?php endif; ?>
                    </span>
                    <span class="wk-rank-time"><?= e($dur((int) $p['seconds'])) ?></span>
                    <span class="wk-rank-bar"><span style="width: <?= e((string) min(100, $p['percent'])) ?>%; background: <?= e($p['color']) ?>"></span></span>
                    <span class="wk-rank-pct"><?= e(number_format((float) $p['percent'], 2, ',', '')) ?>%</span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<section class="wk-card wk-team">
    <div class="wk-team-head">
        <span>Team activities</span>
    </div>
    <div class="table-responsive">
        <table class="wk-table">
            <thead>
                <tr>
                    <th>Team member</th>
                    <th>Latest activity</th>
                    <th colspan="2">Total tracked (<?= !empty($week['is_current']) ? 'this week' : 'selected week' ?>)</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($week['people'] === []): ?>
                <tr><td colspan="4" class="wk-empty">No team members to display.</td></tr>
            <?php endif; ?>
            <?php foreach ($week['people'] as $person): ?>
                <?php $act = $person['activity']; ?>
                <tr>
                    <td class="wk-member">
                        <span class="wk-avatar" style="background: <?= e($person['color']) ?>"><?= e($person['initials']) ?></span>
                        <span class="wk-member-name"><?= e($person['name']) ?></span>
                    </td>
                    <td class="wk-activity">
                        <?php if ($act === null): ?>
                            <span class="text-secondary">(no activity)</span>
                        <?php else: ?>
                            <div class="wk-activity-grid">
                                <div class="wk-activity-text">
                                    <div class="wk-activity-desc"><?= $act['description'] !== '' ? e($act['description']) : '<span class="text-secondary">(no description)</span>' ?></div>
                                    <div class="wk-activity-proj"><i class="wk-dot"></i> <?= e($act['project']) ?><?= $act['task'] !== '' ? ': ' . e($act['task']) : '' ?></div>
                                </div>
                                <span class="wk-activity-dur">
                                    <?= e($dur((int) $act['seconds'])) ?>
                                    <?php if (!empty($act['running'])): ?><i class="wk-live" title="Timer running"></i><?php endif; ?>
                                </span>
                                <span class="wk-activity-ago <?= !empty($act['running']) ? 'is-live' : '' ?>"><?= e($act['ago']) ?></span>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td class="wk-total"><?= e($dur((int) $person['total'])) ?></td>
                    <td class="wk-minibar-cell">
                        <div class="wk-minibar">
                            <?php foreach ($person['segments'] as $seg): ?>
                                <span style="width: <?= $maxPerson > 0 ? e((string) round($seg['seconds'] / $maxPerson * 100, 2)) : 0 ?>%; background: <?= e($seg['color']) ?>"></span>
                            <?php endforeach; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section id="notifications" class="wk-card wk-notes"<?= $notifications === [] ? ' hidden' : '' ?>>
    <div class="wk-team-head d-flex justify-content-between align-items-center">
        <span>Notifications<?= (int) $unread > 0 ? ' (' . (int) $unread . ' new)' : '' ?></span>
        <?php if ((int) $unread > 0): ?>
            <form method="post" action="<?= e(url('/notifications/read')) ?>" class="m-0">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-outline-secondary">Mark all as read</button>
            </form>
        <?php endif; ?>
    </div>
    <ul class="wk-notes-list">
        <?php foreach ($notifications as $note): ?>
            <li class="<?= $note['is_read'] ? '' : 'is-unread' ?>">
                <?php if (!empty($note['link']) && str_starts_with((string) $note['link'], '/') && !str_starts_with((string) $note['link'], '//')): ?>
                    <a href="<?= e(url((string) $note['link'])) ?>"><?= e($note['title']) ?></a>
                <?php else: ?>
                    <?= e($note['title']) ?>
                <?php endif; ?>
                <time><?= e(FormatHelper::datetime((string) $note['created_at'], 'M j, H:i')) ?></time>
            </li>
        <?php endforeach; ?>
    </ul>
</section>