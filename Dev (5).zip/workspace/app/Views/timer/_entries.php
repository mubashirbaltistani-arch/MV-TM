<?php
/**
 * Clockify-style entries list: grouped by day, then by project + task.
 * Rendered inside index.php and re-fetched by timer.js after a timer stops,
 * so every element that must survive a swap lives inside [data-time-region].
 *
 * @var array $result
 * @var bool $viewAll
 * @var bool $canDelete
 * @var bool $canEditAll
 * @var int $userId
 * @var callable $qs
 * @var callable $statusClass
 */

$items = $result['items'];

/* ---- Group: local day -> (user + project + task) -> chunks ---------------- */
$days = [];
foreach ($items as $entry) {
    // Use the viewer's local date, not the UTC date stored in the DB, so a
    // 00:59 PKT entry lands on the correct day.
    $dayKey = FormatHelper::datetime((string) ($entry['start_time'] ?? ''), 'Y-m-d');
    $groupKey = ($viewAll ? (int) ($entry['user_id'] ?? 0) : 0)
        . '|' . (int) ($entry['project_id'] ?? 0)
        . '|' . (int) ($entry['task_id'] ?? 0);

    if (!isset($days[$dayKey])) {
        $days[$dayKey] = ['seconds' => 0, 'groups' => []];
    }
    if (!isset($days[$dayKey]['groups'][$groupKey])) {
        $days[$dayKey]['groups'][$groupKey] = ['entries' => [], 'seconds' => 0];
    }
    $days[$dayKey]['groups'][$groupKey]['entries'][] = $entry;
    $days[$dayKey]['groups'][$groupKey]['seconds'] += (int) ($entry['duration_seconds'] ?? 0);
    $days[$dayKey]['seconds'] += (int) ($entry['duration_seconds'] ?? 0);
}

$todayKey     = FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'Y-m-d');
$yesterdayKey = FormatHelper::datetime(gmdate('Y-m-d H:i:s', time() - 86400), 'Y-m-d');
$dayLabel = static function (string $key) use ($todayKey, $yesterdayKey): string {
    if ($key === $todayKey) { return 'Today'; }
    if ($key === $yesterdayKey) { return 'Yesterday'; }
    $d = DateTimeImmutable::createFromFormat('Y-m-d', $key);
    return $d ? $d->format('D, M j') : $key;
};

$lockedFn = static function (array $e): bool {
    $sheet = (string) ($e['timesheet_status'] ?? '');
    $status = $sheet !== '' ? $sheet : (string) ($e['status'] ?? TimeEntry::STATUS_PENDING);
    return $status === TimeEntry::STATUS_APPROVED || $sheet === 'Submitted' || (int) ($e['timesheet_id'] ?? 0) > 0;
};
$statusOf = static function (array $e): string {
    $sheet = (string) ($e['timesheet_status'] ?? '');
    return $sheet !== '' ? $sheet : (string) ($e['status'] ?? TimeEntry::STATUS_PENDING);
};
$canEditNote = static function (array $e) use ($lockedFn, $canDelete, $canEditAll, $userId): bool {
    $own = (int) $e['user_id'] === $userId;
    return !$lockedFn($e) && (($own && $canDelete) || $canEditAll);
};
$noteInput = static function (array $ids, string $value, string $placeholder): string {
    return '<input type="text" class="time-desc-input" maxlength="255" autocomplete="off"'
        . ' value="' . e($value) . '" data-original="' . e($value) . '"'
        . ' placeholder="' . e($placeholder) . '" aria-label="Description"'
        . ' data-time-desc data-ids="' . e(implode(',', $ids)) . '"'
        . ' data-url="' . e(url('/time/' . (int) $ids[0] . '/description')) . '">';
};
$deleteForm = function (array $e) use ($lockedFn, $canDelete, $canEditAll, $userId): string {
    $own = (int) $e['user_id'] === $userId;
    if ($lockedFn($e)) {
        return '<span class="small text-secondary"><i class="fa-solid fa-lock me-1" aria-hidden="true"></i>Locked</span>';
    }
    if (!(($own && $canDelete) || $canEditAll)) {
        return '';
    }
    return '<form method="post" action="' . e(url('/time/' . (int) $e['id'] . '/delete')) . '" class="d-inline" data-confirm="Delete this time entry?">'
        . csrf_field()
        . '<button type="submit" class="btn btn-sm btn-icon-delete" title="Delete entry" aria-label="Delete entry"><i class="fa-regular fa-trash-can" aria-hidden="true"></i></button></form>';
};
?>
<section class="panel time-list" data-time-region="entries">
    <div class="panel-head">
        <h2 class="panel-title">Entries <span class="count-pill"><?= (int) $result['total'] ?></span></h2>
    </div>

    <?php if ($items === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-clock" aria-hidden="true"></i>
            <p>No time entries match these filters.</p>
        </div>
    <?php else: ?>
        <?php foreach ($days as $dayKey => $day): ?>
            <div class="time-day-head">
                <span class="time-day-title"><?= e($dayLabel((string) $dayKey)) ?></span>
                <span class="time-day-total">Total: <strong class="mono"><?= e(FormatHelper::duration((int) $day['seconds'])) ?></strong></span>
            </div>

            <?php foreach ($day['groups'] as $groupKey => $group): ?>
                <?php
                $entries = $group['entries'];
                $multi   = count($entries) > 1;
                $first   = $entries[0];
                $gid     = 'tg-' . substr(md5($dayKey . '|' . $groupKey), 0, 12);

                // Entries are newest-first; the visible span is earliest start -> latest end.
                $starts = array_map(static fn ($x) => (string) $x['start_time'], $entries);
                $ends   = array_map(static fn ($x) => (string) $x['end_time'], $entries);
                $spanStart = min($starts);
                $spanEnd   = max($ends);

                $notes = array_values(array_unique(array_filter(array_map(
                    static fn ($x) => trim((string) ($x['description'] ?? '')),
                    $entries
                ), static fn ($v) => $v !== '')));
                $noteText = $notes === [] ? '' : $notes[0] . (count($notes) > 1 ? ' +' . (count($notes) - 1) : '');

                $statuses = array_values(array_unique(array_map($statusOf, $entries)));
                $groupStatus = count($statuses) === 1 ? $statuses[0] : 'Mixed';
                $groupClass  = count($statuses) === 1 ? $statusClass($statuses[0]) : 'planning';
                $billable = (int) ($first['is_billable'] ?? 0) === 1;
                ?>
                <div class="time-group<?= $multi ? ' is-multi' : '' ?>" data-time-group="<?= e($gid) ?>">
                    <div class="time-row time-row-main">
                        <div class="time-cell-count">
                            <?php if ($multi): ?>
                                <button type="button" class="time-count-badge" data-time-group-toggle="<?= e($gid) ?>" aria-expanded="false" aria-controls="<?= e($gid) ?>-chunks" title="Show <?= count($entries) ?> entries">
                                    <?= count($entries) ?>
                                </button>
                            <?php endif; ?>
                        </div>
                        <div class="time-cell-desc">
                            <?php
                            $editableIds = [];
                            foreach ($entries as $x) { if ($canEditNote($x)) { $editableIds[] = (int) $x['id']; } }
                            $allSame = count($notes) <= 1;
                            ?>
                            <?php if ($editableIds !== []): ?>
                                <?= $noteInput($editableIds, $allSame ? ($notes[0] ?? '') : '', $allSame ? 'Add description' : 'Multiple descriptions') ?>
                            <?php elseif ($noteText !== ''): ?>
                                <span class="time-desc"><?= e($noteText) ?></span>
                            <?php else: ?>
                                <span class="time-desc is-empty">No description</span>
                            <?php endif; ?>
                        </div>
                        <div class="time-cell-project">
                            <a href="<?= e(url('/projects/' . (int) $first['project_id'])) ?>" class="time-project"><span class="time-dot" aria-hidden="true"></span><?= e((string) $first['project_name']) ?></a><?php if (!empty($first['task_name'])): ?><span class="time-task">: <?= e((string) $first['task_name']) ?></span><?php endif; ?>
                            <?php if ($viewAll): ?><span class="time-person"><i class="fa-regular fa-user me-1" aria-hidden="true"></i><?= e((string) ($first['user_name'] ?? '')) ?></span><?php endif; ?>
                        </div>
                        <div class="time-cell-flag" title="<?= $billable ? 'Billable' : 'Non-billable' ?>">
                            <i class="fa-solid fa-dollar-sign<?= $billable ? '' : ' is-off' ?>" aria-hidden="true"></i>
                        </div>
                        <div class="time-cell-status"><span class="status-badge status-<?= e($groupClass) ?>"><?= e($groupStatus) ?></span></div>
                        <div class="time-cell-range mono">
                            <?= e(FormatHelper::datetime($spanStart, 'H:i')) ?> <span class="text-secondary">-</span> <?= e(FormatHelper::datetime($spanEnd, 'H:i')) ?>
                        </div>
                        <div class="time-cell-total mono"><?= e(FormatHelper::duration((int) $group['seconds'])) ?></div>
                        <div class="time-cell-actions"><?= $multi ? '' : $deleteForm($first) ?></div>
                    </div>

                    <?php if ($multi): ?>
                        <div class="time-chunks" id="<?= e($gid) ?>-chunks" hidden>
                            <?php foreach ($entries as $entry): ?>
                                <div class="time-row time-row-chunk">
                                    <div class="time-cell-count"></div>
                                    <div class="time-cell-desc">
                                        <?php if ($canEditNote($entry)): ?>
                                            <?= $noteInput([(int) $entry['id']], (string) ($entry['description'] ?? ''), 'Add description') ?>
                                        <?php elseif (!empty($entry['description'])): ?>
                                            <span class="time-desc"><?= e((string) $entry['description']) ?></span>
                                        <?php else: ?>
                                            <span class="time-desc is-empty">No description</span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="time-cell-project"></div>
                                    <div class="time-cell-flag"></div>
                                    <div class="time-cell-status"><span class="status-badge status-<?= e($statusClass($statusOf($entry))) ?>"><?= e($statusOf($entry)) ?></span></div>
                                    <div class="time-cell-range mono">
                                        <?= e(FormatHelper::datetime((string) $entry['start_time'], 'H:i')) ?> <span class="text-secondary">-</span> <?= e(FormatHelper::datetime((string) $entry['end_time'], 'H:i')) ?>
                                    </div>
                                    <div class="time-cell-total mono"><?= e(FormatHelper::duration((int) $entry['duration_seconds'])) ?></div>
                                    <div class="time-cell-actions"><?= $deleteForm($entry) ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        <?php endforeach; ?>

        <?php if ($result['pages'] > 1): ?>
            <nav class="pager" aria-label="Time entry pages">
                <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
                    <a class="btn btn-sm <?= $p === (int) $result['page'] ? 'btn-primary' : 'btn-outline-secondary' ?>"
                       href="<?= e(url('/time') . $qs(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>
