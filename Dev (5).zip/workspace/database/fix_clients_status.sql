-- =====================================================================
--  TimeTrack: one-time fix for the clients table (Phase 2)
--
--  Problem : the live table stores status as 'Active' / 'Inactive' /
--            'Archived', but the application expects lowercase 'active' /
--            'inactive' (badge colours, the edit form's preselected value
--            and the status filter depend on it). It also limits the client
--            name to 120 characters while the form allows 160.
--
--  Run ONCE on your existing (live) database, after taking a backup
--  (phpMyAdmin > Export). It is safe to run again.
--
--      mysql -u USER -p DATABASE < database/fix_clients_status.sql
--
--  'Archived' clients become 'inactive' (the application has no archived
--  client state). Nothing else in the database is touched.
-- =====================================================================

SET NAMES utf8mb4;

-- 1. Temporarily widen the column so existing values can be rewritten.
ALTER TABLE `clients`
    MODIFY `status` VARCHAR(20) NOT NULL DEFAULT 'active';

-- 2. Normalise the values: Inactive/Archived -> inactive, everything else -> active.
UPDATE `clients`
   SET `status` = CASE
        WHEN LOWER(`status`) IN ('inactive', 'archived') THEN 'inactive'
        ELSE 'active'
   END;

-- 3. Lock the column down to the two values the application uses,
--    and allow names up to the 160 characters the form accepts.
ALTER TABLE `clients`
    MODIFY `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
    MODIFY `name`   VARCHAR(160) NOT NULL;