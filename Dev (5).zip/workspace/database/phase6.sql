-- =====================================================================
--  TimeTrack: Phase 6 schema, server-authoritative timer and time entries
--  Run AFTER Phase 1, 2, 4 and 5 on an existing database.
--  Safe to re-run: tables use IF NOT EXISTS.
--
--      mysql -u USER -p DATABASE < database/phase6.sql
--
--  Requires: users, projects, tasks, schedules.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- active_timers: at most one running timer per user (UNIQUE user_id)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `active_timers` (
    `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id`          INT UNSIGNED NOT NULL,
    `project_id`       INT UNSIGNED NOT NULL,
    `task_id`          INT UNSIGNED NULL,
    `started_at`       DATETIME     NOT NULL,
    `last_activity_at` DATETIME     NOT NULL,
    `description`      VARCHAR(255) NULL,
    `is_billable`      TINYINT(1)   NOT NULL DEFAULT 1,
    `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_active_timers_user` (`user_id`),
    KEY `idx_active_timers_project` (`project_id`),
    KEY `idx_active_timers_task` (`task_id`),
    CONSTRAINT `fk_active_timers_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_active_timers_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_active_timers_task`
        FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- time_entries: completed timer runs and manual entries
-- Statuses: Pending, Approved, Rejected
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `time_entries` (
    `id`               INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `user_id`          INT UNSIGNED  NOT NULL,
    `project_id`       INT UNSIGNED  NOT NULL,
    `task_id`          INT UNSIGNED  NULL,
    `schedule_id`      INT UNSIGNED  NULL,
    `start_time`       DATETIME      NOT NULL,
    `end_time`         DATETIME      NOT NULL,
    `duration_seconds` INT UNSIGNED  NOT NULL,
    `break_minutes`    INT UNSIGNED  NOT NULL DEFAULT 0,
    `description`      VARCHAR(255)  NULL,
    `is_billable`      TINYINT(1)    NOT NULL DEFAULT 1,
    `billable_rate`    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    `status`           ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    `approved_by`      INT UNSIGNED  NULL,
    `approved_at`      DATETIME      NULL,
    `created_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_time_entries_user_start` (`user_id`, `start_time`),
    KEY `idx_time_entries_project` (`project_id`),
    KEY `idx_time_entries_task` (`task_id`),
    KEY `idx_time_entries_schedule` (`schedule_id`),
    KEY `idx_time_entries_status` (`status`),
    KEY `idx_time_entries_billable` (`is_billable`),
    KEY `idx_time_entries_approved_by` (`approved_by`),
    CONSTRAINT `fk_time_entries_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_task`
        FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_schedule`
        FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_approved_by`
        FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
    ('time.track',    'Track time',         'time', 'Start and stop timers.'),
    ('time.view_own', 'View own time',      'time', 'See own time entries.'),
    ('time.view_all', 'View all time',      'time', 'See everyone''s time entries.'),
    ('time.edit_own', 'Edit own time',      'time', 'Add and edit own time entries.'),
    ('time.edit_all', 'Edit all time',      'time', 'Edit anyone''s time entries.'),
    ('time.approve',  'Approve timesheets', 'time', 'Approve or reject submitted timesheets.')
ON DUPLICATE KEY UPDATE `display_name` = VALUES(`display_name`);

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, `id` FROM `permissions` WHERE `module` = 'time';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, `id` FROM `permissions`
WHERE `name` IN ('time.track', 'time.view_own', 'time.view_all', 'time.edit_own', 'time.approve');

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 3, `id` FROM `permissions`
WHERE `name` IN ('time.track', 'time.view_own', 'time.edit_own');
