-- =====================================================================
--  TimeTrack: consolidated seed data (matches the Phase 1-10 database)
--  Run AFTER schema.sql. Safe to re-run: existing users and settings are
--  never overwritten; roles and permissions are refreshed.
--
--  Default logins (all use the password  Password@123):
--      admin@timetrack.local     Admin
--      manager@timetrack.local   Manager
--      john@timetrack.local      Employee
--      sarah@timetrack.local     Employee
--
--  SECURITY: these accounts are for local setup only. On any server that is
--  reachable from the internet, create your own admin in Users, then DELETE
--  or disable all four @timetrack.local accounts before going live.
-- =====================================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- Workspace (single initial workspace; Projects/Tasks are governed by it).
INSERT INTO `workspaces` (`id`, `name`, `created_by`)
SELECT 1,
       'TimeTrack',
       (SELECT id FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1)
WHERE NOT EXISTS (SELECT 1 FROM workspaces);

-- ---------------------------------------------------------------------
-- Roles (ids are fixed: the application relies on them)
-- ---------------------------------------------------------------------
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`) VALUES
    (1, 'admin',    'Administrator', 'Full access to every module and setting.'),
    (2, 'manager',  'Manager',       'Manages clients, projects, teams and approvals.'),
    (3, 'employee', 'Employee',      'Tracks time on the projects they are assigned to.'),
    (4, 'client',   'Client',        'Read-only view of their own projects and reports.')
ON DUPLICATE KEY UPDATE
    `display_name` = VALUES(`display_name`),
    `description`  = VALUES(`description`);

-- ---------------------------------------------------------------------
-- Permissions
-- ---------------------------------------------------------------------
INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
    ('dashboard.view', 'View dashboard', 'dashboard', 'Open the dashboard.'),
    ('notifications.view', 'View notifications', 'notifications', 'See own notifications.'),
    ('users.view', 'View users', 'users', 'See the user directory.'),
    ('users.create', 'Create users', 'users', 'Add new users.'),
    ('users.edit', 'Edit users', 'users', 'Change user details, roles and status.'),
    ('users.delete', 'Delete users', 'users', 'Remove users.'),
    ('roles.manage', 'Manage roles', 'users', 'Edit roles and their permissions.'),
    ('clients.view', 'View clients', 'clients', 'See the client list.'),
    ('clients.create', 'Create clients', 'clients', 'Add new clients.'),
    ('clients.edit', 'Edit clients', 'clients', 'Change client details.'),
    ('clients.delete', 'Delete clients', 'clients', 'Remove clients.'),
    ('projects.view', 'View projects', 'projects', 'See projects the user is assigned to.'),
    ('projects.view_all', 'View all projects', 'projects', 'See every project, assigned or not.'),
    ('projects.create', 'Create projects', 'projects', 'Add new projects.'),
    ('projects.edit', 'Edit projects', 'projects', 'Change project details.'),
    ('projects.delete', 'Delete projects', 'projects', 'Remove projects.'),
    ('projects.archive', 'Archive projects', 'projects', 'Archive and restore projects.'),
    ('projects.manage_members', 'Manage project members', 'projects', 'Assign and remove project members.'),
    ('tasks.view', 'View tasks', 'tasks', 'See tasks on assigned projects.'),
    ('tasks.create', 'Create tasks', 'tasks', 'Add tasks to projects.'),
    ('tasks.edit', 'Edit tasks', 'tasks', 'Change tasks.'),
    ('tasks.delete', 'Delete tasks', 'tasks', 'Remove tasks.'),
    ('tasks.assign', 'Assign tasks', 'tasks', 'Assign tasks to people.'),
    ('time.track', 'Track time', 'time', 'Start and stop timers.'),
    ('time.view_own', 'View own time', 'time', 'See own time entries.'),
    ('time.view_all', 'View all time', 'time', 'See everyone\'s time entries.'),
    ('time.edit_own', 'Edit own time', 'time', 'Add and edit own time entries.'),
    ('time.edit_all', 'Edit all time', 'time', 'Edit anyone\'s time entries.'),
    ('time.approve', 'Approve timesheets', 'time', 'Approve or reject submitted timesheets.'),
    ('reports.view', 'View reports', 'reports', 'Open reports.'),
    ('reports.export', 'Export reports', 'reports', 'Download reports as CSV/PDF.'),
    ('reports.billing', 'View billing figures', 'reports', 'See rates, budgets and billable amounts.'),
    ('activity.view', 'View activity log', 'system', 'Read the audit trail.'),
    ('settings.manage', 'Manage settings', 'system', 'Change system settings.'),
    ('workspace.manage', 'Manage workspace', 'workspace', 'Change workspace identity, policies and workspace permissions.'),
    ('schedule.view', 'View schedule', 'schedule', 'See planned work on assigned projects.'),
    ('schedule.create', 'Create schedule', 'schedule', 'Add planned work blocks.'),
    ('schedule.edit', 'Edit schedule', 'schedule', 'Change planned work blocks.'),
    ('schedule.delete', 'Delete schedule', 'schedule', 'Remove planned work blocks.'),
    ('schedule.view_team', 'View team schedule', 'schedule', 'See planned work for the whole team.')
ON DUPLICATE KEY UPDATE
    `display_name` = VALUES(`display_name`),
    `module`       = VALUES(`module`),
    `description`  = VALUES(`description`);

-- ---------------------------------------------------------------------
-- Role -> permission mapping (by permission name, so ids never matter)
-- ---------------------------------------------------------------------
-- admin (39 permissions)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, p.`id` FROM `permissions` p
WHERE p.`name` IN (
    'dashboard.view',
    'notifications.view',
    'users.view',
    'users.create',
    'users.edit',
    'users.delete',
    'roles.manage',
    'clients.view',
    'clients.create',
    'clients.edit',
    'clients.delete',
    'projects.view',
    'projects.view_all',
    'projects.create',
    'projects.edit',
    'projects.delete',
    'projects.archive',
    'projects.manage_members',
    'tasks.view',
    'tasks.create',
    'tasks.edit',
    'tasks.delete',
    'tasks.assign',
    'time.track',
    'time.view_own',
    'time.view_all',
    'time.edit_own',
    'time.edit_all',
    'time.approve',
    'reports.view',
    'reports.export',
    'reports.billing',
    'activity.view',
    'settings.manage',
    'workspace.manage',
    'schedule.view',
    'schedule.create',
    'schedule.edit',
    'schedule.delete',
    'schedule.view_team'
);

-- manager (30 permissions)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, p.`id` FROM `permissions` p
WHERE p.`name` IN (
    'dashboard.view',
    'notifications.view',
    'users.view',
    'clients.view',
    'clients.create',
    'clients.edit',
    'projects.view',
    'projects.create',
    'projects.edit',
    'projects.archive',
    'projects.manage_members',
    'tasks.view',
    'tasks.create',
    'tasks.edit',
    'tasks.delete',
    'tasks.assign',
    'time.track',
    'time.view_own',
    'time.view_all',
    'time.edit_own',
    'time.approve',
    'reports.view',
    'reports.export',
    'reports.billing',
    'activity.view',
    'schedule.view',
    'schedule.create',
    'schedule.edit',
    'schedule.delete',
    'schedule.view_team'
);

-- employee (12 permissions)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 3, p.`id` FROM `permissions` p
WHERE p.`name` IN (
    'dashboard.view',
    'notifications.view',
    'projects.view',
    'tasks.view',
    'tasks.edit',
    'time.track',
    'time.view_own',
    'time.edit_own',
    'reports.view',
    'schedule.view',
    'schedule.create',
    'schedule.edit'
);

-- client (5 permissions)
INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 4, p.`id` FROM `permissions` p
WHERE p.`name` IN (
    'dashboard.view',
    'notifications.view',
    'projects.view',
    'reports.view',
    'schedule.view'
);

-- ---------------------------------------------------------------------
-- Default users  (bcrypt hash of Password@123)
-- ---------------------------------------------------------------------
INSERT IGNORE INTO `users`
    (`role_id`, `role`, `name`, `email`, `password`, `job_title`, `timezone`, `status`, `password_changed_at`)
VALUES
    (1, 'admin',    'System Admin',   'admin@timetrack.local',   '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', 'Administrator',    'UTC', 'active', UTC_TIMESTAMP()),
    (2, 'manager',  'Morgan Lee',     'manager@timetrack.local', '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', 'Project Manager',  'UTC', 'active', UTC_TIMESTAMP()),
    (3, 'employee', 'John Carter',    'john@timetrack.local',    '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', 'Developer',        'UTC', 'active', UTC_TIMESTAMP()),
    (3, 'employee', 'Sarah Khan',     'sarah@timetrack.local',   '$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC', 'Designer',         'UTC', 'active', UTC_TIMESTAMP());

-- A welcome message for each seeded user (only on first run)
INSERT INTO `notifications` (`user_id`, `type`, `title`, `message`, `link`)
SELECT u.`id`, 'info', 'Welcome to TimeTrack',
       'Your account is ready. Change the default password from your profile before you start.',
       '/profile'
FROM `users` u
WHERE u.`email` IN ('admin@timetrack.local', 'manager@timetrack.local', 'john@timetrack.local', 'sarah@timetrack.local')
  AND NOT EXISTS (SELECT 1 FROM `notifications` n WHERE n.`user_id` = u.`id` AND n.`title` = 'Welcome to TimeTrack');

-- ---------------------------------------------------------------------
-- Default system settings (includes the Phase 9 billing/general keys)
-- ---------------------------------------------------------------------
INSERT IGNORE INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`) VALUES
    ('app_name', 'TimeTrack', 'string', 'general', 'Name shown in the header and emails.'),
    ('company_email', 'hello@timetrack.local', 'string', 'general', 'Contact address for system emails.'),
    ('default_timezone', 'UTC', 'string', 'general', 'Timezone used when a user has not chosen one.'),
    ('date_format', 'M j, Y', 'string', 'general', 'PHP date() format for dates.'),
    ('time_format', 'H:i', 'string', 'general', 'PHP date() format for times.'),
    ('currency', 'USD', 'string', 'billing', 'ISO currency code for rates and budgets.'),
    ('default_hourly_rate', '0', 'string', 'billing', 'Rate applied to billable projects without their own rate.'),
    ('allow_manual_time_entries', '1', 'bool', 'time', 'Let employees add time entries by hand.'),
    ('timer_max_hours', '12', 'int', 'time', 'Stop a running timer automatically after this many hours.'),
    ('notifications_enabled', '1', 'bool', 'system', 'Create in-app notifications.'),
    ('maintenance_mode', '0', 'bool', 'system', 'Block non-admin sign-ins while maintenance is under way.'),
    ('currency_symbol', '$', 'string', 'billing', 'Symbol shown next to money amounts.');

-- ---------------------------------------------------------------------
-- Initial workspace identity.
INSERT INTO `workspaces` (`id`, `name`, `created_by`)
SELECT 1,
       'TimeTrack',
       (SELECT id FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1)
WHERE NOT EXISTS (SELECT 1 FROM workspaces);