<?php
/**
 * CLI/shared-hosting cleanup for expired running timers.
 *
 * Recommended cron cadence: every minute.
 * Example:
 *   * * * * * /usr/bin/php /home/USER/public_html/Dev/tools/cron_auto_stop.php
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found.\n");
}

if (PHP_VERSION_ID < 80200) {
    fwrite(STDERR, "PHP 8.2 or newer is required.\n");
    exit(1);
}

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');

spl_autoload_register(static function (string $class): void {
    if (!preg_match('/^[A-Za-z][A-Za-z0-9]*$/', $class)) {
        return;
    }

    $names = [$class];
    if (str_ends_with($class, 'Helper')) {
        $names[] = substr($class, 0, -strlen('Helper'));
    }

    foreach (['Core', 'Helpers', 'Middleware', 'Controllers', 'Models'] as $folder) {
        foreach ($names as $name) {
            $file = APP_PATH . '/' . $folder . '/' . $name . '.php';
            if (is_file($file)) {
                require $file;
                return;
            }
        }
    }
});

date_default_timezone_set('UTC');
Config::load(require CONFIG_PATH . '/config.php');
Config::set('database', require CONFIG_PATH . '/database.php');

try {
    $entries = (new Timer())->cleanupExpired();
    printf("Auto-stop cleanup complete: %d timer(s) stopped.\n", count($entries));
    exit(0);
} catch (Throwable $e) {
    LoggerHelper::exception($e);
    fwrite(STDERR, "Auto-stop cleanup failed. See the application log.\n");
    exit(1);
}
