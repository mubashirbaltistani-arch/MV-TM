<?php
/**
 * Server-authoritative timer and time entries.
 *
 * Start/stop/status are JSON-friendly so the global bar and data-timer-start
 * buttons stay in sync. Manual entries go through CSRF and duration validation.
 */

declare(strict_types=1);

final class TimerController extends Controller
{
    private Timer $timers;
    private TimeEntry $entries;
    private Project $projects;
    private Task $tasks;

    public function __construct()
    {
        parent::__construct(true);
        $this->timers   = new Timer();
        $this->entries  = new TimeEntry();
        $this->projects = new Project();
        $this->tasks    = new Task();
    }

    /** GET /time */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled();

        $userId  = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('time.view_all');

        $from = $this->dateOrEmpty((string) $request->input('from', ''));
        $to   = $this->dateOrEmpty((string) $request->input('to', ''));

        $filters = [
            'from'       => $from,
            'to'         => $to,
            'project_id' => (int) $request->input('project_id', 0),
            'task_id'    => (int) $request->input('task_id', 0),
            'billable'   => (string) $request->input('billable', ''),
            'status'     => (string) $request->input('status', ''),
            'user_id'    => $viewAll ? (int) $request->input('user_id', 0) : $userId,
        ];

        if (!$viewAll) {
            $filters['user_id'] = $userId;
        }

        $emptyResult = [
            'items'    => [],
            'total'    => 0,
            'page'     => 1,
            'per_page' => 25,
            'pages'    => 1,
            'totals'   => ['seconds' => 0, 'billable_seconds' => 0, 'count' => 0],
        ];

        try {
            $result = $this->entries->listFiltered($filters, (int) $request->input('page', 1), 25);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $result = $emptyResult;
        }

        try {
            $projects = $this->entries->trackableProjects($userId, PermissionHelper::has('projects.view_all'));
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $projects = [];
        }

        try {
            $filterProjects = $this->filterProjects($userId, $viewAll);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $filterProjects = [];
        }

        try {
            $tasks = $filters['project_id'] > 0 ? $this->entries->tasksForProject($filters['project_id']) : [];
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $tasks = [];
        }

        try {
            $people = $viewAll ? $this->activePeople() : [];
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $people = [];
        }

        $this->view('timer/index', [
            'pageTitle'     => 'Time',
            'result'        => $result,
            'filters'       => $filters,
            'projects'      => $projects,
            'filterProjects'=> $filterProjects,
            'tasks'         => $tasks,
            'people'        => $people,
            'viewAll'       => $viewAll,
            'canTrack'      => PermissionHelper::has('time.track'),
            'canManual'     => $this->allowManual() && PermissionHelper::has('time.edit_own'),
            'canDelete'     => PermissionHelper::has('time.edit_own'),
            'canEditAll'    => PermissionHelper::has('time.edit_all'),
            'activeTimer'   => $this->safeActiveTimer($userId),
            'showManual'    => (string) $request->input('manual', '') === '1',
        ]);
    }

    /** GET /time/status  GET /timer/status */
    public function status(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled(true);

        AuthHelper::releaseSession();

        $timer = $this->timers->getActive((int) AuthHelper::id());

        $this->json([
            'ok'         => true,
            'timer'      => $timer === null ? null : $this->timerPayload($timer),
            'server_now' => time(),
        ]);
    }

    /** POST /time/start  POST /timer/start */
    public function start(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        $projectId   = (int) $request->input('project_id', 0);
        $taskId      = (int) $request->input('task_id', 0);
        $description = trim((string) $request->input('description', ''));
        $billableIn  = $request->input('is_billable', $request->input('billable', null));

        $project = $this->assertTrackableProject($projectId);

        $task = null;
        if ($taskId > 0) {
            $task = $this->assertTrackableTask($taskId, $projectId);
        } else {
            $taskId = 0;
        }

        $isBillable = $billableIn === null
            ? (int) $project['is_billable'] === 1
            : in_array($billableIn, [1, '1', true, 'true', 'on', 'yes'], true);

        try {
            $timer = $this->timers->start(
                (int) AuthHelper::id(),
                $projectId,
                $taskId > 0 ? $taskId : null,
                $description,
                $isBillable
            );
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.started', 'timer', (int) $timer['id'], [
            'project_id' => $projectId,
            'task_id'    => $taskId > 0 ? $taskId : null,
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'timer' => $this->timerPayload($timer),
            ]);
        }

        $label = (string) $project['name'];
        if ($task !== null) {
            $label .= ' / ' . $task['name'];
        }
        $this->flash('success', 'Timer started on ' . $label . '.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/pause  POST /timer/pause */
    public function pause(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        try {
            $timer = $this->timers->pause((int) AuthHelper::id());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.paused', 'timer', (int) $timer['id']);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'timer' => $this->timerPayload($timer),
            ]);
        }

        $this->flash('success', 'Timer paused.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/resume  POST /timer/resume */
    public function resume(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        try {
            $timer = $this->timers->resume((int) AuthHelper::id());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.resumed', 'timer', (int) $timer['id']);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'timer' => $this->timerPayload($timer),
            ]);
        }

        $this->flash('success', 'Timer resumed.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/stop  POST /timer/stop */
    public function stop(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled($request->wantsJson());

        try {
            $entry = $this->timers->stop((int) AuthHelper::id());
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('timer.stopped', 'time_entry', (int) $entry['id'], [
            'project_id'       => (int) $entry['project_id'],
            'duration_seconds' => (int) $entry['duration_seconds'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'    => true,
                'entry' => $this->entryPayload($entry),
                'timer' => null,
            ]);
        }

        $this->flash('success', 'Timer stopped. ' . FormatHelper::duration((int) $entry['duration_seconds']) . ' saved.');
        $this->redirect($this->backPath('/time'));
    }

    /** POST /time/ping  POST /timer/ping */
    public function ping(Request $request, array $params): void
    {
        PermissionHelper::require('time.track');
        $this->requireInstalled(true);

        $ok = $this->timers->ping((int) AuthHelper::id());
        AuthHelper::releaseSession();

        $this->json(['ok' => $ok]);
    }

    /** POST /time/manual */
    public function manualStore(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled($request->wantsJson());

        if (!$this->allowManual()) {
            $this->failTimer('Manual time entries are turned off.', 403);
        }

        $failPath = '/time?manual=1';

        $data = $this->validate([
            'project_id'    => 'required|int|exists:projects,id',
            'task_id'       => 'nullable|int',
            'start_time'    => 'required|datetime',
            'end_time'      => 'required|datetime',
            'break_minutes' => 'nullable|int|min:0|max:1440',
            'description'   => 'nullable|string|max:255',
            'is_billable'   => 'nullable|boolean',
        ], $failPath, [
            'project_id'    => 'Project',
            'task_id'       => 'Task',
            'start_time'    => 'Start',
            'end_time'      => 'End',
            'break_minutes' => 'Break',
            'description'   => 'Description',
        ]);

        $project = $this->assertTrackableProject((int) $data['project_id']);

        $taskId = (int) ($data['task_id'] ?? 0);
        if ($taskId > 0) {
            $this->assertTrackableTask($taskId, (int) $project['id']);
        } else {
            $taskId = 0;
        }

        $startUtc = FormatHelper::toUtc((string) $data['start_time']);
        $endUtc   = FormatHelper::toUtc((string) $data['end_time']);

        if ($startUtc === null || $endUtc === null) {
            $this->failTimerFields($failPath, ['start_time' => 'Start and end must be valid date and time.']);
        }

        $break = (int) ($data['break_minutes'] ?? 0);

        try {
            TimeEntry::computeDuration($startUtc, $endUtc, $break);
        } catch (InvalidArgumentException $e) {
            $this->failTimerFields($failPath, ['end_time' => $e->getMessage()]);
        }

        $isBillable = $data['is_billable'] === null
            ? (int) $project['is_billable'] === 1
            : (int) $data['is_billable'] === 1;

        try {
            $entry = $this->entries->createEntry([
                'user_id'       => (int) AuthHelper::id(),
                'project_id'    => (int) $project['id'],
                'task_id'       => $taskId > 0 ? $taskId : null,
                'start_time'    => $startUtc,
                'end_time'      => $endUtc,
                'break_minutes' => $break,
                'description'   => $data['description'] ?? null,
                'is_billable'   => $isBillable ? 1 : 0,
                'billable_rate' => (float) $project['hourly_rate'],
                'status'        => TimeEntry::STATUS_PENDING,
            ]);
        } catch (InvalidArgumentException $e) {
            $this->failTimerFields($failPath, ['end_time' => $e->getMessage()]);
        }

        LoggerHelper::audit('time_entry.created', 'time_entry', (int) $entry['id'], [
            'project_id'       => (int) $entry['project_id'],
            'duration_seconds' => (int) $entry['duration_seconds'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'entry' => $this->entryPayload($entry)]);
        }

        $this->flash('success', 'Time entry of ' . FormatHelper::duration((int) $entry['duration_seconds']) . ' was saved.');
        $this->redirect('/time');
    }

    /** POST /time/{id} */
    public function updateEntry(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled($request->wantsJson());

        $id    = (int) ($params['id'] ?? 0);
        $entry = $this->entries->findWithRelations($id);
        if ($entry === null) {
            $this->notFound();
        }

        $userId = (int) AuthHelper::id();
        if ((int) $entry['user_id'] !== $userId && !PermissionHelper::has('time.edit_all')) {
            $this->forbidden();
        }

        $failPath = $this->backPath('/time');

        $data = $this->validate([
            'project_id'    => 'required|int|exists:projects,id',
            'task_id'       => 'nullable|int',
            'start_time'    => 'required|datetime',
            'end_time'      => 'required|datetime',
            'break_minutes' => 'nullable|int|min:0|max:1440',
            'description'   => 'nullable|string|max:255',
            'is_billable'   => 'nullable|boolean',
        ], $failPath, [
            'project_id'    => 'Project',
            'task_id'       => 'Task',
            'start_time'    => 'Start',
            'end_time'      => 'End',
            'break_minutes' => 'Break',
            'description'   => 'Description',
        ]);

        $project = $this->assertTrackableProject((int) $data['project_id']);

        $taskId = (int) ($data['task_id'] ?? 0);
        if ($taskId > 0) {
            $this->assertTrackableTask($taskId, (int) $project['id']);
        } else {
            $taskId = 0;
        }

        $startUtc = FormatHelper::toUtc((string) $data['start_time']);
        $endUtc   = FormatHelper::toUtc((string) $data['end_time']);

        if ($startUtc === null || $endUtc === null) {
            $this->failTimerFields($failPath, ['start_time' => 'Start and end must be valid date and time.']);
        }

        $break = (int) ($data['break_minutes'] ?? 0);
        $isBillable = $data['is_billable'] === null
            ? (int) $entry['is_billable'] === 1
            : (int) $data['is_billable'] === 1;

        try {
            $updated = $this->entries->updateEntry($id, [
                'project_id'    => (int) $project['id'],
                'task_id'       => $taskId > 0 ? $taskId : null,
                'start_time'    => $startUtc,
                'end_time'      => $endUtc,
                'break_minutes' => $break,
                'description'   => $data['description'] ?? null,
                'is_billable'   => $isBillable ? 1 : 0,
                'billable_rate' => (float) $project['hourly_rate'],
            ]);
        } catch (InvalidArgumentException $e) {
            $this->failTimerFields($failPath, ['end_time' => $e->getMessage()]);
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('time_entry.updated', 'time_entry', $id, [
            'project_id'       => (int) $updated['project_id'],
            'duration_seconds' => (int) $updated['duration_seconds'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true, 'entry' => $this->entryPayload($updated)]);
        }

        $this->flash('success', 'Time entry was updated.');
        $this->redirect($failPath);
    }

    /** POST /time/{id}/delete */
    public function deleteEntry(Request $request, array $params): void
    {
        PermissionHelper::require('time.edit_own');
        $this->requireInstalled($request->wantsJson());

        $id    = (int) ($params['id'] ?? 0);
        $entry = $this->entries->findWithRelations($id);
        if ($entry === null) {
            $this->notFound();
        }

        $userId = (int) AuthHelper::id();
        if ((int) $entry['user_id'] !== $userId && !PermissionHelper::has('time.edit_all')) {
            $this->forbidden();
        }

        try {
            $this->entries->deleteEntry($id, $entry);
        } catch (RuntimeException $e) {
            $this->failTimer($e->getMessage(), 409);
        }

        LoggerHelper::audit('time_entry.deleted', 'time_entry', $id, [
            'project_id' => (int) $entry['project_id'],
        ]);

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json(['ok' => true]);
        }

        $this->flash('success', 'Time entry was deleted.');
        $this->redirect($this->backPath('/time'));
    }

    /** GET /time/tasks?project_id= */
    public function tasksJson(Request $request, array $params): void
    {
        PermissionHelper::require('time.view_own');
        $this->requireInstalled(true);

        $projectId = (int) $request->input('project_id', 0);
        $this->assertTrackableProject($projectId);

        $this->json(['ok' => true, 'tasks' => $this->entries->tasksForProject($projectId)]);
    }

    private function requireInstalled(bool $asJson = false): void
    {
        if (Timer::installed() && TimeEntry::installed()) {
            return;
        }

        if ($asJson || $this->request->wantsJson()) {
            $this->json(['ok' => false, 'error' => ['status' => 503, 'message' => 'Time tracking is not installed yet.']], 503);
        }

        $this->flash('warning', 'Time tracking tables are not installed. Import database/phase6.sql.');
        $this->redirect('/dashboard');
    }

    /** @return array<string, mixed> */
    private function assertTrackableProject(int $projectId): array
    {
        if ($projectId < 1) {
            $this->failTimer('Choose a project.', 422);
        }

        $project = $this->projects->find($projectId);
        if ($project === null) {
            $this->notFound();
        }

        $userId = (int) AuthHelper::id();
        if (!$this->projects->userCanView($project, $userId, PermissionHelper::has('projects.view_all'))) {
            $this->forbidden();
        }

        if (!in_array((string) $project['status'], Project::OPEN_STATUSES, true)) {
            $this->failTimer('Time can only be tracked on open projects.', 422);
        }

        return $project;
    }

    /**
     * @return array<string, mixed>
     */
    private function assertTrackableTask(int $taskId, int $projectId): array
    {
        if (!Task::installed()) {
            $this->failTimer('Tasks are not available.', 422);
        }

        $task = $this->tasks->find($taskId);
        if ($task === null || (int) $task['project_id'] !== $projectId) {
            $this->failTimer('That task does not belong to the selected project.', 422);
        }

        return $task;
    }

    private function failTimer(string $message, int $status = 422): never
    {
        if ($this->request->wantsJson() || $this->request->isAjax()) {
            $this->json(['ok' => false, 'message' => $message], $status);
        }

        $this->flash($status >= 500 ? 'danger' : 'warning', $message);
        $this->redirect($this->backPath('/time'));
    }

    /** @param array<string, string> $errors */
    private function failTimerFields(string $failPath, array $errors): never
    {
        if ($this->request->wantsJson() || $this->request->isAjax()) {
            $this->json(['ok' => false, 'errors' => $errors, 'message' => (string) reset($errors)], 422);
        }

        $this->backWithErrors($failPath, $errors);
    }

    private function backPath(string $default): string
    {
        $referer = $this->request->header('referer');
        if ($referer === null || $referer === '') {
            return $default;
        }

        $path = (string) parse_url($referer, PHP_URL_PATH);
        $base = Request::basePath();
        if ($base !== '' && str_starts_with($path, $base)) {
            $path = substr($path, strlen($base)) ?: '/';
        }

        if ($path === '' || $path[0] !== '/' || str_starts_with($path, '//')) {
            return $default;
        }

        return $path;
    }

    private function dateOrEmpty(string $value): string
    {
        $value = trim($value);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) === 1 ? $value : '';
    }

    private function allowManual(): bool
    {
        try {
            $value = Database::fetchValue(
                "SELECT setting_value FROM settings WHERE setting_key = 'allow_manual_time_entries' LIMIT 1"
            );
        } catch (Throwable) {
            return true;
        }

        return $value === null || in_array((string) $value, ['1', 'true', 'yes', 'on'], true);
    }

    /**
     * @param array<string, mixed> $timer
     * @return array<string, mixed>
     */
    private function timerPayload(array $timer): array
    {
        $started = (string) ($timer['created_at'] ?? $timer['started_at']);
        $iso     = (new DateTimeImmutable($started, new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');

        return [
            'id'               => (int) $timer['id'],
            'project_id'       => (int) $timer['project_id'],
            'task_id'          => $timer['task_id'] !== null ? (int) $timer['task_id'] : null,
            'project_name'     => (string) ($timer['project_name'] ?? ''),
            'task_name'        => (string) ($timer['task_name'] ?? ''),
            'description'      => (string) ($timer['description'] ?? ''),
            'is_billable'      => (int) $timer['is_billable'] === 1,
            'started_at'       => $started,
            'started_at_iso'   => $iso,
            'elapsed_seconds'  => (int) $timer['elapsed_seconds'],
            'elapsed_display'  => (string) ($timer['elapsed_display'] ?? FormatHelper::duration((int) $timer['elapsed_seconds'])),
            'paused'           => !empty($timer['paused_at']),
            'paused_at'        => !empty($timer['paused_at']) ? (string) $timer['paused_at'] : null,
            'server_now'       => time(),
        ];
    }

    /**
     * @param array<string, mixed> $entry
     * @return array<string, mixed>
     */
    private function entryPayload(array $entry): array
    {
        return [
            'id'               => (int) $entry['id'],
            'project_id'       => (int) $entry['project_id'],
            'task_id'          => $entry['task_id'] !== null ? (int) $entry['task_id'] : null,
            'project_name'     => (string) ($entry['project_name'] ?? ''),
            'task_name'        => (string) ($entry['task_name'] ?? ''),
            'start_time'       => (string) $entry['start_time'],
            'end_time'         => (string) $entry['end_time'],
            'duration_seconds' => (int) $entry['duration_seconds'],
            'duration_display' => FormatHelper::duration((int) $entry['duration_seconds']),
            'break_minutes'    => (int) $entry['break_minutes'],
            'description'      => (string) ($entry['description'] ?? ''),
            'is_billable'      => (int) $entry['is_billable'] === 1,
            'status'           => (string) $entry['status'],
        ];
    }

    /** @return list<array<string, mixed>> */
    private function filterProjects(int $userId, bool $viewAll): array
    {
        $viewAllProjects = $viewAll || PermissionHelper::has('projects.view_all');

        return Database::fetchAll(
            'SELECT p.id, p.name, p.project_code
             FROM projects p
             WHERE p.status <> \'Archived\'' .
            ($viewAllProjects ? '' : ' AND (p.manager_id = :uid_m OR p.created_by = :uid_c OR EXISTS (
                 SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :uid_u
             ))') . '
             ORDER BY p.name ASC',
            $viewAllProjects ? [] : [
                'uid_m' => $userId,
                'uid_c' => $userId,
                'uid_u' => $userId,
            ]
        );
    }

    /** @return list<array<string, mixed>> */
    private function activePeople(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        );
    }

    /** @return array<string, mixed>|null */
    private function safeActiveTimer(int $userId): ?array
    {
        try {
            return $this->timers->getActive($userId);
        } catch (Throwable) {
            return null;
        }
    }
}
