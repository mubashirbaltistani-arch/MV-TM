<?php
/**
 * Server-authoritative running timer. One row per user (UNIQUE user_id).
 *
 * Elapsed time is always computed from the server clock against started_at,
 * never from a client-supplied duration.
 */

declare(strict_types=1);

final class Timer extends Model
{
    protected string $table = 'active_timers';

    protected array $columns = [
        'id', 'user_id', 'project_id', 'task_id',
        'started_at', 'last_activity_at', 'paused_at', 'accumulated_seconds', 'description', 'is_billable', 'created_at',
    ];

    protected array $fillable = [
        'user_id', 'project_id', 'task_id',
        'started_at', 'last_activity_at', 'paused_at', 'accumulated_seconds', 'description', 'is_billable',
    ];

    protected bool $timestamps = false;

    /** True when the active_timers table has been installed. */
    public static function installed(): bool
    {
        static $installed = null;

        if ($installed === null) {
            try {
                $installed = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = 'active_timers'"
                ) > 0;
            } catch (Throwable) {
                $installed = false;
            }
        }

        return $installed;
    }

    /**
     * Start a timer for $userId. At most one active timer exists per user:
     * an existing row is rejected (the caller must stop it first).
     *
     * @return array<string, mixed>
     */
    public function start(
        int $userId,
        int $projectId,
        ?int $taskId,
        string $description,
        bool $isBillable
    ): array {
        if ($userId < 1 || $projectId < 1) {
            throw new InvalidArgumentException('A user and project are required to start a timer.');
        }

        $description = mb_substr(trim($description), 0, 255, 'UTF-8');

        return Database::transaction(function (PDO $pdo) use ($userId, $projectId, $taskId, $description, $isBillable): array {
            $existing = $this->lockForUser($pdo, $userId);
            if ($existing !== null) {
                throw new RuntimeException('You already have a timer running. Stop it before starting another.');
            }

            $now = gmdate('Y-m-d H:i:s', time());

            try {
                Database::execute(
                    'INSERT INTO active_timers
                        (user_id, project_id, task_id, started_at, last_activity_at, paused_at, accumulated_seconds, description, is_billable, created_at)
                     VALUES
                        (:user_id, :project_id, :task_id, :started_at, :last_activity_at, NULL, 0, :description, :is_billable, :created_at)',
                    [
                        'user_id'          => $userId,
                        'project_id'       => $projectId,
                        'task_id'          => $taskId,
                        'started_at'       => $now,
                        'last_activity_at' => $now,
                        'description'      => $description !== '' ? $description : null,
                        'is_billable'      => $isBillable ? 1 : 0,
                        'created_at'       => $now,
                    ]
                );
            } catch (PDOException $e) {
                if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
                    throw new RuntimeException('You already have a timer running. Stop it before starting another.');
                }
                throw $e;
            }

            $row = $this->getActive($userId);
            if ($row === null) {
                throw new RuntimeException('Timer could not be started.');
            }

            return $row;
        });
    }

    /**
     * Fetch the user's running timer with project/task names and server elapsed seconds.
     *
     * @return array<string, mixed>|null
     */
    public function getActive(int $userId): ?array
    {
        if ($userId < 1 || !self::installed()) {
            return null;
        }

        $taskSelect = Task::installed() ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = Task::installed() ? 'LEFT JOIN tasks tk ON tk.id = t.task_id' : '';

        $row = Database::fetchOne(
            "SELECT t.id, t.user_id, t.project_id, t.task_id, t.started_at, t.last_activity_at,
                    t.paused_at, t.accumulated_seconds, t.description, t.is_billable, t.created_at,
                    p.name AS project_name, p.project_code, p.hourly_rate, p.is_billable AS project_billable,
                    {$taskSelect}
             FROM active_timers t
             INNER JOIN projects p ON p.id = t.project_id
             {$taskJoin}
             WHERE t.user_id = :user_id
             LIMIT 1",
            ['user_id' => $userId]
        );

        if ($row === null) {
            return null;
        }

        return $this->withElapsed($row);
    }

    /**
     * Stop the running timer: insert a time_entries row with exact elapsed seconds,
     * delete the active_timers row, return the new entry.
     *
     * @return array<string, mixed>
     */
    public function stop(int $userId): array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to stop a timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId): array {
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is running.');
            }

            $originalStart = (string) ($row['created_at'] ?? $row['started_at']);
            $originalStartTs = strtotime($originalStart . ' UTC');
            if ($originalStartTs === false) {
                $originalStartTs = time();
                $originalStart = gmdate('Y-m-d H:i:s', $originalStartTs);
            }

            $segmentStartTs = strtotime((string) $row['started_at'] . ' UTC');
            if ($segmentStartTs === false) {
                $segmentStartTs = $originalStartTs;
            }

            $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0));
            $isPaused = !empty($row['paused_at']);
            $nowTs = time();
            $elapsed = $accumulated + ($isPaused ? 0 : max(0, $nowTs - $segmentStartTs));
            $elapsed = max(1, $elapsed);
            $endTime = gmdate('Y-m-d H:i:s', $nowTs);
            $wallSeconds = max($elapsed, $nowTs - $originalStartTs);
            $breakMinutes = max(0, (int) floor(($wallSeconds - $elapsed) / 60));
            $rate     = $this->projectRate((int) $row['project_id']);
            $billable = (int) $row['is_billable'] === 1 ? 1 : 0;

            $entry = (new TimeEntry())->createEntry([
                'user_id'          => $userId,
                'project_id'       => (int) $row['project_id'],
                'task_id'          => $row['task_id'] !== null ? (int) $row['task_id'] : null,
                'start_time'       => $originalStart,
                'end_time'         => $endTime,
                'break_minutes'    => $breakMinutes,
                'description'      => $row['description'],
                'is_billable'      => $billable,
                'billable_rate'    => $rate,
                'status'           => TimeEntry::STATUS_PENDING,
            ]);

            Database::execute(
                'DELETE FROM active_timers WHERE user_id = :user_id',
                ['user_id' => $userId]
            );

            return $entry;
        });
    }

    /** Pause the active timer while preserving accumulated work time. */
    public function pause(int $userId): array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to pause a timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId): array {
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is running.');
            }
            if (!empty($row['paused_at'])) {
                throw new RuntimeException('The timer is already paused.');
            }

            $startedTs = strtotime((string) $row['started_at'] . ' UTC');
            if ($startedTs === false) {
                $startedTs = time();
            }
            $now = time();
            $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0)) + max(0, $now - $startedTs);
            $nowSql = gmdate('Y-m-d H:i:s', $now);

            Database::execute(
                'UPDATE active_timers
                 SET accumulated_seconds = :accumulated_seconds,
                     paused_at = :paused_at,
                     last_activity_at = :last_activity_at
                 WHERE user_id = :user_id',
                [
                    'accumulated_seconds' => $accumulated,
                    'paused_at'           => $nowSql,
                    'last_activity_at'   => $nowSql,
                    'user_id'             => $userId,
                ]
            );

            $updated = $this->getActive($userId);
            if ($updated === null) {
                throw new RuntimeException('Timer could not be paused.');
            }
            return $updated;
        });
    }

    /** Resume a paused timer without counting the break as worked time. */
    public function resume(int $userId): array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to resume a timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId): array {
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is paused.');
            }
            if (empty($row['paused_at'])) {
                throw new RuntimeException('The timer is already running.');
            }

            $now = time();
            $nowSql = gmdate('Y-m-d H:i:s', $now);
            Database::execute(
                'UPDATE active_timers
                 SET started_at = :started_at,
                     paused_at = NULL,
                     last_activity_at = :last_activity_at
                 WHERE user_id = :user_id',
                [
                    'started_at'       => $nowSql,
                    'last_activity_at'=> $nowSql,
                    'user_id'          => $userId,
                ]
            );

            $updated = $this->getActive($userId);
            if ($updated === null) {
                throw new RuntimeException('Timer could not be resumed.');
            }
            return $updated;
        });
    }

    /** Touch last_activity_at so idle detection can see the user is still around. */
    public function ping(int $userId): bool
    {
        if ($userId < 1 || !self::installed()) {
            return false;
        }

        return Database::execute(
            'UPDATE active_timers SET last_activity_at = :now WHERE user_id = :user_id',
            ['now' => gmdate('Y-m-d H:i:s', time()), 'user_id' => $userId]
        ) > 0;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public function withElapsed(array $row): array
    {
        $startedTs = strtotime((string) $row['started_at'] . ' UTC');
        if ($startedTs === false) {
            $startedTs = time();
        }

        $accumulated = max(0, (int) ($row['accumulated_seconds'] ?? 0));
        $elapsed = $accumulated + (!empty($row['paused_at']) ? 0 : max(0, time() - $startedTs));

        $row['elapsed_seconds'] = $elapsed;
        $row['paused'] = !empty($row['paused_at']);
        $row['elapsed_display'] = FormatHelper::duration($elapsed);
        $row['is_billable']     = (int) ($row['is_billable'] ?? 0);
        $row['project_id']      = (int) $row['project_id'];
        $row['task_id']         = $row['task_id'] !== null ? (int) $row['task_id'] : null;
        $row['user_id']         = (int) $row['user_id'];
        $row['id']              = (int) $row['id'];

        return $row;
    }

    /**
     * Lock the user's timer row (if any) for the rest of the transaction.
     *
     * @return array<string, mixed>|null
     */
    private function lockForUser(PDO $pdo, int $userId): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM active_timers WHERE user_id = :user_id LIMIT 1 FOR UPDATE');
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    private function projectRate(int $projectId): float
    {
        $rate = Database::fetchValue(
            'SELECT hourly_rate FROM projects WHERE id = :id LIMIT 1',
            ['id' => $projectId]
        );

        return $rate !== null ? (float) $rate : 0.0;
    }
}
