<?php
/**
 * Project page with Clockify-style project sections.
 *
 * @var array<string, mixed> $project
 * @var array{estimated_hours: float, tracked_hours: float, billable_hours: float, budget: float, budget_used: float, progress: int} $totals
 * @var list<array<string, mixed>> $members
 * @var bool $canEdit
 * @var bool $canArchive
 * @var bool $canManageMembers
 * @var bool $canTrack
 * @var list<array<string, mixed>> $users
 * @var string $tab
 * @var bool $tasksReady
 */

$currency = (string) (Database::fetchValue("SELECT setting_value FROM settings WHERE setting_key = 'currency' LIMIT 1") ?: 'USD');
$progress = (int) $totals['progress'];
$budgetPct = $totals['budget'] > 0 ? (int) min(100, round(($totals['budget_used'] / $totals['budget']) * 100)) : 0;
$memberIds = array_map(static fn (array $row): int => (int) $row['user_id'], $members);
$roleMap = [];
foreach ($members as $row) {
    $roleMap[(int) $row['user_id']] = (string) $row['project_role'];
}

$statusClass = match ((string) $project['status']) {
    'Planning'  => 'planning',
    'Active'    => 'active',
    'On Hold'   => 'hold',
    'Completed' => 'completed',
    'Cancelled' => 'cancelled',
    'Archived'  => 'archived',
    default     => 'planning',
};
$priorityClass = match ((string) $project['priority']) {
    'Urgent' => 'urgent',
    'High'   => 'high',
    'Medium' => 'medium',
    default  => 'low',
};

$activeProjectTab = (string) $tab;
?>
<div class="page-toolbar project-page-toolbar">
    <div>
        <p class="mono text-secondary mb-1"><?= e($project['project_code']) ?></p>
        <h2 class="page-heading"><?= e($project['name']) ?></h2>
        <p class="page-lead mb-0">
            <?= e($project['client_name']) ?>
            <?php if (!empty($project['client_company'])): ?> · <?= e($project['client_company']) ?><?php endif; ?>
        </p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <span class="status-badge status-<?= e($statusClass) ?>"><?= e($project['status']) ?></span>
        <span class="priority-badge priority-<?= e($priorityClass) ?>"><?= e($project['priority']) ?></span>
    </div>
</div>

<?php require APP_PATH . '/Views/projects/tabs.php'; ?>

<?php if ($tab === 'tasks' && $tasksReady): ?>
    <?php require APP_PATH . '/Views/tasks/panel.php'; ?>

<?php elseif ($tab === 'access'): ?>
    <div class="row g-4">
        <div class="col-lg-8">
            <section class="panel">
                <div class="panel-head">
                    <h2 class="panel-title">Project access <span class="count-pill"><?= count($members) ?></span></h2>
                    <p class="panel-subtitle">People who can access and work on this project.</p>
                </div>
                <?php if ($members === []): ?>
                    <div class="empty-state">
                        <i class="fa-regular fa-user" aria-hidden="true"></i>
                        <p>No one is assigned yet.</p>
                    </div>
                <?php else: ?>
                    <ul class="member-list">
                        <?php foreach ($members as $member): ?>
                            <?php
                            $initials = '';
                            foreach (array_slice(preg_split('/\s+/', trim((string) $member['name'])) ?: [], 0, 2) as $part) {
                                $initials .= mb_strtoupper(mb_substr($part, 0, 1, 'UTF-8'), 'UTF-8');
                            }
                            ?>
                            <li>
                                <span class="avatar" aria-hidden="true"><?= e($initials !== '' ? $initials : '?') ?></span>
                                <span class="member-copy">
                                    <strong><?= e($member['name']) ?></strong>
                                    <span class="text-secondary small"><?= e($member['job_title'] ?: $member['email']) ?></span>
                                </span>
                                <span class="role-pill role-<?= e($member['role']) ?>"><?= e($member['project_role']) ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </section>
        </div>
        <div class="col-lg-4">
            <section class="panel">
                <div class="panel-head"><h2 class="panel-title">Access management</h2></div>
                <div class="panel-body">
                    <?php if ($canManageMembers): ?>
                        <form method="post" action="<?= e(url('/projects/' . (int) $project['id'] . '/members')) ?>" data-single-submit>
                            <?= csrf_field() ?>
                            <div class="member-picker">
                                <?php foreach ($users as $user): ?>
                                    <?php
                                    $uid = (int) $user['id'];
                                    $checked = in_array($uid, $memberIds, true);
                                    $role = $roleMap[$uid] ?? 'member';
                                    ?>
                                    <label class="member-pick">
                                        <input type="checkbox" name="member_ids[]" value="<?= $uid ?>"<?= $checked ? ' checked' : '' ?>>
                                        <span class="member-pick-body">
                                            <strong><?= e($user['name']) ?></strong>
                                            <span class="text-secondary small"><?= e($user['role']) ?></span>
                                        </span>
                                        <select name="member_roles[<?= $uid ?>]" class="form-select form-select-sm" aria-label="Role for <?= e($user['name']) ?>">
                                            <option value="manager"<?= $role === 'manager' ? ' selected' : '' ?>>Manager</option>
                                            <option value="member"<?= $role === 'member' ? ' selected' : '' ?>>Member</option>
                                            <option value="viewer"<?= $role === 'viewer' ? ' selected' : '' ?>>Viewer</option>
                                        </select>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Save access</button>
                        </form>
                    <?php else: ?>
                        <p class="text-secondary mb-0">You can view project access, but you do not have permission to change members.</p>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>

<?php elseif ($tab === 'note'): ?>
    <section class="panel">
        <div class="panel-head">
            <div>
                <h2 class="panel-title">Project note</h2>
                <p class="panel-subtitle">The project description and notes for this project.</p>
            </div>
            <?php if ($canEdit): ?>
                <a class="btn btn-outline-primary" href="<?= e(url('/projects/' . (int) $project['id'] . '/edit')) ?>">Edit note</a>
            <?php endif; ?>
        </div>
        <div class="panel-body project-note-body">
            <?php if (!empty($project['description'])): ?>
                <?= nl2br(e($project['description'])) ?>
            <?php else: ?>
                <p class="text-secondary mb-0">No project note has been added yet.</p>
            <?php endif; ?>
        </div>
    </section>

<?php else: ?>
    <div class="kpi-grid">
        <article class="kpi-card">
            <p class="kpi-label">Estimated hours</p>
            <p class="kpi-value"><?= e(number_format((float) $totals['estimated_hours'], 1)) ?></p>
            <p class="kpi-sub">Planned effort</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Tracked hours</p>
            <p class="kpi-value"><?= e(number_format((float) $totals['tracked_hours'], 1)) ?></p>
            <div class="progress mt-2" role="progressbar" aria-valuenow="<?= $progress ?>" aria-valuemin="0" aria-valuemax="100">
                <div class="progress-bar" style="width: <?= $progress ?>%"></div>
            </div>
            <p class="kpi-sub"><?= $progress ?>% of estimate</p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Budget used</p>
            <p class="kpi-value"><?= e(FormatHelper::money((float) $totals['budget_used'], $currency)) ?></p>
            <div class="progress mt-2" role="progressbar" aria-valuenow="<?= $budgetPct ?>" aria-valuemin="0" aria-valuemax="100">
                <div class="progress-bar" style="width: <?= $budgetPct ?>%"></div>
            </div>
            <p class="kpi-sub">of <?= e(FormatHelper::money((float) $totals['budget'], $currency)) ?></p>
        </article>
        <article class="kpi-card">
            <p class="kpi-label">Assigned members</p>
            <p class="kpi-value"><?= count($members) ?></p>
            <p class="kpi-sub"><?= e(number_format((float) $totals['billable_hours'], 1)) ?>h billable</p>
        </article>
    </div>

    <section class="panel">
        <div class="panel-head">
            <h2 class="panel-title">Project status</h2>
        </div>
        <div class="panel-body">
            <dl class="facts facts-inline">
                <div><dt>Status</dt><dd><span class="status-badge status-<?= e($statusClass) ?>"><?= e($project['status']) ?></span></dd></div>
                <div><dt>Priority</dt><dd><span class="priority-badge priority-<?= e($priorityClass) ?>"><?= e($project['priority']) ?></span></dd></div>
                <div><dt>Start</dt><dd><?= !empty($project['start_date']) ? e(FormatHelper::date($project['start_date'] . ' 00:00:00', 'M j, Y')) : '—' ?></dd></div>
                <div><dt>Due</dt><dd><?= !empty($project['due_date']) ? e(FormatHelper::date($project['due_date'] . ' 00:00:00', 'M j, Y')) : '—' ?></dd></div>
                <div><dt>Manager</dt><dd><?= e($project['manager_name'] ?? 'Unassigned') ?></dd></div>
                <div><dt>Created by</dt><dd><?= e($project['created_by_name'] ?? '—') ?></dd></div>
                <div><dt>Hourly rate</dt><dd><?= e(FormatHelper::money((float) $project['hourly_rate'], $currency)) ?></dd></div>
                <div><dt>Updated</dt><dd><?= e(FormatHelper::datetime((string) $project['updated_at'], 'M j, Y H:i')) ?></dd></div>
            </dl>
        </div>
    </section>
<?php endif; ?>
