<?php
/**
 * Time entries list with filters, live timer start, and manual add.
 *
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, totals: array{seconds: int, billable_seconds: int, count: int}} $result
 * @var array{from: string, to: string, project_id: int, task_id: int, billable: string, status: string, user_id: int} $filters
 * @var list<array<string, mixed>> $projects
 * @var list<array<string, mixed>> $filterProjects
 * @var list<array<string, mixed>> $tasks
 * @var list<array<string, mixed>> $people
 * @var bool $viewAll
 * @var bool $canTrack
 * @var bool $canManual
 * @var bool $canDelete
 * @var bool $canEditAll
 * @var array<string, mixed>|null $activeTimer
 */

$items  = $result['items'];
$totals = $result['totals'];
$userId = (int) AuthHelper::id();

$qs = static function (array $extra = []) use ($filters): string {
    $data = array_filter([
        'from'       => $extra['from'] ?? $filters['from'],
        'to'         => $extra['to'] ?? $filters['to'],
        'project_id' => $extra['project_id'] ?? ($filters['project_id'] ?: ''),
        'task_id'    => $extra['task_id'] ?? ($filters['task_id'] ?: ''),
        'billable'   => $extra['billable'] ?? $filters['billable'],
        'status'     => $extra['status'] ?? $filters['status'],
        'user_id'    => $extra['user_id'] ?? ($filters['user_id'] ?: ''),
        'page'       => $extra['page'] ?? null,
    ], static fn ($v) => $v !== null && $v !== '' && $v !== 0 && $v !== '0');

    return $data === [] ? '' : '?' . http_build_query($data);
};

$statusClass = static fn (string $status): string => match ($status) {
    'Approved' => 'completed',
    'Rejected' => 'cancelled',
    default    => 'planning',
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Time</h2>
        <p class="page-lead">Track work with a live timer or add entries by hand.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if (class_exists('TimesheetController') && is_file(APP_PATH . '/Controllers/TimesheetController.php')): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets')) ?>">
                <i class="fa-solid fa-table me-1" aria-hidden="true"></i>Timesheet
            </a>
        <?php endif; ?>
        <?php if ($canManual): ?>
            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#manualEntryModal">
                <i class="fa-solid fa-pen-to-square me-1" aria-hidden="true"></i>Add time
            </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($canTrack): ?>
<section class="panel mb-4">
    <div class="panel-head">
        <h2 class="panel-title">Start timer</h2>
    </div>
    <div class="panel-body">
        <form class="row g-2 align-items-end" data-timer-start-form>
            <div class="col-md-4">
                <label for="start_project_id" class="form-label">Project</label>
                <select id="start_project_id" name="project_id" class="form-select" required data-timer-project-select>
                    <option value="">Choose a project</option>
                    <?php foreach ($projects as $project): ?>
                        <option value="<?= (int) $project['id'] ?>" data-billable="<?= (int) ($project['is_billable'] ?? 1) ?>">
                            <?= e($project['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="start_task_id" class="form-label">Task</label>
                <select id="start_task_id" name="task_id" class="form-select" data-timer-task-select>
                    <option value="">No task</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="start_description" class="form-label">What are you working on?</label>
                <input type="text" id="start_description" name="description" maxlength="255" class="form-control" placeholder="Optional note">
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-primary w-100" data-timer-start>
                    <i class="fa-solid fa-play me-1" aria-hidden="true"></i>Start
                </button>
            </div>
        </form>
    </div>
</section>
<?php endif; ?>

<div class="kpi-grid mb-4">
    <article class="kpi-card">
        <p class="kpi-label">Entries</p>
        <p class="kpi-value"><?= (int) $totals['count'] ?></p>
        <p class="kpi-sub">Matching filters</p>
    </article>
    <article class="kpi-card">
        <p class="kpi-label">Tracked</p>
        <p class="kpi-value"><?= e(FormatHelper::duration((int) $totals['seconds'])) ?></p>
        <p class="kpi-sub"><?= e(FormatHelper::hours((int) $totals['seconds'])) ?> h</p>
    </article>
    <article class="kpi-card">
        <p class="kpi-label">Billable</p>
        <p class="kpi-value"><?= e(FormatHelper::duration((int) $totals['billable_seconds'])) ?></p>
        <p class="kpi-sub"><?= e(FormatHelper::hours((int) $totals['billable_seconds'])) ?> h</p>
    </article>
</div>

<form method="get" action="<?= e(url('/time')) ?>" class="filter-bar">
    <div>
        <label for="time-from" class="visually-hidden">From</label>
        <input type="date" id="time-from" name="from" class="form-control" value="<?= e($filters['from']) ?>">
    </div>
    <div>
        <label for="time-to" class="visually-hidden">To</label>
        <input type="date" id="time-to" name="to" class="form-control" value="<?= e($filters['to']) ?>">
    </div>
    <div>
        <label for="time-project" class="visually-hidden">Project</label>
        <select id="time-project" name="project_id" class="form-select">
            <option value="">All projects</option>
            <?php foreach ($filterProjects as $project): ?>
                <option value="<?= (int) $project['id'] ?>"<?= (int) $filters['project_id'] === (int) $project['id'] ? ' selected' : '' ?>><?= e($project['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="time-task" class="visually-hidden">Task</label>
        <select id="time-task" name="task_id" class="form-select">
            <option value="">All tasks</option>
            <?php foreach ($tasks as $task): ?>
                <option value="<?= (int) $task['id'] ?>"<?= (int) $filters['task_id'] === (int) $task['id'] ? ' selected' : '' ?>><?= e($task['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="time-billable" class="visually-hidden">Billable</label>
        <select id="time-billable" name="billable" class="form-select">
            <option value="">Billable and not</option>
            <option value="1"<?= $filters['billable'] === '1' ? ' selected' : '' ?>>Billable</option>
            <option value="0"<?= $filters['billable'] === '0' ? ' selected' : '' ?>>Non-billable</option>
        </select>
    </div>
    <?php if ($viewAll): ?>
        <div>
            <label for="time-user" class="visually-hidden">Person</label>
            <select id="time-user" name="user_id" class="form-select">
                <option value="">Everyone</option>
                <?php foreach ($people as $person): ?>
                    <option value="<?= (int) $person['id'] ?>"<?= (int) $filters['user_id'] === (int) $person['id'] ? ' selected' : '' ?>><?= e($person['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    <?php endif; ?>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Entries <span class="count-pill"><?= (int) $result['total'] ?></span></h2>
    </div>
    <?php if ($items === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-clock" aria-hidden="true"></i>
            <p>No time entries match these filters.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <?php if ($viewAll): ?><th>Person</th><?php endif; ?>
                        <th>Start (PKT)</th>
                        <th>End (PKT)</th>
                        <th>Project</th>
                        <th>Task</th>
                        <th>Note</th>
                        <th>Duration</th>
                        <th>Billable</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $entry): ?>
                        <?php
                        $timesheetStatus = (string) ($entry['timesheet_status'] ?? '');
                        $entryStatus = $timesheetStatus !== '' ? $timesheetStatus : (string) ($entry['status'] ?? TimeEntry::STATUS_PENDING);
                        $locked = $entryStatus === TimeEntry::STATUS_APPROVED
                            || $timesheetStatus === 'Submitted'
                            || (int) ($entry['timesheet_id'] ?? 0) > 0;
                        $own    = (int) $entry['user_id'] === $userId;
                        $canRemove = !$locked && (($own && $canDelete) || $canEditAll);
                        ?>
                        <tr>
                            <?php if ($viewAll): ?>
                                <td><?= e($entry['user_name'] ?? '') ?></td>
                            <?php endif; ?>
                            <td class="text-nowrap">
                                <div class="fw-medium"><?= e(FormatHelper::datetime((string) $entry['start_time'], 'M j, Y')) ?></div>
                                <div class="mono text-secondary"><?= e(FormatHelper::datetime((string) $entry['start_time'], 'H:i')) ?></div>
                            </td>
                            <td class="text-nowrap">
                                <div class="fw-medium"><?= e(FormatHelper::datetime((string) $entry['end_time'], 'M j, Y')) ?></div>
                                <div class="mono text-secondary"><?= e(FormatHelper::datetime((string) $entry['end_time'], 'H:i')) ?></div>
                            </td>
                            <td>
                                <a href="<?= e(url('/projects/' . (int) $entry['project_id'])) ?>" class="fw-medium"><?= e($entry['project_name']) ?></a>
                                <?php if (!empty($entry['description'])): ?>
                                    <div class="small text-secondary"><?= e($entry['description']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td><?= !empty($entry['task_name']) ? e($entry['task_name']) : '—' ?></td>
                            <td><?= !empty($entry['description']) ? e($entry['description']) : '—' ?></td>
                            <td class="mono"><?= e(FormatHelper::duration((int) $entry['duration_seconds'])) ?></td>
                            <td><?= (int) $entry['is_billable'] === 1 ? 'Yes' : 'No' ?></td>
                            <td><span class="status-badge status-<?= e($statusClass($entryStatus)) ?>"><?= e($entryStatus) ?></span></td>
                            <td class="text-end text-nowrap">
                                <?php if ($canRemove): ?>
                                    <form method="post" action="<?= e(url('/time/' . (int) $entry['id'] . '/delete')) ?>" class="d-inline"
                                          data-confirm="Delete this time entry?">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                <?php elseif ($locked): ?>
                                    <span class="small text-secondary">Locked</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php if ($result['pages'] > 1): ?>
            <nav class="pager" aria-label="Time entry pages">
                <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
                    <a class="btn btn-sm <?= $p === (int) $result['page'] ? 'btn-primary' : 'btn-outline-secondary' ?>"
                       href="<?= e(url('/time') . $qs(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>

<?php if ($canManual): ?>
    <?php require APP_PATH . '/Views/timer/manual_entry_modal.php'; ?>
<?php endif; ?>
