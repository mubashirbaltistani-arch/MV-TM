<?php
/**
 * Landing page after sign-in. Every role sees it; what it shows depends on permissions.
 *
 * Phase 1 content: welcome, notifications, and (for admins/managers) team and activity
 * summaries. Project and time widgets are added by the phases that create those tables.
 */

declare(strict_types=1);

final class DashboardController extends Controller
{
    public function __construct()
    {
        parent::__construct(true); // any authenticated, active user
    }

    /** GET /dashboard */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('dashboard.view');

        $userId = (int) AuthHelper::id();

        $unread = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
            ['id' => $userId]
        );

        $notifications = Database::fetchAll(
            'SELECT id, type, title, message, link, is_read, created_at
             FROM notifications
             WHERE user_id = :id
             ORDER BY created_at DESC, id DESC
             LIMIT 6',
            ['id' => $userId]
        );

        $team = [];
        if (PermissionHelper::has('users.view')) {
            $team = Database::fetchAll(
                "SELECT r.display_name, COUNT(u.id) AS total
                 FROM roles r
                 LEFT JOIN users u ON u.role_id = r.id AND u.status = 'active'
                 GROUP BY r.id, r.display_name
                 ORDER BY r.id"
            );
        }

        $activity = [];
        if (PermissionHelper::has('activity.view')) {
            $activity = Database::fetchAll(
                'SELECT a.action, a.entity_type, a.entity_id, a.created_at, u.name AS user_name
                 FROM activity_logs a
                 LEFT JOIN users u ON u.id = a.user_id
                 ORDER BY a.id DESC
                 LIMIT 8'
            );
        }

        $this->view('dashboard/index', [
            'pageTitle'     => 'Dashboard',
            'unread'        => $unread,
            'notifications' => $notifications,
            'team'          => $team,
            'activity'      => $activity,
        ]);
    }

    /** POST /notifications/read : mark all of the user's notifications as read. */
    public function markNotificationsRead(Request $request, array $params): void
    {
        Database::execute(
            'UPDATE notifications SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE user_id = :id AND is_read = 0',
            ['id' => (int) AuthHelper::id()]
        );

        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }

        $this->redirect('/dashboard');
    }
}
