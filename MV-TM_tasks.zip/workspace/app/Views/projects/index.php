<?php
/**
 * Project list: cards + table with progress bars and status badges.
 *
 * @var string $tab
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, counts: array<string, int>} $result
 * @var list<array<string, mixed>> $clients
 * @var list<array<string, mixed>> $managers
 * @var array{status: string, client_id: int, manager_id: int, q: string} $filters
 * @var bool $canCreate
 * @var bool $canEdit
 * @var bool $canArchive
 * @var bool $isAdmin
 * @var int  $userId
 */

$items  = $result['items'];
$counts = $result['counts'];
$currency = (string) (Database::fetchValue("SELECT setting_value FROM settings WHERE setting_key = 'currency' LIMIT 1") ?: 'USD');

$qs = static function (array $extra = []) use ($tab, $filters): string {
    $data = array_filter([
        'tab'        => $extra['tab'] ?? $tab,
        'status'     => $extra['status'] ?? $filters['status'],
        'client_id'  => $extra['client_id'] ?? ($filters['client_id'] ?: ''),
        'manager_id' => $extra['manager_id'] ?? ($filters['manager_id'] ?: ''),
        'q'          => $extra['q'] ?? $filters['q'],
        'page'       => $extra['page'] ?? null,
    ], static fn ($v) => $v !== null && $v !== '' && $v !== 0 && $v !== '0');
    return $data === [] ? '' : '?' . http_build_query($data);
};

$statusClass = static fn (string $status): string => match ($status) {
    'Planning'  => 'planning',
    'Active'    => 'active',
    'On Hold'   => 'hold',
    'Completed' => 'completed',
    'Cancelled' => 'cancelled',
    'Archived'  => 'archived',
    default     => 'planning',
};

$priorityClass = static fn (string $priority): string => match ($priority) {
    'Urgent' => 'urgent',
    'High'   => 'high',
    'Medium' => 'medium',
    default  => 'low',
};

$tabs = [
    'all'       => 'All',
    'active'    => 'Active',
    'completed' => 'Completed',
    'archived'  => 'Archived',
];
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Projects</h2>
        <p class="page-lead">Work you can see, filtered by status and client.</p>
    </div>
    <?php if ($canCreate): ?>
        <a class="btn btn-primary" href="<?= e(url('/projects/create')) ?>">
            <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>New project
        </a>
    <?php endif; ?>
</div>

<nav class="filter-tabs" aria-label="Project status">
    <?php foreach ($tabs as $key => $label): ?>
        <a class="filter-tab<?= $tab === $key ? ' is-active' : '' ?>"
           href="<?= e(url('/projects') . $qs(['tab' => $key, 'page' => 1])) ?>">
            <?= e($label) ?>
            <span class="count-pill"><?= (int) ($counts[$key] ?? 0) ?></span>
        </a>
    <?php endforeach; ?>
</nav>

<form method="get" action="<?= e(url('/projects')) ?>" class="filter-bar">
    <input type="hidden" name="tab" value="<?= e($tab) ?>">
    <div class="filter-search">
        <label for="project-q" class="visually-hidden">Search projects</label>
        <input type="search" id="project-q" name="q" class="form-control" placeholder="Search name, code or client"
               value="<?= e($filters['q']) ?>">
    </div>
    <div>
        <label for="project-status" class="visually-hidden">Status</label>
        <select id="project-status" name="status" class="form-select">
            <option value="">All statuses</option>
            <?php foreach (['Planning','Active','On Hold','Completed','Cancelled','Archived'] as $st): ?>
                <option value="<?= e($st) ?>"<?= $filters['status'] === $st ? ' selected' : '' ?>><?= e($st) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="project-client" class="visually-hidden">Client</label>
        <select id="project-client" name="client_id" class="form-select">
            <option value="">All clients</option>
            <?php foreach ($clients as $client): ?>
                <option value="<?= (int) $client['id'] ?>"<?= (int) $filters['client_id'] === (int) $client['id'] ? ' selected' : '' ?>><?= e($client['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="project-manager" class="visually-hidden">Manager</label>
        <select id="project-manager" name="manager_id" class="form-select">
            <option value="">All managers</option>
            <?php foreach ($managers as $manager): ?>
                <option value="<?= (int) $manager['id'] ?>"<?= (int) $filters['manager_id'] === (int) $manager['id'] ? ' selected' : '' ?>><?= e($manager['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<?php if ($items === []): ?>
    <section class="panel">
        <div class="empty-state">
            <i class="fa-solid fa-diagram-project" aria-hidden="true"></i>
            <p><?= $filters['q'] !== '' || $filters['status'] !== '' || $filters['client_id'] ? 'No projects match these filters.' : 'No projects in this view yet.' ?></p>
        </div>
    </section>
<?php else: ?>
    <div class="project-cards">
        <?php foreach ($items as $project): ?>
            <?php
            $progress = (int) ($project['progress'] ?? 0);
            $href = url('/projects/' . (int) $project['id']);
            ?>
            <article class="project-card">
                <div class="project-card-top">
                    <span class="status-badge status-<?= e($statusClass((string) $project['status'])) ?>"><?= e($project['status']) ?></span>
                    <span class="priority-badge priority-<?= e($priorityClass((string) $project['priority'])) ?>"><?= e($project['priority']) ?></span>
                </div>
                <h3 class="project-card-title">
                    <a href="<?= e($href) ?>"><?= e($project['name']) ?></a>
                </h3>
                <p class="project-card-meta">
                    <span class="mono"><?= e($project['project_code']) ?></span>
                    · <?= e($project['client_name']) ?>
                </p>
                <div class="progress-block">
                    <div class="progress-label">
                        <span><?= e(number_format((float) $project['tracked_hours'], 1)) ?> / <?= e(number_format((float) $project['estimated_hours'], 1)) ?> h</span>
                        <span><?= $progress ?>%</span>
                    </div>
                    <div class="progress" role="progressbar" aria-valuenow="<?= $progress ?>" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar" style="width: <?= $progress ?>%"></div>
                    </div>
                </div>
                <div class="project-card-foot">
                    <span><?= (int) ($project['task_count'] ?? 0) ?> task<?= (int) ($project['task_count'] ?? 0) === 1 ? '' : 's' ?> · <?= (int) $project['member_count'] ?> member<?= (int) $project['member_count'] === 1 ? '' : 's' ?></span>
                    <span><?= !empty($project['due_date']) ? 'Due ' . e(FormatHelper::date($project['due_date'] . ' 00:00:00', 'M j, Y')) : 'No due date' ?></span>
                </div>
            </article>
        <?php endforeach; ?>
    </div>

    <section class="panel mt-4">
        <div class="panel-head">
            <h2 class="panel-title">All matching projects <span class="count-pill"><?= (int) $result['total'] ?></span></h2>
        </div>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>Client</th>
                        <th>Manager</th>
                        <th>Status</th>
                        <th>Priority</th>
                        <th>Progress</th>
                        <th>Budget used</th>
                        <th>Due</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $project): ?>
                        <?php
                        $progress = (int) ($project['progress'] ?? 0);
                        $canManageRow = $isAdmin || (int) ($project['manager_id'] ?? 0) === $userId;
                        ?>
                        <tr>
                            <td>
                                <a href="<?= e(url('/projects/' . (int) $project['id'])) ?>" class="fw-medium"><?= e($project['name']) ?></a>
                                <div class="mono small text-secondary"><?= e($project['project_code']) ?></div>
                            </td>
                            <td><?= e($project['client_name']) ?></td>
                            <td><?= e($project['manager_name'] ?? '—') ?></td>
                            <td><span class="status-badge status-<?= e($statusClass((string) $project['status'])) ?>"><?= e($project['status']) ?></span></td>
                            <td><span class="priority-badge priority-<?= e($priorityClass((string) $project['priority'])) ?>"><?= e($project['priority']) ?></span></td>
                            <td style="min-width: 9rem;">
                                <div class="progress-label small mb-1">
                                    <span><?= e(number_format((float) $project['tracked_hours'], 1)) ?>h</span>
                                    <span><?= $progress ?>%</span>
                                </div>
                                <div class="progress" role="progressbar" aria-valuenow="<?= $progress ?>" aria-valuemin="0" aria-valuemax="100">
                                    <div class="progress-bar" style="width: <?= $progress ?>%"></div>
                                </div>
                            </td>
                            <td>
                                <?= e(FormatHelper::money((float) $project['budget_used'], $currency)) ?>
                                <div class="small text-secondary">of <?= e(FormatHelper::money((float) $project['budget'], $currency)) ?></div>
                            </td>
                            <td><?= !empty($project['due_date']) ? e(FormatHelper::date($project['due_date'] . ' 00:00:00', 'M j, Y')) : '—' ?></td>
                            <td class="text-end text-nowrap">
                                <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/projects/' . (int) $project['id'])) ?>">View</a>
                                <?php if ($canEdit && $canManageRow): ?>
                                    <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/projects/' . (int) $project['id'] . '/edit')) ?>">Edit</a>
                                <?php endif; ?>
                                <?php if ($canArchive && $canManageRow && $project['status'] !== 'Archived'): ?>
                                    <form method="post" action="<?= e(url('/projects/' . (int) $project['id'] . '/archive')) ?>" class="d-inline"
                                          data-confirm="Archive <?= e($project['name']) ?>?">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-secondary">Archive</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php if ($result['pages'] > 1): ?>
            <nav class="pager" aria-label="Project pages">
                <?php for ($p = 1; $p <= $result['pages']; $p++): ?>
                    <a class="btn btn-sm <?= $p === (int) $result['page'] ? 'btn-primary' : 'btn-outline-secondary' ?>"
                       href="<?= e(url('/projects') . $qs(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    </section>
<?php endif; ?>
