<?php
/**
 * Tasks tab of the project page: filter, task table, quick actions.
 * Included by projects/view.php (shares its variables).
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $tasks
 * @var array{all: int, active: int, done: int} $taskCounts
 * @var string $taskFilter   active|done|all
 * @var string $taskSearch
 * @var bool $canCreateTask
 * @var bool $canEditTask
 * @var bool $canDeleteTask
 * @var bool $canAssignTask
 */

$projectUrl  = url('/projects/' . (int) $project['id']);
$today       = gmdate('Y-m-d');
$hasFilter   = $taskSearch !== '' || $taskFilter !== 'active';
$taskStatusClass = static fn (string $status): string => match ($status) {
    'In Progress' => 'active',
    'Done'        => 'completed',
    default       => 'planning',
};
$showActions = $canEditTask || $canDeleteTask;
?>
<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Tasks <span class="count-pill"><?= (int) $taskCounts['all'] ?></span></h2>
        <?php if ($canCreateTask): ?>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#taskModal" data-task-new>
                <i class="fa-solid fa-plus" aria-hidden="true"></i> Add task
            </button>
        <?php endif; ?>
    </div>

    <form method="get" action="<?= e($projectUrl) ?>" class="panel-body border-bottom d-flex flex-wrap gap-2 align-items-center">
        <input type="hidden" name="tab" value="tasks">
        <div>
            <label for="task-status-filter" class="visually-hidden">Show</label>
            <select id="task-status-filter" name="task_status" class="form-select form-select-sm">
                <option value="active"<?= $taskFilter === 'active' ? ' selected' : '' ?>>Show active (<?= (int) $taskCounts['active'] ?>)</option>
                <option value="done"<?= $taskFilter === 'done' ? ' selected' : '' ?>>Show done (<?= (int) $taskCounts['done'] ?>)</option>
                <option value="all"<?= $taskFilter === 'all' ? ' selected' : '' ?>>Show all (<?= (int) $taskCounts['all'] ?>)</option>
            </select>
        </div>
        <div class="flex-grow-1" style="max-width: 22rem;">
            <label for="task-search" class="visually-hidden">Search tasks</label>
            <input type="search" id="task-search" name="task_q" maxlength="100" class="form-control form-control-sm"
                   placeholder="Search by name" value="<?= e($taskSearch) ?>">
        </div>
        <button type="submit" class="btn btn-outline-secondary btn-sm">Apply filter</button>
        <?php if ($hasFilter): ?>
            <a class="btn btn-link btn-sm" href="<?= e($projectUrl . '?tab=tasks') ?>">Reset</a>
        <?php endif; ?>
    </form>

    <?php if ($tasks === []): ?>
        <div class="empty-state">
            <i class="fa-solid fa-list-check" aria-hidden="true"></i>
            <?php if ($hasFilter && $taskCounts['all'] > 0): ?>
                <p>No tasks match this filter.</p>
            <?php else: ?>
                <p>This project has no tasks yet.<?= $canCreateTask ? ' Use “Add task” to create the first one.' : '' ?></p>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>Task</th>
                        <th>Assignees</th>
                        <th>Estimate</th>
                        <th>Due</th>
                        <th>Status</th>
                        <?php if ($showActions): ?><th class="text-end">Actions</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                        <?php
                        $isDone  = (string) $task['status'] === 'Done';
                        $overdue = !$isDone && !empty($task['due_date']) && (string) $task['due_date'] < $today;
                        $payload = [
                            'name'            => (string) $task['name'],
                            'description'     => (string) ($task['description'] ?? ''),
                            'status'          => (string) $task['status'],
                            'estimated_hours' => (float) $task['estimated_hours'] > 0 ? rtrim(rtrim(number_format((float) $task['estimated_hours'], 2, '.', ''), '0'), '.') : '',
                            'due_date'        => (string) ($task['due_date'] ?? ''),
                            'assignee_ids'    => $task['assignee_ids'],
                        ];
                        ?>
                        <tr<?= $isDone ? ' class="task-done"' : '' ?>>
                            <td>
                                <span class="fw-medium task-name"><?= e($task['name']) ?></span>
                                <?php if (!empty($task['description'])): ?>
                                    <div class="small text-secondary text-truncate" style="max-width: 32rem;"><?= e($task['description']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($task['assignees'] === []): ?>
                                    <span class="assignee-chip assignee-any">Anyone</span>
                                <?php else: ?>
                                    <?php foreach ($task['assignees'] as $assignee): ?>
                                        <span class="assignee-chip"><?= e($assignee['name']) ?></span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </td>
                            <td><?= (float) $task['estimated_hours'] > 0 ? e(number_format((float) $task['estimated_hours'], 1)) . ' h' : '—' ?></td>
                            <td class="<?= $overdue ? 'text-danger fw-medium' : '' ?>">
                                <?= !empty($task['due_date']) ? e(FormatHelper::date($task['due_date'] . ' 00:00:00', 'M j, Y')) : '—' ?>
                            </td>
                            <td><span class="status-badge status-<?= e($taskStatusClass((string) $task['status'])) ?>"><?= e($task['status']) ?></span></td>
                            <?php if ($showActions): ?>
                                <td class="text-end text-nowrap">
                                    <?php if ($canEditTask): ?>
                                        <form method="post" action="<?= e(url('/tasks/' . (int) $task['id'] . '/status')) ?>" class="d-inline" data-single-submit>
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="status" value="<?= $isDone ? 'Open' : 'Done' ?>">
                                            <button type="submit" class="btn btn-outline-secondary btn-sm"><?= $isDone ? 'Reopen' : 'Mark done' ?></button>
                                        </form>
                                        <button type="button" class="btn btn-outline-secondary btn-sm"
                                                data-bs-toggle="modal" data-bs-target="#taskModal"
                                                data-task-edit="<?= e(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)) ?>"
                                                data-task-action="<?= e(url('/tasks/' . (int) $task['id'])) ?>">Edit</button>
                                    <?php endif; ?>
                                    <?php if ($canDeleteTask): ?>
                                        <form method="post" action="<?= e(url('/tasks/' . (int) $task['id'] . '/delete')) ?>" class="d-inline"
                                              data-confirm="Delete task <?= e($task['name']) ?>? Planned schedule blocks keep their time but lose the task link.">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-outline-danger btn-sm">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php if ($canCreateTask || $canEditTask): ?>
    <?php require APP_PATH . '/Views/tasks/form_modal.php'; ?>
<?php endif; ?>
