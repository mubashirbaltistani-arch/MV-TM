<?php
/**
 * Route table. Each later phase appends its routes here.
 *
 * Conventions:
 *  - Handlers are [ControllerClass::class, 'method'] and receive (Request $request, array $params).
 *  - State-changing routes (post/put/patch/delete) get automatic CSRF verification.
 *  - Authorization is NOT declared here; it lives in each controller's constructor
 *    so it cannot be forgotten when a route is added.
 */

declare(strict_types=1);

return static function (Router $router): void {
    $router->get('/', [HomeController::class, 'index']);
    $router->get('/health', [HealthController::class, 'index']);

    /* ---- Phase 1: authentication, profile, dashboard ---- */
    $router->get('/login', [AuthController::class, 'login']);
    $router->post('/login', [AuthController::class, 'authenticate']);
    $router->post('/logout', [AuthController::class, 'logout']);

    $router->get('/profile', [AuthController::class, 'profile']);
    $router->post('/profile', [AuthController::class, 'updateProfile']);
    $router->post('/profile/password', [AuthController::class, 'updatePassword']);

    $router->get('/dashboard', [DashboardController::class, 'index']);
    $router->post('/notifications/read', [DashboardController::class, 'markNotificationsRead']);

    /* ---- Phase 2: clients, projects, members ---- */
    $router->get('/clients', [ClientController::class, 'index']);
    $router->post('/clients', [ClientController::class, 'store']);
    $router->post('/clients/{id:\d+}', [ClientController::class, 'update']);
    $router->post('/clients/{id:\d+}/delete', [ClientController::class, 'destroy']);

    $router->get('/projects', [ProjectController::class, 'index']);
    $router->get('/projects/create', [ProjectController::class, 'create']);
    $router->post('/projects', [ProjectController::class, 'store']);
    $router->get('/projects/{id:\d+}', [ProjectController::class, 'show']);
    $router->get('/projects/{id:\d+}/edit', [ProjectController::class, 'edit']);
    $router->post('/projects/{id:\d+}', [ProjectController::class, 'update']);
    $router->post('/projects/{id:\d+}/archive', [ProjectController::class, 'archive']);
    $router->post('/projects/{id:\d+}/members', [ProjectController::class, 'syncMembers']);

    /* ---- Phase 4: planned schedule and conflict detection ---- */
    $router->get('/schedule', [ScheduleController::class, 'calendar']);
    $router->get('/schedule/events', [ScheduleController::class, 'eventsJson']);
    $router->get('/schedule/my', [ScheduleController::class, 'mySchedule']);
    $router->get('/schedule/team', [ScheduleController::class, 'teamSchedule']);
    $router->get('/schedule/tasks', [ScheduleController::class, 'tasksJson']);
    $router->get('/schedule/assignees', [ScheduleController::class, 'assigneesJson']);
    $router->post('/schedule', [ScheduleController::class, 'store']);
    $router->post('/schedule/{id:\d+}', [ScheduleController::class, 'update']);
    $router->post('/schedule/{id:\d+}/time', [ScheduleController::class, 'updateEventTime']);
    $router->post('/schedule/{id:\d+}/delete', [ScheduleController::class, 'destroy']);

    /* ---- Phase 5: tasks inside projects (listed on the project page, "Tasks" tab) ---- */
    $router->post('/projects/{id:\d+}/tasks', [TaskController::class, 'store']);
    $router->post('/tasks/{id:\d+}', [TaskController::class, 'update']);
    $router->post('/tasks/{id:\d+}/status', [TaskController::class, 'status']);
    $router->post('/tasks/{id:\d+}/delete', [TaskController::class, 'destroy']);
};
