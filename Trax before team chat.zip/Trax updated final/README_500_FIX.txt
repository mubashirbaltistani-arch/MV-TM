USER PROFILE PHOTO 500 FIX

This package is backward-safe if the Phase 17 database migration was not applied,
partially applied, or applied successfully. Existing pages do not directly reference
users.avatar_path unless SchemaHelper confirms that the column exists.

If the previous package caused a 500, replace the application files with this package.
Do NOT run the old migration again. The included phase17/01_user_profile_images.sql
is idempotent and may be run once if users.avatar_path is still missing.
