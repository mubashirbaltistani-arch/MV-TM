TimeTrack - complete package

Roles: Admin, Manager, Member (stored as "employee"). There is no team lead.

Hierarchy:
- One team manager may manage any number of teams.
- Timesheets go to the team manager, then the project manager, then admins.

Dashboards (same layout for everyone):
- Admin: all time, plus a card per team (total, top project, who worked how much, who is working now).
- Manager: own time plus the teams they manage.
- Member: own time only, with schedule, tasks and recent entries below.

Database: run database/UPGRADE_LIVE.sql (safe to re-run). It also turns old team leads into
normal team members and shows the employee role as "Member".

Invitation email: logo, app name, "Join <name>", one sentence, ACCEPT INVITE, expiry line.
