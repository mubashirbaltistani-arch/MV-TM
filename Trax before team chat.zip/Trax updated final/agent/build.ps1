$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

dotnet restore .\TimeTrackAgent\TimeTrackAgent.csproj
dotnet publish .\TimeTrackAgent\TimeTrackAgent.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true -o .\publish
Write-Host "Published to $PSScriptRoot\publish"
