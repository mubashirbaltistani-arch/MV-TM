<?php
/**
 * Clockify-style weekly dashboard scoped by hierarchy position.
 * Admin: everyone. Project manager: their projects. Department manager: their
 * departments. Team manager: their teams. Members: their own time.
 */

declare(strict_types=1);

final class DashboardController extends Controller
{
    public function __construct()
    {
        parent::__construct(true);
    }

    /** GET /dashboard  (optional ?week=YYYY-MM-DD&who=team|me) */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('dashboard.view');

        $userId = (int) AuthHelper::id();
        $me = AuthHelper::user() ?? ['name' => '', 'role' => ''];
        $hour = (int) FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'G');
        $greeting = $hour < 12
            ? 'Good morning'
            : ($hour < 18 ? 'Good afternoon' : 'Good evening');

        $firstName = trim((string) strtok((string) ($me['name'] ?? ''), ' '));

        $unread = 0;
        $notifications = [];
        $canViewNotifications = PermissionHelper::has('notifications.view');

        if ($canViewNotifications) {
            try {
                $unread = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
                    ['id' => $userId]
                );

                $notifications = Database::fetchAll(
                    'SELECT id, type, title, message, link, is_read, created_at
                     FROM notifications
                     WHERE user_id = :id
                     ORDER BY created_at DESC, id DESC
                     LIMIT 6',
                    ['id' => $userId]
                );
            } catch (Throwable $e) {
                LoggerHelper::exception($e);
                $unread = 0;
                $notifications = [];
            }
        }

        $shared = [
            'pageTitle' => 'Dashboard',
            'greeting' => $greeting,
            'firstName' => $firstName,
            'unread' => $unread,
            'notifications' => $notifications,
            'canViewNotifications' => $canViewNotifications,
            'canTrack' => PermissionHelper::has('time.track')
                && class_exists('Timer')
                && Timer::installed()
                && FeatureFlagsHelper::trackerVisible(),
            'currency' => AnalyticsHelper::currency(),
        ];

        $this->dashboard($request, $shared, $userId);
    }

    /**
     * @param array<string, mixed> $shared
     */
    private function dashboard(Request $request, array $shared, int $userId): void
    {
        $weekParam = (string) $request->input('week', '');
        $range = (string) $request->input('range', 'week');
        $anchorDate = (string) $request->input('date', '');
        $who = (string) $request->input('who', 'team');

        $scope = WeekDashboardHelper::scopeFor($userId);
        $audience = (string) $scope['audience'];
        $managedTeamCount = (int) $scope['managed_team_count'];
        $showWhoSwitch = !empty($scope['show_who_switch']);
        $onlyMe = $audience === 'member' || $who === 'me';
        if (in_array($audience, ['team_manager', 'department_manager'], true) && $managedTeamCount === 0) {
            $onlyMe = true;
            $showWhoSwitch = false;
        }

        $viewAll = !$onlyMe && !empty($scope['view_all']);
        $restrictUserIds = $onlyMe ? [$userId] : $scope['restrict_user_ids'];
        $includeTeamOverview = !$onlyMe && !empty($scope['include_team_overview']);
        // Departments are no longer shown on the dashboard; Teams cards replace them.
        $includeDepartmentOverview = false;

        try {
            $week = WeekDashboardHelper::build(
                $userId,
                $viewAll || $onlyMe,
                $weekParam !== '' ? $weekParam : null,
                $onlyMe,
                $range,
                $anchorDate !== '' ? $anchorDate : null,
                $restrictUserIds,
                $includeTeamOverview,
                (bool) $scope['managed_teams_only'],
                [
                    'restrict_project_ids' => $onlyMe ? null : $scope['restrict_project_ids'],
                    'restrict_team_ids' => $onlyMe ? null : $scope['restrict_team_ids'],
                    'restrict_department_ids' => $onlyMe ? null : $scope['restrict_department_ids'],
                    'include_department_overview' => $includeDepartmentOverview,
                ]
            );
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $week = WeekDashboardHelper::build($userId, false, null, true);
            $week['ready'] = false;
        }

        $week['managed_team_count'] = $managedTeamCount;
        $week['scope_label'] = (string) ($scope['scope_label'] ?? '');
        $week['audience'] = $audience;

        $pending = 0;
        $isAdmin = $audience === 'admin';
        $canApprove = PermissionHelper::has('time.approve')
            || ApprovalChainHelper::canAccessApprovals($userId);
        if (FeatureFlagsHelper::timeApprovalEnabled() && Timesheet::installed() && $canApprove) {
            try {
                $pending = (int) ((new Timesheet())->queueCounts($userId, $isAdmin)['Submitted'] ?? 0);
            } catch (Throwable $e) {
                LoggerHelper::exception($e);
                $pending = 0;
            }
        }

        $memberExtras = [];
        if ($audience === 'member' || $onlyMe) {
            $memberExtras = $this->memberExtras($userId);
        }

        $this->render(
            'dashboard/admin_manager',
            array_merge($shared, $memberExtras, [
                'week' => $week,
                'canApprove' => $canApprove,
                'pendingApprovals' => $pending,
                'chartAssets' => true,
                'showWhoSwitch' => $showWhoSwitch,
                'audience' => $audience,
                'managedTeamCount' => $managedTeamCount,
                'scopeLabel' => (string) ($scope['scope_label'] ?? ''),
            ])
        );
    }

    /**
     * Schedule, tasks and recent entries shown under a member's own dashboard.
     *
     * @return array<string, mixed>
     */
    private function memberExtras(int $userId): array
    {
        $today = AnalyticsHelper::employeeToday($userId);
        $projects = [];
        if (class_exists('TimeEntry') && TimeEntry::installed()) {
            $projects = (new TimeEntry())->trackableProjects(
                $userId,
                PermissionHelper::has('projects.view_all')
            );
        }

        return [
            'today' => $today,
            'projects' => $projects,
            'canManual' => PermissionHelper::has('time.edit_own') && FeatureFlagsHelper::allowManual(),
            'canDelete' => PermissionHelper::has('time.edit_own'),
            'canEdit' => PermissionHelper::has('time.edit_own'),
            'userId' => $userId,
            'capacityHours' => WorkspacePolicy::dailyCapacityHours(),
            'showMemberExtras' => true,
        ];
    }

    /** POST /notifications/read : mark all of the user's notifications as read. */
    public function markNotificationsRead(Request $request, array $params): void
    {
        PermissionHelper::require('notifications.view');

        Database::execute(
            'UPDATE notifications
             SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE user_id = :id AND is_read = 0',
            ['id' => (int) AuthHelper::id()]
        );

        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }

        $this->redirect('/dashboard');
    }
}