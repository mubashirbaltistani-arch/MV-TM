<?php
declare(strict_types=1);

/** CSV importer for initial migration from another time/project system. */
final class ImportController extends Controller
{
    private const TYPES = [
        'users' => 'Users / team members',
        'clients' => 'Clients',
        'projects' => 'Projects',
        'project_members' => 'Project members',
        'tasks' => 'Tasks',
        'task_assignees' => 'Task assignees',
        'time_entries' => 'Historical time entries (with approval status)',
        'clockify_time' => 'Clockify time report (detailed CSV)',
        'schedules' => 'Schedules',
    ];

    private const MAX_ROWS = 5000;

    /** Date order of the Clockify export being imported: ymd | mdy | dmy. */
    private string $clockifyDateFormat = 'ymd';

    /** Id of the entry written by the last timeEntry() call (used to link approvals). */
    private ?int $lastEntryId = null;

    /** @var list<array<string,mixed>> approval info collected while importing time entries */
    private array $approvalQueue = [];

    /** @var array<string,int>|null name key => project id */
    private ?array $projectNameCache = null;

    /** @var array<string,int>|null name key => user id */
    private ?array $userNameCache = null;

    private const UNASSIGNED_CLIENT = 'Unassigned';

    private const UPSERT_TABLES = [
        'users', 'clients', 'projects', 'project_members', 'tasks', 'task_assignees', 'time_entries', 'schedules',
    ];

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER]);
        // The parent constructor already limits this area to Admin/Manager (same gate the sidebar uses).
        // Only enforce the DB permission for roles that are not Admin, because 'imports.manage' is not
        // seeded in role_permissions on every install and would otherwise 403 admins.
        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            PermissionHelper::require('imports.manage');
        }
    }

    public function index(Request $request, array $params): void
    {
        $this->render('imports/index', [
            'pageTitle' => 'Import data',
            'types' => self::TYPES,
            'selected' => (string) $request->input('type', 'users'),
            'result' => null,
        ]);
    }

    public function import(Request $request, array $params): void
    {
        $type = (string) $request->input('type', '');
        if (!isset(self::TYPES[$type])) {
            $this->flash('danger', 'Choose a valid import type.');
            $this->redirect('/import');
        }
        if (!isset($_FILES['csv']) || !is_array($_FILES['csv']) || (int) ($_FILES['csv']['error'] ?? 99) !== UPLOAD_ERR_OK) {
            $this->flash('danger', 'Please select a CSV file.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        $tmp = (string) $_FILES['csv']['tmp_name'];
        if ((int) ($_FILES['csv']['size'] ?? 0) > 10 * 1024 * 1024) {
            $this->flash('danger', 'CSV is too large. Maximum size is 10 MB.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        $rows = $this->readCsv($tmp);
        if ($rows === []) {
            $this->flash('danger', 'The CSV is empty or its header row could not be read.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }
        if (count($rows) > self::MAX_ROWS) {
            $this->flash('danger', 'CSV has more than ' . self::MAX_ROWS . ' data rows. Split the file and import in batches.');
            $this->redirect('/import?type=' . rawurlencode($type));
        }

        $hasSplitDates = isset($rows[0]['start date']) || isset($rows[0]['start_date']);
        if ($type === 'clockify_time' || ($type === 'time_entries' && $hasSplitDates)) {
            $choice = (string) $request->input('date_format', 'auto');
            $format = in_array($choice, ['mdy', 'dmy'], true) ? $choice : $this->detectClockifyDateFormat($rows);
            if ($format === null) {
                $this->flash('danger', 'Could not tell whether the dates in this Clockify file are MM/DD/YYYY or DD/MM/YYYY. Pick the date format in the form and import again.');
                $this->redirect('/import?type=' . rawurlencode($type));
            }
            $this->clockifyDateFormat = $format;
        }

        $dryRun = $request->input('preview') === '1' || $request->input('preview') === 'on';
        $allOrNothing = $request->input('all_or_nothing') === '1' || $request->input('all_or_nothing') === 'on';

        $result = $this->runImport($type, $rows, $dryRun, $allOrNothing);
        LoggerHelper::audit('import.completed', 'import', null, [
            'type' => $type,
            'rows' => count($rows),
            'created' => $result['created'],
            'updated' => $result['updated'],
            'skipped' => $result['skipped'],
            'preview' => $dryRun,
            'all_or_nothing' => $allOrNothing,
            'passwords_generated' => $result['passwords_generated'] ?? 0,
        ]);
        $this->render('imports/index', [
            'pageTitle' => 'Import data',
            'types' => self::TYPES,
            'selected' => $type,
            'result' => $result,
        ]);
    }

    /** @return list<array<string,string>> */
    private function readCsv(string $path): array
    {
        $fh = fopen($path, 'rb');
        if ($fh === false) {
            return [];
        }
        $header = fgetcsv($fh);
        if ($header === false) {
            fclose($fh);
            return [];
        }
        if (isset($header[0])) {
            $header[0] = preg_replace('/^\xEF\xBB\xBF/', '', (string) $header[0]) ?? (string) $header[0];
        }
        $header = array_map(fn ($v): string => strtolower($this->clean((string) $v)), $header);
        $rows = [];
        while (($line = fgetcsv($fh)) !== false) {
            if (count(array_filter($line, static fn ($v): bool => trim((string) $v) !== '')) === 0) {
                continue;
            }
            $row = [];
            foreach ($header as $i => $key) {
                if ($key !== '') {
                    $row[$key] = $this->clean((string) ($line[$i] ?? ''));
                }
            }
            $rows[] = $row;
        }
        fclose($fh);
        return $rows;
    }

    /** @param list<array<string,string>> $rows */
    private function runImport(string $type, array $rows, bool $dryRun, bool $allOrNothing): array
    {
        $result = [
            'created' => 0,
            'updated' => 0,
            'skipped' => 0,
            'errors' => [],
            'passwords_generated' => 0,
            'preview' => $dryRun,
        ];

        $runner = function () use ($type, $rows, &$result): void {
            $this->approvalQueue = [];
            foreach ($rows as $n => $row) {
                try {
                    $changed = match ($type) {
                        'users' => $this->user($row, $result),
                        'clients' => $this->client($row),
                        'projects' => $this->project($row),
                        'project_members' => $this->projectMember($row),
                        'tasks' => $this->task($row),
                        'task_assignees' => $this->taskAssignee($row),
                        'time_entries' => $this->timeEntry($row),
                        'clockify_time' => $this->clockifyEntry($row),
                        'schedules' => $this->schedule($row),
                    };
                    if ($changed === 'created') {
                        $result['created']++;
                    } elseif ($changed === 'updated') {
                        $result['updated']++;
                    } else {
                        $result['skipped']++;
                    }
                } catch (Throwable $e) {
                    $result['skipped']++;
                    if (count($result['errors']) < 100) {
                        $result['errors'][] = 'CSV row ' . ($n + 2) . ': ' . $e->getMessage();
                    }
                    LoggerHelper::exception($e);
                    if (!empty($result['strict_txn'])) {
                        throw $e;
                    }
                }
            }
            if (in_array($type, ['time_entries', 'clockify_time'], true)) {
                try {
                    $this->applyApprovals($result);
                } catch (Throwable $e) {
                    LoggerHelper::exception($e);
                    $result['errors'][] = 'Approval status could not be applied: ' . $e->getMessage();
                    if (!empty($result['strict_txn'])) {
                        throw $e;
                    }
                }
            }
        };

        $result['all_or_nothing'] = $allOrNothing;
        $result['strict_txn'] = $allOrNothing && !$dryRun;

        try {
            if ($dryRun || $allOrNothing) {
                Database::transaction(function () use ($runner, $dryRun): void {
                    $runner();
                    if ($dryRun) {
                        throw new RuntimeException('__import_preview_rollback__');
                    }
                });
            } else {
                $runner();
            }
        } catch (RuntimeException $e) {
            if ($e->getMessage() !== '__import_preview_rollback__') {
                if ($allOrNothing && !$dryRun) {
                    $result['created'] = 0;
                    $result['updated'] = 0;
                }
            }
        } catch (Throwable $e) {
            if ($allOrNothing && !$dryRun) {
                $result['created'] = 0;
                $result['updated'] = 0;
            }
            LoggerHelper::exception($e);
        }

        if ($dryRun) {
            array_unshift($result['errors'], 'Preview only: no rows were written.');
        }

        return $result;
    }

    /** @param array<string,string> $r */
    private function user(array $r, array &$result): string
    {
        foreach (['name', 'email', 'role'] as $k) {
            $this->required($r, $k);
        }

        $actorIsAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
        $actorId = (int) AuthHelper::id();

        $role = strtolower($r['role']);
        if (!in_array($role, AuthHelper::ROLES, true)) {
            throw new RuntimeException('Invalid role: ' . $role);
        }
        if (!$actorIsAdmin && $role === AuthHelper::ROLE_ADMIN) {
            throw new RuntimeException('Only admins can import admin users.');
        }

        $roleId = (int) Database::fetchValue('SELECT id FROM roles WHERE name = :r', ['r' => $role]);
        if (!$roleId) {
            throw new RuntimeException('Role not found: ' . $role);
        }

        $email = strtolower($r['email']);
        $existing = Database::fetchOne(
            'SELECT u.id, r.name AS role_name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.email = :e',
            ['e' => $email]
        );

        $status = in_array($r['status'] ?? 'active', ['active', 'inactive', 'suspended'], true)
            ? (string) $r['status']
            : 'active';

        if ($existing) {
            $existingId = (int) $existing['id'];
            $existingRole = (string) $existing['role_name'];
            if (!$actorIsAdmin && $existingRole === AuthHelper::ROLE_ADMIN) {
                throw new RuntimeException('Cannot modify an admin account.');
            }
            if ($existingId === $actorId && ($role !== $existingRole || $status !== 'active')) {
                throw new RuntimeException('Cannot change the role or status of the currently logged-in user.');
            }
        }

        $timezone = $r['timezone'] !== '' ? $r['timezone'] : SettingsService::systemTimezone();
        if (!FormatHelper::isValidZone($timezone)) {
            $timezone = SettingsService::systemTimezone();
        }

        $data = [
            'role_id' => $roleId,
            'role' => $role,
            'name' => $r['name'],
            'email' => $email,
            'phone' => ($r['phone'] ?? '') !== '' ? $r['phone'] : null,
            'job_title' => ($r['job_title'] ?? '') !== '' ? $r['job_title'] : null,
            'hourly_rate' => $this->num($r['hourly_rate'] ?? '0'),
            'timezone' => $timezone,
            'status' => $status,
        ];

        if ($existing) {
            $id = (int) $existing['id'];
            Database::execute(
                'UPDATE users SET role_id = :role_id, role = :role, name = :name, phone = :phone,
                 job_title = :job_title, hourly_rate = :hourly_rate, timezone = :timezone,
                 status = :status, updated_at = UTC_TIMESTAMP()
                 WHERE id = :id',
                $data + ['id' => $id]
            );
            LoggerHelper::audit('import.user_updated', 'user', $id, ['email' => $email, 'role' => $role]);
            return 'updated';
        }

        $generated = false;
        if (($r['password'] ?? '') !== '') {
            $password = $r['password'];
        } else {
            $password = bin2hex(random_bytes(12));
            $generated = true;
        }

        Database::execute(
            'INSERT INTO users (role_id, role, name, email, password, phone, job_title, hourly_rate, timezone, status, password_changed_at)
             VALUES (:role_id, :role, :name, :email, :password, :phone, :job_title, :hourly_rate, :timezone, :status, NULL)',
            $data + ['password' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 12])]
        );
        $id = Database::lastInsertId();
        if ($generated) {
            $result['passwords_generated']++;
        }
        LoggerHelper::audit('import.user_created', 'user', $id, [
            'email' => $email,
            'role' => $role,
            'password_generated' => $generated,
        ]);
        return 'created';
    }

    /** @param array<string,string> $r */
    private function client(array $r): string
    {
        $this->required($r, 'name');
        $email = ($r['email'] ?? '') !== '' ? strtolower($r['email']) : null;
        $existingId = $this->lookupClient($email ?? '', $r['name']);
        $lookup = $existingId !== null
            ? ['id' => $existingId]
            : ($email !== null ? ['email' => $email] : ['name' => $r['name']]);
        $data = [
            'name' => $r['name'],
            'email' => $email,
            'phone' => ($r['phone'] ?? '') !== '' ? $r['phone'] : null,
            'address' => ($r['address'] ?? '') !== '' ? $r['address'] : null,
            'status' => in_array($r['status'] ?? 'active', ['active', 'inactive'], true) ? $r['status'] : 'active',
        ];
        return $this->upsert('clients', $lookup, $data);
    }

    /** @param array<string,string> $r */
    private function project(array $r): string
    {
        foreach (['name', 'status'] as $k) {
            $this->required($r, $k);
        }
        $lookup = ($r['project_code'] ?? '') !== ''
            ? ['project_code' => $r['project_code']]
            : ['name' => $r['name']];
        $clientName = trim((string) ($r['client_name'] ?? ''));
        if ($clientName === '') {
            // Projects require a client in this app; park client-less rows under a placeholder.
            $clientName = self::UNASSIGNED_CLIENT;
            if ($this->lookupClient('', $clientName) === null) {
                Database::execute(
                    'INSERT INTO clients (name, status) VALUES (:n, :s)',
                    ['n' => $clientName, 's' => 'active']
                );
            }
        }
        $clientId = $this->lookupClient('', $clientName);
        if (!$clientId) {
            throw new RuntimeException('Client not found: ' . $clientName . ' (import clients first, or fix the spelling)');
        }
        $managerId = $this->lookupUser($r['manager_email'] ?? '');
        $allowed = ['Planning', 'Active', 'On Hold', 'Completed', 'Archived'];
        $statusKey = strtolower(str_replace(['_', '-'], ' ', $r['status']));
        $statusMap = [
            'planning' => 'Planning', 'active' => 'Active', 'on hold' => 'On Hold', 'hold' => 'On Hold',
            'completed' => 'Completed', 'complete' => 'Completed', 'done' => 'Completed',
            'archived' => 'Archived', 'inactive' => 'Archived',
        ];
        $status = $statusMap[$statusKey] ?? 'Planning';
        $createdBy = $this->lookupUser($r['created_by_email'] ?? '') ?: (int) AuthHelper::id();
        $data = [
            'client_id' => $clientId,
            'name' => $r['name'],
            'project_code' => ($r['project_code'] ?? '') !== '' ? $r['project_code'] : null,
            'description' => ($r['description'] ?? '') !== '' ? $r['description'] : null,
            'status' => $status,
            'priority' => (($priority = trim((string) ($r['priority'] ?? ''))) !== '' && in_array($priority, ['Low', 'Medium', 'High', 'Urgent'], true)) ? $priority : 'Medium',
            'start_date' => ($r['start_date'] ?? '') !== '' ? $r['start_date'] : null,
            'due_date' => ($r['due_date'] ?? '') !== '' ? $r['due_date'] : null,
            'manager_id' => $managerId ?: null,
            'hourly_rate' => $this->num($r['hourly_rate'] ?? '0'),
            'is_billable' => $this->bool($r['is_billable'] ?? '1'),
        ];
        return $this->upsert('projects', $lookup, $data, ['created_by' => $createdBy]);
    }

    /** @param array<string,string> $r */
    private function projectMember(array $r): string
    {
        foreach (['project_code', 'user_email'] as $k) {
            $this->required($r, $k);
        }
        $pid = $this->lookupProject($r['project_code']);
        $uid = $this->lookupUser($r['user_email']);
        if (!$pid || !$uid) {
            throw new RuntimeException('Project or user not found');
        }
        $role = in_array($r['project_role'] ?? 'member', ['manager', 'member', 'viewer'], true)
            ? $r['project_role']
            : 'member';
        $pmId = (int) Database::fetchValue('SELECT manager_id FROM projects WHERE id = :id LIMIT 1', ['id' => $pid]);
        if ($role === 'manager' && $uid !== $pmId) {
            $role = 'member';
        }
        if ($uid === $pmId) {
            $role = 'manager';
        }
        $ex = Database::fetchOne(
            'SELECT 1 FROM project_members WHERE project_id = :p AND user_id = :u',
            ['p' => $pid, 'u' => $uid]
        );
        if ($ex) {
            Database::execute(
                'UPDATE project_members SET project_role = :r WHERE project_id = :p AND user_id = :u',
                ['r' => $role, 'p' => $pid, 'u' => $uid]
            );
            return 'updated';
        }
        Database::execute(
            'INSERT INTO project_members (project_id, user_id, project_role) VALUES (:p, :u, :r)',
            ['p' => $pid, 'u' => $uid, 'r' => $role]
        );
        return 'created';
    }

    /** @param array<string,string> $r */
    private function task(array $r): string
    {
        foreach (['project_code', 'name'] as $k) {
            $this->required($r, $k);
        }
        $pid = $this->lookupProject($r['project_code']);
        if (!$pid) {
            throw new RuntimeException('Project not found');
        }
        $rawStatus = ($r['status'] ?? '') !== '' ? $r['status'] : Task::STATUS_TODO;
        $status = Task::persistStatus(Task::normalizeStatus($rawStatus));
        if (!in_array($status, Task::STATUSES, true) && !Task::statusEnumAllows($status)) {
            $status = Task::persistStatus(Task::STATUS_TODO);
        }
        $data = [
            'project_id' => $pid,
            'name' => $r['name'],
            'description' => ($r['description'] ?? '') !== '' ? $r['description'] : null,
            'status' => $status,
            'priority' => in_array($r['priority'] ?? 'Medium', Task::PRIORITIES, true) ? $r['priority'] : Task::PRIORITY_MEDIUM,
            'estimated_hours' => $this->num($r['estimated_hours'] ?? '0'),
            'is_billable' => $this->bool($r['is_billable'] ?? '0'),
        ];
        $teamName = trim((string) ($r['team'] ?? $r['team_name'] ?? ''));
        if ($teamName !== '' && SchemaHelper::columnExists('tasks', 'team_id') && TeamGroup::installed()) {
            $team = Database::fetchOne(
                'SELECT id FROM teams WHERE project_id = :p AND name = :n LIMIT 1',
                ['p' => $pid, 'n' => $teamName]
            );
            if ($team === null) {
                throw new RuntimeException('Team "' . $teamName . '" was not found in this project.');
            }
            $data['team_id'] = (int) $team['id'];
        }
        return $this->upsert(
            'tasks',
            ['project_id' => $pid, 'name' => $r['name']],
            $data,
            ['created_by' => (int) AuthHelper::id()]
        );
    }

    /** @param array<string,string> $r */
    private function taskAssignee(array $r): string
    {
        foreach (['project_code', 'task_name', 'user_email'] as $k) {
            $this->required($r, $k);
        }
        $pid = $this->lookupProject($r['project_code']);
        $uid = $this->lookupUser($r['user_email']);
        $task = Database::fetchOne(
            SchemaHelper::columnExists('tasks', 'team_id')
                ? 'SELECT id, team_id FROM tasks WHERE project_id = :p AND name = :n'
                : 'SELECT id FROM tasks WHERE project_id = :p AND name = :n',
            ['p' => $pid, 'n' => $r['task_name']]
        );
        if (!$task || !$uid) {
            throw new RuntimeException('Task or user not found');
        }
        $project = (new Project())->find($pid);
        if ($project === null) {
            throw new RuntimeException('Project not found');
        }
        $teamId = null;
        if (isset($task['team_id']) && $task['team_id'] !== null && $task['team_id'] !== '') {
            $teamId = (int) $task['team_id'];
            if ($teamId < 1) {
                $teamId = null;
            }
        }
        try {
            TaskPolicy::assertAssignable((int) AuthHelper::id(), $project, $teamId, [$uid]);
        } catch (HttpException $e) {
            throw new RuntimeException($e->getMessage());
        }
        $ex = Database::fetchOne(
            'SELECT 1 FROM task_assignees WHERE task_id = :t AND user_id = :u',
            ['t' => (int) $task['id'], 'u' => $uid]
        );
        if ($ex) {
            return 'skipped';
        }
        Database::execute(
            'INSERT INTO task_assignees (task_id, user_id) VALUES (:t, :u)',
            ['t' => (int) $task['id'], 'u' => $uid]
        );
        return 'created';
    }

    /**
     * Historical time entry. Accepts the full export layout with every value in its own column:
     *   start_date, start_time, end_date, end_time, duration, created date, approval status/submission/processing.
     * The older layout (start_time / end_time holding "YYYY-MM-DD HH:MM:SS") still works.
     *
     * @param array<string,string> $r
     */
    private function timeEntry(array $r): string
    {
        $this->lastEntryId = null;
        $pre = isset($r['_uid'], $r['_pid'], $r['_start_utc'], $r['_end_utc']);

        if (!$pre) {
            $r['user_email'] = $this->col($r, 'user_email', 'email');
            $r['project_code'] = $this->col($r, 'project_code', 'project code');
            $r['task_name'] = $this->col($r, 'task_name', 'task');
            $this->required($r, 'user_email');
            if ($r['project_code'] === '' && $this->col($r, 'project') === '') {
                throw new RuntimeException('Missing project_code');
            }
        }
        $uid = $pre ? (int) $r['_uid'] : $this->lookupUser($r['user_email']);
        $pid = $pre ? (int) $r['_pid'] : $this->lookupProject($r['project_code']);
        if (!$pid && !$pre) {
            $pid = $this->lookupProjectByName($this->col($r, 'project'));
        }
        if (!$uid || !$pid) {
            throw new RuntimeException('User or project not found');
        }
        $zone = FormatHelper::timezoneForUser($uid);

        $taskId = null;
        if (($r['task_name'] ?? '') !== '') {
            $t = Database::fetchOne(
                'SELECT id FROM tasks WHERE project_id = :p AND name = :n',
                ['p' => $pid, 'n' => $r['task_name']]
            );
            $taskId = $t ? (int) $t['id'] : null;
            if ($taskId === null && empty($r['_task_optional'])) {
                throw new RuntimeException('Task not found');
            }
        }

        if ($pre) {
            $start = (string) $r['_start_utc'];
            $end = (string) $r['_end_utc'];
        } else {
            $startDate = $this->col($r, 'start_date', 'start date');
            $endDate = $this->col($r, 'end_date', 'end date');
            if ($startDate !== '' || $endDate !== '') {
                foreach ([['start date', $startDate], ['start time', $this->col($r, 'start_time', 'start time')],
                          ['end date', $endDate], ['end time', $this->col($r, 'end_time', 'end time')]] as [$label, $value]) {
                    if ($value === '') {
                        throw new RuntimeException('Missing ' . $label);
                    }
                }
                $start = $this->clockifyUtc($startDate, $this->col($r, 'start_time', 'start time'), $zone);
                $end = $this->clockifyUtc($endDate, $this->col($r, 'end_time', 'end time'), $zone);
            } else {
                $this->required($r, 'start_time');
                $this->required($r, 'end_time');
                $start = $this->datetime($r['start_time']);
                $end = $this->datetime($r['end_time']);
            }
        }
        $startTs = strtotime($start . ' UTC');
        $endTs = strtotime($end . ' UTC');
        if ($startTs === false || $endTs === false || $endTs <= $startTs) {
            throw new RuntimeException('End must be after start');
        }

        try {
            TimeTrackingRules::assertCanTrack(
                $uid,
                $pid,
                $taskId,
                $start,
                TimeTrackingRules::CONTEXT_IMPORT
            );
        } catch (HttpException $e) {
            throw new RuntimeException($e->getMessage());
        }

        // Break: explicit column wins; otherwise whatever the exported duration is shorter than end-start by.
        $breakRaw = $this->col($r, 'break_minutes', 'break minutes');
        if ($breakRaw !== '') {
            $break = max(0, (int) $breakRaw);
        } else {
            $break = 0;
            $durSeconds = $this->durationSeconds($this->col($r, 'duration_decimal', 'duration (decimal)'), $this->col($r, 'duration_h', 'duration (h)', 'duration'));
            if ($durSeconds !== null && $durSeconds > 0) {
                $gap = ($endTs - $startTs) - $durSeconds;
                if ($gap >= 60) {
                    $break = intdiv($gap, 60);
                }
            }
        }

        $bill = $this->bool($r['is_billable'] ?? '1');
        $rate = $this->num($r['billable_rate'] ?? '0');
        if ($rate <= 0) {
            $rate = (float) (Database::fetchValue('SELECT hourly_rate FROM projects WHERE id = :id', ['id' => $pid]) ?? 0);
        }

        $payload = [
            'user_id' => $uid,
            'project_id' => $pid,
            'task_id' => $taskId,
            'start_time' => $start,
            'end_time' => $end,
            'break_minutes' => $break,
            'description' => ($r['description'] ?? '') !== '' ? $r['description'] : null,
            'is_billable' => $bill,
            'billable_rate' => $rate,
            'auto_stopped' => $this->bool($r['auto_stopped'] ?? '0'),
            '_context' => TimeTrackingRules::CONTEXT_IMPORT,
        ];

        $startCol = TimeEntry::column('start_time') ?? 'started_at';
        $endCol = TimeEntry::column('end_time') ?? 'ended_at';
        $ex = Database::fetchOne(
            "SELECT id FROM time_entries WHERE user_id = :u AND `{$startCol}` = :s AND `{$endCol}` = :e LIMIT 1",
            ['u' => $uid, 's' => $start, 'e' => $end]
        );

        $model = new TimeEntry();
        if ($ex) {
            if ($model->isLocked(['id' => (int) $ex['id']])) {
                // Already on a submitted/approved timesheet: leave it exactly as it is.
                return 'skipped';
            }
            $entry = $model->updateEntry((int) $ex['id'], $payload);
            $result = 'updated';
        } else {
            $entry = $model->createEntry($payload, false);
            $result = 'created';
        }
        $entryId = (int) ($entry['id'] ?? $ex['id'] ?? 0);
        $this->lastEntryId = $entryId > 0 ? $entryId : null;

        // Original creation date from the old tracker.
        $createdRaw = $this->col($r, 'created_at', 'date of creation', 'date_of_creation');
        $createdCol = TimeEntry::column('created_at');
        if ($entryId > 0 && $createdRaw !== '' && $createdCol !== null) {
            $createdUtc = $this->localToUtc($createdRaw, $this->col($r, 'time of creation', 'created_time'), $zone);
            if ($createdUtc === null) {
                throw new RuntimeException('Invalid creation date: ' . $createdRaw);
            }
            Database::execute(
                "UPDATE time_entries SET `{$createdCol}` = :c WHERE id = :id",
                ['c' => $createdUtc, 'id' => $entryId]
            );
        }

        // Approval info is applied per timesheet once every row has been read.
        $approval = $this->approvalFromStatus($this->col($r, 'approval_status', 'approval status'));
        if ($approval !== null && $entryId > 0) {
            $this->approvalQueue[] = [
                'uid' => $uid,
                'entry_id' => $entryId,
                'start_utc' => $start,
                'status' => $approval,
                'approver' => $this->col($r, 'approval_processed_by', 'approval processed by', 'approved_by'),
                'submitted_utc' => $this->localToUtc(
                    $this->col($r, 'submitted_at', 'date of approval submission', 'date_of_approval_submission'),
                    $this->col($r, 'time of approval submission', 'time_of_approval_submission'),
                    $zone
                ),
                'processed_utc' => $this->localToUtc(
                    $this->col($r, 'approved_at', 'date of approval processing', 'date_of_approval_processing'),
                    $this->col($r, 'time of approval processing', 'time_of_approval_processing'),
                    $zone
                ),
                'zone' => $zone,
            ];
        }

        return $result;
    }

    /** First non-empty value among several header spellings. @param array<string,string> $r */
    private function col(array $r, string ...$keys): string
    {
        foreach ($keys as $k) {
            if (isset($r[$k]) && $r[$k] !== '') {
                return (string) $r[$k];
            }
        }
        return '';
    }

    /** Duration in seconds from "2.50" (decimal hours) or "02:30:00" (h:mm:ss); null if neither is usable. */
    private function durationSeconds(string $decimal, string $hms): ?int
    {
        if ($decimal !== '' && is_numeric(str_replace(',', '.', $decimal))) {
            return (int) round(((float) str_replace(',', '.', $decimal)) * 3600);
        }
        if (preg_match('/^(\d+):(\d{2})(?::(\d{2}))?$/', $hms, $m)) {
            return ((int) $m[1]) * 3600 + ((int) $m[2]) * 60 + (int) ($m[3] ?? 0);
        }
        return null;
    }

    /**
     * A date (or date + time, or a combined "date time" value) in the user's timezone -> UTC.
     * Returns null for an empty or unreadable value.
     */
    private function localToUtc(string $dateOrDateTime, string $time, string $zone): ?string
    {
        $v = trim($dateOrDateTime);
        if ($v === '') {
            return null;
        }
        if ($time === '' && preg_match('/^(\S+?)(?:\s+|T)(\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AaPp][Mm])?)$/', $v, $m)) {
            [$v, $time] = [$m[1], $m[2]];
        }
        try {
            return $this->clockifyUtc($v, $time !== '' ? $time : '12:00:00 AM', $zone);
        } catch (RuntimeException) {
            return null;
        }
    }

    /** Map an exported approval status to a timesheet status; null = no timesheet (unsubmitted/unknown). */
    private function approvalFromStatus(string $status): ?string
    {
        $k = strtolower(trim($status));
        return match (true) {
            $k === 'approved' => Timesheet::STATUS_APPROVED,
            in_array($k, ['pending', 'submitted', 'waiting', 'awaiting approval', 'pending approval'], true) => Timesheet::STATUS_SUBMITTED,
            in_array($k, ['rejected', 'declined'], true) => Timesheet::STATUS_REJECTED,
            default => null,
        };
    }

    private function lookupProjectByName(string $name): int
    {
        $key = $this->nameKey($name);
        if ($key === '') {
            return 0;
        }
        if ($this->projectNameCache === null) {
            $this->projectNameCache = [];
            foreach (Database::fetchAll('SELECT id, name FROM projects') as $p) {
                $this->projectNameCache[$this->nameKey((string) $p['name'])] ??= (int) $p['id'];
            }
        }
        return $this->projectNameCache[$key] ?? 0;
    }

    /** Resolve "Approval processed by" (an email or a person's name) to a user id, or null. */
    private function lookupApprover(string $who): ?int
    {
        $who = trim($who);
        if ($who === '') {
            return null;
        }
        if (str_contains($who, '@')) {
            $id = $this->lookupUser($who);
            return $id > 0 ? $id : null;
        }
        if ($this->userNameCache === null) {
            $this->userNameCache = [];
            foreach (Database::fetchAll('SELECT id, name FROM users') as $u) {
                $this->userNameCache[$this->nameKey((string) $u['name'])] ??= (int) $u['id'];
            }
        }
        return $this->userNameCache[$this->nameKey($who)] ?? null;
    }

    /**
     * Turn the approval info collected from the rows into real timesheets.
     * One timesheet per person + approval period (the database allows only one), holding the entries
     * that were Submitted/Approved there. Rejected work is recorded as a Rejected timesheet with no
     * locked entries, exactly as the app does when a manager rejects.
     *
     * @param array<string,mixed> $result
     */
    private function applyApprovals(array &$result): void
    {
        if ($this->approvalQueue === []) {
            return;
        }
        $addNote = static function (array &$result, string $msg): void {
            if (count($result['errors']) < 100) {
                $result['errors'][] = $msg;
            }
        };
        if (!Timesheet::installed()) {
            $addNote($result, 'Approval columns were ignored: the timesheets table is not installed.');
            return;
        }

        $ts = new Timesheet();
        $displayZone = new DateTimeZone(FormatHelper::displayTimezone());
        $utc = new DateTimeZone('UTC');

        $groups = [];
        foreach ($this->approvalQueue as $q) {
            $local = (new DateTimeImmutable((string) $q['start_utc'], $utc))->setTimezone($displayZone)->format('Y-m-d');
            $b = $ts->periodBounds($local);
            $start = $b['start_local']->format('Y-m-d');
            $end = $b['end_local']->format('Y-m-d');
            $groups[$q['uid'] . '|' . $start . '|' . $end]['uid'] = (int) $q['uid'];
            $groups[$q['uid'] . '|' . $start . '|' . $end]['start'] = $start;
            $groups[$q['uid'] . '|' . $start . '|' . $end]['end'] = $end;
            $groups[$q['uid'] . '|' . $start . '|' . $end]['rows'][] = $q;
        }

        $durCol = TimeEntry::column('duration_seconds') ?? 'duration_seconds';
        $billCol = TimeEntry::column('is_billable') ?? 'is_billable';

        foreach ($groups as $g) {
            $statuses = array_values(array_unique(array_column($g['rows'], 'status')));
            // Never approve by accident: any pending entry keeps the whole period Submitted.
            $status = in_array(Timesheet::STATUS_SUBMITTED, $statuses, true) ? Timesheet::STATUS_SUBMITTED
                : (in_array(Timesheet::STATUS_REJECTED, $statuses, true) ? Timesheet::STATUS_REJECTED : Timesheet::STATUS_APPROVED);
            if (count($statuses) > 1) {
                $addNote($result, "Approval: user #{$g['uid']} has mixed statuses (" . implode(', ', $statuses) . ") in {$g['start']} to {$g['end']}; the period was imported as {$status}.");
            }
            $meta = $g['rows'][0];
            foreach ($g['rows'] as $row) {
                if ($row['status'] === $status) {
                    $meta = $row;
                    break;
                }
            }

            $sheet = Database::fetchOne(
                'SELECT id, status FROM timesheets WHERE user_id = :u AND start_date = :s AND end_date = :e ORDER BY id DESC LIMIT 1',
                ['u' => $g['uid'], 's' => $g['start'], 'e' => $g['end']]
            );
            if ($sheet) {
                $sheetId = (int) $sheet['id'];
                $status = (string) $sheet['status'];
                if ($status !== $meta['status']) {
                    $addNote($result, "Approval: user #{$g['uid']} already has a {$status} timesheet for {$g['start']} to {$g['end']}; it was kept and the imported status was not applied.");
                }
            } else {
                $approverId = $this->lookupApprover((string) $meta['approver']);
                if ($meta['approver'] !== '' && $approverId === null) {
                    $addNote($result, "Approval: approver \"{$meta['approver']}\" is not a user here, so \"approved by\" was left empty (import Users first to keep it).");
                }
                $decided = $status === Timesheet::STATUS_APPROVED || $status === Timesheet::STATUS_REJECTED;
                $submitted = $meta['submitted_utc'] ?? $meta['processed_utc'] ?? gmdate('Y-m-d H:i:s');
                $sheetId = $ts->create([
                    'user_id' => $g['uid'],
                    'start_date' => $g['start'],
                    'end_date' => $g['end'],
                    'submission_token' => bin2hex(random_bytes(16)),
                    'total_seconds' => 0,
                    'billable_seconds' => 0,
                    'status' => $status,
                    'submitted_at' => $submitted,
                    'approved_by' => $decided ? $approverId : null,
                    'approved_at' => $decided ? ($meta['processed_utc'] ?? $submitted) : null,
                    'rejection_reason' => $status === Timesheet::STATUS_REJECTED ? 'Rejected in the previous time tracker (imported).' : null,
                ]);
            }

            if ($status === Timesheet::STATUS_SUBMITTED || $status === Timesheet::STATUS_APPROVED) {
                foreach ($g['rows'] as $row) {
                    if ($row['status'] === Timesheet::STATUS_REJECTED) {
                        continue;
                    }
                    $linked = Database::fetchValue(
                        'SELECT COUNT(*) FROM timesheet_entries WHERE time_entry_id = :t',
                        ['t' => $row['entry_id']]
                    );
                    if ((int) $linked === 0) {
                        Database::execute(
                            'INSERT INTO timesheet_entries (timesheet_id, time_entry_id, created_at) VALUES (:s, :t, UTC_TIMESTAMP())',
                            ['s' => $sheetId, 't' => $row['entry_id']]
                        );
                    }
                }
                Database::execute(
                    "UPDATE timesheets SET
                        total_seconds = COALESCE((SELECT SUM(te.`{$durCol}`) FROM timesheet_entries tse INNER JOIN time_entries te ON te.id = tse.time_entry_id WHERE tse.timesheet_id = :a), 0),
                        billable_seconds = COALESCE((SELECT SUM(CASE WHEN te.`{$billCol}` = 1 THEN te.`{$durCol}` ELSE 0 END) FROM timesheet_entries tse INNER JOIN time_entries te ON te.id = tse.time_entry_id WHERE tse.timesheet_id = :b), 0),
                        updated_at = UTC_TIMESTAMP()
                     WHERE id = :id",
                    ['a' => $sheetId, 'b' => $sheetId, 'id' => $sheetId]
                );
            }
        }
        $this->approvalQueue = [];
    }

    /**
     * One row of a Clockify "Detailed" time report export.
     * Columns used: Project, Client, Description, Task, User, Email, Billable, Start/End Date, Start/End Time,
     * Billable Rate. Project is matched by name, user by email (else name); the entry's own timezone is the
     * user's timezone in this app.
     *
     * @param array<string,string> $r
     */
    private function clockifyEntry(array $r): string
    {
        $uid = 0;
        if (($r['email'] ?? '') !== '') {
            $uid = $this->lookupUser($r['email']);
        }
        if (!$uid) {
            $name = $this->nameKey($r['user'] ?? '');
            if ($name === '') {
                throw new RuntimeException('Missing user / email');
            }
            if ($this->userNameCache === null) {
                $this->userNameCache = [];
                foreach (Database::fetchAll('SELECT id, name FROM users') as $u) {
                    $this->userNameCache[$this->nameKey((string) $u['name'])] ??= (int) $u['id'];
                }
            }
            $uid = $this->userNameCache[$name] ?? 0;
            if (!$uid) {
                throw new RuntimeException('User not found: ' . ($r['email'] ?? '') . ' ' . ($r['user'] ?? '') . ' (import users first)');
            }
        }

        $projectName = $this->nameKey($r['project'] ?? '');
        if ($projectName === '') {
            throw new RuntimeException('Entry has no project');
        }
        if ($this->projectNameCache === null) {
            $this->projectNameCache = [];
            foreach (Database::fetchAll('SELECT id, name FROM projects') as $p) {
                $this->projectNameCache[$this->nameKey((string) $p['name'])] ??= (int) $p['id'];
            }
        }
        $pid = $this->projectNameCache[$projectName] ?? 0;
        if (!$pid) {
            throw new RuntimeException('Project not found: ' . ($r['project'] ?? '') . ' (import projects first)');
        }

        foreach (['start date', 'start time', 'end date', 'end time'] as $k) {
            $this->required($r, $k);
        }
        $zone = FormatHelper::timezoneForUser($uid);
        $start = $this->clockifyUtc($r['start date'], $r['start time'], $zone);
        $end = $this->clockifyUtc($r['end date'], $r['end time'], $zone);

        $rate = '0';
        foreach ($r as $key => $value) {
            if (str_starts_with((string) $key, 'billable rate')) {
                $rate = $value !== '' ? $value : '0';
                break;
            }
        }

        return $this->timeEntry([
            // Everything else in the row (duration, creation date, approval columns) is passed through as-is.
            '_uid' => (string) $uid,
            '_pid' => (string) $pid,
            '_start_utc' => $start,
            '_end_utc' => $end,
            '_task_optional' => '1',
            'task_name' => $r['task'] ?? '',
            'description' => $r['description'] ?? '',
            'is_billable' => $r['billable'] ?? 'yes',
            'billable_rate' => $rate,
        ] + $r);
    }

    /** Turn a Clockify local date + time into a UTC "Y-m-d H:i:s" string. */
    private function clockifyUtc(string $date, string $time, string $zone): string
    {
        if (preg_match('/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/', $date, $m)) {
            [$y, $mo, $d] = [(int) $m[1], (int) $m[2], (int) $m[3]];
        } elseif (preg_match('/^(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})$/', $date, $m)) {
            [$a, $b, $y] = [(int) $m[1], (int) $m[2], (int) $m[3]];
            [$mo, $d] = $this->clockifyDateFormat === 'dmy' ? [$b, $a] : [$a, $b];
        } else {
            throw new RuntimeException('Invalid date: ' . $date);
        }
        if (!checkdate($mo, $d, $y)) {
            throw new RuntimeException('Invalid date: ' . $date);
        }
        if (!preg_match('/^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp][Mm])?$/', $time, $t)) {
            throw new RuntimeException('Invalid time: ' . $time);
        }
        $h = (int) $t[1];
        $mi = (int) $t[2];
        $sec = (int) ($t[3] ?? 0);
        if (!empty($t[4])) {
            $pm = strtolower($t[4]) === 'pm';
            if ($h < 1 || $h > 12) {
                throw new RuntimeException('Invalid time: ' . $time);
            }
            $h = ($h % 12) + ($pm ? 12 : 0);
        }
        if ($h > 23 || $mi > 59 || $sec > 59) {
            throw new RuntimeException('Invalid time: ' . $time);
        }
        $local = sprintf('%04d-%02d-%02d %02d:%02d:%02d', $y, $mo, $d, $h, $mi, $sec);
        $utc = FormatHelper::toUtc($local, $zone);
        if ($utc === null) {
            throw new RuntimeException('Invalid date/time: ' . $local);
        }
        return $utc;
    }

    /**
     * Work out the date order of a Clockify export from its values.
     * @param list<array<string,string>> $rows
     * @return string|null ymd | mdy | dmy, or null when the file is ambiguous
     */
    private function detectClockifyDateFormat(array $rows): ?string
    {
        $dmy = false;
        $mdy = false;
        $iso = false;
        $slashed = false;
        foreach ($rows as $r) {
            foreach (['start date', 'end date', 'start_date', 'end_date'] as $k) {
                $v = $r[$k] ?? '';
                if (preg_match('/^\d{4}[-\/.]\d{1,2}[-\/.]\d{1,2}$/', $v)) {
                    $iso = true;
                } elseif (preg_match('/^(\d{1,2})[-\/.](\d{1,2})[-\/.]\d{4}$/', $v, $m)) {
                    $slashed = true;
                    $dmy = $dmy || (int) $m[1] > 12;
                    $mdy = $mdy || (int) $m[2] > 12;
                }
            }
        }
        if ($dmy && $mdy) {
            return null;
        }
        if ($dmy) {
            return 'dmy';
        }
        if ($mdy) {
            return 'mdy';
        }
        return ($iso && !$slashed) ? 'ymd' : null;
    }

    /** @param array<string,string> $r */
    private function schedule(array $r): string
    {
        foreach (['user_email', 'start_datetime', 'end_datetime'] as $k) {
            $this->required($r, $k);
        }
        $uid = $this->lookupUser($r['user_email']);
        if (!$uid) {
            throw new RuntimeException('User not found');
        }
        $pid = $this->lookupProject($r['project_code'] ?? '');
        if (!$pid) {
            throw new RuntimeException('Project not found');
        }
        $start = $this->datetime($r['start_datetime']);
        $end = $this->datetime($r['end_datetime']);
        $startTs = strtotime($start . ' UTC');
        $endTs = strtotime($end . ' UTC');
        if ($startTs === false || $endTs === false || $endTs <= $startTs) {
            throw new RuntimeException('End must be after start');
        }
        $data = [
            'user_id' => $uid,
            'project_id' => $pid,
            'task_id' => null,
            'start_datetime' => $start,
            'end_datetime' => $end,
            'status' => in_array($r['status'] ?? 'Scheduled', ['Scheduled', 'In Progress', 'Completed', 'Missed', 'Cancelled', 'Rescheduled'], true)
                ? $r['status']
                : 'Scheduled',
            'notes' => ($r['notes'] ?? '') !== '' ? $r['notes'] : null,
        ];
        Database::execute(
            'INSERT INTO schedules (user_id, project_id, task_id, start_datetime, end_datetime, status, notes, created_by)
             VALUES (:user_id, :project_id, :task_id, :start_datetime, :end_datetime, :status, :notes, :created_by)',
            $data + ['created_by' => (int) AuthHelper::id()]
        );
        return 'created';
    }

    /**
     * @param array<string, mixed> $lookup
     * @param array<string, mixed> $data
     * @param array<string, mixed> $insertOnly
     */
    private function upsert(string $table, array $lookup, array $data, array $insertOnly = []): string
    {
        if (!in_array($table, self::UPSERT_TABLES, true)) {
            throw new InvalidArgumentException('Unsupported import table.');
        }
        foreach (array_keys($lookup + $data + $insertOnly) as $col) {
            if (!preg_match('/^[a-z_][a-z0-9_]*$/', (string) $col)) {
                throw new InvalidArgumentException('Invalid column name.');
            }
        }

        $where = [];
        $params = [];
        $i = 0;
        foreach ($lookup as $col => $val) {
            $key = 'lk' . $i++;
            $where[] = '`' . $col . '` = :' . $key;
            $params[$key] = $val;
        }
        $existing = Database::fetchOne(
            'SELECT id FROM `' . $table . '` WHERE ' . implode(' AND ', $where) . ' LIMIT 1',
            $params
        );

        if ($existing) {
            $sets = [];
            $update = [];
            $j = 0;
            foreach ($data as $col => $val) {
                $key = 'u' . $j++;
                $sets[] = '`' . $col . '` = :' . $key;
                $update[$key] = $val;
            }
            $update['id'] = (int) $existing['id'];
            Database::execute(
                'UPDATE `' . $table . '` SET ' . implode(', ', $sets) . ', updated_at = UTC_TIMESTAMP() WHERE id = :id',
                $update
            );
            return 'updated';
        }

        $insert = $data + $insertOnly;
        $cols = array_keys($insert);
        $placeholders = [];
        $bound = [];
        $k = 0;
        foreach ($insert as $val) {
            $key = 'i' . $k++;
            $placeholders[] = ':' . $key;
            $bound[$key] = $val;
        }
        Database::execute(
            'INSERT INTO `' . $table . '` (`' . implode('`, `', $cols) . '`) VALUES (' . implode(', ', $placeholders) . ')',
            $bound
        );
        return 'created';
    }

    private function lookupUser(string $email): int
    {
        if ($email === '') {
            return 0;
        }
        return (int) (Database::fetchValue('SELECT id FROM users WHERE email = :e', ['e' => strtolower($email)]) ?? 0);
    }

    private function lookupClient(string $email, string $name): ?int
    {
        if ($email !== '') {
            $v = Database::fetchValue('SELECT id FROM clients WHERE email = :e', ['e' => strtolower($email)]);
            if ($v) {
                return (int) $v;
            }
        }
        $key = $this->nameKey($name);
        if ($key === '') {
            return null;
        }
        foreach (Database::fetchAll('SELECT id, name FROM clients') as $c) {
            if ($this->nameKey((string) $c['name']) === $key) {
                return (int) $c['id'];
            }
        }
        return null;
    }

    /** Whitespace/NBSP/zero-width cleanup. */
    private function clean(string $v): string
    {
        $v = preg_replace('/[\x{00A0}\x{200B}\x{200C}\x{200D}\x{FEFF}\x{202F}\x{2007}]/u', ' ', $v) ?? $v;
        $v = preg_replace('/\s+/u', ' ', $v) ?? $v;
        return trim($v);
    }

    /** Comparison key: "AFIC - NIHD", "afic-nihd" and " AFIC  NIHD " all match. */
    private function nameKey(string $v): string
    {
        return preg_replace('/[^\p{L}\p{N}]+/u', '', mb_strtolower($this->clean($v))) ?? '';
    }

    private function lookupProject(string $code): int
    {
        return $code === '' ? 0 : (int) (Database::fetchValue('SELECT id FROM projects WHERE project_code = :c', ['c' => $code]) ?? 0);
    }

    /** @param array<string,string> $r */
    private function required(array $r, string $k): void
    {
        if (trim((string) ($r[$k] ?? '')) === '') {
            throw new RuntimeException('Missing ' . $k);
        }
    }

    private function num(string $v): float
    {
        return max(0, (float) str_replace(',', '', trim($v)));
    }

    private function bool(string $v): int
    {
        return in_array(strtolower(trim($v)), ['1', 'true', 'yes', 'y'], true) ? 1 : 0;
    }

    private function datetime(string $v): string
    {
        $v = trim($v);
        if ($v === '' || !preg_match('/^\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}(?::\d{2})?(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)?$/', $v)) {
            throw new RuntimeException('Invalid date/time: ' . $v);
        }

        if (str_ends_with($v, 'Z') || preg_match('/[+-]\d{2}:?\d{2}$/', $v)) {
            try {
                return (new DateTimeImmutable($v))->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            } catch (Exception) {
                throw new RuntimeException('Invalid date/time: ' . $v);
            }
        }

        $user = AuthHelper::user();
        $tz = is_array($user) ? (string) ($user['timezone'] ?? '') : '';
        $utc = FormatHelper::toUtc($v, $tz !== '' ? $tz : null);
        if ($utc === null) {
            throw new RuntimeException('Invalid date/time: ' . $v);
        }
        return $utc;
    }
}