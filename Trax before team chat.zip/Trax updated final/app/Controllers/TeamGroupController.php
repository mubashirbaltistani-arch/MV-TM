<?php
/**
 * Department setup: organisation departments, a department manager,
 * teams with one or more team managers, and their members.
 *
 * Departments are not tied to a project. Teams can work on any project.
 */

declare(strict_types=1);

final class TeamGroupController extends Controller
{
    private TeamGroup $teams;
    private Department $departments;

    public function __construct()
    {
        parent::__construct(true);
        SchemaHelper::ensureOrgStructure();
        $this->teams       = new TeamGroup();
        $this->departments = new Department();
    }

    /** GET /teams */
    public function index(Request $request, array $params): void
    {
        $this->requireCanOpen();

        $ready  = Department::installed();
        $search = trim((string) $request->input('q', ''));

        $rows  = [];
        $teams = [];
        if ($ready) {
            $rows  = $this->departments->all($search);
            $teams = $this->departments->teamsByDepartment(array_map(static fn (array $r): int => (int) $r['id'], $rows));
        }
        $teamIds = [];
        foreach ($teams as $list) {
            foreach ($list as $team) {
                $teamIds[] = (int) $team['id'];
            }
        }
        $members  = $ready ? $this->teams->membersByTeam($teamIds) : [];
        $managers = $ready ? $this->teams->managersByTeam($teamIds) : [];
        foreach ($rows as &$row) {
            $row['task_count'] = $ready ? $this->teams->taskCountForDepartment((int) $row['id']) : 0;
        }
        unset($row);

        $this->render('teams/index', [
            'pageTitle' => 'Departments',
            'ready'     => $ready,
            'rows'      => $rows,
            'teams'     => $teams,
            'members'   => $members,
            'managers'  => $managers,
            'search'    => $search,
        ]);
    }

    /** GET /teams/create */
    public function create(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();
        $this->renderForm(null, []);
    }

    /** POST /teams */
    public function store(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        [$data, $teamBlocks] = $this->validated(null, 0);

        $id = (int) Database::transaction(function () use ($data, $teamBlocks): int {
            $deptId = $this->departments->create($data, (int) AuthHelper::id());
            $this->syncTeams($deptId, (string) $data['status'], $teamBlocks);

            return $deptId;
        });
        ApprovalChainHelper::reset();

        LoggerHelper::audit('department.created', 'department', $id, [
            'name' => $data['name'], 'manager_id' => $data['manager_id'], 'teams' => count($teamBlocks),
        ]);
        $this->flash('success', 'Department "' . $data['name'] . '" was created.');
        $this->redirect('/teams');
    }

    /** GET /teams/{id}/edit */
    public function edit(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $department = $this->departments->find((int) ($params['id'] ?? 0));
        if ($department === null) {
            $this->notFound();
        }

        $this->renderForm($department, $this->existingTeamBlocks((int) $department['id']));
    }

    /** POST /teams/{id} */
    public function update(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $id         = (int) ($params['id'] ?? 0);
        $department = $this->departments->find($id);
        if ($department === null) {
            $this->notFound();
        }

        [$data, $teamBlocks] = $this->validated($department, $id);

        Database::transaction(function () use ($id, $data, $teamBlocks): void {
            $this->departments->update($id, $data);
            $this->syncTeams($id, (string) $data['status'], $teamBlocks);
        });
        ApprovalChainHelper::reset();

        LoggerHelper::audit('department.updated', 'department', $id, [
            'name' => $data['name'], 'manager_id' => $data['manager_id'], 'teams' => count($teamBlocks),
        ]);
        $this->flash('success', 'Department "' . $data['name'] . '" was updated.');
        $this->redirect('/teams');
    }

    /** POST /teams/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $id         = (int) ($params['id'] ?? 0);
        $department = $this->departments->find($id);
        if ($department === null) {
            $this->notFound();
        }

        $taskCount = $this->teams->taskCountForDepartment($id);
        $this->departments->delete($id);
        ApprovalChainHelper::reset();

        LoggerHelper::audit('department.deleted', 'department', $id, [
            'name' => (string) $department['name'], 'task_count' => $taskCount,
        ]);
        $message = 'Department "' . (string) $department['name'] . '" was deleted. People keep their accounts.';
        if ($taskCount > 0) {
            $message .= ' ' . $taskCount . ' task' . ($taskCount === 1 ? '' : 's') . ' became unassigned from the team.';
        }
        $this->flash('success', $message);
        $this->redirect('/teams');
    }

    /* ------------------------------------------------------------------ helpers */

    private function requireReady(): void
    {
        if (Department::installed()) {
            return;
        }

        $this->flash('warning', 'Department tables are not installed yet. Run database/UPGRADE_LIVE.sql.');
        $this->redirect('/teams');
    }

    private function requireCanOpen(): void
    {
        if (ClientScope::isClient()) {
            $this->forbidden();
        }

        if (!AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            throw new HttpException(403, 'Only an administrator can manage departments.');
        }

        PermissionHelper::require('settings.manage');
    }

    /**
     * @param array<string, mixed>|null $department
     * @param list<array{id: int, name: string, manager_ids: list<int>, member_ids: list<int>}> $teamBlocks
     */
    private function renderForm(?array $department, array $teamBlocks, array $errors = []): void
    {
        if ($errors !== []) {
            $old = [];
            foreach ($this->request->body() as $key => $value) {
                if (in_array($key, ['_csrf', '_method'], true)) {
                    continue;
                }
                if (is_string($value) || is_array($value)) {
                    $old[$key] = $value;
                }
            }
            FormatHelper::withState($old, $errors);
        }

        $this->render('teams/form', [
            'pageTitle'  => $department === null ? 'New department' : 'Edit department',
            'department' => $department,
            'teamBlocks' => $teamBlocks,
            'people'     => $this->peopleOptions(),
            'statuses'   => Department::STATUSES,
            'taskCount'  => $department !== null ? $this->teams->taskCountForDepartment((int) $department['id']) : 0,
        ]);
    }

    /** @return list<array<string, mixed>> */
    private function peopleOptions(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name, r.name AS role
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        );
    }

    /**
     * @return list<array{id: int, name: string, manager_ids: list<int>, member_ids: list<int>}>
     */
    private function existingTeamBlocks(int $departmentId): array
    {
        $out = [];
        foreach ($this->departments->teamsOf($departmentId) as $team) {
            $out[] = [
                'id'          => (int) $team['id'],
                'name'        => (string) $team['name'],
                'manager_ids' => $this->teams->managerIds((int) $team['id']),
                'member_ids'  => $this->teams->memberIds((int) $team['id']),
            ];
        }

        return $out;
    }

    /**
     * @param array<string, mixed>|null $department
     * @return array{0: array{name: string, manager_id: ?int, status: string}, 1: list<array{id: int, name: string, manager_ids: list<int>, member_ids: list<int>}>}
     */
    private function validated(?array $department, int $exceptId): array
    {
        $request   = $this->request;
        $errors    = [];
        $name      = trim((string) $request->input('name', ''));
        $managerId = (int) $request->input('manager_id', 0);
        $status    = (string) $request->input('status', 'active');

        $validPeople = [];
        foreach ($this->peopleOptions() as $person) {
            $validPeople[(int) $person['id']] = true;
        }

        if ($name === '') {
            $errors['name'] = 'Enter a department name.';
        } elseif (mb_strlen($name, 'UTF-8') > 120) {
            $errors['name'] = 'Use 120 characters or fewer.';
        } elseif ($this->departments->nameTaken($name, $exceptId)) {
            $errors['name'] = 'A department with that name already exists.';
        }

        if (!in_array($status, Department::STATUSES, true)) {
            $status = 'active';
        }

        if ($managerId > 0 && !isset($validPeople[$managerId])) {
            $errors['manager_id'] = 'Choose an active user as department manager.';
        }

        $teamBlocks = $this->postedTeamBlocks($validPeople, $managerId, $errors);

        if ($errors !== []) {
            $this->renderForm(
                $department,
                $teamBlocks !== [] ? $teamBlocks : [['id' => 0, 'name' => '', 'manager_ids' => [], 'member_ids' => []]],
                $errors
            );
            exit;
        }

        return [[
            'name'       => $name,
            'manager_id' => $managerId > 0 ? $managerId : null,
            'status'     => $status,
        ], $teamBlocks];
    }

    /**
     * @param array<int, true> $validPeople
     * @param array<string, string> $errors
     * @return list<array{id: int, name: string, manager_ids: list<int>, member_ids: list<int>}>
     */
    private function postedTeamBlocks(array $validPeople, int $deptManagerId, array &$errors): array
    {
        $raw = $this->request->input('teams', []);
        if (!is_array($raw)) {
            return [];
        }

        $out       = [];
        $usedNames = [];

        foreach (array_values($raw) as $i => $block) {
            if (!is_array($block)) {
                continue;
            }
            $id         = (int) ($block['id'] ?? 0);
            $teamName   = trim((string) ($block['name'] ?? ''));
            $rawMgrs    = $block['manager_ids'] ?? [];
            $rawMembers = $block['member_ids'] ?? [];
            if (!is_array($rawMgrs)) {
                $rawMgrs = [$rawMgrs];
            }
            if (!is_array($rawMembers)) {
                $rawMembers = [$rawMembers];
            }
            $managerIds = array_values(array_unique(array_filter(
                array_map('intval', $rawMgrs),
                static fn (int $uid): bool => $uid > 0
            )));
            $memberIds = array_values(array_unique(array_filter(
                array_map('intval', $rawMembers),
                static fn (int $uid): bool => $uid > 0
            )));

            $empty = $teamName === '' && $managerIds === [] && $memberIds === [];
            if ($empty) {
                continue;
            }

            $managerIds = array_values(array_filter(
                $managerIds,
                static fn (int $uid): bool => isset($validPeople[$uid])
            ));
            if ($managerIds === []) {
                $errors['teams.' . $i . '.manager_ids'] = 'Choose at least one team manager.';
            }

            if ($teamName === '') {
                $errors['teams.' . $i . '.name'] = 'Enter a team name.';
            } elseif (mb_strlen($teamName, 'UTF-8') > 120) {
                $errors['teams.' . $i . '.name'] = 'Use 120 characters or fewer.';
            } else {
                $key = mb_strtolower($teamName, 'UTF-8');
                if (isset($usedNames[$key])) {
                    $errors['teams.' . $i . '.name'] = 'Each team in this department needs a unique name.';
                }
                $usedNames[$key] = true;
            }

            $mgrSet = array_flip($managerIds);
            $memberIds = array_values(array_filter(
                $memberIds,
                static fn (int $uid): bool => isset($validPeople[$uid]) && !isset($mgrSet[$uid])
            ));

            $out[] = [
                'id'          => $id,
                'name'        => $teamName,
                'manager_ids' => $managerIds,
                'member_ids'  => $memberIds,
            ];
        }

        unset($deptManagerId);

        return $out;
    }

    /**
     * @param list<array{id: int, name: string, manager_ids: list<int>, member_ids: list<int>}> $teamBlocks
     */
    private function syncTeams(int $departmentId, string $status, array $teamBlocks): void
    {
        $keep = [];
        foreach ($teamBlocks as $block) {
            $payload = [
                'department_id' => $departmentId,
                'name'          => $block['name'],
                'manager_id'    => $block['manager_ids'][0] ?? null,
                'status'        => $status,
            ];
            $id = (int) $block['id'];
            if ($id > 0) {
                $existing = $this->teams->find($id);
                if ($existing === null || (int) ($existing['department_id'] ?? 0) !== $departmentId) {
                    $id = $this->teams->create($payload, $block['member_ids'], (int) AuthHelper::id(), $block['manager_ids']);
                } else {
                    $this->teams->update($id, $payload, $block['member_ids'], $block['manager_ids']);
                }
            } else {
                $id = $this->teams->create($payload, $block['member_ids'], (int) AuthHelper::id(), $block['manager_ids']);
            }
            $keep[] = $id;
        }

        foreach ($this->departments->teamsOf($departmentId) as $team) {
            $tid = (int) $team['id'];
            if (!in_array($tid, $keep, true)) {
                $this->teams->delete($tid);
            }
        }
    }
}
