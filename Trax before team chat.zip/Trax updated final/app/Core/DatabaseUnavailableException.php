<?php
/**
 * Thrown when the database cannot be reached (server down, refused connection,
 * connection limit hit on shared hosting).
 *
 * It extends RuntimeException on purpose: existing `catch (RuntimeException)` blocks keep
 * behaving as before, while the Router and the front controller can recognise it and answer
 * with 503 Service Unavailable (a temporary outage) instead of 500 (a bug).
 *
 * SECURITY: the message is generic. Never put the DSN, user name or driver message in here.
 */

declare(strict_types=1);

final class DatabaseUnavailableException extends RuntimeException
{
}
