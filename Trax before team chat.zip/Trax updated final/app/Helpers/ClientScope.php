<?php
/**
 * Read-only client-role scoping. A client user may only see projects, tasks
 * and report rows belonging to clients linked in client_users.
 *
 * Integrity: hiding a menu item is not enough; every query and controller
 * must refuse other clients' data or a crafted URL would leak it.
 */

declare(strict_types=1);

final class ClientScope
{
    public static function installed(): bool
    {
        return SchemaHelper::tableExists('client_users');
    }

    public static function isClient(?int $userId = null): bool
    {
        $role = $userId === null || $userId === AuthHelper::id()
            ? AuthHelper::role()
            : (string) Database::fetchValue(
                'SELECT r.name FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE u.id = :id',
                ['id' => $userId]
            );

        return $role === AuthHelper::ROLE_CLIENT;
    }

    /** @return list<int> */
    public static function clientIds(int $userId): array
    {
        if (!self::installed()) {
            return [];
        }

        $rows = Database::fetchAll(
            'SELECT client_id FROM client_users WHERE user_id = :user_id',
            ['user_id' => $userId]
        );

        return array_map(static fn (array $row): int => (int) $row['client_id'], $rows);
    }

    public static function assertReadOnly(): void
    {
        if (!self::isClient()) {
            return;
        }

        throw new HttpException(403, 'Client accounts are read-only.');
    }

    public static function assertCanSeeProject(array $project): void
    {
        if (!self::isClient()) {
            return;
        }

        $ids = self::clientIds((int) AuthHelper::id());
        if (!in_array((int) ($project['client_id'] ?? 0), $ids, true)) {
            throw new HttpException(403, 'You do not have access to this project.');
        }
    }

    /**
     * SQL fragment that restricts projects to the client's linked clients.
     *
     * @return array{0: string, 1: array<string, mixed>}
     */
    public static function projectClause(string $alias = 'p'): array
    {
        if (!self::isClient()) {
            return ['1 = 1', []];
        }

        $ids = self::clientIds((int) AuthHelper::id());
        if ($ids === []) {
            return ['1 = 0', []];
        }

        $placeholders = [];
        $params = [];
        foreach ($ids as $i => $id) {
            $key = 'client_scope_' . $i;
            $placeholders[] = ':' . $key;
            $params[$key] = $id;
        }

        return [$alias . '.client_id IN (' . implode(',', $placeholders) . ')', $params];
    }

    public static function syncUserClients(int $userId, array $clientIds): void
    {
        if (!self::installed()) {
            return;
        }

        $clientIds = array_values(array_unique(array_filter(array_map('intval', $clientIds), static fn (int $id): bool => $id > 0)));
        Database::execute('DELETE FROM client_users WHERE user_id = :id', ['id' => $userId]);
        foreach ($clientIds as $clientId) {
            Database::execute(
                'INSERT INTO client_users (user_id, client_id, created_at) VALUES (:user_id, :client_id, UTC_TIMESTAMP())',
                ['user_id' => $userId, 'client_id' => $clientId]
            );
        }
    }
}
