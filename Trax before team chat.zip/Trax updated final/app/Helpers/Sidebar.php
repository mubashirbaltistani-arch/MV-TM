<?php
/**
 * Sidebar navigation and badge queries.
 *
 * Feature flags hide items here; controllers still 403/404 the same URLs.
 * Badge queries are scoped and logged on failure so a missing table cannot
 * break the layout or leak a global pending count.
 */

declare(strict_types=1);

final class SidebarHelper
{
    /**
     * @return array<string, list<array<string, mixed>>>
     */
    public static function groups(): array
    {
        return [
            'TRACK' => [
                ['label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'path' => '/dashboard', 'permission' => 'dashboard.view'],
                ['label' => 'Time Tracker', 'icon' => 'fa-clock', 'path' => '/time', 'permission' => 'time.view_own', 'controller' => 'TimerController', 'flag' => 'tracker'],
                ['label' => 'Timesheet', 'icon' => 'fa-file-lines', 'path' => '/timesheets', 'permission' => 'time.view_own', 'controller' => 'TimesheetController', 'flag' => 'timesheet'],
                ['label' => 'My schedule', 'icon' => 'fa-calendar-days', 'path' => '/schedule', 'permission' => 'schedule.view', 'controller' => 'ScheduleController', 'flag' => 'scheduling'],
            ],
            'MANAGE' => [
                ['label' => 'Approvals', 'icon' => 'fa-circle-check', 'path' => '/timesheets/team', 'permission' => 'time.approve', 'controller' => 'TimesheetController', 'flag' => 'approval', 'badge' => true],
                ['label' => 'Task review', 'icon' => 'fa-clipboard-check', 'path' => '/tasks/review', 'permission' => 'tasks.edit', 'controller' => 'TaskController', 'badge' => 'review'],
                ['label' => 'Projects', 'icon' => 'fa-diagram-project', 'path' => '/projects', 'permission' => 'projects.view', 'controller' => 'ProjectController', 'flag' => 'projects'],
                ['label' => 'Departments', 'icon' => 'fa-sitemap', 'path' => '/teams', 'permission' => 'projects.view', 'controller' => 'TeamGroupController'],
                ['label' => 'Team', 'icon' => 'fa-users', 'path' => '/team', 'permission' => 'projects.view', 'controller' => 'TeamController', 'flag' => 'team', 'roles' => [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER, AuthHelper::ROLE_EMPLOYEE]],
                ['label' => 'Clients', 'icon' => 'fa-building', 'path' => '/clients', 'permission' => 'clients.view', 'controller' => 'ClientController'],
                ['label' => 'Reports', 'icon' => 'fa-chart-column', 'path' => '/reports', 'permission' => 'reports.view', 'controller' => 'ReportController', 'flag' => 'reports'],
                ['label' => 'Import data', 'icon' => 'fa-file-import', 'path' => '/import', 'permission' => 'imports.manage', 'controller' => 'ImportController'],
                ['label' => 'Team schedule', 'icon' => 'fa-calendar-week', 'path' => '/schedule/team', 'permission' => 'schedule.view_team', 'controller' => 'ScheduleController', 'flag' => 'scheduling_team'],
            ],
            'SYSTEM' => [
                ['label' => 'Users', 'icon' => 'fa-user-gear', 'path' => '/users', 'permission' => 'users.view', 'controller' => 'UserController'],
                ['label' => 'Activity log', 'icon' => 'fa-clipboard-list', 'path' => '/settings/audit-logs', 'permission' => 'activity.view', 'controller' => 'SettingsController'],
                ['label' => 'System settings', 'icon' => 'fa-sliders', 'path' => '/settings', 'permission' => 'settings.manage', 'controller' => 'SettingsController'],
                ['label' => 'Health', 'icon' => 'fa-heart-pulse', 'path' => '/admin/health', 'permission' => 'settings.manage', 'controller' => 'HealthController', 'roles' => [AuthHelper::ROLE_ADMIN]],
            ],
        ];
    }

    /**
     * Groups with at least one visible item. Empty headings (e.g. SYSTEM for employees) are dropped.
     *
     * @return array<string, list<array<string, mixed>>>
     */
    public static function visibleGroups(): array
    {
        $out = [];
        foreach (self::groups() as $heading => $items) {
            $visible = array_values(array_filter($items, static fn (array $item): bool => self::visible($item)));
            if ($visible !== []) {
                $out[$heading] = $visible;
            }
        }

        return $out;
    }

    /**
     * Exactly one sidebar path is active. Longest matching prefix wins so
     * /timesheets/team highlights Approvals, not Timesheet.
     *
     * @param list<string> $paths
     */
    public static function activePath(string $current, array $paths): ?string
    {
        $best = null;
        $bestLen = -1;
        foreach ($paths as $path) {
            if ($current !== $path && !str_starts_with($current, $path . '/')) {
                continue;
            }
            $len = strlen($path);
            if ($len > $bestLen) {
                $best = $path;
                $bestLen = $len;
            }
        }

        return $best;
    }

    /** @param array<string, mixed> $item */
    public static function visible(array $item): bool
    {
        if (isset($item['controller']) && !is_file(APP_PATH . '/Controllers/' . $item['controller'] . '.php')) {
            return false;
        }

        if ((string) $item['path'] === '/reports') {
            // The admin decides per person who sees Reports (Reports > Access).
            if (!ReportAccessHelper::canView()) {
                return false;
            }
        } elseif ((string) $item['path'] === '/timesheets/team') {
            // Approvals: the permission OR a place in the approval hierarchy (team manager / department manager / project manager).
            if (!ApprovalChainHelper::canAccessApprovals((int) AuthHelper::id())) {
                return false;
            }
        } elseif ((string) $item['path'] === '/import') {
            // Mirror ImportController exactly: Admins always see it; a Manager sees it
            // only when imports.manage has been granted to them. Nobody else does.
            if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
                // allowed
            } elseif (!AuthHelper::hasRole(AuthHelper::ROLE_MANAGER) || !PermissionHelper::has('imports.manage')) {
                return false;
            }
        } elseif ((string) $item['path'] === '/tasks/review') {
            if (ClientScope::isClient()) {
                return false;
            }
            if (!Task::installed()) {
                return false;
            }
            if (!TaskPolicy::hasCapability('tasks.edit') && !ApprovalChainHelper::isApprover((int) AuthHelper::id())) {
                return false;
            }
        } elseif ((string) $item['path'] === '/teams') {
            if (ClientScope::isClient()) {
                return false;
            }
            if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
                if (!PermissionHelper::has('settings.manage')) {
                    return false;
                }
            } else {
                return false;
            }
        } elseif (!PermissionHelper::has((string) $item['permission'])) {
            return false;
        }

        if (isset($item['roles']) && !AuthHelper::hasRole(...$item['roles'])) {
            return false;
        }

        if (ClientScope::isClient()) {
            $blocked = ['/time', '/timer', '/timesheets', '/users', '/workspace', '/settings', '/import', '/agent', '/clients', '/team', '/admin/health', '/timesheets/team', '/schedule', '/schedule/team'];
            if (in_array((string) $item['path'], $blocked, true)) {
                return false;
            }
        }

        return match ((string) ($item['flag'] ?? '')) {
            'tracker' => FeatureFlagsHelper::trackerVisible(),
            'timesheet' => FeatureFlagsHelper::timesheetEnabled(),
            'scheduling' => FeatureFlagsHelper::schedulingEnabled(),
            'scheduling_team' => FeatureFlagsHelper::schedulingEnabled() && FeatureFlagsHelper::teamVisible(),
            'approval' => FeatureFlagsHelper::timeApprovalEnabled(),
            'projects' => FeatureFlagsHelper::projectsVisible(),
            'team' => FeatureFlagsHelper::teamVisible(),
            'reports' => FeatureFlagsHelper::reportsVisible(),
            default => true,
        };
    }

    public static function unreadCount(): int
    {
        if (!PermissionHelper::has('notifications.view')) {
            return 0;
        }

        try {
            if (!class_exists('Notification') || !Notification::installed()) {
                return 0;
            }

            return (new Notification())->unreadCount((int) AuthHelper::id());
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return 0;
        }
    }

    /** @return list<array<string, mixed>> */
    public static function recentNotifications(int $limit = 6): array
    {
        if (!PermissionHelper::has('notifications.view')) {
            return [];
        }

        try {
            if (!class_exists('Notification') || !Notification::installed()) {
                return [];
            }

            return (new Notification())->recent((int) AuthHelper::id(), $limit);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return [];
        }
    }

    public static function pendingApprovalCount(): int
    {
        if (!FeatureFlagsHelper::timeApprovalEnabled() || !ApprovalChainHelper::canAccessApprovals((int) AuthHelper::id())) {
            return 0;
        }

        try {
            if (!class_exists('Timesheet') || !Timesheet::installed()) {
                return 0;
            }

            $userId = (int) AuthHelper::id();
            $isAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);

            return (int) ((new Timesheet())->queueCounts($userId, $isAdmin)['Submitted'] ?? 0);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return 0;
        }
    }

    public static function pendingReviewCount(): int
    {
        if (!Task::installed()) {
            return 0;
        }
        if (!TaskPolicy::hasCapability('tasks.edit') && !ApprovalChainHelper::isApprover((int) AuthHelper::id())) {
            return 0;
        }

        try {
            return (new Task())->reviewQueueCount((int) AuthHelper::id());
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return 0;
        }
    }
}
