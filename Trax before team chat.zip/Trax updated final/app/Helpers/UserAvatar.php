<?php
declare(strict_types=1);
final class UserAvatarHelper
{
    private const MAX_BYTES = 2097152;
    private const MAX_DIMENSION = 2048;
    public static function storeUpload(string $field = 'avatar'): string
    {
        if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) return '';
        $file = $_FILES[$field]; $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) return '';
        if ($error !== UPLOAD_ERR_OK) throw new RuntimeException('The profile photo upload failed.');
        if ((int)($file['size'] ?? 0) < 1 || (int)$file['size'] > self::MAX_BYTES) throw new RuntimeException('Profile photos must be 2 MB or smaller.');
        $tmp=(string)($file['tmp_name']??'');
        if ($tmp==='' || !is_uploaded_file($tmp)) throw new RuntimeException('The uploaded profile photo is invalid.');
        $info=@getimagesize($tmp); $mime=is_array($info)?(string)($info['mime']??''):''; $w=is_array($info)?(int)($info[0]??0):0; $h=is_array($info)?(int)($info[1]??0):0;
        $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
        if (!isset($allowed[$mime])) throw new RuntimeException('Profile photo must be a JPG, PNG or WebP image.');
        if ($w<1 || $h<1 || $w>self::MAX_DIMENSION || $h>self::MAX_DIMENSION) throw new RuntimeException('Profile photo dimensions must not exceed 2048 × 2048 pixels.');
        $dir=PUBLIC_PATH.'/uploads/users';
        if (!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)) throw new RuntimeException('Could not create the user photo directory.');
        $name='avatar-'.bin2hex(random_bytes(16)).'.'.$allowed[$mime];
        if (!move_uploaded_file($tmp,$dir.'/'.$name)) throw new RuntimeException('The profile photo could not be saved.');
        @chmod($dir.'/'.$name,0644); return '/uploads/users/'.$name;
    }
    public static function remove(?string $path): void
    {
        $path=(string)$path; if ($path==='' || !str_starts_with($path,'/uploads/users/')) return;
        $base=realpath(PUBLIC_PATH.'/uploads/users'); $file=realpath(PUBLIC_PATH.$path);
        if ($base!==false && $file!==false && str_starts_with($file,$base.DIRECTORY_SEPARATOR) && is_file($file)) @unlink($file);
    }
    public static function url(?string $path): string
    { $path=trim((string)$path); return $path!=='' && str_starts_with($path,'/uploads/users/') ? url($path) : ''; }
    public static function initials(string $name): string
    { $parts=preg_split('/\s+/',trim($name))?:[]; $out=''; foreach(array_slice($parts,0,2) as $part)$out.=mb_strtoupper(mb_substr($part,0,1,'UTF-8'),'UTF-8'); return $out!==''?$out:'?'; }
    public static function html(?string $path,string $name,string $class='avatar'): string
    { $class=e(trim($class)); $alt=e($name); $src=self::url($path); return $src!=='' ? '<span class="'.$class.' avatar-photo"><img src="'.e($src).'" alt="'.$alt.'" loading="lazy" decoding="async"></span>' : '<span class="'.$class.'" aria-hidden="true">'.e(self::initials($name)).'</span>'; }
}
