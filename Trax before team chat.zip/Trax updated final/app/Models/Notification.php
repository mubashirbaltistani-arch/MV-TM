<?php
/**
 * In-app notifications (Phase 9).
 *
 * Writes go through NotificationHelper so that the "notifications_enabled"
 * system setting and length limits are applied consistently. This model is the
 * data access layer used by both the helper and the notification controller.
 */

declare(strict_types=1);

final class Notification extends Model
{
    public const TYPES = ['info', 'success', 'warning', 'danger'];

    public const TYPE_INFO    = 'info';
    public const TYPE_SUCCESS = 'success';
    public const TYPE_WARNING = 'warning';
    public const TYPE_DANGER  = 'danger';

    protected string $table = 'notifications';

    protected bool $timestamps = false;

    protected array $columns = [
        'id', 'user_id', 'type', 'title', 'message', 'link', 'is_read', 'read_at', 'created_at',
    ];

    protected array $fillable = ['user_id', 'type', 'title', 'message', 'link', 'is_read', 'read_at'];

    /** True when the notifications table is present. */
    public static function installed(): bool
    {
        return SchemaHelper::tableExists('notifications');
    }

    /**
     * Insert one notification and return its id (0 on failure).
     * Failures are swallowed: a notification must never break the business action.
     */
    public function createFor(int $userId, string $type, string $title, string $message, string $link = ''): int
    {
        if ($userId < 1 || !self::installed()) {
            return 0;
        }

        if (!in_array($type, self::TYPES, true)) {
            $type = self::TYPE_INFO;
        }

        try {
            Database::execute(
                'INSERT INTO notifications (user_id, type, title, message, link, is_read, created_at)
                 VALUES (:user_id, :type, :title, :message, :link, 0, UTC_TIMESTAMP())',
                [
                    'user_id' => $userId,
                    'type'    => $type,
                    'title'   => mb_substr(trim($title), 0, 160, 'UTF-8'),
                    'message' => mb_substr(trim($message), 0, 500, 'UTF-8'),
                    'link'    => mb_substr(trim($link), 0, 255, 'UTF-8'),
                ]
            );

            return Database::lastInsertId();
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            return 0;
        }
    }

    public function unreadCount(int $userId): int
    {
        try {
            return (int) Database::fetchValue(
                'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
                ['id' => $userId]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Notification unread count failed', ['error' => $e->getMessage()]);
            return 0;
        }
    }

    /**
     * Newest notifications for the header dropdown (read and unread).
     *
     * @return list<array<string, mixed>>
     */
    public function recent(int $userId, int $limit = 8): array
    {
        $limit = min(50, max(1, $limit));

        try {
            return Database::fetchAll(
                "SELECT id, type, title, message, link, is_read, created_at
                 FROM notifications
                 WHERE user_id = :id
                 ORDER BY is_read ASC, created_at DESC, id DESC
                 LIMIT {$limit}",
                ['id' => $userId]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Notification recent list failed', ['error' => $e->getMessage()]);
            return [];
        }
    }

    /**
     * Paginated history for the full notifications page.
     *
     * Exceptions are NOT swallowed here: if the database is unreachable the caller must know,
     * so the Router can answer 503 instead of pretending the user has no notifications.
     *
     * @param string $filter 'all' or 'unread'
     * @param string $type   one of self::TYPES, or '' for every type
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int}
     */
    public function paginateFor(int $userId, int $page = 1, int $perPage = 20, string $filter = 'all', string $type = ''): array
    {
        $perPage = min(100, max(1, $perPage));

        // The WHERE clause is built from fixed fragments only; every value is a bound parameter.
        $where  = 'user_id = :id';
        $params = ['id' => $userId];

        if ($filter === 'unread') {
            $where .= ' AND is_read = 0';
        }

        if ($type !== '' && in_array($type, self::TYPES, true)) {
            $where  .= ' AND type = :type';
            $params['type'] = $type;
        }

        $total = (int) Database::fetchValue("SELECT COUNT(*) FROM notifications WHERE {$where}", $params);

        $pages  = max(1, (int) ceil($total / $perPage));
        $page   = min(max(1, $page), $pages);
        $offset = ($page - 1) * $perPage;

        $items = Database::fetchAll(
            "SELECT id, type, title, message, link, is_read, read_at, created_at
             FROM notifications
             WHERE {$where}
             ORDER BY created_at DESC, id DESC
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return ['items' => $items, 'total' => $total, 'page' => $page, 'per_page' => $perPage, 'pages' => $pages];
    }

    /**
     * Totals for the filter tabs of the notifications page (ignores the active filters).
     *
     * @return array{total: int, unread: int}
     */
    public function counts(int $userId): array
    {
        $row = Database::fetchOne(
            'SELECT COUNT(*) AS total, COALESCE(SUM(is_read = 0), 0) AS unread
             FROM notifications
             WHERE user_id = :id',
            ['id' => $userId]
        );

        return ['total' => (int) ($row['total'] ?? 0), 'unread' => (int) ($row['unread'] ?? 0)];
    }

    /**
     * Turn a stored notification link into a URL that works inside this installation.
     *
     * Links are stored as app paths ("/timesheets/team"). They must go through url() so they keep
     * the install folder (e.g. /Dev/public). SECURITY: only internal paths are accepted; anything
     * else (absolute URL, "//host", backslashes, control characters) yields '' and the caller falls back.
     */
    public static function href(?string $link): string
    {
        $link = trim((string) $link);

        if (
            $link === ''
            || $link[0] !== '/'
            || str_starts_with($link, '//')
            || str_contains($link, '\\')
            || preg_match('/[\r\n]/', $link) === 1
        ) {
            return '';
        }

        // A disabled module answers 404, so never send the person to one: the caller falls back
        // to the notifications page instead.
        try {
            $path = (string) parse_url($link, PHP_URL_PATH);
            if (
                (preg_match('#^/timesheets(/|$)#', $path) === 1 && !FeatureFlagsHelper::timesheetEnabled())
                || (preg_match('#^/schedule(/|$)#', $path) === 1 && !FeatureFlagsHelper::schedulingEnabled())
            ) {
                return '';
            }
        } catch (Throwable) {
            // Flag lookup failed: keep the link rather than hide it.
        }

        return FormatHelper::url($link);
    }

    /** Mark a single notification as read. Only the owner can do so (user_id guard). */
    public function markRead(int $id, int $userId): bool
    {
        if ($id < 1 || $userId < 1) {
            return false;
        }

        return Database::execute(
            'UPDATE notifications
             SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE id = :id AND user_id = :user_id AND is_read = 0',
            ['id' => $id, 'user_id' => $userId]
        ) > 0;
    }

    /** Mark every unread notification of a user as read; returns the number changed. */
    public function markAllRead(int $userId): int
    {
        if ($userId < 1) {
            return 0;
        }

        return Database::execute(
            'UPDATE notifications
             SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE user_id = :user_id AND is_read = 0',
            ['user_id' => $userId]
        );
    }

    public function findForUser(int $id, int $userId): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM notifications WHERE id = :id AND user_id = :user_id LIMIT 1',
            ['id' => $id, 'user_id' => $userId]
        );
    }
}
