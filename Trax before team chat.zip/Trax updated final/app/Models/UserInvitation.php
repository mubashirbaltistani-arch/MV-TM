<?php
/**
 * Pending user invitations. Token is stored as SHA-256 hash only.
 *
 * Statuses: pending, sent, accepted, expired, cancelled.
 * Assignments live in user_invitation_projects / user_invitation_tasks / user_invitation_teams.
 */

declare(strict_types=1);

final class UserInvitation extends Model
{
    public const STATUS_PENDING   = 'pending';
    public const STATUS_SENT      = 'sent';
    public const STATUS_ACCEPTED  = 'accepted';
    public const STATUS_EXPIRED   = 'expired';
    public const STATUS_CANCELLED = 'cancelled';

    public const STATUSES = [
        self::STATUS_PENDING,
        self::STATUS_SENT,
        self::STATUS_ACCEPTED,
        self::STATUS_EXPIRED,
        self::STATUS_CANCELLED,
    ];

    public const OPEN_STATUSES = [self::STATUS_PENDING, self::STATUS_SENT];

    protected string $table = 'user_invitations';

    protected array $columns = [
        'id', 'email', 'name', 'job_title', 'phone', 'account_status',
        'invited_by', 'role_id', 'user_id', 'token_hash', 'expires_at',
        'status', 'sent_at', 'accepted_at', 'cancelled_at', 'last_sent_at',
        'send_count', 'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'email', 'name', 'job_title', 'phone', 'account_status',
        'invited_by', 'role_id', 'user_id', 'token_hash', 'expires_at',
        'status', 'sent_at', 'accepted_at', 'cancelled_at', 'last_sent_at',
        'send_count',
    ];

    public static function installed(): bool
    {
        return SchemaHelper::tableExists('user_invitations');
    }

    public static function hashToken(string $token): string
    {
        return hash('sha256', $token);
    }

    public static function generateToken(): string
    {
        return bin2hex(random_bytes(32));
    }

    /** @return array<string, mixed>|null */
    public function findByToken(string $token): ?array
    {
        if ($token === '' || strlen($token) > 128) {
            return null;
        }

        return Database::fetchOne(
            $this->selectSql() . ' WHERE i.token_hash = :hash LIMIT 1',
            ['hash' => self::hashToken($token)]
        );
    }

    /** @return array<string, mixed>|null */
    public function findDetailed(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }

        $row = Database::fetchOne(
            $this->selectSql() . ' WHERE i.id = :id LIMIT 1',
            ['id' => $id]
        );

        return $row === null ? null : $this->attachAssignments($row);
    }

    /**
     * @param array{q?: string, status?: string} $filters
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int}
     */
    public function search(array $filters, int $page = 1, int $perPage = 20): array
    {
        $clauses = [];
        $params = [];

        $q = trim((string) ($filters['q'] ?? ''));
        if ($q !== '') {
            $clauses[] = '(i.email LIKE :q OR i.name LIKE :q)';
            $params['q'] = '%' . str_replace(['%', '_'], ['\\%', '\\_'], mb_substr($q, 0, 100, 'UTF-8')) . '%';
        }

        $status = (string) ($filters['status'] ?? 'all');
        if (in_array($status, self::STATUSES, true)) {
            if ($status === self::STATUS_EXPIRED) {
                $clauses[] = '(i.status = :status OR (i.status IN (\'pending\', \'sent\') AND i.expires_at < UTC_TIMESTAMP()))';
            } else {
                $clauses[] = 'i.status = :status';
            }
            $params['status'] = $status;
            if ($status === self::STATUS_PENDING || $status === self::STATUS_SENT) {
                $clauses[] = 'i.expires_at >= UTC_TIMESTAMP()';
            }
        }

        $where = $clauses === [] ? '' : ' WHERE ' . implode(' AND ', $clauses);
        $total = (int) Database::fetchValue('SELECT COUNT(*) FROM user_invitations i' . $where, $params);
        $perPage = min(100, max(1, $perPage));
        $pages = max(1, (int) ceil($total / $perPage));
        $page = min(max(1, $page), $pages);
        $offset = ($page - 1) * $perPage;

        $items = Database::fetchAll(
            $this->selectSql() . $where . " ORDER BY i.created_at DESC, i.id DESC LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        $ids = array_map(static fn (array $r): int => (int) $r['id'], $items);
        $projects = $this->projectsByInvitation($ids);
        $tasks = $this->tasksByInvitation($ids);
        $teams = $this->teamsByInvitation($ids);
        foreach ($items as &$row) {
            $id = (int) $row['id'];
            $row['projects'] = $projects[$id] ?? [];
            $row['tasks'] = $tasks[$id] ?? [];
            $row['teams'] = $teams[$id] ?? [];
            $row['status'] = $this->effectiveStatus($row);
        }
        unset($row);

        return [
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'per_page' => $perPage,
            'pages' => $pages,
        ];
    }

    /** @return array<string, mixed>|null */
    public function openByEmail(string $email): ?array
    {
        return Database::fetchOne(
            $this->selectSql() . " WHERE i.email = :email AND i.status IN ('pending','sent') AND i.expires_at >= UTC_TIMESTAMP()
             ORDER BY i.id DESC LIMIT 1",
            ['email' => strtolower($email)]
        );
    }

    public function markSent(int $id): void
    {
        Database::execute(
            'UPDATE user_invitations
             SET status = :sent, sent_at = COALESCE(sent_at, UTC_TIMESTAMP()),
                 last_sent_at = UTC_TIMESTAMP(), send_count = send_count + 1, updated_at = UTC_TIMESTAMP()
             WHERE id = :id',
            ['sent' => self::STATUS_SENT, 'id' => $id]
        );
    }

    public function rotateToken(int $id, string $tokenHash, string $expiresAt): void
    {
        Database::execute(
            'UPDATE user_invitations
             SET token_hash = :hash, expires_at = :expires, status = :pending,
                 cancelled_at = NULL, updated_at = UTC_TIMESTAMP()
             WHERE id = :id',
            [
                'hash' => $tokenHash,
                'expires' => $expiresAt,
                'pending' => self::STATUS_PENDING,
                'id' => $id,
            ]
        );
    }

    public function cancel(int $id): void
    {
        Database::execute(
            'UPDATE user_invitations
             SET status = :cancelled, cancelled_at = UTC_TIMESTAMP(), token_hash = :hash, updated_at = UTC_TIMESTAMP()
             WHERE id = :id AND status IN (\'pending\', \'sent\')',
            [
                'cancelled' => self::STATUS_CANCELLED,
                'hash' => self::hashToken(bin2hex(random_bytes(32))),
                'id' => $id,
            ]
        );
    }

    /**
     * Permanently removes a finished invitation (accepted, cancelled or expired).
     * Open invitations (pending / sent) are never deleted here; cancel them first.
     * Assignment rows go with it through ON DELETE CASCADE; the created user is untouched.
     */
    public function deleteFinished(int $id): bool
    {
        $count = Database::execute(
            'DELETE FROM user_invitations
             WHERE id = :id
               AND (status IN (\'accepted\', \'cancelled\')
                    OR (status IN (\'pending\', \'sent\') AND expires_at < UTC_TIMESTAMP())
                    OR status = \'expired\')',
            ['id' => $id]
        );

        return (int) $count > 0;
    }

    public function markAccepted(int $id, int $userId): void
    {
        Database::execute(
            'UPDATE user_invitations
             SET status = :accepted, accepted_at = UTC_TIMESTAMP(), user_id = :user_id,
                 token_hash = :hash, updated_at = UTC_TIMESTAMP()
             WHERE id = :id',
            [
                'accepted' => self::STATUS_ACCEPTED,
                'user_id' => $userId,
                'hash' => self::hashToken(bin2hex(random_bytes(32))),
                'id' => $id,
            ]
        );
    }

    /**
     * @param list<int> $projectIds
     * @param list<int> $taskIds
     * @param list<int> $teamIds
     */
    public function syncAssignments(int $invitationId, array $projectIds, array $taskIds, array $teamIds): void
    {
        Database::execute('DELETE FROM user_invitation_projects WHERE invitation_id = :id', ['id' => $invitationId]);
        Database::execute('DELETE FROM user_invitation_tasks WHERE invitation_id = :id', ['id' => $invitationId]);
        if (SchemaHelper::tableExists('user_invitation_teams')) {
            Database::execute('DELETE FROM user_invitation_teams WHERE invitation_id = :id', ['id' => $invitationId]);
        }

        foreach ($projectIds as $projectId) {
            Database::execute(
                'INSERT INTO user_invitation_projects (invitation_id, project_id) VALUES (:i, :p)',
                ['i' => $invitationId, 'p' => $projectId]
            );
        }
        foreach ($taskIds as $taskId) {
            Database::execute(
                'INSERT INTO user_invitation_tasks (invitation_id, task_id) VALUES (:i, :t)',
                ['i' => $invitationId, 't' => $taskId]
            );
        }
        if (SchemaHelper::tableExists('user_invitation_teams')) {
            foreach ($teamIds as $teamId) {
                Database::execute(
                    'INSERT INTO user_invitation_teams (invitation_id, team_id) VALUES (:i, :t)',
                    ['i' => $invitationId, 't' => $teamId]
                );
            }
        }
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public function attachAssignments(array $row): array
    {
        $id = (int) $row['id'];
        $row['projects'] = $this->projectsByInvitation([$id])[$id] ?? [];
        $row['tasks'] = $this->tasksByInvitation([$id])[$id] ?? [];
        $row['teams'] = $this->teamsByInvitation([$id])[$id] ?? [];
        $row['status'] = $this->effectiveStatus($row);

        return $row;
    }

    /** @param array<string, mixed> $row */
    public function effectiveStatus(array $row): string
    {
        $status = (string) ($row['status'] ?? '');
        if (in_array($status, self::OPEN_STATUSES, true) && !empty($row['expires_at'])) {
            $expires = strtotime((string) $row['expires_at'] . ' UTC');
            if ($expires !== false && $expires < time()) {
                return self::STATUS_EXPIRED;
            }
        }

        return $status;
    }

    public function isAcceptable(array $row): bool
    {
        $status = $this->effectiveStatus($row);

        return in_array($status, self::OPEN_STATUSES, true);
    }

    /**
     * @param list<int> $ids
     * @return array<int, list<array<string, mixed>>>
     */
    private function projectsByInvitation(array $ids): array
    {
        if ($ids === [] || !SchemaHelper::tableExists('user_invitation_projects')) {
            return [];
        }
        $params = [];
        $in = $this->in('ip', $ids, $params);
        $rows = Database::fetchAll(
            "SELECT ip.invitation_id, p.id, p.name, p.project_code
             FROM user_invitation_projects ip
             INNER JOIN projects p ON p.id = ip.project_id
             WHERE ip.invitation_id IN ({$in})
             ORDER BY p.name ASC",
            $params
        );

        return $this->group($rows, 'invitation_id');
    }

    /**
     * @param list<int> $ids
     * @return array<int, list<array<string, mixed>>>
     */
    private function tasksByInvitation(array $ids): array
    {
        if ($ids === [] || !SchemaHelper::tableExists('user_invitation_tasks')) {
            return [];
        }
        $params = [];
        $in = $this->in('it', $ids, $params);
        $rows = Database::fetchAll(
            "SELECT it.invitation_id, t.id, t.name, t.project_id, p.name AS project_name
             FROM user_invitation_tasks it
             INNER JOIN tasks t ON t.id = it.task_id
             INNER JOIN projects p ON p.id = t.project_id
             WHERE it.invitation_id IN ({$in})
             ORDER BY t.name ASC",
            $params
        );

        return $this->group($rows, 'invitation_id');
    }

    /**
     * @param list<int> $ids
     * @return array<int, list<array<string, mixed>>>
     */
    private function teamsByInvitation(array $ids): array
    {
        if ($ids === [] || !SchemaHelper::tableExists('user_invitation_teams') || !SchemaHelper::tableExists('teams')) {
            return [];
        }
        $params = [];
        $in = $this->in('tm', $ids, $params);
        $rows = Database::fetchAll(
            "SELECT it.invitation_id, te.id, te.name
             FROM user_invitation_teams it
             INNER JOIN teams te ON te.id = it.team_id
             WHERE it.invitation_id IN ({$in})
             ORDER BY te.name ASC",
            $params
        );

        return $this->group($rows, 'invitation_id');
    }

    private function selectSql(): string
    {
        return 'SELECT i.id, i.email, i.name, i.job_title, i.phone, i.account_status,
                       i.invited_by, i.role_id, i.user_id, i.token_hash, i.expires_at,
                       i.status, i.sent_at, i.accepted_at, i.cancelled_at, i.last_sent_at,
                       i.send_count, i.created_at, i.updated_at,
                       r.name AS role, r.display_name AS role_name,
                       inv.name AS invited_by_name, inv.email AS invited_by_email
                FROM user_invitations i
                INNER JOIN roles r ON r.id = i.role_id
                LEFT JOIN users inv ON inv.id = i.invited_by';
    }

    /**
     * @param list<int> $ids
     * @param array<string, mixed> $params
     */
    private function in(string $prefix, array $ids, array &$params): string
    {
        $placeholders = [];
        foreach (array_values($ids) as $i => $id) {
            $key = $prefix . $i;
            $placeholders[] = ':' . $key;
            $params[$key] = (int) $id;
        }

        return implode(', ', $placeholders);
    }

    /**
     * @param list<array<string, mixed>> $rows
     * @return array<int, list<array<string, mixed>>>
     */
    private function group(array $rows, string $key): array
    {
        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row[$key]][] = $row;
        }

        return $out;
    }
}
