<?php
/**
 * Public invitation accept page (auth layout).
 *
 * @var array<string, mixed>|null $invitation
 * @var string $token
 * @var string|null $inviteError
 */

$appName = SettingsService::appName();
$flashes = flash_pull();
$passwordError = field_error('password');
$canAccept = $inviteError === null && is_array($invitation);
?>
<div class="login-page">
    <section class="login-aside" aria-hidden="true">
        <div class="login-aside-inner">
            <div class="brand-link">
                <?= BrandingHelper::mark() ?>
                <span class="brand-name"><?= e($appName) ?></span>
            </div>
            <p class="login-claim">Activate your account.</p>
            <p class="login-sub">Create a password. The invitation link works only once.</p>
        </div>
    </section>

    <main class="login-main" id="main-content">
        <div class="login-card">
            <div class="login-mobile-brand d-lg-none">
                <?= BrandingHelper::mark() ?>
                <span class="brand-name"><?= e($appName) ?></span>
            </div>

            <h1 class="login-title">Accept Invitation</h1>

            <?php foreach ($flashes as $type => $messages): ?>
                <?php foreach ((array) $messages as $message): ?>
                    <div class="alert alert-<?= e($type) ?>" role="<?= $type === 'danger' ? 'alert' : 'status' ?>"><?= e($message) ?></div>
                <?php endforeach; ?>
            <?php endforeach; ?>

            <?php if (!$canAccept): ?>
                <div class="alert alert-danger" role="alert"><?= e((string) $inviteError) ?></div>
                <p class="login-foot"><a href="<?= e(url('/login')) ?>">Sign in</a></p>
            <?php else: ?>
                <form method="post" action="<?= e(url('/accept-invitation')) ?>" novalidate data-single-submit>
                    <?= csrf_field() ?>
                    <input type="hidden" name="token" value="<?= e($token) ?>">

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="password" required autocomplete="new-password"
                               class="form-control form-control-lg<?= $passwordError !== null ? ' is-invalid' : '' ?>"
                               data-password-meter="#password-meter">
                        <?php if ($passwordError !== null): ?><div class="invalid-feedback"><?= e($passwordError) ?></div><?php endif; ?>
                        <div class="strength" id="password-meter" aria-live="polite"><span class="strength-bar"></span><span class="strength-text"></span></div>
                        <div class="form-text">Please use a strong password.</div>
                    </div>
                    <div class="mb-4">
                        <label for="password_confirmation" class="form-label">Confirm password</label>
                        <input type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password" class="form-control form-control-lg">
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-100">Accept invitation</button>
                </form>
            <?php endif; ?>
        </div>
    </main>
</div>
