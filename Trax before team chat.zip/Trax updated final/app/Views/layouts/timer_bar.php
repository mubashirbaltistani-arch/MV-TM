<?php
/**
 * Strip shown at the very top of the page content (inside <main>): the running-timer
 * bar followed by one-time flash messages.
 *
 * The bar is always in the DOM (hidden when idle) so timer.js can show it without a reload.
 *
 * @var array<string, mixed>|null $activeTimer optional; loaded here when omitted
 */

$flashes = flash_pull();
$icons   = ['success' => 'fa-circle-check', 'danger' => 'fa-circle-exclamation', 'warning' => 'fa-triangle-exclamation', 'info' => 'fa-circle-info'];

$canTrackTimer = AuthHelper::check()
    && PermissionHelper::has('time.track')
    && class_exists('Timer')
    && Timer::installed()
    && FeatureFlagsHelper::trackerVisible();
$timer = isset($activeTimer) && is_array($activeTimer) ? $activeTimer : null;
if (!isset($activeTimer) && $canTrackTimer) {
    try {
        $timer = (new Timer())->getActive((int) AuthHelper::id());
    } catch (Throwable $e) {
        LoggerHelper::debug('Timer bar load failed', ['error' => $e->getMessage()]);
        $timer = null;
    }
}

$hasTimer = $canTrackTimer && is_array($timer) && !empty($timer['started_at']);
$paused = $hasTimer && !empty($timer['paused_at']);
$running = $hasTimer && !$paused;
$startedIso = '';
if ($running) {
    try {
        $startedIso = (new DateTimeImmutable((string) $timer['started_at'], new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');
    } catch (Exception) {
        $startedIso = '';
    }
}
?>
<?php if ($canTrackTimer): ?>
    <div id="timerBar"
         class="timer-bar<?= $hasTimer ? '' : ' is-idle' ?><?= $paused ? ' is-paused' : '' ?>"
         role="status"
         <?= $hasTimer ? '' : 'hidden' ?>
         data-timer-bar
         data-status-url="<?= e(url('/time/status')) ?>"
         data-start-url="<?= e(url('/time/start')) ?>"
         data-stop-url="<?= e(url('/time/stop')) ?>"
         data-pause-url="<?= e(url('/time/pause')) ?>"
         data-resume-url="<?= e(url('/time/resume')) ?>"
         data-ping-url="<?= e(url('/time/ping')) ?>"
         data-idle-response-url="<?= e(url('/time/idle-response')) ?>"
         data-tasks-url="<?= e(url('/time/tasks')) ?>"
         data-started-at="<?= e($startedIso) ?>"
         data-elapsed="<?= $hasTimer ? (int) ($timer['elapsed_seconds'] ?? 0) : 0 ?>">
        <span class="timer-pulse" aria-hidden="true"></span>
        <span class="timer-label">
            <strong data-timer-project><?= e($hasTimer ? ($timer['project_name'] ?? 'Timer running') : 'Timer running') ?></strong>
            <span class="timer-task<?= $hasTimer && !empty($timer['task_name']) ? '' : ' d-none' ?>" data-timer-task><?= e($hasTimer ? ($timer['task_name'] ?? '') : '') ?></span>
        </span>
        <span class="timer-clock" data-timer-clock><?= $hasTimer ? e(FormatHelper::duration((int) ($timer['elapsed_seconds'] ?? 0))) : '0:00:00' ?></span>
        <button type="button" class="btn btn-sm btn-dark timer-pause" data-timer-toggle<?= $hasTimer ? '' : ' disabled' ?>>
            <i class="fa-solid <?= $paused ? 'fa-play' : 'fa-pause' ?>" aria-hidden="true"></i> <span data-timer-toggle-label><?= $paused ? 'Resume' : 'Pause' ?></span>
        </button>
        <button type="button" class="btn btn-sm btn-dark timer-stop" data-timer-stop<?= $hasTimer ? '' : ' disabled' ?>>
            <i class="fa-solid fa-stop" aria-hidden="true"></i> Stop
        </button>
        <button type="button"
                class="btn btn-sm btn-dark timer-pip-open<?= $hasTimer ? '' : ' d-none' ?>"
                data-timer-pip-open
                <?= $hasTimer ? '' : ' disabled' ?>
                title="Open always-on-top timer">
            <i class="fa-solid fa-up-right-from-square" aria-hidden="true"></i>
            <span class="d-none d-md-inline">Picture in picture</span>
        </button>
    </div>

    <div class="timer-pip" data-timer-pip hidden>
        <div class="timer-pip-head">
            <span class="timer-pulse" aria-hidden="true"></span>
            <span class="timer-pip-kicker">Live timer</span>
            <button type="button" class="timer-pip-close" data-timer-pip-close aria-label="Close picture in picture">
                <i class="fa-solid fa-xmark" aria-hidden="true"></i>
            </button>
        </div>
        <div class="timer-pip-main">
            <span class="timer-pulse timer-pip-dot" aria-hidden="true"></span>
            <div class="timer-pip-label">
                <strong data-timer-project><?= e($hasTimer ? ($timer['project_name'] ?? 'Timer running') : 'Timer running') ?></strong>
                <span class="timer-task<?= $hasTimer && !empty($timer['task_name']) ? '' : ' d-none' ?>" data-timer-task><?= e($hasTimer ? ($timer['task_name'] ?? '') : '') ?></span>
            </div>
            <div class="timer-pip-clock" data-timer-clock><?= $hasTimer ? e(FormatHelper::duration((int) ($timer['elapsed_seconds'] ?? 0))) : '0:00:00' ?></div>
        </div>
        <div class="timer-pip-actions">
            <button type="button" class="btn btn-sm btn-dark" data-timer-pip-toggle<?= $hasTimer ? '' : ' disabled' ?>>
                <i class="fa-solid <?= $paused ? 'fa-play' : 'fa-pause' ?>" aria-hidden="true"></i>
                <span class="timer-pip-btn-text"><?= $paused ? 'Resume' : 'Pause' ?></span>
            </button>
            <button type="button" class="btn btn-sm btn-dark" data-timer-stop<?= $hasTimer ? '' : ' disabled' ?>>
                <i class="fa-solid fa-stop" aria-hidden="true"></i> <span class="timer-pip-btn-text">Stop</span>
            </button>
        </div>
    </div>

    <div class="modal fade" id="timerIdleModal" tabindex="-1" aria-labelledby="timerIdleTitle" aria-hidden="true" data-timer-idle-modal data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="timerIdleTitle"><i class="fa-solid fa-circle-question me-2" data-idle-title-icon></i><span data-idle-title>Are you still on?</span></h5>
                </div>
                <div class="modal-body" data-idle-body-warning>
                    <p class="mb-2">No computer activity has been detected for <strong data-idle-threshold>10 minutes</strong>.</p>
                    <p class="text-secondary mb-0">If you are still working, choose <strong>Yes, I'm still working</strong>. If you do nothing, TimeTrack will pause this timer automatically.</p>
                    <div class="small text-secondary mt-3" data-idle-countdown></div>
                </div>
                <div class="modal-body d-none" data-idle-body-paused>
                    <p class="mb-2">Your timer was <strong>paused automatically</strong> because no computer activity was detected and the warning was not answered.</p>
                    <p class="text-secondary mb-0">Choose <strong>Resume</strong> to continue tracking, or <strong>Stop</strong> to finish this entry.</p>
                </div>
                <div class="modal-footer" data-idle-footer-warning>
                    <button type="button" class="btn btn-outline-secondary" data-idle-pause>Pause timer</button>
                    <button type="button" class="btn btn-primary" data-idle-continue>Yes, I’m still working</button>
                </div>
                <div class="modal-footer d-none" data-idle-footer-paused>
                    <button type="button" class="btn btn-outline-danger" data-idle-stop><i class="fa-solid fa-stop me-1" aria-hidden="true"></i>Stop</button>
                    <button type="button" class="btn btn-primary" data-idle-resume><i class="fa-solid fa-play me-1" aria-hidden="true"></i>Resume</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="timerStopConflictModal" tabindex="-1" aria-labelledby="timerStopConflictTitle" aria-hidden="true" data-timer-stop-conflict-modal>
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="timerStopConflictTitle">Timer overlaps existing time</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-2" data-timer-conflict-message>
                        This timer overlaps an existing time entry. Choose how to resolve the conflict.
                    </p>
                    <div class="small text-secondary" data-timer-conflict-details></div>
                    <div class="alert alert-warning mt-3 mb-0" role="alert">
                        Closing this dialog does <strong>not</strong> stop the timer. It remains active until you choose Trim or Discard.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Keep Timer</button>
                    <button type="button" class="btn btn-danger" data-timer-discard>Discard Timer</button>
                    <button type="button" class="btn btn-primary" data-timer-trim>Trim &amp; Stop</button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<?php foreach ($flashes as $type => $messages): ?>
    <?php foreach ((array) $messages as $message): ?>
        <div class="alert alert-<?= e($type) ?> d-flex align-items-start gap-2 alert-dismissible fade show" role="<?= $type === 'danger' ? 'alert' : 'status' ?>" data-auto-dismiss="<?= $type === 'success' || $type === 'info' ? '6000' : '0' ?>">
            <i class="fa-solid <?= e($icons[$type] ?? 'fa-circle-info') ?> mt-1" aria-hidden="true"></i>
            <div class="flex-grow-1"><?= e($message) ?></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Dismiss"></button>
        </div>
    <?php endforeach; ?>
<?php endforeach; ?>
