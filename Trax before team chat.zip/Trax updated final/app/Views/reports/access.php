<?php
/**
 * Admin only: decide who can open Reports and how much they see.
 *
 * @var bool $ready
 * @var list<array<string,mixed>> $people
 */
?>
<div class="page-head d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
    <div>
        <h1 class="page-heading mb-1">Who can see reports</h1>
        <p class="text-muted mb-0">You always have full access. Everyone else sees Reports only if you allow it here.</p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= e(url('/reports/summary')) ?>"><i class="fa-solid fa-arrow-left me-2"></i>Back to reports</a>
</div>

<?php if (!$ready): ?>
<div class="alert alert-warning">The access table does not exist yet. Run <strong>STEP 7</strong> of <code>database/UPGRADE_LIVE.sql</code> in phpMyAdmin, then reload this page. Until then, the old role permissions decide.</div>
<?php endif; ?>

<form method="post" action="<?= e(url('/reports/access')) ?>">
    <?= csrf_field() ?>
    <div class="card">
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead><tr><th>Person</th><th>Role</th><th style="min-width:15rem">Reports access</th><th class="text-center">Export CSV</th><th class="text-center">See billing amounts</th></tr></thead>
                <tbody>
                <?php if ($people === []): ?><tr><td colspan="5" class="text-center text-muted py-4">There are no other active users.</td></tr><?php endif; ?>
                <?php foreach ($people as $p): $id = (int) $p['id']; $level = (string) ($p['access_level'] ?? 'none'); $isClient = $p['role'] === 'client'; ?>
                    <tr>
                        <td><strong><?= e($p['name']) ?></strong><div class="small text-muted"><?= e($p['email']) ?></div></td>
                        <td><?= e(AuthHelper::roleLabel((string) $p['role'])) ?></td>
                        <td>
                            <select class="form-select form-select-sm" name="level[<?= $id ?>]" aria-label="Reports access for <?= e($p['name']) ?>">
                                <option value="none"<?= $level !== 'own' && $level !== 'all' ? ' selected' : '' ?>>No access</option>
                                <option value="own"<?= $level === 'own' ? ' selected' : '' ?>><?= $isClient ? 'Their clients\' projects only' : 'Own time only' ?></option>
                                <?php if (!$isClient): ?><option value="all"<?= $level === 'all' ? ' selected' : '' ?>>Everyone's time (incl. team reports)</option><?php endif; ?>
                            </select>
                        </td>
                        <td class="text-center"><input class="form-check-input" type="checkbox" name="export[<?= $id ?>]" value="1" <?= (int) $p['can_export'] === 1 ? 'checked' : '' ?> aria-label="Export CSV for <?= e($p['name']) ?>"></td>
                        <td class="text-center"><input class="form-check-input" type="checkbox" name="billing[<?= $id ?>]" value="1" <?= (int) $p['can_billing'] === 1 ? 'checked' : '' ?> aria-label="Billing amounts for <?= e($p['name']) ?>"></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer d-flex justify-content-between align-items-center">
            <span class="small text-muted">Export and billing only apply to people who have reports access. New users start with no access.</span>
            <button class="btn btn-primary" type="submit"<?= $ready ? '' : ' disabled' ?>>Save access</button>
        </div>
    </div>
</form>
