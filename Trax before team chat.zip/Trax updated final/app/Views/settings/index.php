<?php
/**
 * Global/system settings form. Workspace identity and policies are managed on /workspace.
 *
 * @var array<string, string> $settings
 * @var array<string, mixed> $smtp
 * @var list<string> $smtpEncryptions
 * @var list<string> $timezones
 * @var list<string> $currencies
 * @var list<string> $dateFormats
 * @var list<string> $timeFormats
 * @var bool $appKeyOk
 * @var list<string> $smtpHints
 */

$val = static fn (string $key, string $default = ''): string => old($key, (string) ($settings[$key] ?? $default));
$on = static fn (string $key): bool => old($key, (string) ($settings[$key] ?? '0')) === '1';
$selectedZone = old('default_timezone', (string) ($settings['default_timezone'] ?? 'UTC'));
$selectedCurrency = old('currency', (string) ($settings['currency'] ?? 'USD'));
$selectedDate = old('date_format', (string) ($settings['date_format'] ?? 'M j, Y'));
$selectedTime = old('time_format', (string) ($settings['time_format'] ?? 'H:i'));
$smtp = $smtp ?? [];
$smtpEncryptions = $smtpEncryptions ?? ['tls', 'ssl', 'none'];
$smtpVal = static fn (string $key, string $default = ''): string => old($key, (string) ($smtp[$key] ?? $default));
$smtpOn = old('smtp_enabled', (string) ($smtp['smtp_enabled'] ?? '0')) === '1';
$selectedEnc = $smtpVal('smtp_encryption', 'tls');
$appKeyOk = $appKeyOk ?? false;
$smtpHints = is_array($smtpHints ?? null) ? $smtpHints : [];

// Branding panel
$brandColorRaw = trim(old('brand_color', (string) ($settings['brand_color'] ?? '')));
$brandColorVal = BrandingHelper::normalizeHex($brandColorRaw) ?? '';
$brandPreview  = $brandColorVal !== '' ? $brandColorVal : BrandingHelper::EMAIL_DEFAULT;
$brandLogoUrl  = BrandingHelper::logoUrl();
$brandFaviconUrl = BrandingHelper::faviconUrl();
$brandSwatches = [
    '#03a9df' => 'Sky',    '#0b7a75' => 'Teal',   '#16a34a' => 'Green',  '#4f46e5' => 'Indigo',
    '#7c3aed' => 'Violet', '#db2777' => 'Pink',   '#dc2626' => 'Red',    '#ea580c' => 'Orange',
    '#f59e0b' => 'Amber',  '#475569' => 'Slate',
];
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">System settings</h2>
        <p class="page-lead">Application name, branding, billing, timezone and mail. Workspace policies live under Workspace.</p>
    </div>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <form method="post" action="<?= e(url('/settings')) ?>" novalidate data-single-submit>
            <?= csrf_field() ?>
            <section class="panel mb-4">
                <div class="panel-head">
                    <h2 class="panel-title">General</h2>
                </div>
                <div class="panel-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="app_name" class="form-label">Application name</label>
                            <input type="text" id="app_name" name="app_name" maxlength="80" required
                                   class="form-control<?= field_error('app_name') ? ' is-invalid' : '' ?>" value="<?= e($val('app_name', 'TimeTrack')) ?>">
                            <?php if (field_error('app_name')): ?><div class="invalid-feedback"><?= e(field_error('app_name')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="company_email" class="form-label">Company email</label>
                            <input type="email" id="company_email" name="company_email" maxlength="190" required
                                   class="form-control<?= field_error('company_email') ? ' is-invalid' : '' ?>" value="<?= e($val('company_email')) ?>">
                            <?php if (field_error('company_email')): ?><div class="invalid-feedback"><?= e(field_error('company_email')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label for="date_format" class="form-label">Date format</label>
                            <select id="date_format" name="date_format" class="form-select<?= field_error('date_format') ? ' is-invalid' : '' ?>" required>
                                <?php foreach ($dateFormats as $format): ?>
                                    <option value="<?= e($format) ?>"<?= $selectedDate === $format ? ' selected' : '' ?>><?= e($format) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('date_format')): ?><div class="invalid-feedback"><?= e(field_error('date_format')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label for="time_format" class="form-label">Time format</label>
                            <select id="time_format" name="time_format" class="form-select<?= field_error('time_format') ? ' is-invalid' : '' ?>" required>
                                <?php foreach ($timeFormats as $format): ?>
                                    <option value="<?= e($format) ?>"<?= $selectedTime === $format ? ' selected' : '' ?>><?= e($format) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('time_format')): ?><div class="invalid-feedback"><?= e(field_error('time_format')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label for="default_timezone" class="form-label">Default timezone</label>
                            <select id="default_timezone" name="default_timezone" class="form-select<?= field_error('default_timezone') ? ' is-invalid' : '' ?>" required>
                                <?php foreach ($timezones as $zone): ?>
                                    <option value="<?= e($zone) ?>"<?= $zone === $selectedZone ? ' selected' : '' ?>><?= e(str_replace('_', ' ', $zone)) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('default_timezone')): ?><div class="invalid-feedback"><?= e(field_error('default_timezone')) ?></div><?php endif; ?>
                            <div class="form-text">Stored data stays in UTC. Users can override this on their profile.</div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="panel mb-4">
                <div class="panel-head">
                    <h2 class="panel-title">Billing</h2>
                </div>
                <div class="panel-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <label for="currency" class="form-label">Currency code</label>
                            <select id="currency" name="currency" class="form-select<?= field_error('currency') ? ' is-invalid' : '' ?>">
                                <?php foreach ($currencies as $currency): ?>
                                    <option value="<?= e($currency) ?>"<?= $selectedCurrency === $currency ? ' selected' : '' ?>><?= e($currency) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('currency')): ?><div class="invalid-feedback"><?= e(field_error('currency')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-3">
                            <label for="currency_symbol" class="form-label">Currency symbol</label>
                            <input type="text" id="currency_symbol" name="currency_symbol" maxlength="6" required
                                   class="form-control<?= field_error('currency_symbol') ? ' is-invalid' : '' ?>" value="<?= e($val('currency_symbol', '$')) ?>">
                            <?php if (field_error('currency_symbol')): ?><div class="invalid-feedback"><?= e(field_error('currency_symbol')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="default_hourly_rate" class="form-label">Default hourly rate</label>
                            <input type="number" id="default_hourly_rate" name="default_hourly_rate" min="0" step="0.01" inputmode="decimal" required
                                   class="form-control<?= field_error('default_hourly_rate') ? ' is-invalid' : '' ?>" value="<?= e($val('default_hourly_rate', '0')) ?>">
                            <?php if (field_error('default_hourly_rate')): ?><div class="invalid-feedback"><?= e(field_error('default_hourly_rate')) ?></div><?php endif; ?>
                            <div class="form-text">Used when a project or person has no rate of their own.</div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="panel">
                <div class="panel-head">
                    <h2 class="panel-title">Time and system</h2>
                </div>
                <div class="panel-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="timer_max_hours" class="form-label">Timer maximum hours</label>
                            <input type="number" id="timer_max_hours" name="timer_max_hours" min="1" max="24" step="1" required
                                   class="form-control<?= field_error('timer_max_hours') ? ' is-invalid' : '' ?>" value="<?= e($val('timer_max_hours', '12')) ?>">
                            <?php if (field_error('timer_max_hours')): ?><div class="invalid-feedback"><?= e(field_error('timer_max_hours')) ?></div><?php endif; ?>
                            <div class="form-text">The server stops a running timer after this many hours.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="timer_reminder_minutes" class="form-label">Ask "Still working?" every (minutes)</label>
                            <input type="number" id="timer_reminder_minutes" name="timer_reminder_minutes" min="0" max="240" step="1" required
                                   class="form-control<?= field_error('timer_reminder_minutes') ? ' is-invalid' : '' ?>" value="<?= e($val('timer_reminder_minutes', '10')) ?>">
                            <?php if (field_error('timer_reminder_minutes')): ?><div class="invalid-feedback"><?= e(field_error('timer_reminder_minutes')) ?></div><?php endif; ?>
                            <div class="form-text">A popup asks whether the person is still working while their timer runs. Use 0 to turn it off.</div>
                        </div>
                        <div class="col-12 d-flex flex-column gap-2">
                            <label class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="allow_manual_time_entries" value="1" <?= $on('allow_manual_time_entries') ? 'checked' : '' ?>>
                                <span class="form-check-label">Allow manual time entries</span>
                            </label>
                            <label class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="notifications_enabled" value="1" <?= $on('notifications_enabled') ? 'checked' : '' ?>>
                                <span class="form-check-label">In-app notifications</span>
                            </label>
                            <label class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="maintenance_mode" value="1" <?= $on('maintenance_mode') ? 'checked' : '' ?>>
                                <span class="form-check-label">Maintenance mode</span>
                            </label>
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">Save settings</button>
                        <a class="btn btn-outline-secondary ms-2" href="<?= e(url('/workspace?tab=features')) ?>">Workspace policies</a>
                    </div>
                </div>
            </section>
        </form>

        <section class="panel mb-4" id="branding">
            <div class="panel-head">
                <h2 class="panel-title">Branding</h2>
            </div>
            <div class="panel-body">
                <p class="form-text mb-3">Choose how the application looks. The application name is set under General above. Changes apply to every page, the sign-in screen and emails.</p>
                <form method="post" action="<?= e(url('/settings/branding')) ?>" enctype="multipart/form-data" novalidate data-single-submit data-branding-form>
                    <?= csrf_field() ?>
                    <div class="row g-4">
                        <div class="col-md-7">
                            <label for="brand_color" class="form-label">Brand colour</label>
                            <div class="brand-color-row">
                                <input type="color" id="brand_color_picker" class="form-control form-control-color" value="<?= e($brandPreview) ?>" aria-label="Pick a colour" data-brand-picker>
                                <input type="text" id="brand_color" name="brand_color" maxlength="7" autocomplete="off" spellcheck="false" placeholder="Built-in colours"
                                       class="form-control<?= field_error('brand_color') ? ' is-invalid' : '' ?>" value="<?= e($brandColorVal) ?>" data-brand-hex>
                            </div>
                            <?php if (field_error('brand_color')): ?><div class="invalid-feedback d-block"><?= e(field_error('brand_color')) ?></div><?php endif; ?>
                            <div class="brand-swatches" role="group" aria-label="Suggested colours">
                                <?php foreach ($brandSwatches as $hex => $label): ?>
                                    <button type="button" class="brand-swatch" style="background:<?= e($hex) ?>" data-brand-swatch="<?= e($hex) ?>" title="<?= e($label) ?>" aria-label="<?= e($label . ' ' . $hex) ?>"></button>
                                <?php endforeach; ?>
                            </div>
                            <div class="form-text">Used for buttons, links, the highlighted menu item and the logo tile. Leave empty to keep the built-in colours. Text colour adjusts automatically so it stays readable.</div>
                        </div>
                        <div class="col-md-5">
                            <div class="form-label">Preview</div>
                            <div class="brand-preview" data-brand-preview data-default="<?= e(BrandingHelper::EMAIL_DEFAULT) ?>">
                                <span class="brand-preview-tile" data-brand-tile><i class="fa-solid fa-stopwatch"></i></span>
                                <span class="brand-preview-btn" data-brand-btn>Primary button</span>
                                <span class="brand-preview-link" data-brand-link>Link text</span>
                            </div>
                        </div>

                        <div class="col-12"><hr class="my-0"></div>

                        <div class="col-md-7">
                            <label for="logo" class="form-label">Application logo</label>
                            <input type="file" id="logo" name="logo" accept="image/png,image/jpeg,image/webp"
                                   class="form-control<?= field_error('logo') ? ' is-invalid' : '' ?>" data-brand-logo>
                            <?php if (field_error('logo')): ?><div class="invalid-feedback d-block"><?= e(field_error('logo')) ?></div><?php endif; ?>
                            <div class="form-text">Square PNG, JPG or WebP, at least 128 x 128 px, up to 1 MB. Shown in the menu and on the sign-in page. A wide logo is shown at its natural proportions. Without one, the stopwatch icon is used. The browser tab icon is set separately below.</div>
                            <?php if ($brandLogoUrl !== ''): ?>
                                <label class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" name="remove_logo" value="1" data-brand-remove>
                                    <span class="form-check-label">Remove the current logo</span>
                                </label>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-5">
                            <div class="form-label">Current logo</div>
                            <span class="brand-logo-box" data-brand-logo-box>
                                <?php if ($brandLogoUrl !== ''): ?>
                                    <img src="<?= e($brandLogoUrl) ?>" alt="Current application logo">
                                <?php else: ?>
                                    <span class="text-secondary small">None, using the stopwatch icon</span>
                                <?php endif; ?>
                            </span>
                        </div>

                        <div class="col-12"><hr class="my-0"></div>

                        <div class="col-md-7">
                            <label for="favicon" class="form-label">Favicon</label>
                            <input type="file" id="favicon" name="favicon" accept="image/png,image/jpeg,image/webp"
                                   class="form-control<?= field_error('favicon') ? ' is-invalid' : '' ?>" data-brand-favicon>
                            <?php if (field_error('favicon')): ?><div class="invalid-feedback d-block"><?= e(field_error('favicon')) ?></div><?php endif; ?>
                            <div class="form-text">The small icon shown in the browser tab and bookmarks. Square PNG, JPG or WebP, at least 32 x 32 px (256 x 256 px is ideal), up to 1 MB. A non-square image is centred on a square. Without one, the built-in icon is used.</div>
                            <?php if ($brandFaviconUrl !== ''): ?>
                                <label class="form-check mt-2">
                                    <input class="form-check-input" type="checkbox" name="remove_favicon" value="1" data-brand-favicon-remove>
                                    <span class="form-check-label">Remove the current favicon</span>
                                </label>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-5">
                            <div class="form-label">Current favicon</div>
                            <span class="brand-logo-box brand-favicon-box" data-brand-favicon-box>
                                <?php if ($brandFaviconUrl !== ''): ?>
                                    <img src="<?= e($brandFaviconUrl) ?>" alt="Current favicon">
                                <?php else: ?>
                                    <img src="<?= e(asset('img/favicon-180.png')) ?>" alt="Built-in favicon">
                                <?php endif; ?>
                            </span>
                            <?php if ($brandFaviconUrl === ''): ?>
                                <div class="form-text">None uploaded, using the built-in icon.</div>
                            <?php endif; ?>
                        </div>

                        <div class="col-12"><hr class="my-0"></div>

                        <div class="col-md-5">
                            <label for="login_headline" class="form-label">Sign-in headline</label>
                            <input type="text" id="login_headline" name="login_headline" maxlength="120"
                                   class="form-control<?= field_error('login_headline') ? ' is-invalid' : '' ?>" value="<?= e($val('login_headline')) ?>">
                            <?php if (field_error('login_headline')): ?><div class="invalid-feedback"><?= e(field_error('login_headline')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-7">
                            <label for="login_subtext" class="form-label">Sign-in description</label>
                            <input type="text" id="login_subtext" name="login_subtext" maxlength="300"
                                   class="form-control<?= field_error('login_subtext') ? ' is-invalid' : '' ?>" value="<?= e($val('login_subtext')) ?>">
                            <?php if (field_error('login_subtext')): ?><div class="invalid-feedback"><?= e(field_error('login_subtext')) ?></div><?php endif; ?>
                            <div class="form-text">Shown beside the sign-in form on large screens.</div>
                        </div>
                    </div>
                    <div class="mt-4 d-flex flex-wrap gap-2">
                        <button type="submit" class="btn btn-primary">Save branding</button>
                    </div>
                </form>
                <form method="post" action="<?= e(url('/settings/branding/reset')) ?>" class="mt-2" novalidate data-single-submit data-confirm="Reset the brand colour, logo and sign-in text to the defaults?">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-link btn-sm px-0 text-secondary">Reset branding to defaults</button>
                </form>
            </div>
        </section>

        <section class="panel mb-4" id="smtp">
            <div class="panel-head">
                <h2 class="panel-title">Mail / SMTP</h2>
            </div>
            <div class="panel-body">
                <?php if (!$appKeyOk): ?>
                    <div class="alert alert-warning" role="status">APP_KEY is not set, so the SMTP password cannot be stored. Set a random 32+ character secret in config/config.php first.</div>
                <?php endif; ?>
                <?php foreach ($smtpHints as $hint): ?>
                    <div class="alert alert-warning" role="status"><?= e($hint) ?></div>
                <?php endforeach; ?>
                <p class="form-text mb-3">“Test email sent” means the mail server accepted the message. Gmail can still put it in Spam or Promotions, or drop it if From is a Gmail address sent through another host.</p>
                <form method="post" action="<?= e(url('/settings/smtp')) ?>" novalidate data-single-submit>
                    <?= csrf_field() ?>
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="smtp_enabled" value="1" <?= $smtpOn ? 'checked' : '' ?>>
                                <span class="form-check-label">Send invitation and reset emails through SMTP</span>
                            </label>
                        </div>
                        <div class="col-md-8">
                            <label for="smtp_host" class="form-label">SMTP host</label>
                            <input type="text" id="smtp_host" name="smtp_host" maxlength="190" autocomplete="off"
                                   class="form-control<?= field_error('smtp_host') ? ' is-invalid' : '' ?>" value="<?= e($smtpVal('smtp_host')) ?>">
                            <?php if (field_error('smtp_host')): ?><div class="invalid-feedback"><?= e(field_error('smtp_host')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-4">
                            <label for="smtp_port" class="form-label">Port</label>
                            <input type="number" id="smtp_port" name="smtp_port" min="1" max="65535" required
                                   class="form-control<?= field_error('smtp_port') ? ' is-invalid' : '' ?>" value="<?= e($smtpVal('smtp_port', '587')) ?>">
                            <?php if (field_error('smtp_port')): ?><div class="invalid-feedback"><?= e(field_error('smtp_port')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="smtp_encryption" class="form-label">Encryption</label>
                            <select id="smtp_encryption" name="smtp_encryption" class="form-select<?= field_error('smtp_encryption') ? ' is-invalid' : '' ?>" required>
                                <?php foreach ($smtpEncryptions as $enc): ?>
                                    <option value="<?= e($enc) ?>"<?= $selectedEnc === $enc ? ' selected' : '' ?>><?= e(strtoupper($enc)) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <?php if (field_error('smtp_encryption')): ?><div class="invalid-feedback"><?= e(field_error('smtp_encryption')) ?></div><?php endif; ?>
                            <div class="form-text">Gmail: host smtp.gmail.com, TLS on 587 or SSL on 465. Username is the full Gmail address. Password is a 16-character App Password, not your Google password.</div>
                        </div>
                        <div class="col-md-6">
                            <label for="invite_expiry_days" class="form-label">Invitation expiry (days)</label>
                            <input type="number" id="invite_expiry_days" name="invite_expiry_days" min="1" max="90" required
                                   class="form-control<?= field_error('invite_expiry_days') ? ' is-invalid' : '' ?>" value="<?= e($smtpVal('invite_expiry_days', '7')) ?>">
                            <?php if (field_error('invite_expiry_days')): ?><div class="invalid-feedback"><?= e(field_error('invite_expiry_days')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="smtp_username" class="form-label">Username</label>
                            <input type="text" id="smtp_username" name="smtp_username" maxlength="190" autocomplete="off"
                                   class="form-control<?= field_error('smtp_username') ? ' is-invalid' : '' ?>" value="<?= e($smtpVal('smtp_username')) ?>">
                            <?php if (field_error('smtp_username')): ?><div class="invalid-feedback"><?= e(field_error('smtp_username')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="smtp_password" class="form-label">Password</label>
                            <input type="password" id="smtp_password" name="smtp_password" maxlength="255" autocomplete="new-password"
                                   class="form-control<?= field_error('smtp_password') ? ' is-invalid' : '' ?>" placeholder="<?= !empty($smtp['smtp_password_set']) ? 'Leave blank to keep the stored password' : '' ?>">
                            <?php if (field_error('smtp_password')): ?><div class="invalid-feedback"><?= e(field_error('smtp_password')) ?></div><?php endif; ?>
                            <div class="form-text"><?= !empty($smtp['smtp_password_set']) ? 'A password is stored (encrypted). Leave blank to keep it.' : 'Stored encrypted. Never shown again.' ?></div>
                        </div>
                        <div class="col-md-6">
                            <label for="smtp_from_name" class="form-label">From name</label>
                            <input type="text" id="smtp_from_name" name="smtp_from_name" maxlength="120"
                                   class="form-control<?= field_error('smtp_from_name') ? ' is-invalid' : '' ?>" value="<?= e($smtpVal('smtp_from_name')) ?>">
                            <?php if (field_error('smtp_from_name')): ?><div class="invalid-feedback"><?= e(field_error('smtp_from_name')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="smtp_from_email" class="form-label">From email</label>
                            <input type="email" id="smtp_from_email" name="smtp_from_email" maxlength="190"
                                   class="form-control<?= field_error('smtp_from_email') ? ' is-invalid' : '' ?>" value="<?= e($smtpVal('smtp_from_email')) ?>">
                            <?php if (field_error('smtp_from_email')): ?><div class="invalid-feedback"><?= e(field_error('smtp_from_email')) ?></div><?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label for="smtp_reply_to" class="form-label">Reply-To</label>
                            <input type="email" id="smtp_reply_to" name="smtp_reply_to" maxlength="190"
                                   class="form-control<?= field_error('smtp_reply_to') ? ' is-invalid' : '' ?>" value="<?= e($smtpVal('smtp_reply_to')) ?>">
                            <?php if (field_error('smtp_reply_to')): ?><div class="invalid-feedback"><?= e(field_error('smtp_reply_to')) ?></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" class="btn btn-primary">Save mail settings</button>
                    </div>
                </form>

                <hr class="my-4">

                <form method="post" action="<?= e(url('/settings/smtp/test')) ?>" novalidate data-single-submit class="row g-3 align-items-end">
                    <?= csrf_field() ?>
                    <div class="col-md-8">
                        <label for="test_email" class="form-label">Send a test email to</label>
                        <input type="email" id="test_email" name="test_email" maxlength="190" required
                               class="form-control<?= field_error('test_email') ? ' is-invalid' : '' ?>" value="<?= e(old('test_email')) ?>">
                        <?php if (field_error('test_email')): ?><div class="invalid-feedback"><?= e(field_error('test_email')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <button type="submit" class="btn btn-outline-secondary w-100">Send test</button>
                    </div>
                </form>
            </div>
        </section>
    </div>
</div>
<script src="<?= e(asset('js/branding-form.js')) ?>"></script>