<?php
/**
 * TASKS tab (Clockify layout): filter + search on the left, "Add new Task" + ADD on the right,
 * grey "Tasks" band, NAME / TEAM / ASSIGNEES / STATUS table with inline rename, inline assignee picker and row menu.
 * Included by projects/view.php (shares its variables).
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $members
 * @var list<array<string, mixed>> $tasks
 * @var array{all: int, active: int, done: int} $taskCounts
 * @var string $taskFilter   active|done|all
 * @var string $taskSearch
 * @var string $taskDir      asc|desc
 * @var int $taskTeam
 * @var list<array{id: int, name: string}> $projectTeams
 * @var list<array{id: int, name: string}> $creatableTeams
 * @var bool $canCreateTask
 * @var bool $canEditTask
 * @var bool $canDeleteTask
 * @var bool $canAssignTask
 */

$projectId     = (int) $project['id'];
$projectUrl    = url('/projects/' . $projectId);
$taskTeam      = (int) ($taskTeam ?? 0);
$projectTeams  = $projectTeams ?? [];
$creatableTeams = $creatableTeams ?? [];
$hasFilter     = $taskSearch !== '' || $taskFilter !== 'active' || $taskTeam > 0;
$sortUrl       = $projectUrl . '?' . http_build_query([
    'tab'         => 'tasks',
    'task_status' => $taskFilter,
    'task_q'      => $taskSearch,
    'task_dir'    => $taskDir === 'asc' ? 'desc' : 'asc',
    'task_team'   => $taskTeam > 0 ? $taskTeam : '',
]);
$backPath      = '/projects/' . $projectId . '?' . http_build_query([
    'tab'         => 'tasks',
    'task_status' => $taskFilter,
    'task_q'      => $taskSearch,
    'task_dir'    => $taskDir,
    'task_team'   => $taskTeam > 0 ? $taskTeam : '',
]);
$assignableAll = array_values(array_filter($members, static fn (array $m): bool => (string) ($m['status'] ?? 'active') === 'active'));
$showKebab     = false;
foreach ($tasks as $row) {
    $f = $row['flags'] ?? [];
    if (!empty($f['canEdit']) || !empty($f['canDelete']) || !empty($f['canStatus']) || !empty($f['canReview'])) {
        $showKebab = true;
        break;
    }
}
$showTeamCol = $projectTeams !== [] || Task::hasColumn('team_id');
$statusCss   = static function (string $status): string {
    return match (Task::normalizeStatus($status)) {
        Task::STATUS_COMPLETED => 'is-done',
        Task::STATUS_CANCELLED => 'is-cancelled',
        Task::STATUS_REVIEW    => 'is-review',
        Task::STATUS_ON_HOLD   => 'is-hold',
        Task::STATUS_IN_PROGRESS => 'is-progress',
        default                => 'is-active',
    };
};
?>
<section class="cf-card cf-tasks">
    <div class="cf-toolbar">
        <form method="get" action="<?= e($projectUrl) ?>" class="cf-filters">
            <input type="hidden" name="tab" value="tasks">
            <label for="task-status-filter" class="visually-hidden">Show</label>
            <select id="task-status-filter" name="task_status" class="cf-select cf-select-filter" data-auto-submit>
                <option value="active"<?= $taskFilter === 'active' ? ' selected' : '' ?>>Show active</option>
                <option value="done"<?= $taskFilter === 'done' ? ' selected' : '' ?>>Show done</option>
                <option value="all"<?= $taskFilter === 'all' ? ' selected' : '' ?>>Show all</option>
            </select>
            <?php if ($projectTeams !== []): ?>
                <label for="task-team-filter" class="visually-hidden">Team</label>
                <select id="task-team-filter" name="task_team" class="cf-select cf-select-filter" data-auto-submit>
                    <option value="">All teams</option>
                    <?php foreach ($projectTeams as $team): ?>
                        <option value="<?= (int) $team['id'] ?>"<?= $taskTeam === (int) $team['id'] ? ' selected' : '' ?>><?= e($team['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            <?php endif; ?>
            <div class="cf-search">
                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                <label for="task-search" class="visually-hidden">Search tasks</label>
                <input type="search" id="task-search" name="task_q" maxlength="100" placeholder="Search by name" value="<?= e($taskSearch) ?>">
            </div>
        </form>

        <?php if ($canCreateTask): ?>
            <form method="post" action="<?= e(url('/projects/' . $projectId . '/tasks')) ?>" class="cf-add" data-single-submit>
                <?= csrf_field() ?>
                <?php if (count($creatableTeams) === 1): ?>
                    <input type="hidden" name="team_id" value="<?= (int) $creatableTeams[0]['id'] ?>">
                <?php elseif (count($creatableTeams) > 1): ?>
                    <label for="new-task-team" class="visually-hidden">Team</label>
                    <select id="new-task-team" name="team_id" class="cf-select cf-select-filter">
                        <?php foreach ($creatableTeams as $team): ?>
                            <option value="<?= (int) $team['id'] ?>"><?= e($team['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
                <label for="new-task-name" class="visually-hidden">Add new task</label>
                <input type="text" id="new-task-name" name="name" maxlength="160" required placeholder="Add new Task" autocomplete="off">
                <button type="submit" class="cf-btn cf-btn-primary">Add</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="cf-band">
        <span>Tasks</span>
        <?php if ($hasFilter): ?>
            <a class="cf-band-link" href="<?= e($projectUrl . '?tab=tasks') ?>">Reset filter</a>
        <?php endif; ?>
    </div>

    <?php if ($tasks === []): ?>
        <div class="cf-empty">
            <?php if ($hasFilter && $taskCounts['all'] > 0): ?>
                No tasks match this filter.
            <?php else: ?>
                This project has no tasks yet.<?= $canCreateTask ? ' Type a name above and press ADD.' : '' ?>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="cf-table-wrap">
            <table class="cf-table">
                <thead>
                    <tr>
                        <th class="cf-col-name">
                            <a class="cf-sort" href="<?= e($sortUrl) ?>">Name
                                <i class="fa-solid <?= $taskDir === 'desc' ? 'fa-sort-down' : 'fa-sort-up' ?>" aria-hidden="true"></i>
                            </a>
                        </th>
                        <?php if ($showTeamCol): ?><th class="cf-col-team">Team</th><?php endif; ?>
                        <th class="cf-col-assignees">Assignees</th>
                        <th class="cf-col-status">Status</th>
                        <?php if ($showKebab): ?><th class="cf-col-actions" aria-label="Actions"></th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                        <?php
                        $taskId   = (int) $task['id'];
                        $status   = Task::normalizeStatus((string) $task['status']);
                        $isDone   = Task::isDone($status);
                        $isClosed = Task::isClosed($status);
                        $flags    = $task['flags'] ?? [
                            'canEdit' => $canEditTask, 'canAssign' => $canAssignTask, 'canStatus' => $canEditTask,
                            'canReview' => $canEditTask, 'canDelete' => $canDeleteTask, 'canCancel' => $canEditTask,
                            'canReopen' => $canEditTask, 'canComplete' => $canEditTask,
                        ];
                        $teamId   = isset($task['team_id']) && $task['team_id'] !== null ? (int) $task['team_id'] : null;
                        $teamName = (string) ($task['team_name'] ?? '');
                        $names    = array_map(static fn (array $a): string => (string) $a['name'], $task['assignees']);
                        $label    = $names === [] ? 'Anyone' : implode(', ', $names);
                        $rowAssignIds = TaskPolicy::assignableIdsFor((int) AuthHelper::id(), $project, $teamId);
                        $rowAssignable = array_values(array_filter(
                            $assignableAll,
                            static fn (array $m): bool => in_array((int) $m['user_id'], $rowAssignIds, true)
                        ));
                        $payload = [
                            'name'            => (string) $task['name'],
                            'description'     => (string) ($task['description'] ?? ''),
                            'status'          => $status,
                            'team_id'         => $teamId,
                            'estimated_hours' => (float) $task['estimated_hours'] > 0 ? rtrim(rtrim(number_format((float) $task['estimated_hours'], 2, '.', ''), '0'), '.') : '',
                            'due_date'        => (string) ($task['due_date'] ?? ''),
                            'assignee_ids'    => $task['assignee_ids'],
                        ];
                        $rowKebab = !empty($flags['canEdit']) || !empty($flags['canDelete']) || !empty($flags['canStatus']) || !empty($flags['canReview']);
                        ?>
                        <tr<?= $isDone ? ' class="is-done"' : '' ?>>
                            <td class="cf-col-name" data-label="Name">
                                <?php if (!empty($flags['canEdit'])): ?>
                                    <input type="text" class="cf-name-input" value="<?= e($task['name']) ?>" maxlength="160"
                                           data-task-rename="<?= e(url('/tasks/' . $taskId . '/rename')) ?>"
                                           data-original="<?= e($task['name']) ?>" aria-label="Task name" autocomplete="off"
                                           <?= $isDone ? 'disabled title="Completed tasks cannot be renamed. Mark the task active first."' : '' ?>>
                                <?php else: ?>
                                    <span class="cf-name-text"><?= e($task['name']) ?></span>
                                <?php endif; ?>
                            </td>
                            <?php if ($showTeamCol): ?>
                                <td class="cf-col-team" data-label="Team">
                                    <?php if ($teamName !== ''): ?>
                                        <span class="cf-team-pill"><?= e($teamName) ?></span>
                                    <?php else: ?>
                                        <span class="cf-team-pill is-project">Project</span>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                            <td class="cf-col-assignees" data-label="Assignees">
                                <?php if (!empty($flags['canAssign']) && $rowAssignable !== []): ?>
                                    <div class="dropdown cf-assignee" data-task-assignees="<?= e(url('/tasks/' . $taskId . '/assignees')) ?>">
                                        <button type="button" class="cf-pill" data-bs-toggle="dropdown" data-bs-auto-close="outside" data-bs-popper-config='{"strategy":"fixed"}' aria-expanded="false">
                                            <span class="cf-pill-label"><?= e($label) ?></span><i class="fa-solid fa-caret-down" aria-hidden="true"></i>
                                        </button>
                                        <div class="dropdown-menu cf-assignee-menu">
                                            <?php foreach ($rowAssignable as $member): ?>
                                                <?php $posLabel = TaskPolicy::positionLabel((int) $member['user_id'], $projectId, $teamId); ?>
                                                <label class="cf-check">
                                                    <input type="checkbox" value="<?= (int) $member['user_id'] ?>"
                                                           data-name="<?= e($member['name']) ?>"
                                                           <?= in_array((int) $member['user_id'], $task['assignee_ids'], true) ? 'checked' : '' ?>>
                                                    <span><?= e($member['name']) ?><?php if ($posLabel !== ''): ?> <small class="text-secondary"><?= e($posLabel) ?></small><?php endif; ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                            <p class="cf-menu-hint">Nobody selected means <strong>Anyone</strong>.</p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <span class="cf-pill is-static"><span class="cf-pill-label"><?= e($label) ?></span></span>
                                <?php endif; ?>
                            </td>
                            <td class="cf-col-status" data-label="Status">
                                <span class="cf-status-badge <?= e($statusCss($status)) ?>" data-task-status><?= e($status) ?></span>
                            </td>
                            <?php if ($showKebab): ?>
                                <td class="cf-col-actions" data-label="Actions">
                                    <?php if ($rowKebab): ?>
                                    <div class="dropdown">
                                        <button type="button" class="cf-kebab" data-bs-toggle="dropdown" data-bs-popper-config='{"strategy":"fixed"}' aria-expanded="false" aria-label="Task actions">
                                            <span class="cf-dots" aria-hidden="true"><i></i><i></i><i></i></span>
                                        </button>
                                        <ul class="dropdown-menu dropdown-menu-end cf-menu">
                                            <?php if (!empty($flags['canEdit'])): ?>
                                                <li>
                                                    <button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#taskModal"
                                                            data-task-edit="<?= e(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)) ?>"
                                                            data-task-action="<?= e(url('/tasks/' . $taskId)) ?>">Edit</button>
                                                </li>
                                            <?php endif; ?>
                                            <?php if (!empty($flags['canStatus']) && in_array(Task::STATUS_REVIEW, $task['allowed_statuses'] ?? [], true) && $status !== Task::STATUS_REVIEW): ?>
                                                <li>
                                                    <form method="post" action="<?= e(url('/tasks/' . $taskId . '/status')) ?>">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="back" value="<?= e($backPath) ?>">
                                                        <input type="hidden" name="status" value="<?= e(Task::STATUS_REVIEW) ?>">
                                                        <button type="submit" class="dropdown-item">Send for review</button>
                                                    </form>
                                                </li>
                                            <?php endif; ?>
                                            <?php if (!empty($flags['canReview']) && $status === Task::STATUS_REVIEW): ?>
                                                <li>
                                                    <form method="post" action="<?= e(url('/tasks/' . $taskId . '/review')) ?>">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="back" value="<?= e($backPath) ?>">
                                                        <button type="submit" class="dropdown-item">Approve &amp; complete</button>
                                                    </form>
                                                </li>
                                                <li>
                                                    <button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#returnTaskModal"
                                                            data-return-id="<?= $taskId ?>" data-return-name="<?= e($task['name']) ?>">Return to In Progress</button>
                                                </li>
                                            <?php endif; ?>
                                            <?php if (!empty($flags['canStatus']) && $isClosed && in_array(Task::STATUS_IN_PROGRESS, $task['allowed_statuses'] ?? [], true)): ?>
                                                <li>
                                                    <form method="post" action="<?= e(url('/tasks/' . $taskId . '/status')) ?>">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="back" value="<?= e($backPath) ?>">
                                                        <input type="hidden" name="status" value="<?= e(Task::STATUS_IN_PROGRESS) ?>">
                                                        <button type="submit" class="dropdown-item">Reopen</button>
                                                    </form>
                                                </li>
                                            <?php endif; ?>
                                            <?php if (!empty($flags['canDelete'])): ?>
                                                <li><hr class="dropdown-divider"></li>
                                                <li>
                                                    <form method="post" action="<?= e(url('/tasks/' . $taskId . '/delete')) ?>"
                                                          data-confirm="Delete task <?= e($task['name']) ?>? Planned schedule blocks keep their time but lose the task link.">
                                                        <?= csrf_field() ?>
                                                        <button type="submit" class="dropdown-item text-danger">Delete</button>
                                                    </form>
                                                </li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php if ($canCreateTask || $canEditTask): ?>
    <?php require APP_PATH . '/Views/tasks/form_modal.php'; ?>
<?php endif; ?>

<div class="modal fade" id="returnTaskModal" tabindex="-1" aria-labelledby="returnTaskTitle" aria-hidden="true">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('/tasks/0/return')) ?>" id="returnTaskForm" data-single-submit>
            <?= csrf_field() ?>
            <input type="hidden" name="back" value="<?= e($backPath) ?>">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title fs-5" id="returnTaskTitle">Return task</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-secondary" id="returnTaskLead">Send this task back to In Progress with a note.</p>
                    <label for="review_note" class="form-label">Reason</label>
                    <textarea id="review_note" name="review_note" class="form-control" rows="4" required maxlength="500"
                              placeholder="What needs to change?"></textarea>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Return task</button>
                </div>
            </div>
        </form>
    </div>
</div>
