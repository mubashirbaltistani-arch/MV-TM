<?php
/**
 * Department setup: organisation departments with teams, managers and members.
 *
 * @var bool $ready
 * @var list<array<string, mixed>> $rows
 * @var array<int, list<array<string, mixed>>> $teams
 * @var array<int, list<array{id: int, name: string}>> $members
 * @var array<int, list<array{id: int, name: string}>> $managers
 * @var string $search
 */
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Departments</h2>
        <p class="page-lead">Organisation structure: department &rarr; teams &rarr; members. Teams can work on any project.</p>
    </div>
    <?php if ($ready): ?>
        <a class="btn btn-primary" href="<?= e(url('/teams/create')) ?>">
            <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>New department
        </a>
    <?php endif; ?>
</div>

<?php if (!$ready): ?>
    <div class="alert alert-warning" role="alert">
        Department tables are not installed yet. Run <code>database/UPGRADE_LIVE.sql</code> on the live database, then reload this page.
    </div>
<?php else: ?>
    <form method="get" action="<?= e(url('/teams')) ?>" class="filter-bar">
        <div class="filter-search">
            <label for="team-q" class="visually-hidden">Search departments</label>
            <input type="search" id="team-q" name="q" class="form-control" placeholder="Search department, team or person" value="<?= e($search) ?>">
        </div>
        <button type="submit" class="btn btn-outline-secondary">Filter</button>
    </form>

    <?php if ($rows === []): ?>
        <section class="panel">
            <div class="empty-state">
                <i class="fa-solid fa-sitemap" aria-hidden="true"></i>
                <p><?= $search !== '' ? 'No departments match this search.' : 'No departments yet. Create one, then add teams and members.' ?></p>
            </div>
        </section>
    <?php endif; ?>

    <?php foreach ($rows as $dept): ?>
        <?php $teamList = $teams[(int) $dept['id']] ?? []; ?>
        <section class="panel mb-4">
            <div class="dept-card-head">
                <div>
                    <h2 class="panel-title mb-1"><?= e((string) $dept['name']) ?></h2>
                    <div class="small text-muted">
                        Department manager:
                        <?php if (!empty($dept['manager_name'])): ?>
                            <strong><?= e((string) $dept['manager_name']) ?></strong>
                        <?php else: ?>
                            <span class="text-warning">not set</span>
                        <?php endif; ?>
                        <span class="status-badge status-<?= (string) $dept['status'] === 'active' ? 'completed' : 'planning' ?> ms-2"><?= e(ucfirst((string) $dept['status'])) ?></span>
                    </div>
                </div>
                <div class="d-flex gap-2">
                    <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/teams/' . (int) $dept['id'] . '/edit')) ?>">Edit</a>
                    <?php
                    $taskCount = (int) ($dept['task_count'] ?? 0);
                    $confirm = 'Delete department "' . (string) $dept['name'] . '"? Members keep their accounts.';
                    if ($taskCount > 0) {
                        $confirm .= ' ' . $taskCount . ' open task' . ($taskCount === 1 ? '' : 's') . ' will become unassigned from the team.';
                    }
                    ?>
                    <form method="post" action="<?= e(url('/teams/' . (int) $dept['id'] . '/delete')) ?>" class="d-inline"
                          data-confirm="<?= e($confirm) ?>">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                    </form>
                </div>
            </div>
            <?php if ($teamList === []): ?>
                <p class="small text-muted mb-0 px-3 pb-3">No teams yet.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table data-table mb-0">
                        <thead>
                            <tr>
                                <th>Team</th>
                                <th>Team managers</th>
                                <th>Members</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($teamList as $team): ?>
                                <?php
                                $list = $members[(int) $team['id']] ?? [];
                                $mgrs = $managers[(int) $team['id']] ?? [];
                                ?>
                                <tr>
                                    <td class="fw-semibold"><?= e((string) $team['name']) ?></td>
                                    <td>
                                        <?php if ($mgrs === []): ?>
                                            <span class="text-muted">—</span>
                                        <?php else: ?>
                                            <?= e(implode(', ', array_map(static fn (array $m): string => $m['name'], $mgrs))) ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($list === []): ?>
                                            <span class="text-muted">No members</span>
                                        <?php else: ?>
                                            <span class="count-pill"><?= count($list) ?></span>
                                            <span class="small text-muted"><?= e(implode(', ', array_map(static fn (array $m): string => $m['name'], array_slice($list, 0, 4)))) ?><?= count($list) > 4 ? ' +' . (count($list) - 4) . ' more' : '' ?></span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
<?php endif; ?>
<style>
.dept-card-head { display:flex; justify-content:space-between; align-items:flex-start; gap:1rem; padding:1rem 1.15rem .75rem; flex-wrap:wrap; }
</style>
