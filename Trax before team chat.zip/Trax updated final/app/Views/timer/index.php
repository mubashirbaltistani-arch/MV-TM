<?php
/**
 * Time entries list with filters, live timer start, and manual add.
 *
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, totals: array{seconds: int, billable_seconds: int, count: int}} $result
 * @var array{from: string, to: string, project_id: int, task_id: int, billable: string, status: string, user_id: int} $filters
 * @var list<array<string, mixed>> $projects
 * @var list<array<string, mixed>> $filterProjects
 * @var list<array<string, mixed>> $tasks
 * @var list<array<string, mixed>> $people
 * @var bool $viewAll
 * @var bool $canTrack
 * @var bool $canManual
 * @var bool $canDelete
 * @var bool $canEditAll
 * @var array<string, mixed>|null $activeTimer
 */

$items  = $result['items'];
$submittable = $submittable ?? [];
$totals = $result['totals'];
$userId = (int) AuthHelper::id();

$qs = static function (array $extra = []) use ($filters): string {
    $data = array_filter([
        'from'       => $extra['from'] ?? $filters['from'],
        'to'         => $extra['to'] ?? $filters['to'],
        'project_id' => $extra['project_id'] ?? ($filters['project_id'] ?: ''),
        'task_id'    => $extra['task_id'] ?? ($filters['task_id'] ?: ''),
        'billable'   => $extra['billable'] ?? $filters['billable'],
        'status'     => $extra['status'] ?? $filters['status'],
        'user_id'    => $extra['user_id'] ?? ($filters['user_id'] ?: ''),
        'page'       => $extra['page'] ?? null,
    ], static fn ($v) => $v !== null && $v !== '' && $v !== 0 && $v !== '0');

    return $data === [] ? '' : '?' . http_build_query($data);
};

$statusClass = static fn (string $status): string => match ($status) {
    'Approved' => 'completed',
    'Rejected' => 'cancelled',
    default    => 'planning',
};
?>
<link rel="stylesheet" href="<?= e(asset('css/time-list.css')) ?>">
<div class="page-toolbar" data-time-region="toolbar">
    <div>
        <h2 class="page-heading">Time</h2>
        <p class="page-lead">Track work with a live timer or add entries by hand. Daily capacity <?= e(rtrim(rtrim(number_format((float) ($capacityHours ?? 8), 2, '.', ''), '0'), '.')) ?>h<?= isset($usedTodaySeconds) ? '; ' . e(FormatHelper::hours((int) $usedTodaySeconds)) . 'h used today' : '' ?>.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if (FeatureFlagsHelper::timesheetEnabled() && class_exists('TimesheetController') && is_file(APP_PATH . '/Controllers/TimesheetController.php')): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets')) ?>">
                <i class="fa-solid fa-table me-1" aria-hidden="true"></i>Timesheet
            </a>
        <?php endif; ?>
        <?php if ($submittable !== [] && FeatureFlagsHelper::timesheetEnabled()): ?>
            <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#submitWorkModal">
                <i class="fa-solid fa-paper-plane me-1" aria-hidden="true"></i>Submit for approval
            </button>
        <?php endif; ?>
        <?php if ($canManual): ?>
            <button type="button" class="btn btn-outline-secondary" data-bs-toggle="modal" data-bs-target="#manualEntryModal">
                <i class="fa-solid fa-pen-to-square me-1" aria-hidden="true"></i>Add time
            </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($canTrack): ?>
<section class="panel mb-4">
    <div class="panel-head">
        <h2 class="panel-title">Start timer</h2>
    </div>
    <div class="panel-body">
        <form class="row g-2 align-items-end" data-timer-start-form>
            <div class="col-md-4">
                <label for="start_project_id" class="form-label">Project</label>
                <select id="start_project_id" name="project_id" class="form-select" required data-timer-project-select>
                    <option value="">Choose a project</option>
                    <?php foreach ($projects as $project): ?>
                        <option value="<?= (int) $project['id'] ?>" data-billable="<?= (int) ($project['is_billable'] ?? 1) ?>">
                            <?= e($project['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="start_task_id" class="form-label">Task <span class="text-secondary">(optional)</span></label>
                <select id="start_task_id" name="task_id" class="form-select" data-timer-task-select>
                    <option value="">No task</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="start_description" class="form-label">What are you working on?</label>
                <input type="text" id="start_description" name="description" maxlength="255" class="form-control" placeholder="Optional note">
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-primary w-100" data-timer-start>
                    <i class="fa-solid fa-play me-1" aria-hidden="true"></i>Start
                </button>
            </div>
        </form>
    </div>
</section>
<?php endif; ?>

<?php if (false): ?>
<section class="panel mb-4" data-live-timers-panel data-live-timers-url="<?= e(url('/time/active')) ?>" data-live-user-id="<?= (int) $filters['user_id'] > 0 ? (int) $filters['user_id'] : 0 ?>" hidden>
    <div class="panel-head">
        <div>
            <h2 class="panel-title"><span class="live-now-dot" aria-hidden="true"></span>Running now</h2>
            <p class="small text-secondary mb-0">Live timers update automatically without refreshing this page.</p>
        </div>
        <span class="count-pill" data-live-timers-count>0</span>
    </div>
    <div class="table-responsive">
        <table class="table data-table mb-0">
            <thead>
                <tr>
                    <?php if ($viewAll): ?><th>Person</th><?php endif; ?>
                    <th>Project</th>
                    <th>Task</th>
                    <th>Note</th>
                    <th>Started (PKT)</th>
                    <th class="text-end">Duration</th>
                </tr>
            </thead>
            <tbody data-live-timers-body></tbody>
        </table>
    </div>
</section>
<?php endif; ?>

<form method="get" action="<?= e(url('/time')) ?>" class="filter-bar">
    <div>
        <label for="time-from" class="visually-hidden">From</label>
        <input type="date" id="time-from" name="from" class="form-control" value="<?= e($filters['from']) ?>">
    </div>
    <div>
        <label for="time-to" class="visually-hidden">To</label>
        <input type="date" id="time-to" name="to" class="form-control" value="<?= e($filters['to']) ?>">
    </div>
    <div>
        <label for="time-project" class="visually-hidden">Project</label>
        <select id="time-project" name="project_id" class="form-select">
            <option value="">All projects</option>
            <?php foreach ($filterProjects as $project): ?>
                <option value="<?= (int) $project['id'] ?>"<?= (int) $filters['project_id'] === (int) $project['id'] ? ' selected' : '' ?>><?= e($project['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="time-task" class="visually-hidden">Task</label>
        <select id="time-task" name="task_id" class="form-select">
            <option value="">All tasks</option>
            <?php foreach ($tasks as $task): ?>
                <option value="<?= (int) $task['id'] ?>"<?= (int) $filters['task_id'] === (int) $task['id'] ? ' selected' : '' ?>><?= e($task['name']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="time-billable" class="visually-hidden">Billable</label>
        <select id="time-billable" name="billable" class="form-select">
            <option value="">Billable and not</option>
            <option value="1"<?= $filters['billable'] === '1' ? ' selected' : '' ?>>Billable</option>
            <option value="0"<?= $filters['billable'] === '0' ? ' selected' : '' ?>>Non-billable</option>
        </select>
    </div>
    <div>
        <label for="time-status" class="visually-hidden">Timesheet status</label>
        <select id="time-status" name="status" class="form-select">
            <option value="">All states</option>
            <option value="unsubmitted"<?= $filters['status'] === 'unsubmitted' ? ' selected' : '' ?>>Unsubmitted</option>
            <option value="submitted"<?= $filters['status'] === 'submitted' ? ' selected' : '' ?>>Submitted</option>
            <option value="approved"<?= $filters['status'] === 'approved' ? ' selected' : '' ?>>Approved</option>
            <option value="rejected"<?= $filters['status'] === 'rejected' ? ' selected' : '' ?>>Rejected</option>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<?php require APP_PATH . '/Views/timer/_entries.php'; ?>

<div data-time-region="submit-modal">
<?php if ($submittable !== []): ?>
<div class="modal fade" id="submitWorkModal" tabindex="-1" aria-labelledby="submitWorkModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <div>
          <h2 class="modal-title h5 mb-1" id="submitWorkModalTitle">Submit work for approval</h2>
          <p class="small text-secondary mb-0">Select the work you want to submit. Unselected work stays available for your next submission.</p>
        </div>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= e(url('/timesheets/submit-selected')) ?>" id="submitWorkForm" data-single-submit data-confirm="Submit the selected work for approval?">
        <?= csrf_field() ?>
        <div class="modal-body">
          <div class="d-flex justify-content-between align-items-center mb-2">
            <label class="form-check mb-0"><input type="checkbox" class="form-check-input me-1" data-submit-modal-select-all> Select all</label>
            <span class="small text-secondary"><span data-submit-modal-count>0</span> selected</span>
          </div>
          <div class="table-responsive">
            <table class="table data-table mb-0">
              <thead><tr><th></th><th>Date</th><th>Project</th><th>Task</th><th>Note</th><th class="text-end">Duration</th></tr></thead>
              <tbody>
              <?php foreach ($submittable as $entry): ?>
                <tr>
                  <td class="text-center"><input type="checkbox" class="form-check-input" name="entry_ids[]" value="<?= (int) $entry['id'] ?>" data-submit-modal-work></td>
                  <td><?= e(FormatHelper::datetime((string) $entry['start_time'], 'M j, Y H:i')) ?></td>
                  <td><?= e((string) $entry['project_name']) ?></td>
                  <td><?= !empty($entry['task_name']) ? e((string) $entry['task_name']) : '&mdash;' ?></td>
                  <td><?= !empty($entry['description']) ? e((string) $entry['description']) : '&mdash;' ?></td>
                  <td class="text-end mono"><?= e(FormatHelper::duration((int) $entry['duration_seconds'])) ?></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary" data-submit-modal-button disabled><i class="fa-solid fa-paper-plane me-1" aria-hidden="true"></i>Submit selected</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
</div>

<?php if ($canManual): ?>
    <?php require APP_PATH . '/Views/timer/manual_entry_modal.php'; ?>
<?php endif; ?>

<script src="<?= e(asset('js/time-page.js')) ?>"></script>
<script src="<?= e(asset('js/time-list.js')) ?>"></script>
