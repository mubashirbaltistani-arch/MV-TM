<?php
/**
 * User directory (Phase 9). Admin/manager read; admins create, edit and deactivate.
 *
 * @var list<array<string, mixed>> $users
 * @var array{q: string, role: string, status: string} $filters
 * @var int  $total
 * @var int  $page
 * @var int  $pages
 * @var bool $canManage
 * @var int  $currentId
 */

$statusClass = static fn (string $status): string => match ($status) {
    'active'    => 'status-active',
    'suspended' => 'status-hold',
    default     => 'status-inactive',
};

$query = static function (array $extra = []) use ($filters): string {
    $params = array_filter([
        'q'      => $extra['q'] ?? $filters['q'],
        'role'   => ($extra['role'] ?? $filters['role']) !== 'all' ? ($extra['role'] ?? $filters['role']) : null,
        'status' => ($extra['status'] ?? $filters['status']) !== 'all' ? ($extra['status'] ?? $filters['status']) : null,
        'page'   => $extra['page'] ?? null,
    ], static fn ($v): bool => $v !== null && $v !== '');
    return $params === [] ? '' : '?' . http_build_query($params);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Users</h2>
        <p class="page-lead">People, roles, billing rates and account status.</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <?php if (PermissionHelper::has('users.view') && class_exists('UserInvitation') && UserInvitation::installed()): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/users/invitations')) ?>">Invitations</a>
        <?php endif; ?>
        <?php if (PermissionHelper::has('users.create')): ?>
            <?php if (class_exists('UserInvitation') && UserInvitation::installed()): ?>
                <a class="btn btn-outline-secondary" href="<?= e(url('/users/invite')) ?>">
                    <i class="fa-solid fa-envelope me-1" aria-hidden="true"></i>Invite
                </a>
            <?php endif; ?>
            <a class="btn btn-primary" href="<?= e(url('/users/create')) ?>">
                <i class="fa-solid fa-user-plus me-1" aria-hidden="true"></i>New user
            </a>
        <?php endif; ?>
    </div>
</div>

<form method="get" action="<?= e(url('/users')) ?>" class="filter-bar">
    <div class="filter-search">
        <label for="user-q" class="visually-hidden">Search users</label>
        <input type="search" id="user-q" name="q" class="form-control" placeholder="Search name, email or job title" value="<?= e($filters['q']) ?>">
    </div>
    <div>
        <label for="user-role" class="visually-hidden">Role</label>
        <select id="user-role" name="role" class="form-select">
            <option value="all">All roles</option>
            <?php foreach (AuthHelper::ROLES as $role): ?>
                <option value="<?= e($role) ?>"<?= $filters['role'] === $role ? ' selected' : '' ?>><?= e(AuthHelper::roleLabel((string) $role)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div>
        <label for="user-status" class="visually-hidden">Status</label>
        <select id="user-status" name="status" class="form-select">
            <option value="all">All statuses</option>
            <?php foreach (['active', 'inactive', 'suspended'] as $status): ?>
                <option value="<?= e($status) ?>"<?= $filters['status'] === $status ? ' selected' : '' ?>><?= e(ucfirst($status)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Directory <span class="count-pill"><?= (int) $total ?></span></h2>
    </div>

    <?php if ($users === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-user" aria-hidden="true"></i>
            <p>No users match these filters.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table table-stack mb-0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Rate / h</th>
                        <th>Status</th>
                        <th>Last sign-in</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <tr>
                            <td data-label="Name">
                                <div class="user-cell">
                                    <?= UserAvatarHelper::html($user['avatar_path'] ?? null, (string) $user['name'], 'avatar avatar-sm') ?>
                                    <span>
                                        <strong><?= e($user['name']) ?></strong>
                                        <?php if (!empty($user['job_title'])): ?><span class="d-block text-secondary small"><?= e($user['job_title']) ?></span><?php endif; ?>
                                    </span>
                                </div>
                            </td>
                            <td data-label="Email"><a href="mailto:<?= e($user['email']) ?>"><?= e($user['email']) ?></a></td>
                            <td data-label="Role"><span class="role-pill role-<?= e(strtolower((string) $user['role'])) ?>"><?= e($user['role_name']) ?></span></td>
                            <td data-label="Rate / h" class="mono"><?= e(number_format((float) $user['hourly_rate'], 2)) ?></td>
                            <td data-label="Status"><span class="status-badge <?= e($statusClass((string) $user['status'])) ?>"><?= e(ucfirst((string) $user['status'])) ?></span></td>
                            <td data-label="Last sign-in"><?= $user['last_login_at'] ? e(FormatHelper::datetime((string) $user['last_login_at'], 'M j, Y H:i')) : '<span class="text-secondary">Never</span>' ?></td>
                            <td data-label="Actions" class="text-end text-nowrap">
                                <?php if ($canManage): ?>
                                    <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/users/' . (int) $user['id'] . '/edit')) ?>">Edit</a>
                                <?php endif; ?>
                                <?php if (PermissionHelper::has('users.delete') && (int) $user['id'] !== $currentId): ?>
                                    <form method="post" action="<?= e(url('/users/' . (int) $user['id'] . '/delete')) ?>" class="d-inline"
                                          data-confirm="Delete <?= e($user['name']) ?>? This cannot be undone.">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($pages > 1): ?>
            <nav class="pager" aria-label="User pages">
                <?php for ($p = 1; $p <= $pages; $p++): ?>
                    <a class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-outline-secondary' ?>" href="<?= e(url('/users') . $query(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>
