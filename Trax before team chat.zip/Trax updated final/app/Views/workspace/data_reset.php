<?php
/**
 * Workspace > Reset data (admin only).
 *
 * @var array<string, mixed>                                                                $workspace
 * @var array<string, array{label: string, help: string, requires: list<string>, rows: int}> $groups
 * @var string                                                                              $phrase
 * @var int                                                                                 $lockedFor Seconds of cool-down left
 * @var list<string>                                                                        $selected
 */

declare(strict_types=1);

$locked = (int) $lockedFor > 0;
?>
<div class="page-head d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
  <div>
    <h2 class="page-heading mb-1">Workspace settings</h2>
    <p class="text-muted mb-0">One place for workspace identity, permissions and workspace-wide rules.</p>
  </div>
</div>

<div class="workspace-settings-shell">
  <aside class="workspace-settings-sidebar">
    <div class="workspace-brand-card">
      <?php if (!empty($workspace['logo_path'])): ?>
        <img src="<?= e(url((string) $workspace['logo_path'])) ?>" class="workspace-logo" alt="Workspace logo">
      <?php endif; ?>
      <strong><?= e((string) $workspace['name']) ?></strong><span>Workspace</span>
    </div>
    <nav class="workspace-settings-nav">
      <a href="<?= e(url('/workspace?tab=general')) ?>"><i class="fa-solid fa-sliders"></i> General</a>
      <a href="<?= e(url('/workspace?tab=permissions')) ?>"><i class="fa-solid fa-shield-halved"></i> Permissions</a>
      <a href="<?= e(url('/workspace?tab=features')) ?>"><i class="fa-solid fa-toggle-on"></i> Features &amp; policies</a>
      <a class="active" href="<?= e(url('/workspace/data-reset')) ?>"><i class="fa-solid fa-trash-can"></i> Reset data</a>
    </nav>
  </aside>

  <section class="workspace-settings-content">
    <div class="settings-card border border-danger">
      <div class="settings-card-head">
        <h3 class="text-danger">Reset data</h3>
        <p>Remove selected data so you can start again from zero. Roles, permissions, settings, the workspace itself and <strong>your own account</strong> are never deleted.</p>
      </div>

      <?php if ($locked): ?>
        <div class="alert alert-danger mx-3">
          Too many failed attempts. Resetting is locked for about <?= (int) ceil($lockedFor / 60) ?> more minute(s).
        </div>
      <?php endif; ?>

      <form method="post" action="<?= e(url('/workspace/data-reset')) ?>" data-reset-form autocomplete="off">
        <?= csrf_field() ?>

        <div class="px-3 pb-2">
          <div class="alert alert-warning">
            <strong>This cannot be undone.</strong> Download a backup first (button below). Choosing a group automatically selects the groups that depend on it,
            for example removing Projects also removes their tasks, time entries and schedule.
          </div>

          <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" id="reset-all" data-preset-all>
            <label class="form-check-label fw-semibold" for="reset-all">Fresh start: select everything</label>
          </div>

          <div class="list-group mb-3">
            <?php foreach ($groups as $key => $info): ?>
              <label class="list-group-item d-flex gap-3 align-items-start">
                <input class="form-check-input mt-1" type="checkbox" name="groups[]"
                       value="<?= e($key) ?>"
                       data-group="<?= e($key) ?>"
                       data-requires="<?= e(implode(',', $info['requires'])) ?>"
                       <?= in_array($key, $selected, true) ? 'checked' : '' ?>>
                <span class="flex-grow-1">
                  <span class="fw-semibold"><?= e($info['label']) ?></span>
                  <span class="d-block small text-secondary"><?= e($info['help']) ?></span>
                </span>
                <span class="badge text-bg-light border"><?= e(number_format((int) $info['rows'])) ?> rows</span>
              </label>
            <?php endforeach; ?>
          </div>

          <p class="small text-secondary">
            Backups are plain .sql files. The Users backup includes password hashes, so keep the file private.
          </p>
        </div>

        <div class="px-3 pb-3 border-top pt-3">
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label" for="reset-password">Your password</label>
              <input class="form-control" type="password" id="reset-password" name="password" maxlength="200"
                     autocomplete="current-password" required <?= $locked ? 'disabled' : '' ?>>
            </div>
            <div class="col-md-6">
              <label class="form-label" for="reset-phrase">Type <code><?= e($phrase) ?></code> to confirm</label>
              <input class="form-control" type="text" id="reset-phrase" name="confirm_phrase" maxlength="40"
                     autocomplete="off" spellcheck="false" required <?= $locked ? 'disabled' : '' ?>>
            </div>
          </div>

          <div class="form-check mt-3">
            <input class="form-check-input" type="checkbox" id="reset-understand" name="understand" value="1" required <?= $locked ? 'disabled' : '' ?>>
            <label class="form-check-label" for="reset-understand">I understand this permanently deletes the selected data.</label>
          </div>
        </div>

        <div class="settings-card-foot d-flex flex-wrap gap-2 justify-content-between">
          <button type="submit" class="btn btn-outline-secondary"
                  formaction="<?= e(url('/workspace/data-reset/backup')) ?>" formnovalidate
                  data-needs-selection disabled>
            <i class="fa-solid fa-download me-1" aria-hidden="true"></i>Download backup (.sql)
          </button>
          <button type="submit" class="btn btn-danger" data-destructive data-needs-selection disabled <?= $locked ? 'data-locked' : '' ?>>
            <i class="fa-solid fa-trash-can me-1" aria-hidden="true"></i>Delete selected data
          </button>
        </div>
      </form>
    </div>
  </section>
</div>
<script src="<?= e(asset('js/data-reset.js')) ?>"></script>
