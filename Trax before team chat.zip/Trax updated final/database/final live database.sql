-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 09, 2026 at 10:52 AM
-- Server version: 11.8.9-MariaDB-log
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u897128490_timer`
--

-- --------------------------------------------------------

--
-- Table structure for table `active_timers`
--

CREATE TABLE `active_timers` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `started_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `paused_at` datetime DEFAULT NULL,
  `accumulated_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(60) DEFAULT NULL,
  `entity_type` varchar(60) DEFAULT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `ip_address`, `user_agent`, `old_value`, `new_value`, `meta`, `created_at`) VALUES
(1, 1, 'data.reset', 'workspace', 'workspace', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"rows_before\":{\"time\":0,\"schedule\":0,\"tasks\":0,\"projects\":80,\"logs\":3,\"agents\":0,\"invitations\":0}}', '{\"rows_deleted\":{\"timer_idle_events\":0,\"timesheet_entries\":0,\"timesheets\":0,\"active_timers\":0,\"time_entries\":0,\"schedule_recurrences\":0,\"schedules\":0,\"user_invitation_tasks\":0,\"task_assignees\":0,\"tasks\":0,\"user_invitation_projects\":0,\"project_favorites\":0,\"project_members\":0,\"projects\":80,\"notifications\":0,\"activity_logs\":3,\"desktop_agent_pairing_codes\":0,\"agent_pair_attempts\":0,\"desktop_agent_devices\":0,\"user_invitation_teams\":0,\"user_invitations\":0,\"password_reset_tokens\":0}}', '{\"groups\":[\"time\",\"schedule\",\"tasks\",\"projects\",\"logs\",\"agents\",\"invitations\"]}', '2026-10-07 15:30:11'),
(2, 1, 'import.completed', 'import', 'import', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"projects\",\"rows\":11,\"created\":11,\"updated\":0,\"skipped\":0,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-07 15:30:30'),
(3, 1, 'import.completed', 'import', 'import', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"tasks\",\"rows\":80,\"created\":19,\"updated\":61,\"skipped\":0,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-07 15:38:20'),
(4, 1, 'timer.started', 'timer', 'timer', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":4}', '2026-10-07 15:52:05'),
(5, 1, 'timer.stopped', 'time_entry', 'time_entry', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":4}', '2026-10-07 15:52:09'),
(6, 1, 'import.user_created', 'user', 'user', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"muhammadnoman@mavenprojects.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:02'),
(7, 1, 'import.user_created', 'user', 'user', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"umairbadshah0314@gmail.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:02'),
(8, 1, 'import.user_created', 'user', 'user', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"saqibhussain@mavenprojects.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:03'),
(9, 1, 'import.user_created', 'user', 'user', 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"am4416179@gmail.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:03'),
(10, 1, 'import.user_created', 'user', 'user', 6, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"imranjavedarch@gmail.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:03'),
(11, 1, 'import.user_created', 'user', 'user', 7, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"rizwanwarsi508@gmail.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:03'),
(12, 1, 'import.user_created', 'user', 'user', 8, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"usmankhan@mavenprojects.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:03'),
(13, 1, 'import.user_created', 'user', 'user', 9, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"jamilahmad@mavenprojects.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:04'),
(14, 1, 'import.user_created', 'user', 'user', 10, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"ayeshayousuf@mavenprojects.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:04'),
(15, 1, 'import.completed', 'import', 'import', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"users\",\"rows\":10,\"created\":9,\"updated\":0,\"skipped\":1,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":9}', '2026-10-07 15:57:04'),
(16, 1, 'import.user_created', 'user', 'user', 11, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"muhammadkazmeen@mavenprojects.com\",\"role\":\"employee\",\"password_generated\":true}', '2026-10-07 15:57:41'),
(17, 1, 'import.completed', 'import', 'import', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"users\",\"rows\":10,\"created\":1,\"updated\":0,\"skipped\":9,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":1}', '2026-10-07 15:57:41'),
(18, 1, 'user.created', 'user', 'user', 12, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Hamza Arshad\",\"email\":\"hamzatest@gmail.com\",\"role\":\"manager\",\"status\":\"active\"}', NULL, '2026-10-07 16:54:27'),
(19, 1, 'department.updated', 'department', 'department', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Building System\",\"manager_id\":12,\"teams\":1}', '2026-10-07 16:55:48'),
(20, 1, 'user.created', 'user', 'user', 13, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Usman Tallat\",\"email\":\"usmantest@gmail.com\",\"role\":\"manager\",\"status\":\"active\"}', NULL, '2026-10-07 16:57:00'),
(21, 1, 'user.created', 'user', 'user', 14, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Muhammad Waqas\",\"email\":\"waqastest@gmail.com\",\"role\":\"manager\",\"status\":\"active\"}', NULL, '2026-10-07 16:57:34'),
(22, 1, 'department.updated', 'department', 'department', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Building System\",\"manager_id\":13,\"teams\":1}', '2026-10-07 16:59:16'),
(23, 1, 'department.updated', 'department', 'department', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Design Services\",\"manager_id\":12,\"teams\":1}', '2026-10-07 17:00:40'),
(24, 1, 'timer.started', 'timer', 'timer', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":10,\"task_id\":19}', '2026-10-07 17:02:15'),
(25, 1, 'timer.stopped', 'time_entry', 'time_entry', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":10,\"duration_seconds\":11}', '2026-10-07 17:02:26'),
(26, 1, 'timer.started', 'timer', 'timer', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"task_id\":12}', '2026-10-07 17:02:40'),
(27, 1, 'timer.stopped', 'time_entry', 'time_entry', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":2,\"duration_seconds\":1192}', '2026-10-07 17:22:32'),
(28, 1, 'reports.access_updated', 'reports', 'reports', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '[{\"user_id\":2,\"access_level\":\"all\",\"can_export\":1,\"can_billing\":1},{\"user_id\":3,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":4,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":5,\"access_level\":\"all\",\"can_export\":1,\"can_billing\":1},{\"user_id\":6,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":7,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":8,\"access_level\":\"all\",\"can_export\":1,\"can_billing\":1}]', '[{\"user_id\":2,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":3,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":4,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":5,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":6,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":7,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":8,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":9,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":10,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":11,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":12,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":13,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0},{\"user_id\":14,\"access_level\":\"own\",\"can_export\":0,\"can_billing\":0}]', NULL, '2026-10-07 17:48:43'),
(29, 12, 'auth.login', 'user', 'user', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 05:12:32'),
(30, 12, 'auth.password_changed', 'user', 'user', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 05:20:52'),
(31, NULL, 'auth.login_failed', 'user', 'user', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"aylinnoore@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-08 12:49:42'),
(32, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 12:49:48'),
(33, 1, 'import.completed', 'import', 'import', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"clockify_time\",\"rows\":80,\"created\":0,\"updated\":0,\"skipped\":80,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-08 13:22:13'),
(34, 1, 'project.members_added', 'project', 'project', 11, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:26:52'),
(35, 1, 'project.members_added', 'project', 'project', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:27:15'),
(36, 1, 'project.members_added', 'project', 'project', 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:27:38'),
(37, 1, 'project.members_added', 'project', 'project', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:28:00'),
(38, 1, 'project.members_added', 'project', 'project', 8, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:28:32'),
(39, 1, 'project.members_added', 'project', 'project', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:28:48'),
(40, 1, 'project.members_added', 'project', 'project', 5, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:29:08'),
(41, 1, 'project.members_added', 'project', 'project', 6, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:29:31'),
(42, 1, 'project.members_added', 'project', 'project', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:29:49'),
(43, 1, 'project.members_added', 'project', 'project', 9, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:30:17'),
(44, 1, 'project.members_added', 'project', 'project', 7, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":14}', '2026-10-08 13:30:40'),
(45, 1, 'import.completed', 'import', 'import', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"clockify_time\",\"rows\":75,\"created\":74,\"updated\":0,\"skipped\":1,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-08 13:30:57'),
(46, 1, 'data.reset', 'workspace', 'workspace', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"rows_before\":{\"time\":114}}', '{\"rows_deleted\":{\"timer_idle_events\":0,\"timesheet_entries\":33,\"timesheets\":4,\"active_timers\":0,\"time_entries\":77}}', '{\"groups\":[\"time\"]}', '2026-10-08 13:35:42'),
(47, 1, 'user.created', 'user', 'user', 15, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Waqas Hafeez\",\"email\":\"waqashafeez@mavenprojects.com\",\"role\":\"manager\",\"status\":\"active\"}', NULL, '2026-10-08 13:36:45'),
(48, 1, 'project.members_added', 'project', 'project', 11, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:37:04'),
(49, 1, 'project.members_added', 'project', 'project', 10, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:37:13'),
(50, 1, 'project.members_added', 'project', 'project', 3, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:37:20'),
(51, 1, 'project.members_added', 'project', 'project', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:37:30'),
(52, 1, 'project.members_added', 'project', 'project', 8, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:37:39'),
(53, 1, 'project.members_added', 'project', 'project', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:37:47'),
(54, 1, 'project.members_added', 'project', 'project', 5, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:37:56'),
(55, 1, 'project.members_added', 'project', 'project', 6, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:38:06'),
(56, 1, 'project.members_added', 'project', 'project', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:38:22'),
(57, 1, 'project.members_added', 'project', 'project', 7, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 13:38:31'),
(58, 1, 'import.completed', 'import', 'import', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"clockify_time\",\"rows\":196,\"created\":189,\"updated\":2,\"skipped\":5,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-08 13:39:48'),
(59, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 14:54:50'),
(60, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 15:01:00'),
(61, 1, 'user.created', 'user', 'user', 16, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Hamza Farooq\",\"email\":\"hamzafarooq@mavenprojects.com\",\"role\":\"employee\",\"status\":\"active\"}', NULL, '2026-10-08 15:01:32'),
(62, 1, 'import.completed', 'import', 'import', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"clockify_time\",\"rows\":199,\"created\":5,\"updated\":55,\"skipped\":139,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-08 15:02:33'),
(63, 1, 'data.reset', 'workspace', 'workspace', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"rows_before\":{\"time\":309}}', '{\"rows_deleted\":{\"timer_idle_events\":0,\"timesheet_entries\":104,\"timesheets\":11,\"active_timers\":0,\"time_entries\":194}}', '{\"groups\":[\"time\"]}', '2026-10-08 15:03:26'),
(64, 1, 'import.completed', 'import', 'import', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"clockify_time\",\"rows\":199,\"created\":194,\"updated\":2,\"skipped\":3,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-08 15:03:44'),
(65, 1, 'data.reset', 'workspace', 'workspace', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"rows_before\":{\"time\":309}}', '{\"rows_deleted\":{\"timer_idle_events\":0,\"timesheet_entries\":104,\"timesheets\":11,\"active_timers\":0,\"time_entries\":194}}', '{\"groups\":[\"time\"]}', '2026-10-08 15:04:59'),
(66, 1, 'project.members_added', 'project', 'project', 11, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-08 15:05:16'),
(67, 1, 'user.created', 'user', 'user', 17, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Maven\",\"email\":\"info@mavenprojects.com\",\"role\":\"admin\",\"status\":\"active\"}', NULL, '2026-10-08 15:06:07'),
(68, 1, 'import.completed', 'import', 'import', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"type\":\"clockify_time\",\"rows\":199,\"created\":197,\"updated\":2,\"skipped\":0,\"preview\":false,\"all_or_nothing\":false,\"passwords_generated\":0}', '2026-10-08 15:06:26'),
(69, 1, 'invitation.created', 'invite', 'invite', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\",\"role\":\"employee\",\"projects\":11,\"tasks\":19}', NULL, '2026-10-08 15:09:09'),
(70, 1, 'invitation.sent', 'invite', 'invite', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\"}', NULL, '2026-10-08 15:09:12'),
(71, 1, 'invitation.cancelled', 'invite', 'invite', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"status\":\"sent\"}', '{\"status\":\"cancelled\"}', NULL, '2026-10-08 15:13:45'),
(72, 1, 'invitation.created', 'invite', 'invite', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\",\"role\":\"admin\",\"projects\":11,\"tasks\":19}', NULL, '2026-10-08 15:14:02'),
(73, 1, 'invitation.sent', 'invite', 'invite', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\"}', NULL, '2026-10-08 15:14:05'),
(74, 1, 'invitation.deleted', 'invite', 'invite', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"status\":\"cancelled\",\"email\":\"mubashirbaltistani@gmail.com\"}', NULL, NULL, '2026-10-08 15:19:47'),
(75, 1, 'invitation.cancelled', 'invite', 'invite', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"status\":\"sent\"}', '{\"status\":\"cancelled\"}', NULL, '2026-10-08 15:19:50'),
(76, 1, 'invitation.deleted', 'invite', 'invite', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"status\":\"cancelled\",\"email\":\"mubashirbaltistani@gmail.com\"}', NULL, NULL, '2026-10-08 15:19:54'),
(77, 1, 'invitation.created', 'invite', 'invite', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\",\"role\":\"admin\",\"projects\":11,\"tasks\":19}', NULL, '2026-10-08 15:20:10'),
(78, 1, 'invitation.sent', 'invite', 'invite', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\"}', NULL, '2026-10-08 15:20:13'),
(79, 1, 'department.updated', 'department', 'department', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Design Services\",\"manager_id\":12,\"teams\":1}', '2026-10-08 15:34:37'),
(80, 1, 'department.updated', 'department', 'department', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Design Services\",\"manager_id\":12,\"teams\":1}', '2026-10-08 15:35:17'),
(81, 1, 'department.updated', 'department', 'department', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Building System\",\"manager_id\":13,\"teams\":1}', '2026-10-08 15:35:56'),
(82, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 15:48:15'),
(83, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 15:54:38'),
(84, 1, 'timer.started', 'timer', 'timer', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":4}', '2026-10-08 17:12:17'),
(85, 1, 'timer.paused', 'timer', 'timer', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:12:24'),
(86, 1, 'timer.resumed', 'timer', 'timer', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:12:30'),
(87, 1, 'timer.paused', 'timer', 'timer', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:12:38'),
(88, 1, 'timer.resumed', 'timer', 'timer', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:12:39'),
(89, 1, 'timer.stopped', 'time_entry', 'time_entry', 198, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":25}', '2026-10-08 17:12:42'),
(90, 1, 'timer.started', 'timer', 'timer', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":4}', '2026-10-08 17:12:58'),
(91, 1, 'timer.paused', 'timer', 'timer', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:13:06'),
(92, 1, 'timer.resumed', 'timer', 'timer', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:13:39'),
(93, 1, 'timer.stopped', 'time_entry', 'time_entry', 199, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":45}', '2026-10-08 17:13:43'),
(94, 1, 'timer.started', 'timer', 'timer', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":4}', '2026-10-08 17:17:32'),
(95, 1, 'timer.paused', 'timer', 'timer', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:17:39'),
(96, 1, 'timer.resumed', 'timer', 'timer', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:17:40'),
(97, 1, 'timer.stopped', 'time_entry', 'time_entry', 200, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":10}', '2026-10-08 17:17:42'),
(98, 1, 'time_entry.deleted', 'time_entry', 'time_entry', 198, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4}', '2026-10-08 17:21:12'),
(99, 1, 'time_entry.deleted', 'time_entry', 'time_entry', 200, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4}', '2026-10-08 17:21:19'),
(100, 1, 'time_entry.deleted', 'time_entry', 'time_entry', 199, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4}', '2026-10-08 17:21:24'),
(101, 1, 'timer.started', 'timer', 'timer', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":4}', '2026-10-08 17:21:38'),
(102, 1, 'timer.paused', 'timer', 'timer', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:21:50'),
(103, 1, 'timer.resumed', 'timer', 'timer', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:22:24'),
(104, 1, 'timer.stopped', 'time_entry', 'time_entry', 201, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":22}', '2026-10-08 17:22:34'),
(105, 1, 'time_entry.deleted', 'time_entry', 'time_entry', 201, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4}', '2026-10-08 17:22:51'),
(106, 1, 'project.updated', 'project', 'project', 11, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Al Shifa Trust Eye Hospital\",\"status\":\"Active\"}', '{\"name\":\"Al Shifa Trust Eye Hospital\",\"status\":\"Active\"}', NULL, '2026-10-08 17:44:19'),
(107, 1, 'project.updated', 'project', 'project', 10, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Citadel 7 Novacare Hospital\",\"status\":\"Active\"}', '{\"name\":\"Citadel 7 Novacare Hospital\",\"status\":\"Active\"}', NULL, '2026-10-08 17:44:36'),
(108, 1, 'project.updated', 'project', 'project', 3, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Expansion of AFIC\",\"status\":\"Active\"}', '{\"name\":\"Expansion of AFIC\",\"status\":\"Active\"}', NULL, '2026-10-08 17:44:50'),
(109, 1, 'project.updated', 'project', 'project', 4, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"General\",\"status\":\"Active\"}', '{\"name\":\"General\",\"status\":\"Active\"}', NULL, '2026-10-08 17:45:28'),
(110, 1, 'project.updated', 'project', 'project', 8, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"HIVE\",\"status\":\"Active\"}', '{\"name\":\"HIVE\",\"status\":\"Active\"}', NULL, '2026-10-08 17:45:50'),
(111, 1, 'project.updated', 'project', 'project', 2, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Novacare Hospital\",\"status\":\"Active\"}', '{\"name\":\"Novacare Hospital\",\"status\":\"Active\"}', NULL, '2026-10-08 17:46:06'),
(112, 1, 'project.updated', 'project', 'project', 5, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Pure One\",\"status\":\"Active\"}', '{\"name\":\"Pure One\",\"status\":\"Active\"}', NULL, '2026-10-08 17:46:22'),
(113, 1, 'project.updated', 'project', 'project', 6, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Rehabilitation Hospital Project\",\"status\":\"Active\"}', '{\"name\":\"Rehabilitation Hospital Project\",\"status\":\"Active\"}', NULL, '2026-10-08 17:46:39'),
(114, 1, 'project.updated', 'project', 'project', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Residential building G+P+6 (Dubai)\",\"status\":\"Active\"}', '{\"name\":\"Residential building G+P+6 (Dubai)\",\"status\":\"Active\"}', NULL, '2026-10-08 17:46:57'),
(115, 1, 'project.updated', 'project', 'project', 9, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Support Services Hub Novacare Hospital\",\"status\":\"Active\"}', '{\"name\":\"Support Services Hub Novacare Hospital\",\"status\":\"Active\"}', NULL, '2026-10-08 17:47:13'),
(116, 1, 'project.updated', 'project', 'project', 7, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Welfare Hospital Kharian\",\"status\":\"Active\"}', '{\"name\":\"Welfare Hospital Kharian\",\"status\":\"Active\"}', NULL, '2026-10-08 17:47:41'),
(117, 1, 'auth.logout', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:55:45'),
(118, 1, 'auth.login', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 17:55:51'),
(119, 1, 'profile.updated', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 18:03:26'),
(120, 1, 'profile.updated', 'user', 'user', 1, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-08 18:17:55'),
(121, 1, 'settings.updated', 'settings', 'settings', NULL, '58.65.217.235', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"app_name\":\"Trax\",\"company_email\":\"admin@akhoonzadaholdings.com\",\"date_format\":\"M j, Y\",\"time_format\":\"H:i\",\"currency\":\"USD\",\"currency_symbol\":\"$\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"timer_max_hours\":\"12\",\"timer_reminder_minutes\":\"10\",\"allow_manual_time_entries\":\"1\",\"notifications_enabled\":\"1\",\"maintenance_mode\":\"0\",\"brand_color\":\"\",\"brand_logo\":\"logo-af4f9f400f77c3fb.png\",\"brand_favicon\":\"\",\"login_headline\":\"See where every hour goes.\",\"login_subtext\":\"Track time against projects, keep budgets honest, and hand clients numbers they can trust.\"}', '{\"app_name\":\"Trax\",\"company_email\":\"admin@akhoonzadaholdings.com\",\"date_format\":\"M j, Y\",\"time_format\":\"H:i\",\"currency_symbol\":\"-\",\"currency\":\"USD\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"timer_max_hours\":\"12\",\"timer_reminder_minutes\":\"10\",\"allow_manual_time_entries\":\"1\",\"notifications_enabled\":\"1\",\"maintenance_mode\":\"0\"}', NULL, '2026-10-08 18:19:41'),
(122, NULL, 'auth.login_failed', 'user', 'user', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"mubashirjco@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-09 04:13:45'),
(123, NULL, 'auth.login_failed', 'user', 'user', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"mubashirjco@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-09 04:13:53'),
(124, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:13:57'),
(125, 1, 'user.updated', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"role\":\"admin\",\"status\":\"active\"}', '{\"role\":\"admin\",\"status\":\"active\",\"name\":\"Admin\"}', NULL, '2026-10-09 04:14:34'),
(126, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:35:25'),
(127, NULL, 'auth.login_failed', 'user', 'user', NULL, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"bc250416343mha@vu.edu.pk\",\"reason\":\"bad_credentials\"}', '2026-10-09 04:42:22'),
(128, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:42:32'),
(129, 1, 'client.updated', 'client', 'client', 7, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"General\"}', '2026-10-09 04:43:23'),
(130, 1, 'user.created', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Mubashir Hassan\",\"email\":\"mubashirbaltistani@gmail.com\",\"role\":\"employee\",\"status\":\"active\"}', NULL, '2026-10-09 04:46:10'),
(131, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:46:16'),
(132, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:46:36'),
(133, 1, 'department.created', 'department', 'department', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Test\",\"manager_id\":1,\"teams\":1}', '2026-10-09 04:47:57'),
(134, 1, 'department.updated', 'department', 'department', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Building System\",\"manager_id\":13,\"teams\":1}', '2026-10-09 04:49:08'),
(135, 1, 'user.deleted', 'user', 'user', 14, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Muhammad Waqas\",\"email\":\"waqastest@gmail.com\"}', NULL, NULL, '2026-10-09 04:49:23'),
(136, 1, 'user.deleted', 'user', 'user', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Usman Tallat\",\"email\":\"usmantest@gmail.com\"}', NULL, NULL, '2026-10-09 04:49:31'),
(137, 1, 'user.updated', 'user', 'user', 12, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"role\":\"manager\",\"status\":\"active\"}', '{\"role\":\"manager\",\"status\":\"active\",\"name\":\"Hamza Arshad\"}', NULL, '2026-10-09 04:50:40'),
(138, 1, 'user.created', 'user', 'user', 19, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"name\":\"Usman Talat\",\"email\":\"usmantalat@mavenprojects.com\",\"role\":\"manager\",\"status\":\"active\"}', NULL, '2026-10-09 04:51:29'),
(139, 1, 'department.updated', 'department', 'department', 2, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Building System\",\"manager_id\":19,\"teams\":1}', '2026-10-09 04:53:33'),
(140, 1, 'department.updated', 'department', 'department', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Design Services\",\"manager_id\":12,\"teams\":1}', '2026-10-09 04:54:02'),
(141, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:55:28'),
(142, NULL, 'auth.login', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:55:41'),
(143, NULL, 'auth.password_changed', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:56:15'),
(144, NULL, 'auth.logout', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:56:32'),
(145, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:56:59'),
(146, 1, 'project.members_added', 'project', 'project', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"count\":1}', '2026-10-09 04:57:18'),
(147, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:57:29'),
(148, NULL, 'auth.login', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:57:39'),
(149, NULL, 'timer.started', 'timer', 'timer', 5, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":4}', '2026-10-09 04:58:22'),
(150, NULL, 'timer.paused', 'timer', 'timer', 5, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:58:37'),
(151, NULL, 'timer.resumed', 'timer', 'timer', 5, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:59:03'),
(152, NULL, 'auth.logout', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:59:08'),
(153, NULL, 'auth.login_failed', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"mubashirjco@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-09 04:59:20'),
(154, NULL, 'auth.login_failed', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"mubashirjco@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-09 04:59:27'),
(155, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 04:59:39'),
(156, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 05:00:00'),
(157, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 05:03:00'),
(158, 1, 'auth.logout', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 05:03:12'),
(159, NULL, 'auth.login', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 05:03:20'),
(160, NULL, 'timer.stopped', 'time_entry', 'time_entry', 202, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":280}', '2026-10-09 05:03:28'),
(161, NULL, 'timer.started', 'timer', 'timer', 6, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"task_id\":4}', '2026-10-09 05:04:05'),
(162, NULL, 'timer.stopped', 'time_entry', 'time_entry', 203, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"project_id\":4,\"duration_seconds\":9}', '2026-10-09 05:04:14'),
(163, NULL, 'timesheet.entries_submitted', 'timesheet', 'timesheet', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"entry_count\":2,\"total_seconds\":289}', '2026-10-09 05:05:03'),
(164, NULL, 'auth.logout', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 05:05:40'),
(165, NULL, 'auth.login_failed', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"mubashirjco@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-09 05:05:50'),
(166, NULL, 'auth.login_failed', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"mubashirjco@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-09 05:05:53'),
(167, NULL, 'auth.login_failed', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"email\":\"mubashirjco@gmail.com\",\"reason\":\"bad_credentials\"}', '2026-10-09 05:05:59'),
(168, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 05:06:07'),
(169, 1, 'timesheet.approved', 'timesheet', 'timesheet', 13, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"user_id\":18,\"start_date\":\"2026-10-05\",\"total_seconds\":289,\"billable_seconds\":289}', '2026-10-09 05:07:11'),
(170, 1, 'auth.login', 'user', 'user', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, NULL, '2026-10-09 05:19:52');
INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `ip_address`, `user_agent`, `old_value`, `new_value`, `meta`, `created_at`) VALUES
(171, 1, 'department.deleted', 'department', 'department', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Test\",\"task_count\":0}', '2026-10-09 06:09:21'),
(172, 1, 'user.deleted', 'user', 'user', 18, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', '{\"name\":\"Mubashir Hassan\",\"email\":\"mubashirbaltistani@gmail.com\"}', NULL, NULL, '2026-10-09 06:09:46'),
(173, 1, 'department.updated', 'department', 'department', 1, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, NULL, '{\"name\":\"Design Services\",\"manager_id\":12,\"teams\":1}', '2026-10-09 06:52:02'),
(174, 1, 'invitation.created', 'invite', 'invite', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\",\"role\":\"employee\",\"projects\":11,\"tasks\":19}', NULL, '2026-10-09 08:25:43'),
(175, 1, 'invitation.sent', 'invite', 'invite', 4, '103.87.194.250', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36', NULL, '{\"email_domain\":\"gmail.com\"}', NULL, '2026-10-09 08:25:45');

-- --------------------------------------------------------

--
-- Table structure for table `agent_pair_attempts`
--

CREATE TABLE `agent_pair_attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(45) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `email`, `phone`, `address`, `status`, `created_at`, `updated_at`) VALUES
(1, 'AFIC-NIHD', NULL, NULL, 'RWP', 'active', '2026-10-07 15:24:22', '2026-10-07 15:24:22'),
(2, 'Al Shifa Trust', NULL, NULL, 'LHR', 'active', '2026-10-07 15:24:22', '2026-10-07 15:24:22'),
(3, 'Novacare Hospitals', NULL, NULL, 'ISB', 'active', '2026-10-07 15:24:22', '2026-10-07 15:24:22'),
(4, 'Faraz Minai', NULL, NULL, NULL, 'active', '2026-10-07 15:24:22', '2026-10-07 15:24:22'),
(5, 'PAF', NULL, NULL, 'KHR', 'active', '2026-10-07 15:24:22', '2026-10-07 15:24:22'),
(6, 'Pure Properties', NULL, NULL, 'ISB', 'active', '2026-10-07 15:24:22', '2026-10-07 15:24:22'),
(7, 'General', NULL, NULL, NULL, 'active', '2026-10-07 15:24:42', '2026-10-09 04:43:23');

-- --------------------------------------------------------

--
-- Table structure for table `client_users`
--

CREATE TABLE `client_users` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `manager_id` int(10) UNSIGNED DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `project_id`, `name`, `manager_id`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'Design Services', 12, 'active', 1, '2026-10-06 17:08:56', '2026-10-09 06:52:02'),
(2, 1, 'Building System', 19, 'active', 1, '2026-10-06 17:12:29', '2026-10-09 04:53:33');

-- --------------------------------------------------------

--
-- Table structure for table `desktop_agent_devices`
--

CREATE TABLE `desktop_agent_devices` (
  `id` int(10) UNSIGNED NOT NULL,
  `workspace_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `device_id` varchar(120) NOT NULL,
  `device_name` varchar(160) NOT NULL,
  `token_hash` char(64) NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `agent_version` varchar(40) NOT NULL DEFAULT 'unknown',
  `status` enum('active','revoked') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `desktop_agent_pairing_codes`
--

CREATE TABLE `desktop_agent_pairing_codes` (
  `id` int(10) UNSIGNED NOT NULL,
  `workspace_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `code_hash` char(64) NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT 'info',
  `title` varchar(160) NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `type`, `title`, `message`, `link`, `is_read`, `read_at`, `created_at`) VALUES
(1, 12, 'info', 'Welcome to Trax', 'Your account is ready. Change the temporary password from your profile.', '/profile', 0, NULL, '2026-10-07 16:54:27'),
(4, 15, 'info', 'Welcome to Trax', 'Your account is ready. Change the temporary password from your profile.', '/profile', 0, NULL, '2026-10-08 13:36:45'),
(5, 16, 'info', 'Welcome to Trax', 'Your account is ready. Change the temporary password from your profile.', '/profile', 0, NULL, '2026-10-08 15:01:32'),
(6, 17, 'info', 'Welcome to Trax', 'Your account is ready. Change the temporary password from your profile.', '/profile', 0, NULL, '2026-10-08 15:06:07'),
(8, 19, 'info', 'Welcome to Trax', 'Your account is ready. Change the temporary password from your profile.', '/profile', 0, NULL, '2026-10-09 04:51:29'),
(9, 1, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/13', 1, '2026-10-09 08:36:17', '2026-10-09 05:05:04'),
(10, 17, 'info', 'Work submitted for approval', 'Mubashir Hassan submitted selected work for Oct 5 – Oct 11, 2026.', '/timesheets/13', 0, NULL, '2026-10-09 05:05:06');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(60) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `module` varchar(40) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `module`, `description`, `created_at`) VALUES
(1, 'dashboard.view', 'View dashboard', 'dashboard', 'Open the dashboard.', '2026-10-01 08:55:54'),
(2, 'notifications.view', 'View notifications', 'notifications', 'See own notifications.', '2026-10-01 08:55:54'),
(3, 'users.view', 'View users', 'users', 'See the user directory.', '2026-10-01 08:55:54'),
(4, 'users.create', 'Create users', 'users', 'Add new users.', '2026-10-01 08:55:54'),
(5, 'users.edit', 'Edit users', 'users', 'Change user details, roles and status.', '2026-10-01 08:55:54'),
(6, 'users.delete', 'Delete users', 'users', 'Remove users.', '2026-10-01 08:55:54'),
(7, 'roles.manage', 'Manage roles', 'users', 'Edit roles and their permissions.', '2026-10-01 08:55:54'),
(8, 'clients.view', 'View clients', 'clients', 'See the client list.', '2026-10-01 08:55:54'),
(9, 'clients.create', 'Create clients', 'clients', 'Add new clients.', '2026-10-01 08:55:54'),
(10, 'clients.edit', 'Edit clients', 'clients', 'Change client details.', '2026-10-01 08:55:54'),
(11, 'clients.delete', 'Delete clients', 'clients', 'Remove clients.', '2026-10-01 08:55:54'),
(12, 'projects.view', 'View projects', 'projects', 'See projects the user is assigned to.', '2026-10-01 08:55:54'),
(13, 'projects.view_all', 'View all projects', 'projects', 'See every project, assigned or not.', '2026-10-01 08:55:54'),
(14, 'projects.create', 'Create projects', 'projects', 'Add new projects.', '2026-10-01 08:55:54'),
(15, 'projects.edit', 'Edit projects', 'projects', 'Change project details.', '2026-10-01 08:55:54'),
(16, 'projects.delete', 'Delete projects', 'projects', 'Remove projects.', '2026-10-01 08:55:54'),
(17, 'projects.archive', 'Archive projects', 'projects', 'Archive and restore projects.', '2026-10-01 08:55:54'),
(18, 'projects.manage_members', 'Manage project members', 'projects', 'Assign and remove project members.', '2026-10-01 08:55:54'),
(19, 'tasks.view', 'View tasks', 'tasks', 'See tasks on assigned projects.', '2026-10-01 08:55:54'),
(20, 'tasks.create', 'Create tasks', 'tasks', 'Add tasks to projects.', '2026-10-01 08:55:54'),
(21, 'tasks.edit', 'Edit tasks', 'tasks', 'Change tasks.', '2026-10-01 08:55:54'),
(22, 'tasks.delete', 'Delete tasks', 'tasks', 'Remove tasks.', '2026-10-01 08:55:54'),
(23, 'tasks.assign', 'Assign tasks', 'tasks', 'Assign tasks to people.', '2026-10-01 08:55:54'),
(24, 'time.track', 'Track time', 'time', 'Start and stop timers.', '2026-10-01 08:55:54'),
(25, 'time.view_own', 'View own time', 'time', 'See own time entries.', '2026-10-01 08:55:54'),
(26, 'time.view_all', 'View all time', 'time', 'See everyone\'s time entries.', '2026-10-01 08:55:54'),
(27, 'time.edit_own', 'Edit own time', 'time', 'Add and edit own time entries.', '2026-10-01 08:55:54'),
(28, 'time.edit_all', 'Edit all time', 'time', 'Edit anyone\'s time entries.', '2026-10-01 08:55:54'),
(29, 'time.approve', 'Approve timesheets', 'time', 'Approve or reject submitted timesheets.', '2026-10-01 08:55:54'),
(30, 'reports.view', 'View reports', 'reports', 'Open reports.', '2026-10-01 08:55:54'),
(31, 'reports.export', 'Export reports', 'reports', 'Download reports as CSV/PDF.', '2026-10-01 08:55:54'),
(32, 'reports.billing', 'View billing figures', 'reports', 'See rates, budgets and billable amounts.', '2026-10-01 08:55:54'),
(33, 'activity.view', 'View activity log', 'system', 'Read the audit trail.', '2026-10-01 08:55:54'),
(34, 'settings.manage', 'Manage settings', 'system', 'Change system settings.', '2026-10-01 08:55:54'),
(35, 'schedule.view', 'View schedule', 'schedule', 'See planned work on assigned projects.', '2026-10-01 10:28:52'),
(36, 'schedule.create', 'Create schedule', 'schedule', 'Add planned work blocks.', '2026-10-01 10:28:52'),
(37, 'schedule.edit', 'Edit schedule', 'schedule', 'Change planned work blocks.', '2026-10-01 10:28:52'),
(38, 'schedule.delete', 'Delete schedule', 'schedule', 'Remove planned work blocks.', '2026-10-01 10:28:52'),
(39, 'schedule.view_team', 'View team schedule', 'schedule', 'See planned work for the whole team.', '2026-10-01 10:28:52'),
(57, 'workspace.manage', 'Manage workspace', 'workspace', 'Change workspace identity, policies and workspace permissions.', '2026-10-02 08:51:16'),
(59, 'users.avatar_upload', 'Upload profile photos', 'users', 'Allows the user to upload profile photos. Users with this permission can upload their own photo; users with users.edit can upload photos for other users.', '2026-10-08 18:01:57');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `project_code` varchar(50) NOT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('Planning','Active','On Hold','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Planning',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `budget` decimal(14,2) NOT NULL DEFAULT 0.00,
  `hourly_rate` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#03A9F4',
  `estimate_type` enum('none','time','budget') NOT NULL DEFAULT 'none',
  `manager_id` int(10) UNSIGNED DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `client_id`, `project_code`, `name`, `description`, `start_date`, `due_date`, `status`, `priority`, `estimated_hours`, `budget`, `hourly_rate`, `is_billable`, `is_public`, `color`, `estimate_type`, `manager_id`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 7, 'PRJ-001', 'Residential building G+P+6 (Dubai)', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#607D8B', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:46:57'),
(2, 3, 'PRJ-002', 'Novacare Hospital', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#FF9800', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:46:06'),
(3, 1, 'PRJ-003', 'Expansion of AFIC', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#795548', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:44:50'),
(4, 7, 'PRJ-004', 'General', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#E91E63', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:45:28'),
(5, 6, 'PRJ-005', 'Pure One', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#CDDC39', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:46:22'),
(6, 5, 'PRJ-006', 'Rehabilitation Hospital Project', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#4CAF50', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:46:39'),
(7, 5, 'PRJ-007', 'Welfare Hospital Kharian', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#009688', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:47:41'),
(8, 6, 'PRJ-008', 'HIVE', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#F44336', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:45:50'),
(9, 3, 'PRJ-009', 'Support Services Hub Novacare Hospital', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#9E9E9E', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:47:13'),
(10, 3, 'PRJ-010', 'Citadel 7 Novacare Hospital', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#03A9F4', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:44:36'),
(11, 2, 'PRJ-011', 'Al Shifa Trust Eye Hospital', NULL, NULL, NULL, 'Active', 'Medium', 0.00, 0.00, 0.00, 1, 0, '#9C27B0', 'none', NULL, 1, '2026-10-07 15:30:30', '2026-10-08 17:44:19');

-- --------------------------------------------------------

--
-- Table structure for table `project_favorites`
--

CREATE TABLE `project_favorites` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_members`
--

CREATE TABLE `project_members` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `project_role` varchar(60) NOT NULL DEFAULT 'Member',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_members`
--

INSERT INTO `project_members` (`id`, `project_id`, `user_id`, `project_role`, `created_at`) VALUES
(1, 11, 10, 'member', '2026-10-08 13:26:52'),
(2, 11, 12, 'member', '2026-10-08 13:26:52'),
(3, 11, 6, 'member', '2026-10-08 13:26:52'),
(4, 11, 9, 'member', '2026-10-08 13:26:52'),
(5, 11, 5, 'member', '2026-10-08 13:26:52'),
(6, 11, 11, 'member', '2026-10-08 13:26:52'),
(7, 11, 2, 'member', '2026-10-08 13:26:52'),
(9, 11, 1, 'member', '2026-10-08 13:26:52'),
(10, 11, 7, 'member', '2026-10-08 13:26:52'),
(11, 11, 4, 'member', '2026-10-08 13:26:52'),
(12, 11, 3, 'member', '2026-10-08 13:26:52'),
(13, 11, 8, 'member', '2026-10-08 13:26:52'),
(15, 10, 10, 'member', '2026-10-08 13:27:15'),
(16, 10, 12, 'member', '2026-10-08 13:27:15'),
(17, 10, 6, 'member', '2026-10-08 13:27:15'),
(18, 10, 9, 'member', '2026-10-08 13:27:15'),
(19, 10, 5, 'member', '2026-10-08 13:27:15'),
(20, 10, 11, 'member', '2026-10-08 13:27:15'),
(21, 10, 2, 'member', '2026-10-08 13:27:15'),
(23, 10, 1, 'member', '2026-10-08 13:27:15'),
(24, 10, 7, 'member', '2026-10-08 13:27:15'),
(25, 10, 4, 'member', '2026-10-08 13:27:15'),
(26, 10, 3, 'member', '2026-10-08 13:27:15'),
(27, 10, 8, 'member', '2026-10-08 13:27:15'),
(29, 3, 10, 'member', '2026-10-08 13:27:38'),
(30, 3, 12, 'member', '2026-10-08 13:27:38'),
(31, 3, 6, 'member', '2026-10-08 13:27:38'),
(32, 3, 9, 'member', '2026-10-08 13:27:38'),
(33, 3, 5, 'member', '2026-10-08 13:27:38'),
(34, 3, 11, 'member', '2026-10-08 13:27:38'),
(35, 3, 2, 'member', '2026-10-08 13:27:38'),
(37, 3, 1, 'member', '2026-10-08 13:27:38'),
(38, 3, 7, 'member', '2026-10-08 13:27:38'),
(39, 3, 4, 'member', '2026-10-08 13:27:38'),
(40, 3, 3, 'member', '2026-10-08 13:27:38'),
(41, 3, 8, 'member', '2026-10-08 13:27:38'),
(43, 4, 10, 'member', '2026-10-08 13:28:00'),
(44, 4, 12, 'member', '2026-10-08 13:28:00'),
(45, 4, 6, 'member', '2026-10-08 13:28:00'),
(46, 4, 9, 'member', '2026-10-08 13:28:00'),
(47, 4, 5, 'member', '2026-10-08 13:28:00'),
(48, 4, 11, 'member', '2026-10-08 13:28:00'),
(49, 4, 2, 'member', '2026-10-08 13:28:00'),
(51, 4, 1, 'member', '2026-10-08 13:28:00'),
(52, 4, 7, 'member', '2026-10-08 13:28:00'),
(53, 4, 4, 'member', '2026-10-08 13:28:00'),
(54, 4, 3, 'member', '2026-10-08 13:28:00'),
(55, 4, 8, 'member', '2026-10-08 13:28:00'),
(57, 8, 10, 'member', '2026-10-08 13:28:32'),
(58, 8, 12, 'member', '2026-10-08 13:28:32'),
(59, 8, 6, 'member', '2026-10-08 13:28:32'),
(60, 8, 9, 'member', '2026-10-08 13:28:32'),
(61, 8, 5, 'member', '2026-10-08 13:28:32'),
(62, 8, 11, 'member', '2026-10-08 13:28:32'),
(63, 8, 2, 'member', '2026-10-08 13:28:32'),
(65, 8, 1, 'member', '2026-10-08 13:28:32'),
(66, 8, 7, 'member', '2026-10-08 13:28:32'),
(67, 8, 4, 'member', '2026-10-08 13:28:32'),
(68, 8, 3, 'member', '2026-10-08 13:28:32'),
(69, 8, 8, 'member', '2026-10-08 13:28:32'),
(71, 2, 10, 'member', '2026-10-08 13:28:48'),
(72, 2, 12, 'member', '2026-10-08 13:28:48'),
(73, 2, 6, 'member', '2026-10-08 13:28:48'),
(74, 2, 9, 'member', '2026-10-08 13:28:48'),
(75, 2, 5, 'member', '2026-10-08 13:28:48'),
(76, 2, 11, 'member', '2026-10-08 13:28:48'),
(77, 2, 2, 'member', '2026-10-08 13:28:48'),
(79, 2, 1, 'member', '2026-10-08 13:28:48'),
(80, 2, 7, 'member', '2026-10-08 13:28:48'),
(81, 2, 4, 'member', '2026-10-08 13:28:48'),
(82, 2, 3, 'member', '2026-10-08 13:28:48'),
(83, 2, 8, 'member', '2026-10-08 13:28:48'),
(85, 5, 10, 'member', '2026-10-08 13:29:07'),
(86, 5, 12, 'member', '2026-10-08 13:29:08'),
(87, 5, 6, 'member', '2026-10-08 13:29:08'),
(88, 5, 9, 'member', '2026-10-08 13:29:08'),
(89, 5, 5, 'member', '2026-10-08 13:29:08'),
(90, 5, 11, 'member', '2026-10-08 13:29:08'),
(91, 5, 2, 'member', '2026-10-08 13:29:08'),
(93, 5, 1, 'member', '2026-10-08 13:29:08'),
(94, 5, 7, 'member', '2026-10-08 13:29:08'),
(95, 5, 4, 'member', '2026-10-08 13:29:08'),
(96, 5, 3, 'member', '2026-10-08 13:29:08'),
(97, 5, 8, 'member', '2026-10-08 13:29:08'),
(99, 6, 10, 'member', '2026-10-08 13:29:31'),
(100, 6, 12, 'member', '2026-10-08 13:29:31'),
(101, 6, 6, 'member', '2026-10-08 13:29:31'),
(102, 6, 9, 'member', '2026-10-08 13:29:31'),
(103, 6, 5, 'member', '2026-10-08 13:29:31'),
(104, 6, 11, 'member', '2026-10-08 13:29:31'),
(105, 6, 2, 'member', '2026-10-08 13:29:31'),
(107, 6, 1, 'member', '2026-10-08 13:29:31'),
(108, 6, 7, 'member', '2026-10-08 13:29:31'),
(109, 6, 4, 'member', '2026-10-08 13:29:31'),
(110, 6, 3, 'member', '2026-10-08 13:29:31'),
(111, 6, 8, 'member', '2026-10-08 13:29:31'),
(113, 1, 10, 'member', '2026-10-08 13:29:49'),
(114, 1, 12, 'member', '2026-10-08 13:29:49'),
(115, 1, 6, 'member', '2026-10-08 13:29:49'),
(116, 1, 9, 'member', '2026-10-08 13:29:49'),
(117, 1, 5, 'member', '2026-10-08 13:29:49'),
(118, 1, 11, 'member', '2026-10-08 13:29:49'),
(119, 1, 2, 'member', '2026-10-08 13:29:49'),
(121, 1, 1, 'member', '2026-10-08 13:29:49'),
(122, 1, 7, 'member', '2026-10-08 13:29:49'),
(123, 1, 4, 'member', '2026-10-08 13:29:49'),
(124, 1, 3, 'member', '2026-10-08 13:29:49'),
(125, 1, 8, 'member', '2026-10-08 13:29:49'),
(127, 9, 10, 'member', '2026-10-08 13:30:17'),
(128, 9, 12, 'member', '2026-10-08 13:30:17'),
(129, 9, 6, 'member', '2026-10-08 13:30:17'),
(130, 9, 9, 'member', '2026-10-08 13:30:17'),
(131, 9, 5, 'member', '2026-10-08 13:30:17'),
(132, 9, 11, 'member', '2026-10-08 13:30:17'),
(133, 9, 2, 'member', '2026-10-08 13:30:17'),
(135, 9, 1, 'member', '2026-10-08 13:30:17'),
(136, 9, 7, 'member', '2026-10-08 13:30:17'),
(137, 9, 4, 'member', '2026-10-08 13:30:17'),
(138, 9, 3, 'member', '2026-10-08 13:30:17'),
(139, 9, 8, 'member', '2026-10-08 13:30:17'),
(141, 7, 10, 'member', '2026-10-08 13:30:40'),
(142, 7, 12, 'member', '2026-10-08 13:30:40'),
(143, 7, 6, 'member', '2026-10-08 13:30:40'),
(144, 7, 9, 'member', '2026-10-08 13:30:40'),
(145, 7, 5, 'member', '2026-10-08 13:30:40'),
(146, 7, 11, 'member', '2026-10-08 13:30:40'),
(147, 7, 2, 'member', '2026-10-08 13:30:40'),
(149, 7, 1, 'member', '2026-10-08 13:30:40'),
(150, 7, 7, 'member', '2026-10-08 13:30:40'),
(151, 7, 4, 'member', '2026-10-08 13:30:40'),
(152, 7, 3, 'member', '2026-10-08 13:30:40'),
(153, 7, 8, 'member', '2026-10-08 13:30:40'),
(155, 11, 15, 'member', '2026-10-08 13:37:04'),
(156, 10, 15, 'member', '2026-10-08 13:37:13'),
(157, 3, 15, 'member', '2026-10-08 13:37:20'),
(158, 4, 15, 'member', '2026-10-08 13:37:30'),
(159, 8, 15, 'member', '2026-10-08 13:37:39'),
(160, 2, 15, 'member', '2026-10-08 13:37:47'),
(161, 5, 15, 'member', '2026-10-08 13:37:56'),
(162, 6, 15, 'member', '2026-10-08 13:38:06'),
(163, 1, 15, 'member', '2026-10-08 13:38:22'),
(164, 7, 15, 'member', '2026-10-08 13:38:31'),
(165, 11, 16, 'member', '2026-10-08 15:05:16');

-- --------------------------------------------------------

--
-- Table structure for table `report_access`
--

CREATE TABLE `report_access` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `access_level` enum('own','all') NOT NULL DEFAULT 'own',
  `can_export` tinyint(1) NOT NULL DEFAULT 0,
  `can_billing` tinyint(1) NOT NULL DEFAULT 0,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `report_access`
--

INSERT INTO `report_access` (`user_id`, `access_level`, `can_export`, `can_billing`, `updated_by`, `updated_at`) VALUES
(2, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(3, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(4, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(5, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(6, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(7, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(8, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(9, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(10, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(11, 'own', 0, 0, 1, '2026-10-07 17:48:43'),
(12, 'own', 0, 0, 1, '2026-10-07 17:48:43');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(30) NOT NULL,
  `display_name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Administrator', 'Full access to every module and setting.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(2, 'manager', 'Manager', 'Manages clients, projects, teams and approvals.', '2026-10-01 08:55:54', '2026-10-01 08:55:54'),
(3, 'employee', 'Member', 'Tracks time on the projects they are assigned to.', '2026-10-01 08:55:54', '2026-10-07 11:28:12'),
(4, 'client', 'Client', 'Read-only view of their own projects and reports.', '2026-10-01 08:55:54', '2026-10-01 08:55:54');

-- --------------------------------------------------------

--
-- Table structure for table `role_permissions`
--

CREATE TABLE `role_permissions` (
  `role_id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_permissions`
--

INSERT INTO `role_permissions` (`role_id`, `permission_id`, `created_at`) VALUES
(1, 1, '2026-10-01 08:55:54'),
(1, 2, '2026-10-01 08:55:54'),
(1, 3, '2026-10-01 08:55:54'),
(1, 4, '2026-10-01 08:55:54'),
(1, 5, '2026-10-01 08:55:54'),
(1, 6, '2026-10-01 08:55:54'),
(1, 7, '2026-10-01 08:55:54'),
(1, 8, '2026-10-01 08:55:54'),
(1, 9, '2026-10-01 08:55:54'),
(1, 10, '2026-10-01 08:55:54'),
(1, 11, '2026-10-01 08:55:54'),
(1, 12, '2026-10-01 08:55:54'),
(1, 13, '2026-10-01 08:55:54'),
(1, 14, '2026-10-01 08:55:54'),
(1, 15, '2026-10-01 08:55:54'),
(1, 16, '2026-10-01 08:55:54'),
(1, 17, '2026-10-01 08:55:54'),
(1, 18, '2026-10-01 08:55:54'),
(1, 19, '2026-10-01 08:55:54'),
(1, 20, '2026-10-01 08:55:54'),
(1, 21, '2026-10-01 08:55:54'),
(1, 22, '2026-10-01 08:55:54'),
(1, 23, '2026-10-01 08:55:54'),
(1, 24, '2026-10-01 08:55:54'),
(1, 25, '2026-10-01 08:55:54'),
(1, 26, '2026-10-01 08:55:54'),
(1, 27, '2026-10-01 08:55:54'),
(1, 28, '2026-10-01 08:55:54'),
(1, 29, '2026-10-01 08:55:54'),
(1, 30, '2026-10-01 08:55:54'),
(1, 31, '2026-10-01 08:55:54'),
(1, 32, '2026-10-01 08:55:54'),
(1, 33, '2026-10-01 08:55:54'),
(1, 34, '2026-10-01 08:55:54'),
(1, 35, '2026-10-01 10:28:52'),
(1, 36, '2026-10-01 10:28:52'),
(1, 37, '2026-10-01 10:28:52'),
(1, 38, '2026-10-01 10:28:52'),
(1, 39, '2026-10-01 10:28:52'),
(1, 57, '2026-10-02 08:51:16'),
(1, 59, '2026-10-08 18:01:57'),
(2, 1, '2026-10-01 08:55:54'),
(2, 2, '2026-10-01 08:55:54'),
(2, 3, '2026-10-01 08:55:54'),
(2, 8, '2026-10-01 08:55:54'),
(2, 9, '2026-10-01 08:55:54'),
(2, 10, '2026-10-01 08:55:54'),
(2, 12, '2026-10-01 08:55:54'),
(2, 14, '2026-10-01 08:55:54'),
(2, 15, '2026-10-01 08:55:54'),
(2, 17, '2026-10-01 08:55:54'),
(2, 18, '2026-10-01 08:55:54'),
(2, 19, '2026-10-01 08:55:54'),
(2, 20, '2026-10-01 08:55:54'),
(2, 21, '2026-10-01 08:55:54'),
(2, 22, '2026-10-01 08:55:54'),
(2, 23, '2026-10-01 08:55:54'),
(2, 24, '2026-10-01 08:55:54'),
(2, 25, '2026-10-01 08:55:54'),
(2, 26, '2026-10-01 08:55:54'),
(2, 27, '2026-10-01 08:55:54'),
(2, 29, '2026-10-01 08:55:54'),
(2, 30, '2026-10-01 08:55:54'),
(2, 31, '2026-10-01 08:55:54'),
(2, 32, '2026-10-01 08:55:54'),
(2, 33, '2026-10-01 08:55:54'),
(2, 35, '2026-10-01 10:28:52'),
(2, 36, '2026-10-01 10:28:52'),
(2, 37, '2026-10-01 10:28:52'),
(2, 38, '2026-10-01 10:28:52'),
(2, 39, '2026-10-01 10:28:52'),
(3, 1, '2026-10-01 08:55:54'),
(3, 2, '2026-10-01 08:55:54'),
(3, 12, '2026-10-01 08:55:54'),
(3, 19, '2026-10-01 08:55:54'),
(3, 21, '2026-10-01 08:55:54'),
(3, 24, '2026-10-01 08:55:54'),
(3, 25, '2026-10-01 08:55:54'),
(3, 27, '2026-10-01 08:55:54'),
(3, 30, '2026-10-01 08:55:54'),
(3, 35, '2026-10-01 10:28:52'),
(3, 36, '2026-10-01 10:28:52'),
(3, 37, '2026-10-01 10:28:52'),
(4, 1, '2026-10-01 08:55:54'),
(4, 2, '2026-10-01 08:55:54'),
(4, 12, '2026-10-01 08:55:54'),
(4, 30, '2026-10-01 08:55:54');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `recurrence_parent_id` int(10) UNSIGNED DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `estimated_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `status` enum('Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
  `notes` text DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `schedule_recurrences`
--

CREATE TABLE `schedule_recurrences` (
  `id` int(10) UNSIGNED NOT NULL,
  `schedule_id` int(10) UNSIGNED NOT NULL,
  `recurrence_type` enum('daily','weekly','weekdays','custom') NOT NULL DEFAULT 'weekly',
  `repeat_until` date DEFAULT NULL,
  `days_of_week` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','int','bool','json') NOT NULL DEFAULT 'string',
  `setting_group` varchar(40) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `setting_key`, `setting_value`, `setting_type`, `setting_group`, `description`, `updated_at`) VALUES
(1, 'app_name', 'Trax', 'string', 'general', 'Name shown in the header and emails.', '2026-10-08 18:19:41'),
(2, 'company_name', 'Maven Projects LLP', 'string', 'general', 'Legal or trading name used on reports.', '2026-10-06 16:11:57'),
(3, 'company_email', 'admin@akhoonzadaholdings.com', 'string', 'general', 'Contact address for system emails.', '2026-10-08 18:19:41'),
(4, 'default_timezone', 'UTC', 'string', 'general', 'Timezone used when a user has not chosen one.', '2026-10-08 18:19:41'),
(5, 'date_format', 'M j, Y', 'string', 'general', 'PHP date() format for dates.', '2026-10-08 18:19:41'),
(6, 'time_format', 'H:i', 'string', 'general', 'PHP date() format for times.', '2026-10-08 18:19:41'),
(7, 'week_start_day', '1', 'int', 'general', 'First day of the week: 0 = Sunday, 1 = Monday.', '2026-10-06 16:11:57'),
(8, 'currency', 'USD', 'string', 'billing', 'ISO currency code for rates and budgets.', '2026-10-08 18:19:41'),
(9, 'default_hourly_rate', '0', 'string', 'billing', 'Rate applied to billable projects without their own rate.', '2026-10-08 18:19:41'),
(10, 'time_rounding_minutes', '0', 'int', 'time', 'Round tracked time up to this many minutes (0 = off).', '2026-10-06 16:11:57'),
(11, 'allow_manual_time_entries', '1', 'bool', 'time', 'Let employees add time entries by hand.', '2026-10-08 18:19:41'),
(12, 'timesheet_approval', '0', 'bool', 'time', 'Require manager approval before time is billable.', '2026-10-06 16:11:57'),
(13, 'timer_max_hours', '12', 'int', 'time', 'Stop a running timer automatically after this many hours.', '2026-10-08 18:19:41'),
(14, 'notifications_enabled', '1', 'bool', 'system', 'Create in-app notifications.', '2026-10-08 18:19:41'),
(15, 'maintenance_mode', '0', 'bool', 'system', 'Block non-admin sign-ins while maintenance is under way.', '2026-10-08 18:19:41'),
(16, 'currency_symbol', '-', 'string', 'billing', 'Symbol shown next to money amounts.', '2026-10-08 18:19:41'),
(17, 'working_hours_per_day', '9', 'string', 'general', 'Standard billable hours in one working day.', '2026-10-06 16:11:57'),
(18, 'smtp_enabled', '1', 'bool', 'mail', 'Send mail through SMTP', '2026-10-06 17:28:46'),
(19, 'smtp_host', 'smtp.hostinger.com', 'string', 'mail', 'SMTP host', '2026-10-06 17:28:46'),
(20, 'smtp_port', '465', 'int', 'mail', 'SMTP port', '2026-10-06 17:28:46'),
(21, 'smtp_username', 'admin@akhoonzadaholdings.com', 'string', 'mail', 'SMTP username', '2026-10-06 17:28:46'),
(22, 'smtp_password', 'v1:g1OG7NeZQCY44QXR1gkikz01JZkFpW8/WpGabbva8b60ds+hOuL8ww==', 'string', 'mail', 'SMTP password (encrypted by the app)', '2026-10-06 17:28:46'),
(23, 'smtp_encryption', 'ssl', 'string', 'mail', 'SMTP encryption: tls, ssl or none', '2026-10-06 17:28:46'),
(24, 'smtp_from_name', 'Maven Test', 'string', 'mail', 'From name', '2026-10-06 17:28:46'),
(25, 'smtp_from_email', 'admin@akhoonzadaholdings.com', 'string', 'mail', 'From email', '2026-10-06 17:28:46'),
(26, 'smtp_reply_to', '', 'string', 'mail', 'Reply-To email', '2026-10-06 17:28:46'),
(27, 'invite_expiry_days', '7', 'int', 'mail', 'Invitation link lifetime in days', '2026-10-06 17:28:46'),
(28, 'brand_color', '', 'string', 'general', NULL, '2026-10-06 17:13:23'),
(29, 'brand_logo', 'logo-af4f9f400f77c3fb.png', 'string', 'general', NULL, '2026-10-06 17:13:23'),
(30, 'brand_favicon', '', 'string', 'general', NULL, '2026-10-06 17:13:23'),
(31, 'login_headline', 'See where every hour goes.', 'string', 'general', NULL, '2026-10-06 17:13:23'),
(32, 'login_subtext', 'Track time against projects, keep budgets honest, and hand clients numbers they can trust.', 'string', 'general', NULL, '2026-10-06 17:13:23'),
(72, 'timer_reminder_minutes', '10', 'int', 'time', NULL, '2026-10-08 18:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `team_id` int(10) UNSIGNED DEFAULT NULL,
  `parent_task_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('To Do','In Progress','On Hold','Review','Completed','Cancelled') NOT NULL DEFAULT 'To Do',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `completion_percent` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `review_note` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `project_id`, `team_id`, `parent_task_id`, `name`, `description`, `status`, `priority`, `estimated_hours`, `completion_percent`, `start_date`, `due_date`, `is_billable`, `created_by`, `reviewed_by`, `reviewed_at`, `review_note`, `created_at`, `updated_at`) VALUES
(1, 1, NULL, NULL, 'Shop Drawings - Drainage', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(2, 2, NULL, NULL, 'DD - Interior Design', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(3, 3, NULL, NULL, 'DD - MEP Systems', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(4, 4, NULL, NULL, 'Building Services', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(5, 3, NULL, NULL, 'Detailed Design', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(6, 1, NULL, NULL, 'PreCon Building Services - Shop Drawings', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(7, 5, NULL, NULL, 'Building Systems (Electrical)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(8, 3, NULL, NULL, 'PreCon - Building Services (MEP)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(9, 6, NULL, NULL, 'Concept Design', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(10, 7, NULL, NULL, 'Services Yard Concept Plan', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(11, 8, NULL, NULL, 'Working Drawings', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(12, 2, NULL, NULL, 'CON - Interior Fit-out', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(13, 5, NULL, NULL, 'Building Systems (Coordination)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(14, 9, NULL, NULL, 'DD - MEP Systems', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(15, 3, NULL, NULL, 'CON - Building Services (MEP)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(16, 2, NULL, NULL, 'CON - Building Services (MEP)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(17, 9, NULL, NULL, 'CON - Building Services (MEP)', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(18, 9, NULL, NULL, 'Detailed Design', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20'),
(19, 10, NULL, NULL, 'Concept Design', NULL, 'To Do', 'Medium', 0.00, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2026-10-07 15:38:20', '2026-10-07 15:38:20');

-- --------------------------------------------------------

--
-- Table structure for table `task_assignees`
--

CREATE TABLE `task_assignees` (
  `id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED DEFAULT NULL,
  `department_id` int(10) UNSIGNED DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `manager_id` int(10) UNSIGNED DEFAULT NULL,
  `lead_id` int(10) UNSIGNED DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `project_id`, `department_id`, `name`, `manager_id`, `lead_id`, `status`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Architect', 11, NULL, 'active', 1, '2026-10-06 17:08:56', '2026-10-09 06:52:02'),
(2, 1, 2, 'Design MEP', 15, NULL, 'active', 1, '2026-10-06 17:12:29', '2026-10-09 04:53:33');

-- --------------------------------------------------------

--
-- Table structure for table `team_managers`
--

CREATE TABLE `team_managers` (
  `team_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_managers`
--

INSERT INTO `team_managers` (`team_id`, `user_id`, `created_at`) VALUES
(1, 11, '2026-10-09 06:52:02'),
(2, 15, '2026-10-09 04:53:33');

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE `team_members` (
  `team_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`team_id`, `user_id`, `created_at`) VALUES
(1, 3, '2026-10-09 06:52:02'),
(1, 5, '2026-10-09 06:52:02'),
(1, 6, '2026-10-09 06:52:02'),
(1, 7, '2026-10-09 06:52:02'),
(1, 10, '2026-10-09 06:52:02'),
(1, 12, '2026-10-09 06:52:02'),
(2, 2, '2026-10-09 04:53:33'),
(2, 4, '2026-10-09 04:53:33'),
(2, 8, '2026-10-09 04:53:33'),
(2, 9, '2026-10-09 04:53:33'),
(2, 19, '2026-10-09 04:53:33');

-- --------------------------------------------------------

--
-- Table structure for table `timer_idle_events`
--

CREATE TABLE `timer_idle_events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `timer_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `warning_at` datetime NOT NULL,
  `response` enum('continued','manual_pause','auto_paused') DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timesheets`
--

CREATE TABLE `timesheets` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `submission_token` varchar(64) DEFAULT NULL,
  `total_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `billable_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` enum('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
  `submitted_at` datetime DEFAULT NULL,
  `approved_by` int(10) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `rejection_reason` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timesheets`
--

INSERT INTO `timesheets` (`id`, `user_id`, `start_date`, `end_date`, `submission_token`, `total_seconds`, `billable_seconds`, `status`, `submitted_at`, `approved_by`, `approved_at`, `rejection_reason`, `created_at`, `updated_at`) VALUES
(1, 9, '2026-10-05', '2026-10-11', '46d88da654296bbd7c96e2379da8a5c1', 92108, 92108, 'Approved', '2026-10-07 13:49:41', 15, '2026-10-08 03:55:11', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(2, 4, '2026-10-05', '2026-10-11', '42e2bd9bdc166f90ebde1e98764446e9', 88808, 88808, 'Approved', '2026-10-07 13:45:19', 15, '2026-10-08 03:54:58', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(3, 2, '2026-10-05', '2026-10-11', '541f980b2f1aabbdd9a23be6fe06d1c9', 30389, 30389, 'Approved', '2026-10-08 03:56:12', 15, '2026-10-08 04:27:05', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(4, 8, '2026-10-05', '2026-10-11', '307a1305c73138bca6a04108b5036bda', 65100, 65100, 'Approved', '2026-10-08 04:10:05', 15, '2026-10-08 04:26:58', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(5, 2, '2026-09-28', '2026-10-04', 'dd1da362aa744692ece0154906ec6083', 147288, 147288, 'Approved', '2026-10-02 14:17:40', 17, '2026-10-05 06:32:30', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(6, 4, '2026-09-28', '2026-10-04', '3ecb42c1533c9805c697595c265802fb', 116383, 116383, 'Approved', '2026-10-02 13:32:28', 15, '2026-10-02 13:39:19', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(7, 8, '2026-09-28', '2026-10-04', 'a5e41193a8cf3df0ec8dffb253be97ab', 113037, 113037, 'Approved', '2026-10-05 07:14:09', 15, '2026-10-06 03:57:27', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(8, 9, '2026-09-28', '2026-10-04', 'd14bd162bb1523ee3ec6536f1b9a648c', 151083, 151083, 'Approved', '2026-10-02 14:17:19', 17, '2026-10-05 06:32:30', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(9, 9, '2026-09-21', '2026-09-27', 'f25495bc500967ba35506a9aadd4521b', 59459, 59459, 'Approved', '2026-09-25 14:01:50', 15, '2026-09-28 13:19:32', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(10, 8, '2026-09-21', '2026-09-27', 'cf084abc625a90272b2c095fb1b14062', 67500, 67500, 'Approved', '2026-09-29 10:50:32', 15, '2026-09-29 11:06:24', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(11, 2, '2026-09-21', '2026-09-27', '8a2875a12a4c7b6a81435a23def5fbae', 29700, 29700, 'Approved', '2026-09-28 14:58:10', 15, '2026-09-29 11:06:42', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26'),
(12, 16, '2026-09-21', '2026-09-27', '6130ea569011ee6727b5d38ed40c5449', 10800, 10800, 'Approved', '2026-09-24 15:18:30', 17, '2026-09-24 15:19:24', NULL, '2026-10-08 15:06:26', '2026-10-08 15:06:26');

-- --------------------------------------------------------

--
-- Table structure for table `timesheet_entries`
--

CREATE TABLE `timesheet_entries` (
  `timesheet_id` int(10) UNSIGNED NOT NULL,
  `time_entry_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timesheet_entries`
--

INSERT INTO `timesheet_entries` (`timesheet_id`, `time_entry_id`, `created_at`) VALUES
(1, 27, '2026-10-08 15:06:26'),
(1, 42, '2026-10-08 15:06:26'),
(1, 49, '2026-10-08 15:06:26'),
(1, 63, '2026-10-08 15:06:26'),
(1, 66, '2026-10-08 15:06:26'),
(1, 82, '2026-10-08 15:06:26'),
(2, 28, '2026-10-08 15:06:26'),
(2, 33, '2026-10-08 15:06:26'),
(2, 35, '2026-10-08 15:06:26'),
(2, 44, '2026-10-08 15:06:26'),
(2, 48, '2026-10-08 15:06:26'),
(2, 59, '2026-10-08 15:06:26'),
(2, 71, '2026-10-08 15:06:26'),
(2, 79, '2026-10-08 15:06:26'),
(3, 29, '2026-10-08 15:06:26'),
(3, 38, '2026-10-08 15:06:26'),
(4, 32, '2026-10-08 15:06:26'),
(4, 40, '2026-10-08 15:06:26'),
(4, 52, '2026-10-08 15:06:26'),
(4, 64, '2026-10-08 15:06:26'),
(4, 69, '2026-10-08 15:06:26'),
(4, 77, '2026-10-08 15:06:26'),
(5, 86, '2026-10-08 15:06:26'),
(5, 87, '2026-10-08 15:06:26'),
(5, 92, '2026-10-08 15:06:26'),
(5, 102, '2026-10-08 15:06:26'),
(5, 112, '2026-10-08 15:06:26'),
(5, 115, '2026-10-08 15:06:26'),
(5, 121, '2026-10-08 15:06:26'),
(5, 124, '2026-10-08 15:06:26'),
(5, 126, '2026-10-08 15:06:26'),
(5, 130, '2026-10-08 15:06:26'),
(5, 134, '2026-10-08 15:06:26'),
(5, 137, '2026-10-08 15:06:26'),
(5, 139, '2026-10-08 15:06:26'),
(5, 140, '2026-10-08 15:06:26'),
(5, 151, '2026-10-08 15:06:26'),
(5, 157, '2026-10-08 15:06:26'),
(5, 161, '2026-10-08 15:06:26'),
(5, 167, '2026-10-08 15:06:26'),
(6, 91, '2026-10-08 15:06:26'),
(6, 105, '2026-10-08 15:06:26'),
(6, 111, '2026-10-08 15:06:26'),
(6, 122, '2026-10-08 15:06:26'),
(6, 128, '2026-10-08 15:06:26'),
(6, 136, '2026-10-08 15:06:26'),
(6, 144, '2026-10-08 15:06:26'),
(6, 146, '2026-10-08 15:06:26'),
(6, 149, '2026-10-08 15:06:26'),
(6, 150, '2026-10-08 15:06:26'),
(6, 159, '2026-10-08 15:06:26'),
(6, 166, '2026-10-08 15:06:26'),
(7, 96, '2026-10-08 15:06:26'),
(7, 113, '2026-10-08 15:06:26'),
(7, 118, '2026-10-08 15:06:26'),
(7, 123, '2026-10-08 15:06:26'),
(7, 129, '2026-10-08 15:06:26'),
(7, 138, '2026-10-08 15:06:26'),
(7, 143, '2026-10-08 15:06:26'),
(7, 145, '2026-10-08 15:06:26'),
(7, 147, '2026-10-08 15:06:26'),
(7, 152, '2026-10-08 15:06:26'),
(7, 153, '2026-10-08 15:06:26'),
(7, 154, '2026-10-08 15:06:26'),
(7, 155, '2026-10-08 15:06:26'),
(7, 158, '2026-10-08 15:06:26'),
(7, 160, '2026-10-08 15:06:26'),
(7, 162, '2026-10-08 15:06:26'),
(7, 164, '2026-10-08 15:06:26'),
(8, 104, '2026-10-08 15:06:26'),
(8, 109, '2026-10-08 15:06:26'),
(8, 110, '2026-10-08 15:06:26'),
(8, 120, '2026-10-08 15:06:26'),
(8, 131, '2026-10-08 15:06:26'),
(8, 133, '2026-10-08 15:06:26'),
(8, 135, '2026-10-08 15:06:26'),
(8, 141, '2026-10-08 15:06:26'),
(8, 142, '2026-10-08 15:06:26'),
(8, 148, '2026-10-08 15:06:26'),
(8, 156, '2026-10-08 15:06:26'),
(8, 163, '2026-10-08 15:06:26'),
(8, 165, '2026-10-08 15:06:26'),
(9, 170, '2026-10-08 15:06:26'),
(9, 172, '2026-10-08 15:06:26'),
(9, 174, '2026-10-08 15:06:26'),
(9, 182, '2026-10-08 15:06:26'),
(9, 190, '2026-10-08 15:06:26'),
(9, 196, '2026-10-08 15:06:26'),
(10, 171, '2026-10-08 15:06:26'),
(10, 173, '2026-10-08 15:06:26'),
(10, 176, '2026-10-08 15:06:26'),
(10, 178, '2026-10-08 15:06:26'),
(10, 179, '2026-10-08 15:06:26'),
(10, 183, '2026-10-08 15:06:26'),
(10, 184, '2026-10-08 15:06:26'),
(10, 185, '2026-10-08 15:06:26'),
(10, 186, '2026-10-08 15:06:26'),
(10, 187, '2026-10-08 15:06:26'),
(10, 191, '2026-10-08 15:06:26'),
(10, 192, '2026-10-08 15:06:26'),
(10, 193, '2026-10-08 15:06:26'),
(10, 197, '2026-10-08 15:06:26'),
(11, 175, '2026-10-08 15:06:26'),
(11, 180, '2026-10-08 15:06:26'),
(12, 194, '2026-10-08 15:06:26');

-- --------------------------------------------------------

--
-- Table structure for table `time_entries`
--

CREATE TABLE `time_entries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `started_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `duration_seconds` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `auto_stopped` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `billable_rate` decimal(10,2) NOT NULL DEFAULT 0.00
) ;

--
-- Dumping data for table `time_entries`
--

INSERT INTO `time_entries` (`id`, `project_id`, `task_id`, `user_id`, `started_at`, `ended_at`, `duration_seconds`, `is_billable`, `auto_stopped`, `description`, `created_at`, `updated_at`, `billable_rate`) VALUES
(1, 3, 8, 8, '2026-10-08 12:40:00', '2026-10-08 14:40:00', 7200, 1, 0, 'AFIC HVAC Drawings Optimization', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(2, 5, NULL, 8, '2026-10-08 12:00:00', '2026-10-08 12:40:00', 2400, 1, 0, 'Firefighting Estimation Compiled', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(3, 10, NULL, 4, '2026-10-08 09:28:33', '2026-10-08 14:16:52', 17299, 1, 0, 'MECHANICAL (FIRE FIGHTING)', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(4, 2, NULL, 6, '2026-10-08 09:02:42', '2026-10-08 09:31:43', 1741, 1, 0, NULL, '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(5, 3, 3, 9, '2026-10-08 09:00:00', '2026-10-08 14:40:00', 20400, 1, 0, 'Voice & Data AFIC', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(6, 3, 8, 8, '2026-10-08 09:00:00', '2026-10-08 12:00:00', 10800, 1, 0, 'AFIC HVAC VRF Equipment Schedule', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(7, 3, 3, 2, '2026-10-08 08:51:43', '2026-10-08 10:42:19', 6636, 1, 0, 'Lightning Protection and earthing system', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(8, 11, NULL, 5, '2026-10-08 05:59:52', '2026-10-08 08:00:00', 7208, 1, 0, NULL, '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(9, 3, 15, 8, '2026-10-08 05:45:00', '2026-10-08 08:15:00', 9000, 1, 0, 'AFIC HVAC Room Data Sheet', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(10, 3, 3, 2, '2026-10-08 05:00:17', '2026-10-08 08:02:26', 10929, 1, 0, 'Lightning Protection and earthing system', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(11, 3, 3, 4, '2026-10-08 04:45:41', '2026-10-08 08:02:10', 11789, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(12, 3, 3, 9, '2026-10-08 04:23:30', '2026-10-08 08:00:00', 12990, 1, 0, 'Voice & Data AFIC', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(13, 4, 4, 8, '2026-10-08 04:15:00', '2026-10-08 05:45:00', 5400, 1, 0, 'Intradepartmental discussion', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(14, 10, NULL, 4, '2026-10-08 04:11:01', '2026-10-08 04:45:27', 2066, 1, 0, 'MECHANICAL (FIRE FIGHTING)', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(15, 7, NULL, 7, '2026-10-08 04:11:00', '2026-10-08 14:06:11', 35711, 1, 0, 'Working Accommodation Building Plans', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(16, 10, NULL, 4, '2026-10-08 04:10:36', '2026-10-08 04:10:59', 23, 1, 0, 'MECHANICAL (FIRE FIGHTING)', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(17, 3, 5, 6, '2026-10-08 04:10:17', '2026-10-08 08:22:51', 15154, 1, 0, NULL, '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(18, 2, 2, 5, '2026-10-08 04:10:04', '2026-10-08 05:59:05', 6541, 1, 0, NULL, '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(19, 3, 3, 2, '2026-10-08 04:07:43', '2026-10-08 04:59:11', 3088, 1, 0, 'Voice and Data', '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(20, 10, 19, 9, '2026-10-08 04:07:42', '2026-10-08 04:23:07', 925, 1, 0, NULL, '2026-10-07 19:00:00', '2026-10-08 15:06:25', 0.00),
(21, 3, 3, 4, '2026-10-08 04:06:15', '2026-10-08 04:08:20', 125, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-07 19:00:00', '2026-10-08 15:06:26', 0.00),
(22, 4, 4, 8, '2026-10-08 03:15:00', '2026-10-08 04:15:00', 3600, 1, 0, 'Tasks discussion and assignment', '2026-10-07 19:00:00', '2026-10-08 15:06:26', 0.00),
(23, 2, 2, 5, '2026-10-07 12:04:20', '2026-10-07 13:00:00', 3340, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(24, 4, 4, 8, '2026-10-07 12:00:00', '2026-10-07 12:20:00', 1200, 1, 0, 'Closing', '2026-10-07 19:00:00', '2026-10-08 15:06:26', 0.00),
(25, 11, NULL, 5, '2026-10-07 11:02:57', '2026-10-07 12:02:22', 3565, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(26, 4, 4, 8, '2026-10-07 10:30:00', '2026-10-07 12:00:00', 5400, 1, 0, 'Jr. MEP Engineer Interviews', '2026-10-07 19:00:00', '2026-10-08 15:06:26', 0.00),
(27, 3, 3, 9, '2026-10-07 09:07:36', '2026-10-07 13:49:28', 16912, 1, 0, 'Voice & Data AFIC', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(28, 11, NULL, 4, '2026-10-07 09:06:18', '2026-10-07 13:45:10', 16732, 1, 0, 'TYPICAL DETAIL', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(29, 3, 3, 2, '2026-10-07 09:05:32', '2026-10-07 13:48:31', 16979, 1, 0, 'Lightning Protection and earthing system', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(30, 2, NULL, 5, '2026-10-07 09:01:04', '2026-10-07 11:02:45', 7301, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(31, 3, 5, 6, '2026-10-07 09:00:22', '2026-10-07 12:59:07', 14325, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(32, 3, 15, 8, '2026-10-07 09:00:00', '2026-10-07 10:30:00', 5400, 1, 0, 'AFIC HVAC Room Data Sheet', '2026-10-07 19:00:00', '2026-10-08 15:06:26', 0.00),
(33, 3, 3, 4, '2026-10-07 06:40:19', '2026-10-07 08:02:53', 4954, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(34, 3, 5, 6, '2026-10-07 05:27:11', '2026-10-07 07:55:59', 8928, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(35, 11, NULL, 4, '2026-10-07 05:00:00', '2026-10-07 06:35:00', 5700, 1, 0, 'TYPICAL DETAIL', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(36, 9, 18, 6, '2026-10-07 04:48:54', '2026-10-07 05:26:39', 2265, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(37, 8, 11, 3, '2026-10-07 04:30:00', '2026-10-07 08:00:00', 12600, 1, 0, 'FLOORING', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(38, 3, 3, 2, '2026-10-07 04:20:30', '2026-10-07 08:04:00', 13410, 1, 0, 'Lightning Protection and earthing system', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(39, 7, NULL, 7, '2026-10-07 04:16:25', '2026-10-07 13:01:07', 31482, 1, 0, 'WorkingAccommodation Building Plans', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(40, 3, 15, 8, '2026-10-07 04:15:00', '2026-10-07 08:15:00', 14400, 1, 0, 'AFIC HVAC Room Data Sheet', '2026-10-07 19:00:00', '2026-10-08 15:06:26', 0.00),
(41, 1, 1, 2, '2026-10-07 04:13:07', '2026-10-07 04:18:55', 348, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(42, 3, 3, 9, '2026-10-07 04:12:56', '2026-10-07 08:06:11', 13995, 1, 0, 'Voice & Data AFIC', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(43, 2, NULL, 5, '2026-10-07 04:11:57', '2026-10-07 08:00:00', 13683, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(44, 3, 3, 4, '2026-10-07 04:03:26', '2026-10-07 05:00:00', 3394, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(45, 3, 5, 6, '2026-10-07 04:02:49', '2026-10-07 04:48:18', 2729, 1, 0, NULL, '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(46, 4, 4, 8, '2026-10-07 03:15:00', '2026-10-07 04:00:00', 2700, 1, 0, 'Work alignment and discusion', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(47, 1, 1, 2, '2026-10-06 09:17:43', '2026-10-06 13:55:29', 16666, 1, 0, NULL, '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(48, 3, 3, 4, '2026-10-06 09:15:51', '2026-10-06 14:01:24', 17133, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(49, 3, 3, 9, '2026-10-06 09:09:28', '2026-10-06 13:57:05', 17257, 1, 0, 'Voice & Data AFIC', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(50, 2, NULL, 5, '2026-10-06 09:07:55', '2026-10-06 13:10:21', 14546, 1, 0, NULL, '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(51, 7, NULL, 7, '2026-10-06 09:05:35', '2026-10-06 13:09:34', 14639, 1, 0, 'working on layout plans', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(52, 3, 8, 8, '2026-10-06 09:00:00', '2026-10-06 12:20:00', 12000, 1, 0, 'AFIC HAP Modeling', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(53, 2, 2, 3, '2026-10-06 08:00:00', '2026-10-06 13:00:00', 18000, 1, 0, 'TYPICAL CEILING SECTIONS', '2026-10-06 19:00:00', '2026-10-08 15:06:26', 0.00),
(54, 2, NULL, 5, '2026-10-06 07:22:57', '2026-10-06 08:00:06', 2229, 1, 0, NULL, '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(55, 7, NULL, 7, '2026-10-06 07:08:43', '2026-10-06 08:00:56', 3133, 1, 0, 'working on layout plans', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(56, 9, 18, 6, '2026-10-06 07:06:34', '2026-10-06 12:59:54', 21200, 1, 0, NULL, '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(57, 1, 1, 2, '2026-10-06 05:16:29', '2026-10-06 08:00:53', 9864, 1, 0, NULL, '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(58, 2, 2, 3, '2026-10-06 05:00:00', '2026-10-06 07:10:00', 7800, 1, 0, 'TYPICAL CEILING SECTIONS', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(59, 3, 3, 4, '2026-10-06 04:22:45', '2026-10-06 08:00:33', 13068, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(60, 2, 2, 7, '2026-10-06 04:12:09', '2026-10-06 06:59:48', 10059, 1, 0, 'detail ceiling plan', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(61, 11, NULL, 5, '2026-10-06 04:11:48', '2026-10-06 07:22:26', 11438, 1, 0, NULL, '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(62, 3, 5, 6, '2026-10-06 04:08:29', '2026-10-06 07:05:12', 10603, 1, 0, NULL, '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(63, 3, 3, 9, '2026-10-06 04:05:38', '2026-10-06 08:00:36', 14098, 1, 0, 'Voice & Data AFIC', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(64, 3, 8, 8, '2026-10-06 04:00:00', '2026-10-06 08:15:00', 15300, 1, 0, 'HVAC Load Calculations', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(65, 4, 4, 8, '2026-10-06 03:30:00', '2026-10-06 04:00:00', 1800, 1, 0, 'Work Priority Assessment', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(66, 3, 3, 9, '2026-10-05 13:39:12', '2026-10-05 13:41:38', 146, 1, 0, 'Voice & Data AFIC', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(67, 4, 4, 7, '2026-10-05 11:22:00', '2026-10-06 04:00:00', 59880, 1, 0, 'Boundary Wall Detail DHA House Usman Sb', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(68, 3, 5, 6, '2026-10-05 10:38:27', '2026-10-05 12:54:54', 8187, 1, 0, NULL, '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(69, 3, 8, 8, '2026-10-05 10:00:00', '2026-10-05 12:20:00', 8400, 1, 0, 'AFIC HAP Modeling', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(70, 5, 13, 7, '2026-10-05 09:16:28', '2026-10-05 11:21:07', 7479, 1, 0, 'BATH DETAILS', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(71, 3, 3, 4, '2026-10-05 09:06:55', '2026-10-05 13:15:57', 14942, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(72, 1, 1, 2, '2026-10-05 09:06:36', '2026-10-05 13:16:14', 14978, 1, 0, NULL, '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(73, 1, 6, 8, '2026-10-05 09:05:00', '2026-10-05 10:00:00', 3300, 1, 0, 'LPS Design Review', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(74, 11, NULL, 5, '2026-10-05 09:03:02', '2026-10-05 13:00:00', 14218, 1, 0, NULL, '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(75, 7, NULL, 6, '2026-10-05 09:01:42', '2026-10-05 10:38:02', 5780, 1, 0, NULL, '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(76, 8, 11, 3, '2026-10-05 09:00:00', '2026-10-05 13:00:00', 14400, 1, 0, 'FALSE CEILING DIMENSIONS', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(77, 10, NULL, 8, '2026-10-05 05:30:00', '2026-10-05 08:10:00', 9600, 1, 0, 'Satellite Clinic HAP', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(78, 1, 1, 2, '2026-10-05 04:49:02', '2026-10-05 07:59:59', 11457, 1, 0, NULL, '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(79, 3, 3, 4, '2026-10-05 04:25:46', '2026-10-05 08:00:31', 12885, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(80, 11, NULL, 5, '2026-10-05 04:18:49', '2026-10-05 08:00:00', 13271, 1, 0, NULL, '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(81, 1, 6, 8, '2026-10-05 04:15:00', '2026-10-05 05:30:00', 4500, 1, 0, 'Design Calculations', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(82, 3, 3, 9, '2026-10-05 04:10:00', '2026-10-05 12:25:00', 29700, 1, 0, 'Voice & Data AFIC', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(83, 3, 5, 6, '2026-10-05 04:01:48', '2026-10-05 08:21:35', 15587, 1, 0, NULL, '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(84, 8, 11, 3, '2026-10-05 04:00:00', '2026-10-05 08:00:00', 14400, 1, 0, 'FALSE CEILING', '2026-10-05 19:00:00', '2026-10-08 15:06:26', 0.00),
(85, 5, 13, 7, '2026-10-05 04:00:00', '2026-10-05 08:01:00', 14460, 1, 0, 'BATH DETAILS', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(86, 1, 1, 2, '2026-10-02 11:53:17', '2026-10-02 14:08:15', 8098, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(87, 1, 1, 2, '2026-10-02 11:53:12', '2026-10-02 11:53:17', 5, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(88, 1, 6, 8, '2026-10-02 11:30:00', '2026-10-02 12:30:00', 3600, 1, 0, 'Design Calculations', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(89, 2, 2, 3, '2026-10-02 11:00:00', '2026-10-02 11:20:00', 1200, 1, 0, 'TYPICAL CEILING SECTION', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(90, 11, NULL, 5, '2026-10-02 10:22:39', '2026-10-02 13:01:07', 9508, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(91, 3, 3, 4, '2026-10-02 09:43:52', '2026-10-02 13:32:22', 13710, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(92, 1, 1, 2, '2026-10-02 09:31:57', '2026-10-02 11:40:07', 7690, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(93, 3, 5, 7, '2026-10-02 09:12:52', '2026-10-02 13:05:21', 13949, 1, 0, 'section details', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(94, 4, 4, 3, '2026-10-02 09:07:38', '2026-10-02 10:45:43', 5885, 1, 0, 'COMPITETION PRESENTATION', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(95, 3, 5, 6, '2026-10-02 09:02:20', '2026-10-02 13:00:03', 14263, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(96, 3, 8, 8, '2026-10-02 09:00:00', '2026-10-02 11:30:00', 9000, 1, 0, 'HVAC Load Calculations', '2026-10-04 19:00:00', '2026-10-08 15:06:26', 0.00),
(97, 2, 2, 5, '2026-10-02 09:00:00', '2026-10-02 10:15:00', 4500, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(98, 4, 4, 3, '2026-10-02 04:59:25', '2026-10-02 07:30:00', 9035, 1, 0, 'COMPITETION PRESENTATION', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(99, 4, 4, 3, '2026-10-02 04:59:00', '2026-10-02 04:59:05', 5, 1, 0, 'COMPETETION PRESENTATION', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(100, 2, 2, 3, '2026-10-02 04:46:53', '2026-10-02 04:47:53', 60, 1, 0, 'LG-CAFE DETAILS', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(101, 2, 2, 5, '2026-10-02 04:25:00', '2026-10-02 07:30:00', 11100, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(102, 1, 1, 2, '2026-10-02 04:18:44', '2026-10-02 07:32:06', 11602, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(103, 3, 5, 6, '2026-10-02 04:11:04', '2026-10-02 07:30:08', 11944, 1, 0, NULL, '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(104, 5, 7, 9, '2026-10-02 04:07:19', '2026-10-02 13:17:00', 32981, 1, 0, 'The Hive Electrical', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(105, 3, 3, 4, '2026-10-02 04:06:12', '2026-10-02 07:31:14', 12302, 1, 0, 'Detail Design HVAC Layout Plan', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(106, 3, 5, 7, '2026-10-02 04:00:00', '2026-10-02 07:30:00', 12600, 1, 0, 'section details', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(107, 1, 6, 8, '2026-10-02 03:15:00', '2026-10-02 07:45:00', 16200, 1, 0, 'Drawings Review and Discussion', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(108, 1, 6, 8, '2026-10-01 14:20:00', '2026-10-01 15:45:00', 5100, 1, 0, 'Drawings Review and Discussion', '2026-10-01 19:00:00', '2026-10-08 15:06:26', 0.00),
(109, 5, 7, 9, '2026-10-01 13:49:51', '2026-10-01 13:49:55', 4, 1, 0, 'The Hive Electrical', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(110, 5, 7, 9, '2026-10-01 12:37:56', '2026-10-01 13:47:00', 4144, 1, 0, 'The Hive Electrical', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(111, 3, 3, 4, '2026-10-01 12:32:47', '2026-10-01 14:00:00', 5233, 1, 0, 'Detail Design HVAC Layout Plan', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(112, 1, 1, 2, '2026-10-01 12:02:11', '2026-10-01 14:51:54', 10183, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(113, 3, 8, 8, '2026-10-01 10:45:00', '2026-10-01 14:20:00', 12900, 1, 0, 'HVAC Load Description', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(114, 6, 9, 10, '2026-10-01 10:40:37', '2026-10-01 10:40:54', 17, 1, 0, 'Resolving Floor Plans and Massing', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(115, 1, 1, 2, '2026-10-01 10:37:46', '2026-10-01 11:54:48', 4622, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(116, 4, 4, 8, '2026-10-01 10:20:00', '2026-10-01 10:45:00', 1500, 1, 0, 'New Joiner Orientation (Sr. Inspector Finishes)', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(117, 7, 10, 11, '2026-10-01 10:00:00', '2026-10-01 12:30:00', 9000, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(118, 3, 8, 8, '2026-10-01 09:45:00', '2026-10-01 10:20:00', 2100, 1, 0, 'HVAC Load Description', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(119, 8, 11, 11, '2026-10-01 09:30:00', '2026-10-01 09:50:00', 1200, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(120, 5, 7, 9, '2026-10-01 09:08:16', '2026-10-01 12:37:53', 12577, 1, 0, 'The Hive Electrical', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(121, 1, 1, 2, '2026-10-01 09:04:49', '2026-10-01 10:23:19', 4710, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(122, 3, 3, 4, '2026-10-01 09:00:20', '2026-10-01 12:32:26', 12726, 1, 0, 'Detail Design HVAC Layout Plan', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(123, 3, 8, 8, '2026-10-01 07:30:00', '2026-10-01 08:15:00', 2700, 1, 0, 'HVAC Load Calculations', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(124, 1, 1, 2, '2026-10-01 06:45:16', '2026-10-01 08:04:52', 4776, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(125, 2, 12, 11, '2026-10-01 06:30:00', '2026-10-01 08:35:00', 7500, 1, 0, 'Ceiling Transition details for OPD and IPD waiting rooms', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(126, 1, 1, 2, '2026-10-01 06:17:16', '2026-10-01 06:17:33', 17, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(127, 1, 6, 8, '2026-10-01 04:45:00', '2026-10-01 07:30:00', 9900, 1, 0, 'Team Alignment and Work Distribution', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(128, 3, 3, 4, '2026-10-01 04:16:14', '2026-10-01 08:04:22', 13688, 1, 0, 'Detail Design HVAC Layout Plan', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(129, 3, 8, 8, '2026-10-01 04:15:00', '2026-10-01 04:45:00', 1800, 1, 0, 'HVAC Load Calculations Discussion', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(130, 5, 13, 2, '2026-10-01 04:06:54', '2026-10-01 06:04:28', 7054, 1, 0, NULL, '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(131, 5, 7, 9, '2026-10-01 04:05:00', '2026-10-01 08:00:00', 14100, 1, 0, 'The Hive Electrical', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(132, 1, 6, 8, '2026-10-01 03:15:00', '2026-10-01 04:15:00', 3600, 1, 0, 'Project Overview', '2026-09-30 19:00:00', '2026-10-08 15:06:26', 0.00),
(133, 9, 14, 9, '2026-09-30 12:20:25', '2026-09-30 13:12:40', 3135, 1, 0, 'SSH Detail Design', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(134, 5, 13, 2, '2026-09-30 12:19:21', '2026-09-30 13:00:47', 2486, 1, 0, NULL, '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(135, 9, 14, 9, '2026-09-30 09:04:13', '2026-09-30 12:09:05', 11092, 1, 0, 'SSH Detail Design', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(136, 3, 3, 4, '2026-09-30 09:02:59', '2026-09-30 13:11:36', 14917, 1, 0, 'Detail Design HVAC Layout Plan', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(137, 5, 13, 2, '2026-09-30 09:01:00', '2026-09-30 12:06:26', 11126, 1, 0, NULL, '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(138, 3, 15, 8, '2026-09-30 09:00:00', '2026-09-30 12:15:00', 11700, 1, 0, 'HVAC Load Calculations', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(139, 5, 13, 2, '2026-09-30 07:48:41', '2026-09-30 08:15:23', 1602, 1, 0, NULL, '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(140, 5, 7, 2, '2026-09-30 07:48:13', '2026-09-30 07:48:25', 12, 1, 0, 'The Hive', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(141, 9, 14, 9, '2026-09-30 07:15:22', '2026-09-30 08:02:03', 2801, 1, 0, 'SSH Detail Design', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(142, 9, 14, 9, '2026-09-30 07:09:19', '2026-09-30 07:09:23', 4, 1, 0, 'SSH Detail Design', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(143, 3, 15, 8, '2026-09-30 07:05:00', '2026-09-30 08:10:00', 3900, 1, 0, 'HVAC Load Calculations', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(144, 3, 3, 4, '2026-09-30 06:32:24', '2026-09-30 08:01:48', 5364, 1, 0, 'Detail Design HVAC Layout Plan', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(145, 2, 16, 8, '2026-09-30 06:15:00', '2026-09-30 07:05:00', 3000, 1, 0, 'Solar System Vendors Online Meeting', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(146, 9, 17, 4, '2026-09-30 05:43:38', '2026-09-30 06:30:37', 2819, 1, 0, 'Detail design mechanical', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(147, 3, 15, 8, '2026-09-30 04:40:19', '2026-09-30 06:15:00', 5681, 1, 0, 'HVAC Load Calculations', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(148, 9, 14, 9, '2026-09-30 04:24:28', '2026-09-30 07:09:06', 9878, 1, 0, 'SSH Detail Design', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(149, 9, 17, 4, '2026-09-30 04:10:54', '2026-09-30 05:40:31', 5377, 1, 0, 'Detail design mechanical', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(150, 9, 17, 4, '2026-09-30 04:10:35', '2026-09-30 04:10:37', 2, 1, 0, 'Detail design mechanical', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(151, 5, 7, 2, '2026-09-30 04:06:32', '2026-09-30 07:43:23', 13011, 1, 0, 'The Hive', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(152, 3, 15, 8, '2026-09-30 03:20:00', '2026-09-30 04:40:00', 4800, 1, 0, 'General Discussion', '2026-09-29 19:00:00', '2026-10-08 15:06:26', 0.00),
(153, 3, 15, 8, '2026-09-29 09:05:00', '2026-09-29 12:15:00', 11400, 1, 0, 'HVAC Load Calculations', '2026-09-28 19:00:00', '2026-10-08 15:06:26', 0.00),
(154, 3, 15, 8, '2026-09-29 06:17:10', '2026-09-29 08:15:00', 7070, 1, 0, 'HVAC Load Calculations', '2026-09-28 19:00:00', '2026-10-08 15:06:26', 0.00),
(155, 2, 16, 8, '2026-09-29 04:30:00', '2026-09-29 06:17:00', 6420, 1, 0, 'BMS Bid Evaluation', '2026-09-28 19:00:00', '2026-10-08 15:06:26', 0.00),
(156, 9, 14, 9, '2026-09-29 04:26:04', '2026-09-29 12:52:00', 30356, 1, 0, NULL, '2026-09-28 19:00:00', '2026-10-08 15:06:26', 0.00),
(157, 3, 3, 2, '2026-09-29 04:24:12', '2026-09-29 12:42:00', 29868, 1, 0, 'CCTV LAYOUTS', '2026-09-28 19:00:00', '2026-10-08 15:06:26', 0.00),
(158, 3, 15, 8, '2026-09-29 03:10:00', '2026-09-29 04:30:00', 4800, 1, 0, 'HVAC Load Calculations', '2026-09-28 19:00:00', '2026-10-08 15:06:26', 0.00),
(159, 9, 17, 4, '2026-09-28 12:52:59', '2026-09-28 13:11:01', 1082, 1, 0, 'Detail design mechanical', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(160, 2, 16, 8, '2026-09-28 08:15:00', '2026-09-28 12:15:00', 14400, 1, 0, 'BMS Bid Evaluation', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(161, 3, 3, 2, '2026-09-28 07:36:56', '2026-09-28 13:13:01', 20165, 1, 0, 'CCTV LAYOUTS', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(162, 2, 16, 8, '2026-09-28 06:20:34', '2026-09-28 08:15:00', 6866, 1, 0, 'BMS Bid Evaluation', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(163, 9, 18, 9, '2026-09-28 05:13:30', '2026-09-28 13:13:07', 28777, 1, 0, 'Detail Design Electrical (LV & ELV)', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(164, 3, 15, 8, '2026-09-28 05:05:00', '2026-09-28 06:20:00', 4500, 1, 0, 'HVAC Load Calculations', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(165, 10, 19, 9, '2026-09-28 04:51:18', '2026-09-28 05:11:52', 1234, 1, 0, NULL, '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(166, 9, 17, 4, '2026-09-28 04:45:38', '2026-09-28 12:51:41', 29163, 1, 0, 'Detail design mechanical', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(167, 3, 3, 2, '2026-09-28 04:41:29', '2026-09-28 07:32:30', 10261, 1, 0, 'CCTV LAYOUTS', '2026-09-27 19:00:00', '2026-10-08 15:06:26', 0.00),
(168, 10, NULL, 4, '2026-09-25 11:01:42', '2026-09-25 16:00:00', 17898, 1, 0, 'Fire Fighting Layout', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(169, 10, NULL, 4, '2026-09-25 11:00:57', '2026-09-25 11:01:22', 25, 1, 0, 'Fire Fighting Layout', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(170, 10, 19, 9, '2026-09-25 10:55:40', '2026-09-25 14:01:44', 11164, 1, 0, NULL, '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(171, 10, NULL, 8, '2026-09-25 10:55:00', '2026-09-25 12:15:00', 4800, 1, 0, 'HVAC Load Calculations', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(172, 10, 19, 9, '2026-09-25 10:51:20', '2026-09-25 10:52:24', 64, 1, 0, NULL, '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(173, 3, 15, 8, '2026-09-25 10:05:00', '2026-09-25 10:55:00', 3000, 1, 0, 'Clockify Training', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(174, 10, 19, 9, '2026-09-25 09:17:09', '2026-09-25 10:51:00', 5631, 1, 0, 'Power recepticales & Voice data', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(175, 3, 3, 2, '2026-09-25 09:00:00', '2026-09-25 14:00:00', 18000, 1, 0, 'CCTV LAYOUTS', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(176, 10, NULL, 8, '2026-09-25 09:00:00', '2026-09-25 10:05:00', 3900, 1, 0, 'HVAC Load Calculation Sheet', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(177, 10, NULL, 4, '2026-09-25 09:00:00', '2026-09-25 10:15:00', 4500, 1, 0, 'Fire Fighting Layout', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(178, 10, NULL, 8, '2026-09-25 05:45:00', '2026-09-25 07:45:00', 7200, 1, 0, 'Room Data Sheet', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(179, 3, 15, 8, '2026-09-25 05:15:00', '2026-09-25 05:45:00', 1800, 1, 0, 'AFIC Minutes Discussed with Sir Usman', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(180, 3, 3, 2, '2026-09-25 04:15:00', '2026-09-25 07:30:00', 11700, 1, 0, 'CCTV LAYOUTS', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(181, 10, NULL, 4, '2026-09-25 04:10:00', '2026-09-25 07:30:00', 12000, 1, 0, 'Fire Fighting Layout', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(182, 10, 19, 9, '2026-09-25 04:10:00', '2026-09-25 07:30:00', 12000, 1, 0, NULL, '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(183, 11, NULL, 8, '2026-09-25 03:15:00', '2026-09-25 05:15:00', 7200, 1, 0, 'ELV BOQs', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(184, 11, NULL, 8, '2026-09-24 13:40:00', '2026-09-24 14:40:00', 3600, 1, 0, 'ELV BOQs', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00),
(185, 3, 15, 8, '2026-09-24 13:00:00', '2026-09-24 13:40:00', 2400, 1, 0, 'Clockify Update', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00),
(186, 3, 15, 8, '2026-09-24 12:00:00', '2026-09-24 13:00:00', 3600, 1, 0, 'AFIC HVAC Room Data Sheet', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00),
(187, 3, 15, 8, '2026-09-24 11:00:00', '2026-09-24 12:00:00', 3600, 1, 0, 'AFIC Meeting Minutes', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00),
(188, 11, NULL, 16, '2026-09-24 15:19:43', '2026-09-24 15:19:53', 10, 1, 0, 'I worked on the project master plan for AST', '2026-09-24 00:00:00', '2026-10-08 15:06:26', 0.00),
(189, 11, NULL, 16, '2026-09-24 15:19:42', '2026-09-24 15:19:43', 1, 1, 0, 'I worked on the project master plan for AST', '2026-09-24 00:00:00', '2026-10-08 15:06:26', 0.00),
(190, 10, 19, 9, '2026-09-24 09:00:00', '2026-09-24 13:30:00', 16200, 1, 0, NULL, '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(191, 3, 15, 8, '2026-09-24 09:00:00', '2026-09-24 11:00:00', 7200, 1, 0, 'AFIC HVAC Room Data Sheet', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00),
(192, 3, 15, 8, '2026-09-24 06:00:00', '2026-09-24 08:20:00', 8400, 1, 0, 'Progress Review Meeting and Driving Back', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00),
(193, 3, 15, 8, '2026-09-24 05:00:00', '2026-09-24 06:00:00', 3600, 1, 0, 'Waiting & Traveling to Meeting Site', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00),
(194, 11, NULL, 16, '2026-09-24 10:00:00', '2026-09-24 13:00:00', 10800, 1, 0, NULL, '2026-09-24 00:00:00', '2026-10-08 15:06:26', 0.00),
(195, 10, NULL, 4, '2026-09-24 04:05:00', '2026-09-24 09:00:00', 17700, 1, 0, 'Water Supply Layout', '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(196, 10, 19, 9, '2026-09-24 04:00:00', '2026-09-24 08:00:00', 14400, 1, 0, NULL, '2026-09-24 19:00:00', '2026-10-08 15:06:26', 0.00),
(197, 3, 15, 8, '2026-09-24 03:00:00', '2026-09-24 05:00:00', 7200, 1, 0, 'AFIC Meeting Prepration', '2026-09-23 19:00:00', '2026-10-08 15:06:26', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `role` enum('admin','manager','employee','client') NOT NULL DEFAULT 'employee',
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timezone` varchar(64) NOT NULL DEFAULT 'UTC',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `failed_login_attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `role`, `name`, `email`, `password`, `phone`, `job_title`, `avatar_path`, `hourly_rate`, `timezone`, `status`, `failed_login_attempts`, `locked_until`, `last_login_at`, `last_login_ip`, `password_changed_at`, `must_change_password`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'Admin', 'mubashirjco@gmail.com', '$2y$12$Sl8sP/SFym3JwxgrD1H0VemW4WE9IfSYIWnY49pDksXa.VJYksH8m', NULL, NULL, '/uploads/users/avatar-3e8f54b90e2832245ed53625bbdb64c1.jpg', 0.00, 'UTC', 'active', 0, NULL, '2026-10-09 05:19:52', '103.87.194.250', '2026-10-06 16:22:56', 0, '2026-10-06 16:13:44', '2026-10-09 05:19:52'),
(2, 3, 'employee', 'Muhammad Noman', 'muhammadnoman@mavenprojects.com', '$2y$12$UuZ.ROoEe8QYexJXuESq0OLMVJzKRySAwjn5GbWSuHqG75Edy8Aze', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:02', '2026-10-07 15:57:02'),
(3, 3, 'employee', 'Umair Khan', 'umairbadshah0314@gmail.com', '$2y$12$0z/gz6lIrT8RXQf19A9BNe3BmLe8wFO63oyDJLFR7qwXRtAWE.ED2', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:02', '2026-10-07 15:57:02'),
(4, 3, 'employee', 'Saqib Hussain', 'saqibhussain@mavenprojects.com', '$2y$12$UI5BAZ8midOY7KpaPDao5O3aftkjdt202OyHdsBhmmxMgoIQ3vUeq', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:03', '2026-10-07 15:57:03'),
(5, 3, 'employee', 'Muhammad Arslan', 'am4416179@gmail.com', '$2y$12$A2QHbe936awGVAbfnpj/4eWFy9PCQzzJhftgMiLLkmGrWFHh7w8PO', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:03', '2026-10-07 15:57:03'),
(6, 3, 'employee', 'Imran Javed', 'imranjavedarch@gmail.com', '$2y$12$PIrQcwqklWUYZV3FImSbS.pzVo5KLhIPDGNnEVFzV40Al3REC7cie', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:03', '2026-10-07 15:57:03'),
(7, 3, 'employee', 'Rizwan Ali Warsi', 'rizwanwarsi508@gmail.com', '$2y$12$u5vpu3KH5UMSrpPU0o9Ni.rRp/rHu1zCdSta1FUKYluq8pub.dEpS', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:03', '2026-10-07 15:57:03'),
(8, 3, 'employee', 'Usman Khan', 'usmankhan@mavenprojects.com', '$2y$12$7UjCQ6Hd4ntkob62oQiAnO8U9YjhDu.ZK8YMWpWO/LMcMAW/NTX9u', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:03', '2026-10-07 15:57:03'),
(9, 3, 'employee', 'Jamil Ahmad', 'jamilahmad@mavenprojects.com', '$2y$12$RjiDHZvKJGDf.Le7tcvM9OSB44fs5kRXZ6nMjpqSVwj6uIinp2oOi', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:04', '2026-10-07 15:57:04'),
(10, 3, 'employee', 'Ayesha Yousuf', 'ayeshayousuf@mavenprojects.com', '$2y$12$1o/FH0NgqDJMfeWOC9WBBeTlxqaUkJxsFxy8.H8Hb0Lc7kUuFJHW6', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:04', '2026-10-07 15:57:04'),
(11, 3, 'employee', 'Muhammad Kazmeen', 'muhammadkazmeen@mavenprojects.com', '$2y$12$d6jVqZmFPmMFZaRz8O6V9ukGbk5gXveWXPsJZrrxDs3kdn9hDTqaa', NULL, NULL, NULL, 0.00, 'Asia/Karachi', 'active', 0, NULL, NULL, NULL, NULL, 0, '2026-10-07 15:57:41', '2026-10-07 15:57:41'),
(12, 2, 'manager', 'Hamza Arshad', 'hamza@mavenprojects.com', '$2y$12$sjS5ZRXS1mTcXD3fRBEIEuwH3Ea1BaVuUUk/F.vmvSxMyQFOONUmm', NULL, NULL, NULL, 0.00, 'UTC', 'active', 0, NULL, '2026-10-08 05:12:32', '103.87.194.250', '2026-10-08 05:20:52', 0, '2026-10-07 16:54:27', '2026-10-09 04:50:40'),
(15, 2, 'manager', 'Waqas Hafeez', 'waqashafeez@mavenprojects.com', '$2y$12$/48Vny268E7eW18T/3HH1uupY3kuQ/ldwA.A2XmQcn531YXOPDnlm', NULL, NULL, NULL, 0.00, 'UTC', 'active', 0, NULL, NULL, NULL, NULL, 1, '2026-10-08 13:36:45', '2026-10-08 13:36:45'),
(16, 3, 'employee', 'Hamza Farooq', 'hamzafarooq@mavenprojects.com', '$2y$12$Yfr8ymNw..C7G0/AWd.6eedDIL2RZcjUQBfZAvy8NL94CgEfzmFZO', NULL, NULL, NULL, 0.00, 'UTC', 'active', 0, NULL, NULL, NULL, NULL, 1, '2026-10-08 15:01:32', '2026-10-08 15:01:32'),
(17, 1, 'admin', 'Maven', 'info@mavenprojects.com', '$2y$12$1ttnybsD14JIXTl3qRHEJeqRT5XtC/5b7mXnx1HBPUdG60A3sh2q.', NULL, NULL, NULL, 0.00, 'UTC', 'active', 0, NULL, NULL, NULL, NULL, 1, '2026-10-08 15:06:07', '2026-10-08 15:06:07'),
(19, 2, 'manager', 'Usman Talat', 'usmantalat@mavenprojects.com', '$2y$12$hgzrT7gYJJKWCelMkpGevOdxyPVBGGwn6ksCJ7pPpSLCbyAzNMeCi', NULL, NULL, NULL, 0.00, 'UTC', 'active', 0, NULL, NULL, NULL, NULL, 1, '2026-10-09 04:51:29', '2026-10-09 04:51:29');

-- --------------------------------------------------------

--
-- Table structure for table `user_invitations`
--

CREATE TABLE `user_invitations` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(190) NOT NULL,
  `name` varchar(120) NOT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `account_status` varchar(20) NOT NULL DEFAULT 'active',
  `invited_by` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `token_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `sent_at` datetime DEFAULT NULL,
  `accepted_at` datetime DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `last_sent_at` datetime DEFAULT NULL,
  `send_count` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_invitations`
--

INSERT INTO `user_invitations` (`id`, `email`, `name`, `job_title`, `phone`, `account_status`, `invited_by`, `role_id`, `user_id`, `token_hash`, `expires_at`, `status`, `sent_at`, `accepted_at`, `cancelled_at`, `last_sent_at`, `send_count`, `created_at`, `updated_at`) VALUES
(3, 'mubashirbaltistani@gmail.com', 'Mubashir Hassan', NULL, NULL, 'active', 1, 1, NULL, '8b22febdfad9ec193fb1d39c31df8700a947597dc31d4f2b9877d080044de2c0', '2026-10-15 15:20:10', 'sent', '2026-10-08 15:20:13', NULL, NULL, '2026-10-08 15:20:13', 1, '2026-10-08 15:20:10', '2026-10-08 15:20:13'),
(4, 'mubashirbaltistani1@gmail.com', 'Mubashir Hassan', NULL, NULL, 'active', 1, 3, NULL, 'e17fd06bad820b62b6268b6de454a72d9c5a95a7f5fe0d2d302c078aa171a577', '2026-10-16 08:25:43', 'sent', '2026-10-09 08:25:45', NULL, NULL, '2026-10-09 08:25:45', 1, '2026-10-09 08:25:43', '2026-10-09 08:25:45');

-- --------------------------------------------------------

--
-- Table structure for table `user_invitation_projects`
--

CREATE TABLE `user_invitation_projects` (
  `invitation_id` int(10) UNSIGNED NOT NULL,
  `project_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_invitation_projects`
--

INSERT INTO `user_invitation_projects` (`invitation_id`, `project_id`) VALUES
(3, 1),
(4, 1),
(3, 2),
(4, 2),
(3, 3),
(4, 3),
(3, 4),
(4, 4),
(3, 5),
(4, 5),
(3, 6),
(4, 6),
(3, 7),
(4, 7),
(3, 8),
(4, 8),
(3, 9),
(4, 9),
(3, 10),
(4, 10),
(3, 11),
(4, 11);

-- --------------------------------------------------------

--
-- Table structure for table `user_invitation_tasks`
--

CREATE TABLE `user_invitation_tasks` (
  `invitation_id` int(10) UNSIGNED NOT NULL,
  `task_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_invitation_tasks`
--

INSERT INTO `user_invitation_tasks` (`invitation_id`, `task_id`) VALUES
(3, 1),
(4, 1),
(3, 2),
(4, 2),
(3, 3),
(4, 3),
(3, 4),
(4, 4),
(3, 5),
(4, 5),
(3, 6),
(4, 6),
(3, 7),
(4, 7),
(3, 8),
(4, 8),
(3, 9),
(4, 9),
(3, 10),
(4, 10),
(3, 11),
(4, 11),
(3, 12),
(4, 12),
(3, 13),
(4, 13),
(3, 14),
(4, 14),
(3, 15),
(4, 15),
(3, 16),
(4, 16),
(3, 17),
(4, 17),
(3, 18),
(4, 18),
(3, 19),
(4, 19);

-- --------------------------------------------------------

--
-- Table structure for table `user_invitation_teams`
--

CREATE TABLE `user_invitation_teams` (
  `invitation_id` int(10) UNSIGNED NOT NULL,
  `team_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_invitation_teams`
--

INSERT INTO `user_invitation_teams` (`invitation_id`, `team_id`) VALUES
(3, 1),
(4, 1),
(3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `workspaces`
--

CREATE TABLE `workspaces` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(160) NOT NULL,
  `logo_path` varchar(500) DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workspaces`
--

INSERT INTO `workspaces` (`id`, `name`, `logo_path`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 'Maven Projects LLP', '/uploads/workspace/logo-21cea855718ee7a7ac88.png', 1, '2026-10-06 16:13:44', '2026-10-08 15:13:30');

-- --------------------------------------------------------

--
-- Table structure for table `workspace_settings`
--

CREATE TABLE `workspace_settings` (
  `workspace_id` int(10) UNSIGNED NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` varchar(1000) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `workspace_settings`
--

INSERT INTO `workspace_settings` (`workspace_id`, `setting_key`, `setting_value`, `updated_at`) VALUES
(1, 'approval_period', 'weekly', '2026-10-09 08:55:49'),
(1, 'daily_capacity', '10', '2026-10-09 08:55:49'),
(1, 'default_project_visibility', 'private', '2026-10-09 08:55:49'),
(1, 'edit_time_others_policy', 'admins', '2026-10-09 08:55:49'),
(1, 'force_timer', '0', '2026-10-09 08:55:49'),
(1, 'hide_projects', '0', '2026-10-09 08:55:49'),
(1, 'hide_reports', '1', '2026-10-09 08:55:49'),
(1, 'hide_team', '1', '2026-10-09 08:55:49'),
(1, 'hide_tracker', '0', '2026-10-09 08:55:49'),
(1, 'idle_detection_enabled', '0', '2026-10-09 08:55:49'),
(1, 'idle_threshold_minutes', '10', '2026-10-09 08:55:49'),
(1, 'idle_warning_seconds', '60', '2026-10-09 08:55:49'),
(1, 'lock_time_enabled', '0', '2026-10-09 08:55:49'),
(1, 'members_can_create_subtasks', '0', '2026-10-09 08:55:49'),
(1, 'other_team_tasks_visibility', 'hidden', '2026-10-09 08:55:49'),
(1, 'project_creation_policy', 'admins', '2026-10-09 08:55:49'),
(1, 'regular_user_time_visibility', 'own', '2026-10-09 08:55:49'),
(1, 'scheduling_enabled', '0', '2026-10-09 08:55:49'),
(1, 'task_creation_policy', 'admins', '2026-10-09 08:55:49'),
(1, 'task_review_required', '1', '2026-10-09 08:55:49'),
(1, 'task_scope_mode', 'legacy', '2026-10-09 08:55:49'),
(1, 'time_approval_enabled', '1', '2026-10-09 08:55:49'),
(1, 'time_rounding_minutes', '1', '2026-10-09 08:55:49'),
(1, 'timesheet_enabled', '1', '2026-10-09 08:55:49'),
(1, 'week_start', 'monday', '2026-10-09 08:55:49'),
(1, 'workflow_access_admin', '1', '2026-10-09 08:55:49'),
(1, 'workflow_access_department_manager', '1', '2026-10-09 08:55:49'),
(1, 'workflow_access_project_manager', '1', '2026-10-09 08:55:49'),
(1, 'workflow_access_team_manager', '1', '2026-10-09 08:55:49'),
(1, 'workflow_notify_email_admin', '1', '2026-10-09 08:55:49'),
(1, 'workflow_notify_email_department_manager', '0', '2026-10-09 08:55:49'),
(1, 'workflow_notify_email_project_manager', '0', '2026-10-09 08:55:49'),
(1, 'workflow_notify_email_team_manager', '1', '2026-10-09 08:55:49'),
(1, 'workflow_notify_inapp_admin', '1', '2026-10-09 08:55:49'),
(1, 'workflow_notify_inapp_department_manager', '1', '2026-10-09 08:55:49'),
(1, 'workflow_notify_inapp_project_manager', '1', '2026-10-09 08:55:49'),
(1, 'workflow_notify_inapp_team_manager', '1', '2026-10-09 08:55:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `active_timers`
--
ALTER TABLE `active_timers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_active_timers_user` (`user_id`),
  ADD KEY `idx_active_timers_project` (`project_id`),
  ADD KEY `idx_active_timers_task` (`task_id`);

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_activity_user` (`user_id`),
  ADD KEY `idx_activity_action` (`action`),
  ADD KEY `idx_activity_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_activity_created` (`created_at`);

--
-- Indexes for table `agent_pair_attempts`
--
ALTER TABLE `agent_pair_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_agent_pair_attempts_ip_created` (`ip`,`created_at`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_clients_name` (`name`),
  ADD KEY `idx_clients_email` (`email`),
  ADD KEY `idx_clients_status` (`status`);

--
-- Indexes for table `client_users`
--
ALTER TABLE `client_users`
  ADD PRIMARY KEY (`user_id`,`client_id`),
  ADD UNIQUE KEY `uq_client_users_user_client` (`user_id`,`client_id`),
  ADD KEY `idx_client_users_client` (`client_id`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_departments_name` (`name`),
  ADD KEY `idx_departments_manager` (`manager_id`),
  ADD KEY `idx_departments_project` (`project_id`);

--
-- Indexes for table `desktop_agent_devices`
--
ALTER TABLE `desktop_agent_devices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_desktop_agent_token_hash` (`token_hash`),
  ADD UNIQUE KEY `uq_desktop_agent_user_device` (`user_id`,`device_id`),
  ADD KEY `idx_desktop_agent_workspace` (`workspace_id`),
  ADD KEY `idx_desktop_agent_user_status` (`user_id`,`status`),
  ADD KEY `idx_desktop_agent_last_seen` (`last_seen_at`);

--
-- Indexes for table `desktop_agent_pairing_codes`
--
ALTER TABLE `desktop_agent_pairing_codes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_desktop_pairing_code_hash` (`code_hash`),
  ADD KEY `idx_desktop_pairing_user` (`user_id`,`used_at`),
  ADD KEY `idx_desktop_pairing_expires` (`expires_at`),
  ADD KEY `fk_desktop_pairing_workspace` (`workspace_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_password_reset_tokens_hash` (`token_hash`),
  ADD KEY `idx_password_reset_tokens_user` (`user_id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_permissions_name` (`name`),
  ADD KEY `idx_permissions_module` (`module`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_projects_code` (`project_code`),
  ADD KEY `idx_projects_client` (`client_id`),
  ADD KEY `idx_projects_status` (`status`),
  ADD KEY `idx_projects_manager` (`manager_id`),
  ADD KEY `idx_projects_due` (`due_date`),
  ADD KEY `fk_projects_created_by` (`created_by`);

--
-- Indexes for table `project_favorites`
--
ALTER TABLE `project_favorites`
  ADD PRIMARY KEY (`user_id`,`project_id`),
  ADD KEY `idx_project_favorites_project` (`project_id`);

--
-- Indexes for table `project_members`
--
ALTER TABLE `project_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_project_members_project_user` (`project_id`,`user_id`),
  ADD KEY `idx_project_members_user` (`user_id`);

--
-- Indexes for table `report_access`
--
ALTER TABLE `report_access`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_report_access_updated_by` (`updated_by`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_roles_name` (`name`);

--
-- Indexes for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`role_id`,`permission_id`),
  ADD KEY `idx_role_permissions_permission` (`permission_id`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_schedules_user_time` (`user_id`,`start_datetime`,`end_datetime`),
  ADD KEY `idx_schedules_project` (`project_id`),
  ADD KEY `idx_schedules_task` (`task_id`),
  ADD KEY `idx_schedules_status` (`status`),
  ADD KEY `idx_schedules_created_by` (`created_by`),
  ADD KEY `idx_schedules_recurrence_parent` (`recurrence_parent_id`);

--
-- Indexes for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_recurrence_schedule` (`schedule_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_settings_key` (`setting_key`),
  ADD KEY `idx_settings_group` (`setting_group`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_tasks_project` (`project_id`),
  ADD KEY `idx_tasks_parent` (`parent_task_id`),
  ADD KEY `idx_tasks_status` (`status`),
  ADD KEY `idx_tasks_priority` (`priority`),
  ADD KEY `idx_tasks_due` (`due_date`),
  ADD KEY `fk_tasks_created_by` (`created_by`),
  ADD KEY `idx_tasks_team` (`team_id`),
  ADD KEY `idx_tasks_reviewed_by` (`reviewed_by`);

--
-- Indexes for table `task_assignees`
--
ALTER TABLE `task_assignees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_task_assignees` (`task_id`,`user_id`),
  ADD KEY `idx_task_assignees_user` (`user_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_teams_department_name` (`department_id`,`name`),
  ADD KEY `idx_teams_manager` (`manager_id`),
  ADD KEY `idx_teams_lead` (`lead_id`),
  ADD KEY `idx_teams_department` (`department_id`),
  ADD KEY `idx_teams_project` (`project_id`);

--
-- Indexes for table `team_managers`
--
ALTER TABLE `team_managers`
  ADD PRIMARY KEY (`team_id`,`user_id`),
  ADD KEY `idx_team_managers_user` (`user_id`);

--
-- Indexes for table `team_members`
--
ALTER TABLE `team_members`
  ADD PRIMARY KEY (`team_id`,`user_id`),
  ADD KEY `idx_team_members_user` (`user_id`);

--
-- Indexes for table `timer_idle_events`
--
ALTER TABLE `timer_idle_events`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_timer_idle_events_timer_response` (`timer_id`,`response`),
  ADD KEY `idx_timer_idle_events_user` (`user_id`),
  ADD KEY `idx_timer_idle_events_created` (`created_at`);

--
-- Indexes for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_timesheets_user_period` (`user_id`,`start_date`,`end_date`),
  ADD UNIQUE KEY `uq_timesheets_submission_token` (`submission_token`),
  ADD KEY `idx_timesheets_status` (`status`),
  ADD KEY `idx_timesheets_submitted` (`submitted_at`),
  ADD KEY `idx_timesheets_approved_by` (`approved_by`),
  ADD KEY `idx_timesheets_user` (`user_id`);

--
-- Indexes for table `timesheet_entries`
--
ALTER TABLE `timesheet_entries`
  ADD PRIMARY KEY (`timesheet_id`,`time_entry_id`),
  ADD UNIQUE KEY `uq_timesheet_entries_entry` (`time_entry_id`),
  ADD KEY `idx_timesheet_entries_timesheet` (`timesheet_id`);

--
-- Indexes for table `time_entries`
--
ALTER TABLE `time_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_time_entries_project` (`project_id`),
  ADD KEY `idx_time_entries_task` (`task_id`),
  ADD KEY `idx_time_entries_user` (`user_id`),
  ADD KEY `idx_time_entries_running` (`user_id`,`ended_at`),
  ADD KEY `idx_time_entries_user_started` (`user_id`,`started_at`),
  ADD KEY `idx_time_entries_project_started` (`project_id`,`started_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD KEY `idx_users_status` (`status`),
  ADD KEY `idx_users_role_id` (`role_id`),
  ADD KEY `idx_users_role_status` (`role`,`status`);

--
-- Indexes for table `user_invitations`
--
ALTER TABLE `user_invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_user_invitations_token_hash` (`token_hash`),
  ADD KEY `idx_user_invitations_email` (`email`),
  ADD KEY `idx_user_invitations_status_expires` (`status`,`expires_at`),
  ADD KEY `idx_user_invitations_invited_by` (`invited_by`),
  ADD KEY `idx_user_invitations_user` (`user_id`),
  ADD KEY `fk_user_invitations_role` (`role_id`);

--
-- Indexes for table `user_invitation_projects`
--
ALTER TABLE `user_invitation_projects`
  ADD PRIMARY KEY (`invitation_id`,`project_id`),
  ADD KEY `idx_user_invitation_projects_project` (`project_id`);

--
-- Indexes for table `user_invitation_tasks`
--
ALTER TABLE `user_invitation_tasks`
  ADD PRIMARY KEY (`invitation_id`,`task_id`),
  ADD KEY `idx_user_invitation_tasks_task` (`task_id`);

--
-- Indexes for table `user_invitation_teams`
--
ALTER TABLE `user_invitation_teams`
  ADD PRIMARY KEY (`invitation_id`,`team_id`),
  ADD KEY `idx_user_invitation_teams_team` (`team_id`);

--
-- Indexes for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_workspaces_created_by` (`created_by`);

--
-- Indexes for table `workspace_settings`
--
ALTER TABLE `workspace_settings`
  ADD PRIMARY KEY (`workspace_id`,`setting_key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `active_timers`
--
ALTER TABLE `active_timers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;

--
-- AUTO_INCREMENT for table `agent_pair_attempts`
--
ALTER TABLE `agent_pair_attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `desktop_agent_devices`
--
ALTER TABLE `desktop_agent_devices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `desktop_agent_pairing_codes`
--
ALTER TABLE `desktop_agent_pairing_codes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `project_members`
--
ALTER TABLE `project_members`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `task_assignees`
--
ALTER TABLE `task_assignees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `timer_idle_events`
--
ALTER TABLE `timer_idle_events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timesheets`
--
ALTER TABLE `timesheets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `time_entries`
--
ALTER TABLE `time_entries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `user_invitations`
--
ALTER TABLE `user_invitations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `workspaces`
--
ALTER TABLE `workspaces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `active_timers`
--
ALTER TABLE `active_timers`
  ADD CONSTRAINT `fk_active_timers_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_active_timers_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_active_timers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `client_users`
--
ALTER TABLE `client_users`
  ADD CONSTRAINT `fk_client_users_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_client_users_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `departments`
--
ALTER TABLE `departments`
  ADD CONSTRAINT `fk_departments_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_departments_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `desktop_agent_devices`
--
ALTER TABLE `desktop_agent_devices`
  ADD CONSTRAINT `fk_desktop_agent_devices_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_desktop_agent_devices_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `desktop_agent_pairing_codes`
--
ALTER TABLE `desktop_agent_pairing_codes`
  ADD CONSTRAINT `fk_desktop_pairing_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_desktop_pairing_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD CONSTRAINT `fk_password_reset_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `fk_projects_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_projects_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_projects_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `project_favorites`
--
ALTER TABLE `project_favorites`
  ADD CONSTRAINT `fk_project_favorites_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_project_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_members`
--
ALTER TABLE `project_members`
  ADD CONSTRAINT `fk_project_members_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_project_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `report_access`
--
ALTER TABLE `report_access`
  ADD CONSTRAINT `fk_report_access_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_report_access_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `fk_schedules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_recurrence_parent` FOREIGN KEY (`recurrence_parent_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_schedules_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedule_recurrences`
--
ALTER TABLE `schedule_recurrences`
  ADD CONSTRAINT `fk_recurrence_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `fk_tasks_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_parent` FOREIGN KEY (`parent_task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_reviewed_by` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_tasks_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `task_assignees`
--
ALTER TABLE `task_assignees`
  ADD CONSTRAINT `fk_task_assignees_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_task_assignees_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `fk_teams_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_teams_lead` FOREIGN KEY (`lead_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_teams_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_teams_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `team_managers`
--
ALTER TABLE `team_managers`
  ADD CONSTRAINT `fk_team_managers_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_team_managers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `team_members`
--
ALTER TABLE `team_members`
  ADD CONSTRAINT `fk_team_members_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_team_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timer_idle_events`
--
ALTER TABLE `timer_idle_events`
  ADD CONSTRAINT `fk_timer_idle_events_timer` FOREIGN KEY (`timer_id`) REFERENCES `active_timers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_timer_idle_events_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheets`
--
ALTER TABLE `timesheets`
  ADD CONSTRAINT `fk_timesheets_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_timesheets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheet_entries`
--
ALTER TABLE `timesheet_entries`
  ADD CONSTRAINT `fk_timesheet_entries_entry` FOREIGN KEY (`time_entry_id`) REFERENCES `time_entries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_timesheet_entries_timesheet` FOREIGN KEY (`timesheet_id`) REFERENCES `timesheets` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `time_entries`
--
ALTER TABLE `time_entries`
  ADD CONSTRAINT `fk_time_entries_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_time_entries_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_time_entries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `user_invitations`
--
ALTER TABLE `user_invitations`
  ADD CONSTRAINT `fk_user_invitations_invited_by` FOREIGN KEY (`invited_by`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitations_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitations_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `user_invitation_projects`
--
ALTER TABLE `user_invitation_projects`
  ADD CONSTRAINT `fk_user_invitation_projects_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitation_projects_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_invitation_tasks`
--
ALTER TABLE `user_invitation_tasks`
  ADD CONSTRAINT `fk_user_invitation_tasks_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitation_tasks_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_invitation_teams`
--
ALTER TABLE `user_invitation_teams`
  ADD CONSTRAINT `fk_user_invitation_teams_invite` FOREIGN KEY (`invitation_id`) REFERENCES `user_invitations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_invitation_teams_team` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `workspaces`
--
ALTER TABLE `workspaces`
  ADD CONSTRAINT `fk_workspaces_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `workspace_settings`
--
ALTER TABLE `workspace_settings`
  ADD CONSTRAINT `fk_workspace_settings_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
