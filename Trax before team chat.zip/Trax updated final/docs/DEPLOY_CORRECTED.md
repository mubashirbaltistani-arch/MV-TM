# Corrected deployment

1. Back up the live database.
2. Remove the old application files from `/domains/akhoonzadaholdings.com/public_html/Dev/`.
3. Upload this package so `app/`, `public/`, `config/`, `routes/`, `database/`, `tools/`, and
   `agent/` are directly under `Dev/`.
4. Keep the correct live database settings in `config/config.php` and `config/database.php`.
5. Run `database/UPGRADE_LIVE.sql`.
6. Configure/test SMTP in TimeTrack System settings.
7. Test one Team Manager assigned to several teams, with a different Team Lead on each team.
8. Submit Team A member time: email Team A Lead + Team Manager + Project Manager + Admins.
9. Confirm Team B/C leads do not receive that submission unless their teams are also included.
10. Submit new time later in the same approval period. It must remain recordable despite earlier
    entries being submitted/approved.
