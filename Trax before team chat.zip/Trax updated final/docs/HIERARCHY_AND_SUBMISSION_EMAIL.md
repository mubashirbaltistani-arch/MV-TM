# TimeTrack hierarchy, dashboard stats and workflow notifications

## Hierarchy

Departments are organisation units. They are not children of a project.
A team in Design, Systems or MIS can work on any project.

```
ADMIN
└── Department (e.g. Design)
    ├── Department Manager
    └── Team
        ├── Team managers (one or more)
        └── Members
```

Create a department with a name and a department manager. Then add teams with a team
name, one or more team managers, and members. Project managers stay on the project
itself and can be enabled or disabled under Workspace > Features.

## Dashboard stats (filtered date range)

Stats follow the person's place in the hierarchy, not their global role:

- Admin: everyone, with breakdowns by project, department, client and team
- Project manager: only projects they manage (when that position is enabled)
- Department manager: only their departments and the teams inside them
- Team manager: only their teams
- Member: only their own time

The date picker on the dashboard still limits every view to the selected period.

## Workflow access and notifications

Workspace > Features controls who can open Approvals and who is notified on submission.

Defaults:

- Access: team manager, department manager, project manager, admin
- In-app notice: all of those positions
- Email: team manager and admin only (department and project managers are skipped)

Change these switches to grant or revoke access, in-app notices or email per position.

Admins submitting their own time are routed only to other active admins who still have
access and notification enabled.

## Time locking

A submission creates a timesheet batch and links only the selected time entries. Existing
submitted/approved entries stay locked; new unsubmitted entries in the same week/month remain
recordable. This allows one task to remain active across multiple weeks with many time chunks.
