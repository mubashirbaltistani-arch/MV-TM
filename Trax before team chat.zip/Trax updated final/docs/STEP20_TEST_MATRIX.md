# Step 20 — TimeTrack test matrix

Run against a staging copy of the live database after `database/UPGRADE_LIVE.sql` (its last query must show OK on every row; run it twice to prove it is repeatable). For every route below, also open the URL as each role; expected result is **403** (or login redirect when logged out). Feature-disabled routes may be 404.

## Role matrix

| Area | Admin | Manager | Employee | Client |
|---|---|---|---|---|
| Login / logout | yes | yes | yes | yes |
| Lockout / failed login | yes | yes | yes | yes |
| Forced password change | flag blocks all except /profile /logout | same | same | same |
| Users CRUD | yes | view only where granted | 403 | 403 |
| Client CRUD | yes | yes | 403 | 403 |
| Project CRUD | yes | yes | limited | own clients, read-only |
| Member access | yes | yes | own assignment | 403 |
| Timer start/pause/resume/stop | yes | yes | yes | 403 |
| Second-tab timer | yes | yes | yes | 403 |
| Manual entry/edit/delete | yes | yes | yes | 403 |
| Viewer cannot track or be assigned | yes | yes | yes | n/a |
| Time only on Active projects | yes (admins not exempt) | yes | yes | n/a |
| Time not before project start_date | yes | yes | yes | n/a |
| Completed/Cancelled task blocked on start/add/edit | yes | yes | yes | n/a |
| Overlap rejection | yes | yes | yes | n/a |
| 12-hour auto-stop | yes | yes | yes | n/a |
| Timesheet submit | yes | yes | yes | 403 |
| Approve/reject/resubmit | yes (not self) | own people only | 403 | 403 |
| Backdate into Approved period | 409 | 409 | 409 | n/a |
| Schedule create/recurrence/conflict | yes | yes | granted schedule roles | 403 |
| Notifications | yes | yes | yes | yes |
| Settings on/off | yes | 403 | 403 | 403 |
| /health public ok only | yes | yes | yes | yes |
| /admin/health | yes | 403 | 403 | 403 |
| Project Tasks tab (add, rename, status, assignees, edit, delete) | yes | yes | where granted | read-only |
| Dark mode | yes | yes | yes | yes |
| Mobile layout | yes | yes | yes | yes |
| Reports | yes | yes | own only | own client only |
| Report billing money | yes | yes | 403/hidden | 403/hidden |
| Report CSV export | yes | yes | 403 | 403 |

## Functional tests

1. **Login/lockout** — valid login succeeds; repeated invalid passwords lock the account; lockout expires; password change invalidates old password.
2. **Forced password** — set must_change_password=1; every URL except /profile, /profile/password, /logout redirects; after change the flag is 0 and password_changed_at is set.
3. **CRUD** — create/edit/delete a client, project, task and user according to role; direct URLs must not bypass controller checks.
4. **Tracking rules** — a viewer is blocked on timer start, manual add and edit; an entry before start_date is rejected; Completed/Cancelled tasks are rejected on start, add and edit; On Hold/Planning projects are not in the picker and are rejected.
5. **Timer** — start, pause, resume, stop; Pakistan/user-local display and UTC storage. Second tab: only one active timer.
6. **Manual/overlap** — add 01:00-02:00, then overlap; server rejects. Edit/delete unlocked entries; submitted/approved entries stay locked. Description-only edit also fails when locked.
7. **Auto-stop** — timer max 12 hours; cron_auto_stop.php sets auto_stopped=1.
8. **Timesheets** — one sheet per user per period; overlapping create fails; reject then resubmit reuses the same sheet; unsubmitted warning shows; sidebar pending count uses approverScope.
9. **Scheduling** — 5-day weekday recurrence makes 5 one-day rows with recurrence_parent_id; conflicts skipped and reported ("N created, M skipped because of conflicts").
10. **Notifications** — approval/rejection/timer events; unread/read/read-all.
11. **Workspace flags** — scheduling/projects/team/reports/timesheet on/off; sidebar and direct URL.
12. **Reports** — totals match Time page; employee sees self; client sees only linked clients; without reports.billing, money is hidden. CSV cells starting `= + - @` tab or CR get a leading apostrophe.
13. **CSP/assets** — Network tab shows no cdn.jsdelivr.net; console has zero CSP errors.
14. **Health** — public /health is `{ok, status}`; /admin/health details for admin, 403 employee, redirect logged-out.
15. **Maintenance flag** — create `storage/maintenance.flag` shows 503 + Retry-After + maintenance.html; delete restores the site. Other 503s are not rewritten.
16. **golive.php** — CLI only; `--check` reports APP_KEY/database/schema; demo @timetrack.local become inactive; new admin must change password.
17. **Mobile/dark mode** — 360px/390px/768px, navigation, filters, tables, dark theme.
18. **Project Tasks tab** — add a task with an empty name (red flash message, back on the Tasks tab, no 404); add, inline rename, mark done / active, assignees, Edit modal, delete: each returns to `/projects/{id}?tab=tasks`. Edit a task that has a priority, start date, billable flag or parent: they keep their values. `/tasks`, `/tasks/create`, `/tasks/{id}` and `/tasks/{id}/edit` are 404 for every role (no GET route).
19. **APP_KEY** — with the placeholder in `config/config.php`: Desktop Agent page shows the red "Pairing is disabled" message, the Generate button is disabled, a forced POST to `/agent/pairing-code` is refused with the same message, `POST /api/agent/pair` answers 503, `/admin/health` shows APP_KEY as `fail`. After setting a 32+ character secret everything works and the health row is `ok`.
20. **Session browser binding** — with `security.bind_session_to_browser` = true, sign in with Chrome, replay the same cookie with an Edge user agent: signed out, and `storage/logs` has "Session dropped" with `old_browser_family` and `new_browser_family`. With it set to false the same replay stays signed in.
21. **UPGRADE_LIVE.sql twice** — second run changes nothing and the checklist is all OK; `SHOW CREATE TABLE schedules` has `recurrence_parent_id`, its index and `ON DELETE SET NULL` foreign key; `clients` has no `company` column.
22. **SMTP invitations** — admin saves Mail / SMTP, Send test is accepted and the 6-character code is searchable in Gmail (Inbox, Spam, Promotions); Gmail App Password + smtp.gmail.com is required for a Gmail From; Invite user with role/team/projects/tasks; email arrives without a password; Accept invitation creates password, activates account, assignments apply; resend invalidates the old token; cancel blocks accept; existing-user email offers assign-without-duplicate; employee cannot grant Admin.

## Direct URL authorization checklist

Test as every role: `/users`, `/clients`, `/projects`, `/team`, `/schedule`, `/schedule/team`, `/timesheets/team`, `/settings`, `/workspace`, `/reports`, `/reports/export.csv`, `/time`, `/timer`, `/timesheets`, `/profile`, `/admin/health`, `/import`, `/agent`.

Generate the client expected-result column with:

```bash
php tools/route_matrix.php
```
