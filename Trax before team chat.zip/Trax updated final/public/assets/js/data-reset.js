/**
 * Reset data page: ticking a group also ticks the groups it depends on, unticking a
 * group also unticks the groups that depend on it, and the Reset button stays
 * disabled until something is selected. The server re-validates everything, so this
 * file is a convenience only.
 */
(function () {
    'use strict';

    var form = document.querySelector('[data-reset-form]');
    if (!form) { return; }

    var boxes = Array.prototype.slice.call(form.querySelectorAll('[data-group]'));
    var buttons = Array.prototype.slice.call(document.querySelectorAll('[data-needs-selection]'));
    var presetAll = document.querySelector('[data-preset-all]');

    function requires(box) {
        return (box.getAttribute('data-requires') || '').split(',').filter(Boolean);
    }

    function byKey(key) {
        return boxes.filter(function (b) { return b.getAttribute('data-group') === key; })[0];
    }

    function refresh() {
        var any = boxes.some(function (b) { return b.checked; });
        buttons.forEach(function (btn) {
            // A locked-out reset button stays disabled no matter what is ticked.
            btn.disabled = !any || btn.hasAttribute('data-locked');
        });
        if (presetAll) { presetAll.checked = boxes.every(function (b) { return b.checked; }); }
    }

    function check(box) {
        box.checked = true;
        requires(box).forEach(function (key) {
            var dep = byKey(key);
            if (dep && !dep.checked) { check(dep); }
        });
    }

    function uncheck(box) {
        box.checked = false;
        var key = box.getAttribute('data-group');
        boxes.forEach(function (other) {
            if (other.checked && requires(other).indexOf(key) !== -1) { uncheck(other); }
        });
    }

    boxes.forEach(function (box) {
        box.addEventListener('change', function () {
            if (box.checked) { check(box); } else { uncheck(box); }
            refresh();
        });
    });

    if (presetAll) {
        presetAll.addEventListener('change', function () {
            boxes.forEach(function (b) { b.checked = presetAll.checked; });
            refresh();
        });
    }

    // Final browser-side confirmation before the destructive POST.
    form.addEventListener('submit', function (event) {
        var submitter = event.submitter;
        if (submitter && submitter.hasAttribute('data-destructive')) {
            if (!window.confirm('This permanently deletes the selected data. Continue?')) {
                event.preventDefault();
            }
        }
    });

    refresh();
})();
