/*
 * Notifications page behaviour (loaded only on /notifications).
 *
 * Works WITHOUT this file: every "Mark as read" control is a normal form post that redirects
 * back. With it, the same forms are sent in the background so the list updates in place, and any
 * failure (server unavailable 503, offline, expired session) is shown in a banner with a retry.
 *
 * Relies on window.TT.request / window.TT.errorMessage from app.js (loaded first). No inline
 * script, as the Content-Security-Policy requires.
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {
        var root = document.querySelector('[data-notifications-page]');
        if (!root || !window.fetch || !window.TT || !window.TT.request) { return; }

        var banner = root.querySelector('[data-notification-alert]');
        var bannerText = root.querySelector('[data-notification-alert-text]');
        var retryButton = root.querySelector('[data-notification-retry]');
        var retryAction = null; // what "Try again" repeats

        /* ---- error banner ------------------------------------------------ */
        function showError(res, action) {
            retryAction = action;
            if (bannerText) { bannerText.textContent = window.TT.errorMessage(res.status, res.message); }
            if (banner) { banner.hidden = false; }
        }

        function clearError() {
            retryAction = null;
            if (banner) { banner.hidden = true; }
        }

        if (retryButton) {
            retryButton.addEventListener('click', function () {
                var action = retryAction;
                clearError();
                if (action) { action(); }
            });
        }

        /* ---- UI updates -------------------------------------------------- */
        function setUnread(count) {
            count = Math.max(0, parseInt(count, 10) || 0);

            document.querySelectorAll('[data-notification-badge]').forEach(function (badge) {
                badge.hidden = count < 1;
                badge.textContent = count > 9 ? '9+' : String(count);
            });
            root.querySelectorAll('[data-unread-count]').forEach(function (el) { el.textContent = String(count); });
            document.querySelectorAll('[data-notification-form][data-kind="all"]').forEach(function (form) {
                form.hidden = count < 1;
            });
        }

        function markRowRead(row) {
            row.classList.remove('is-unread');

            var label = row.querySelector('[data-unread-label]');
            if (label) { label.remove(); }

            var form = row.querySelector('[data-notification-form]');
            if (form) { form.remove(); }

            var link = row.querySelector('[data-notification-link]');
            if (link) { link.setAttribute('data-read-url', ''); }
        }

        /* ---- "Mark as read" / "Mark all as read" ------------------------- */
        function submitForm(form) {
            var button = form.querySelector('button[type="submit"]');
            if (button) { button.disabled = true; }

            window.TT.request(form.getAttribute('action'), {
                method: 'POST',
                headers: { Accept: 'application/json' }
            }).then(function (res) {
                if (button) { button.disabled = false; }

                if (!res.ok) {
                    showError(res, function () { submitForm(form); });
                    return;
                }

                clearError();

                if (form.getAttribute('data-kind') === 'all') {
                    root.querySelectorAll('[data-notification-row].is-unread').forEach(markRowRead);
                } else {
                    var row = form.closest('[data-notification-row]');
                    if (row) { markRowRead(row); }
                }

                setUnread(res.data.unread);
            });
        }

        document.querySelectorAll('[data-notification-form]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                event.preventDefault();
                submitForm(form);
            });
        });

        /*
         * Opening a notification marks it read. keepalive lets the request finish even though the
         * browser is already leaving this page; failures are ignored on purpose (the person
         * should still reach the page they clicked, and the notification simply stays unread).
         */
        root.addEventListener('click', function (event) {
            var link = event.target.closest('[data-notification-link]');
            if (!link) { return; }

            var url = link.getAttribute('data-read-url');
            if (!url) { return; }

            fetch(url, { method: 'POST', keepalive: true, headers: { Accept: 'application/json' } })
                .catch(function () { /* best effort */ });
        });
    });
})();
