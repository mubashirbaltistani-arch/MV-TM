/*
 * Server-authoritative timer.
 *
 * Fetches /time/status on load, ticks from the server-reported elapsed seconds
 * (not Date.parse of a client clock), and handles every [data-timer-start] /
 * [data-timer-stop] control on the page.
 */
/*
 * Live timer feed for the Time page.
 * The server is polled periodically for authoritative timer state; each row
 * then advances locally every second between polls. This avoids a database
 * request every second while still keeping different viewers synchronized.
 */
(function () {
    'use strict';

    var panel = document.querySelector('[data-live-timers-panel]');
    if (!panel) { return; }

    var url = panel.getAttribute('data-live-timers-url') || '';
    var userId = panel.getAttribute('data-live-user-id') || '0';
    var body = panel.querySelector('[data-live-timers-body]');
    var countEl = panel.querySelector('[data-live-timers-count]');
    var timers = Object.create(null);
    var pollTimer = null;
    var tickTimer = null;
    var polling = false;

    function pad(n) { return n < 10 ? '0' + n : String(n); }
    function duration(seconds) {
        seconds = Math.max(0, Math.floor(seconds || 0));
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = seconds % 60;
        return h + ':' + pad(m) + ':' + pad(s);
    }
    function text(value) {
        return value === null || value === undefined || value === '' ? '—' : String(value);
    }
    function formatStart(iso) {
        if (!iso) { return '—'; }
        try {
            return new Intl.DateTimeFormat('en-PK', {
                timeZone: 'Asia/Karachi', month: 'short', day: 'numeric',
                hour: 'numeric', minute: '2-digit', hour12: true
            }).format(new Date(iso));
        } catch (e) {
            return iso;
        }
    }
    function currentSeconds(item) {
        if (item.paused) { return item.elapsed; }
        return item.elapsed + Math.max(0, Math.floor((Date.now() - item.anchorAt) / 1000));
    }
    function makeCell(value, className) {
        var td = document.createElement('td');
        if (className) { td.className = className; }
        td.textContent = value;
        return td;
    }
    function render() {
        var ids = Object.keys(timers);
        panel.hidden = ids.length === 0;
        if (countEl) { countEl.textContent = String(ids.length); }
        if (!body) { return; }
        body.innerHTML = '';
        ids.forEach(function (id) {
            var item = timers[id];
            var tr = document.createElement('tr');
            tr.className = 'live-timer-row';
            tr.setAttribute('data-live-timer-id', id);
            if (window.__ttViewAllLiveTimers) {
                tr.appendChild(makeCell(text(item.user_name), 'fw-medium'));
            }
            tr.appendChild(makeCell(text(item.project_name)));
            tr.appendChild(makeCell(text(item.task_name)));
            tr.appendChild(makeCell(text(item.description)));
            tr.appendChild(makeCell(formatStart(item.started_at_iso), 'mono text-nowrap'));
            var durationCell = makeCell(duration(currentSeconds(item)), 'live-duration mono text-end');
            durationCell.setAttribute('data-live-duration', id);
            tr.appendChild(durationCell);
            body.appendChild(tr);
        });
    }
    function tick() {
        Object.keys(timers).forEach(function (id) {
            var el = body ? body.querySelector('[data-live-duration="' + id + '"]') : null;
            if (el) { el.textContent = duration(currentSeconds(timers[id])); }
        });
    }
    function parse(response) {
        return response.text().then(function (raw) {
            var data = {};
            try { data = raw ? JSON.parse(raw) : {}; } catch (e) { data = {}; }
            return data;
        });
    }
    function refresh() {
        if (!url || polling) { return; }
        polling = true;
        var requestUrl = url;
        if (userId && userId !== '0') {
            requestUrl += (requestUrl.indexOf('?') === -1 ? '?' : '&') + 'user_id=' + encodeURIComponent(userId);
        }
        fetch(requestUrl, {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            cache: 'no-store'
        }).then(parse).then(function (data) {
            if (!data.ok || !Array.isArray(data.timers)) { return; }
            var next = Object.create(null);
            data.timers.forEach(function (timer) {
                var id = String(timer.id);
                next[id] = {
                    id: id,
                    user_name: timer.user_name || '',
                    project_name: timer.project_name || '',
                    task_name: timer.task_name || '',
                    description: timer.description || '',
                    started_at_iso: timer.started_at_iso || '',
                    elapsed: parseInt(timer.elapsed_seconds, 10) || 0,
                    paused: !!timer.paused,
                    anchorAt: Date.now()
                };
            });
            timers = next;
            render();
            tick();
        }).catch(function () { /* keep the last good state visible */ })
          .finally(function () { polling = false; });
    }

    window.__ttViewAllLiveTimers = panel.querySelector('thead th:first-child') &&
        panel.querySelector('thead th:first-child').textContent.trim() === 'Person';

    refresh();
    pollTimer = window.setInterval(function () {
        if (document.hidden) { return; }
        refresh();
    }, 15000);
    tickTimer = window.setInterval(tick, 1000);

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) { refresh(); }
    });
    window.addEventListener('tt:timer-changed', refresh);
})();

(function () {
    'use strict';

    var bar = document.querySelector('[data-timer-bar]');
    if (!bar) { return; }

    var statusUrl = bar.getAttribute('data-status-url') || '';
    var startUrl = bar.getAttribute('data-start-url') || '';
    var stopUrl = bar.getAttribute('data-stop-url') || '';
    var pauseUrl = bar.getAttribute('data-pause-url') || '';
    var resumeUrl = bar.getAttribute('data-resume-url') || '';
    var pingUrl = bar.getAttribute('data-ping-url') || '';
    var idleResponseUrl = bar.getAttribute('data-idle-response-url') || '';
    var tasksUrl = bar.getAttribute('data-tasks-url') || '';

    var pip = document.querySelector('[data-timer-pip]');
    var pipOpenBtn = bar.querySelector('[data-timer-pip-open]');
    var pipToggleBtn = pip ? pip.querySelector('[data-timer-pip-toggle]') : null;
    var pipHome = pip && pip.parentNode ? pip.parentNode : null;
    var pipWindow = null;
    var pipOpening = false;
    var pipResizeObserver = null;
    var clockEls = document.querySelectorAll('[data-timer-clock]');
    var projectEls = document.querySelectorAll('[data-timer-project]');
    var taskEls = document.querySelectorAll('[data-timer-task]');
    var stopBtns = document.querySelectorAll('[data-timer-stop]');
    var toggleBtns = document.querySelectorAll('[data-timer-toggle]');
    var conflictModalEl = document.querySelector('[data-timer-stop-conflict-modal]');
    var conflictModal = null;
    var conflictDetails = conflictModalEl ? conflictModalEl.querySelector('[data-timer-conflict-details]') : null;
    var trimBtn = conflictModalEl ? conflictModalEl.querySelector('[data-timer-trim]') : null;
    var discardBtn = conflictModalEl ? conflictModalEl.querySelector('[data-timer-discard]') : null;
    var idleModalEl = document.querySelector('[data-timer-idle-modal]');
    var idleModal = idleModalEl && window.bootstrap && window.bootstrap.Modal ? window.bootstrap.Modal.getOrCreateInstance(idleModalEl) : null;
    var idleContinueBtn = idleModalEl ? idleModalEl.querySelector('[data-idle-continue]') : null;
    var idlePauseBtn = idleModalEl ? idleModalEl.querySelector('[data-idle-pause]') : null;
    var idleThresholdEl = idleModalEl ? idleModalEl.querySelector('[data-idle-threshold]') : null;
    var idleCountdownEl = idleModalEl ? idleModalEl.querySelector('[data-idle-countdown]') : null;
    var idleTitleEl = idleModalEl ? idleModalEl.querySelector('[data-idle-title]') : null;
    var idleTitleIcon = idleModalEl ? idleModalEl.querySelector('[data-idle-title-icon]') : null;
    var idleBodyWarning = idleModalEl ? idleModalEl.querySelector('[data-idle-body-warning]') : null;
    var idleBodyPaused = idleModalEl ? idleModalEl.querySelector('[data-idle-body-paused]') : null;
    var idleFooterWarning = idleModalEl ? idleModalEl.querySelector('[data-idle-footer-warning]') : null;
    var idleFooterPaused = idleModalEl ? idleModalEl.querySelector('[data-idle-footer-paused]') : null;
    var idleResumeBtn = idleModalEl ? idleModalEl.querySelector('[data-idle-resume]') : null;
    var idleStopBtn = idleModalEl ? idleModalEl.querySelector('[data-idle-stop]') : null;
    var idleEventId = 0;
    var idleWarningDeadline = 0;
    var idleCountdownTimer = null;
    var idleLastExpiryPoll = 0;

    if (conflictModalEl && window.bootstrap && window.bootstrap.Modal) {
        conflictModal = window.bootstrap.Modal.getOrCreateInstance(conflictModalEl);
    }

    var originElapsed = 0;
    var originAt = 0;
    var running = false;
    var paused = false;
    var tickTimer = null;
    var busy = false;

    function pad(n) { return n < 10 ? '0' + n : String(n); }

    function formatElapsed(seconds) {
        seconds = Math.max(0, Math.floor(seconds));
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = seconds % 60;
        return h + ':' + pad(m) + ':' + pad(s);
    }

    function currentElapsed() {
        if (!running) { return originElapsed; }
        return originElapsed + Math.max(0, Math.floor((Date.now() - originAt) / 1000));
    }

    function allIn(selector) {
        var nodes = Array.prototype.slice.call(document.querySelectorAll(selector));
        if (pipWindow && pipWindow.document && pipWindow.document !== document) {
            Array.prototype.push.apply(nodes, pipWindow.document.querySelectorAll(selector));
        }
        if (pip) {
            Array.prototype.forEach.call(pip.querySelectorAll(selector), function (el) {
                if (nodes.indexOf(el) === -1) { nodes.push(el); }
            });
        }
        return nodes;
    }

    function collectTimerEls() {
        clockEls = allIn('[data-timer-clock]');
        projectEls = allIn('[data-timer-project]');
        taskEls = allIn('[data-timer-task]');
        stopBtns = allIn('[data-timer-stop]');
        toggleBtns = allIn('[data-timer-toggle]');
        pipToggleBtn = pip ? pip.querySelector('[data-timer-pip-toggle]') : null;
    }

    function renderClock() {
        var text = formatElapsed(currentElapsed());
        clockEls.forEach(function (el) { el.textContent = text; });
    }

    function copyStylesTo(targetDoc) {
        Array.prototype.forEach.call(document.querySelectorAll('link[rel="stylesheet"]'), function (link) {
            var clone = targetDoc.createElement('link');
            clone.rel = 'stylesheet';
            clone.href = link.href;
            targetDoc.head.appendChild(clone);
        });
        Array.prototype.forEach.call(document.querySelectorAll('style'), function (style) {
            targetDoc.head.appendChild(style.cloneNode(true));
        });
        var htmlTheme = document.documentElement.getAttribute('data-bs-theme');
        if (htmlTheme) {
            targetDoc.documentElement.setAttribute('data-bs-theme', htmlTheme);
        }
        targetDoc.documentElement.classList.add('timer-pip-window');
        targetDoc.body.className = document.body.className;
    }

    function bindPipClicks(doc) {
        doc.addEventListener('click', function (event) {
            var toggleEl = event.target.closest ? event.target.closest('[data-timer-pip-toggle]') : null;
            if (toggleEl) {
                event.preventDefault();
                togglePause();
                return;
            }
            var stopEl = event.target.closest ? event.target.closest('[data-timer-stop]') : null;
            if (stopEl) {
                event.preventDefault();
                stopTimer();
                return;
            }
            var closeEl = event.target.closest ? event.target.closest('[data-timer-pip-close]') : null;
            if (closeEl) {
                event.preventDefault();
                closePip();
            }
        });
    }

    function supportsDocPip() {
        return !!(window.documentPictureInPicture && typeof window.documentPictureInPicture.requestWindow === 'function');
    }

    function syncPipCompact() {
        if (!pip) { return; }
        var width = pip.clientWidth || (pipWindow && pipWindow.innerWidth) || 0;
        var height = pip.clientHeight || (pipWindow && pipWindow.innerHeight) || 0;
        pip.classList.toggle('is-narrow', width > 0 && width < 280);
        pip.classList.toggle('is-short', height > 0 && height < 180);
    }

    function watchPipSize() {
        if (!pip) { return; }
        if (typeof ResizeObserver === 'function') {
            if (!pipResizeObserver) {
                pipResizeObserver = new ResizeObserver(function () { syncPipCompact(); });
            }
            try { pipResizeObserver.observe(pip); } catch (e) { /* ignore */ }
        }
        if (pipWindow) {
            pipWindow.addEventListener('resize', syncPipCompact);
        }
        syncPipCompact();
    }

    function unwatchPipSize() {
        if (pipResizeObserver && pip) {
            try { pipResizeObserver.unobserve(pip); } catch (e) { /* ignore */ }
        }
        if (pip) {
            pip.classList.remove('is-narrow', 'is-short');
        }
    }

    function closePip() {
        if (pipWindow && !pipWindow.closed) {
            try { pipWindow.close(); } catch (e) { /* ignore */ }
        }
        restorePip();
    }

    function restorePip() {
        unwatchPipSize();
        pipWindow = null;
        if (pip && pipHome && pip.parentNode !== pipHome) {
            pipHome.appendChild(pip);
        }
        if (pip) {
            pip.hidden = true;
            pip.classList.remove('is-paused');
        }
        collectTimerEls();
        renderClock();
    }

    function openFallbackPip() {
        if (!pip) { return; }
        pip.hidden = false;
        watchPipSize();
        collectTimerEls();
        renderClock();
    }

    function openPip() {
        if (!pip || bar.classList.contains('is-idle') || pipOpening) { return; }
        if (pipWindow && !pipWindow.closed) { return; }
        if (!pip.hidden && !supportsDocPip()) { return; }

        if (!supportsDocPip()) {
            openFallbackPip();
            return;
        }

        pipOpening = true;
        window.documentPictureInPicture.requestWindow({
            width: 340,
            height: 150,
            disallowReturnToOpener: false
        }).then(function (win) {
            pipOpening = false;
            pipWindow = win;
            win.document.title = 'Live timer';
            copyStylesTo(win.document);
            pip.hidden = false;
            win.document.body.appendChild(pip);
            bindPipClicks(win.document);
            watchPipSize();
            collectTimerEls();
            renderClock();
            win.addEventListener('pagehide', restorePip);
        }).catch(function () {
            pipOpening = false;
            openFallbackPip();
        });
    }

    function applyTimer(timer) {
        collectTimerEls();
        if (!timer) {
            running = false;
            paused = false;
            originElapsed = 0;
            originAt = Date.now();
            bar.hidden = true;
            bar.classList.add('is-idle');
            bar.classList.remove('is-paused');
            bar.setAttribute('data-started-at', '');
            bar.setAttribute('data-elapsed', '0');
            stopBtns.forEach(function (el) { el.disabled = true; });
            toggleBtns.forEach(function (el) { el.disabled = true; });
            if (pipOpenBtn) {
                pipOpenBtn.disabled = true;
                pipOpenBtn.classList.add('d-none');
            }
            if (pipToggleBtn) { pipToggleBtn.disabled = true; }
            projectEls.forEach(function (el) { el.textContent = 'Timer running'; });
            taskEls.forEach(function (el) {
                el.textContent = '';
                el.classList.add('d-none');
            });
            closePip();
            if (pip) { pip.classList.remove('is-paused'); }
            renderClock();
            return;
        }

        originElapsed = parseInt(timer.elapsed_seconds, 10) || 0;
        originAt = Date.now();
        paused = !!timer.paused;
        running = !paused;

        bar.hidden = false;
        bar.classList.remove('is-idle');
        bar.classList.toggle('is-paused', paused);
        bar.setAttribute('data-started-at', timer.started_at_iso || '');
        bar.setAttribute('data-elapsed', String(originElapsed));
        if (pip) { pip.classList.toggle('is-paused', paused); }

        projectEls.forEach(function (el) { el.textContent = timer.project_name || 'Timer running'; });
        taskEls.forEach(function (el) {
            if (timer.task_name) {
                el.textContent = timer.task_name;
                el.classList.remove('d-none');
            } else {
                el.textContent = '';
                el.classList.add('d-none');
            }
        });
        stopBtns.forEach(function (el) { el.disabled = false; });
        toggleBtns.forEach(function (el) {
            el.disabled = false;
            var label = el.querySelector('[data-timer-toggle-label]');
            if (label) { label.textContent = paused ? 'Resume' : 'Pause'; }
            var icon = el.querySelector('i');
            if (icon) { icon.className = paused ? 'fa-solid fa-play' : 'fa-solid fa-pause'; }
        });
        if (pipOpenBtn) {
            pipOpenBtn.disabled = false;
            pipOpenBtn.classList.remove('d-none');
        }
        if (pipToggleBtn) {
            pipToggleBtn.disabled = false;
            var pipIcon = pipToggleBtn.querySelector('i');
            var pipText = pipToggleBtn.querySelector('.timer-pip-btn-text');
            if (pipIcon) { pipIcon.className = paused ? 'fa-solid fa-play' : 'fa-solid fa-pause'; }
            if (pipText) { pipText.textContent = paused ? 'Resume' : 'Pause'; }
        }
        renderClock();
        window.dispatchEvent(new Event('tt:timer-changed'));
    }

    function tick() {
        if (!running) { return; }
        renderClock();
    }

    function ensureTicker() {
        if (tickTimer) { return; }
        tickTimer = window.setInterval(tick, 1000);
    }

    function parseJson(response) {
        return response.text().then(function (text) {
            var data = {};
            if (text) {
                try { data = JSON.parse(text); } catch (e) { data = {}; }
            }
            data._http = response.status;
            data._okHttp = response.ok;
            return data;
        });
    }

    function fail(message) {
        window.alert(message || 'The timer request failed.');
    }

    function startFrom(el) {
        if (busy) { return; }

        var form = el.closest ? el.closest('[data-timer-start-form], form') : null;
        var projectId = el.getAttribute('data-project-id')
            || (form && form.querySelector('[name="project_id"]') ? form.querySelector('[name="project_id"]').value : '')
            || '';
        var taskId = el.getAttribute('data-task-id')
            || (form && form.querySelector('[name="task_id"]') ? form.querySelector('[name="task_id"]').value : '')
            || '';
        var description = el.getAttribute('data-description')
            || (form && form.querySelector('[name="description"]') ? form.querySelector('[name="description"]').value : '')
            || '';
        var billable = el.getAttribute('data-billable');
        if (billable === null && form) {
            var billableField = form.querySelector('[name="is_billable"]');
            if (billableField) {
                billable = billableField.type === 'checkbox' ? (billableField.checked ? '1' : '0') : billableField.value;
            }
        }

        if (!projectId) {
            fail('Choose a project first.');
            return;
        }

        var body = {
            project_id: parseInt(projectId, 10),
            description: description
        };
        if (taskId) { body.task_id = parseInt(taskId, 10); }
        if (billable === '0' || billable === '1') { body.is_billable = parseInt(billable, 10); }

        busy = true;
        fetch(startUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(body)
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not start the timer.');
                return;
            }
            applyTimer(data.timer);
        }).catch(function () {
            busy = false;
            fail('Could not start the timer.');
        });
    }

    function formatConflictTime(value) {
        if (!value) { return '—'; }
        try {
            var normalized = String(value).replace(' ', 'T') + 'Z';
            return new Intl.DateTimeFormat('en-PK', {
                timeZone: 'Asia/Karachi',
                dateStyle: 'medium',
                timeStyle: 'short',
                hour12: true
            }).format(new Date(normalized));
        } catch (e) {
            return String(value) + ' UTC';
        }
    }

    function showStopConflict(data) {
        if (!conflictModalEl || !conflictModal) {
            fail((data && data.message) || 'The timer overlaps existing time. Open the Time page to resolve it.');
            return;
        }

        var conflict = data.conflict || {};
        if (conflictDetails) {
            conflictDetails.textContent = 'Existing entry: ' +
                formatConflictTime(conflict.start_time) + ' – ' +
                formatConflictTime(conflict.end_time) + '.';
        }
        if (trimBtn) {
            trimBtn.disabled = data.can_trim !== true;
            trimBtn.title = data.can_trim === true
                ? 'Save the timer only up to the start of the conflicting entry.'
                : 'The conflict begins at or before the timer start, so trimming is not possible.';
        }
        conflictModal.show();
    }

    function resolveStop(resolution) {
        if (busy) { return; }
        busy = true;

        fetch(stopUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ resolution: resolution })
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not resolve the timer conflict.');
                return;
            }
            if (conflictModal) { conflictModal.hide(); }
            applyTimer(null);
            window.dispatchEvent(new Event('tt:timer-changed'));
        }).catch(function () {
            busy = false;
            fail('Could not resolve the timer conflict.');
        });
    }

    function stopTimer() {
        if (busy) { return; }
        busy = true;

        fetch(stopUrl, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                if (data.resolution_required === true) {
                    hideIdlePrompt();
                    showStopConflict(data);
                    return;
                }
                fail(data.message || (data.error && data.error.message) || 'Could not stop the timer.');
                return;
            }
            hideIdlePrompt();
            applyTimer(null);
            window.dispatchEvent(new Event('tt:timer-changed'));
            window.dispatchEvent(new Event('tt:entries-changed'));
        }).catch(function () {
            busy = false;
            fail('Could not stop the timer.');
        });
    }

    function togglePause() {
        if (busy || !pauseUrl || !resumeUrl) { return; }
        busy = true;
        var url = paused ? resumeUrl : pauseUrl;

        fetch(url, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not change the timer state.');
                return;
            }
            applyTimer(data.timer || null);
            hideIdlePrompt();
        }).catch(function () {
            busy = false;
            fail('Could not change the timer state.');
        });
    }

    function setIdleMode(mode) {
        var paused = mode === 'paused';
        if (idleBodyWarning) idleBodyWarning.classList.toggle('d-none', paused);
        if (idleFooterWarning) idleFooterWarning.classList.toggle('d-none', paused);
        if (idleBodyPaused) idleBodyPaused.classList.toggle('d-none', !paused);
        if (idleFooterPaused) idleFooterPaused.classList.toggle('d-none', !paused);
        if (idleTitleEl) idleTitleEl.textContent = paused ? 'Timer paused' : 'Are you still on?';
        if (idleTitleIcon) idleTitleIcon.className = 'fa-solid ' + (paused ? 'fa-circle-pause' : 'fa-circle-question') + ' me-2';
    }

    function hideIdlePrompt() {
        idleEventId = 0;
        idleWarningDeadline = 0;
        if (idleCountdownTimer) { window.clearInterval(idleCountdownTimer); idleCountdownTimer = null; }
        if (idleCountdownEl) { idleCountdownEl.textContent = ''; }
        if (idleModal && idleModalEl && idleModalEl.classList.contains('show')) { idleModal.hide(); }
    }

    function updateIdleCountdown() {
        var remaining = Math.max(0, Math.ceil((idleWarningDeadline - Date.now()) / 1000));
        if (idleCountdownEl) {
            idleCountdownEl.textContent = remaining > 0
                ? 'Automatic pause in ' + remaining + ' seconds unless you confirm.'
                : 'Pausing your timer\u2026';
        }
        // When the countdown ends, ask the server straight away so the pause is not delayed.
        if (remaining === 0 && Date.now() - idleLastExpiryPoll > 3000) {
            idleLastExpiryPoll = Date.now();
            loadStatus();
        }
    }

    function showIdlePrompt(idle) {
        if (!idleModal || !idle || idle.warning !== true || !idle.event_id) return;
        idleEventId = parseInt(idle.event_id, 10) || 0;
        if (!idleEventId) return;
        setIdleMode('warning');
        if (idleThresholdEl) { idleThresholdEl.textContent = Math.max(1, Math.round((idle.threshold_seconds || 600) / 60)) + ' minutes'; }
        // Use the time the SERVER says is left, so repeated status checks never restart the countdown.
        var remaining = parseInt(idle.warning_remaining, 10);
        if (isNaN(remaining)) { remaining = Math.max(10, parseInt(idle.warning_seconds, 10) || 60); }
        idleWarningDeadline = Date.now() + Math.max(0, remaining) * 1000;
        if (!idleCountdownTimer) { idleCountdownTimer = window.setInterval(updateIdleCountdown, 1000); }
        updateIdleCountdown();
        if (!idleModalEl.classList.contains('show')) idleModal.show();
    }

    // After an automatic idle pause the prompt stays open (Resume / Stop only) until the person acts.
    function showIdlePausedPrompt() {
        if (!idleModal) return;
        idleEventId = 0;
        idleWarningDeadline = 0;
        if (idleCountdownTimer) { window.clearInterval(idleCountdownTimer); idleCountdownTimer = null; }
        if (idleCountdownEl) { idleCountdownEl.textContent = ''; }
        setIdleMode('paused');
        if (!idleModalEl.classList.contains('show')) idleModal.show();
    }

    function respondToIdle(response) {
        if (!idleEventId || !idleResponseUrl || busy) return;
        busy = true;
        fetch(idleResponseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            body: JSON.stringify({ event_id: idleEventId, response: response })
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                hideIdlePrompt();
                loadStatus();
                fail((data.error && data.error.message) || 'The idle prompt has expired.');
                return;
            }
            hideIdlePrompt();
            applyTimer(data.timer || null);
        }).catch(function () {
            busy = false;
            // Do not dismiss the prompt on a transient network failure.
        });
    }

    function loadStatus() {
        if (!statusUrl) { return; }

        fetch(statusUrl, {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(parseJson).then(function (data) {
            if (data.ok) {
                applyTimer(data.timer || null);
                var idleState = data.idle || {};
                if (data.timer && data.timer.paused && idleState.paused_by_idle === true) {
                    showIdlePausedPrompt();
                } else if (data.timer && !data.timer.paused && idleState.warning === true) {
                    showIdlePrompt(idleState);
                } else {
                    hideIdlePrompt();
                }
            }
        }).catch(function () { /* keep server-rendered bar */ });
    }

    function ping() {
        if (!running || !pingUrl) { return; }
        fetch(pingUrl, {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).catch(function () { /* ignore */ });
    }

    function fillTasks(select, projectId, selectedId) {
        if (!select || !tasksUrl) { return; }
        select.innerHTML = '<option value="">No task</option>';
        if (!projectId) { return; }

        fetch(tasksUrl + (tasksUrl.indexOf('?') === -1 ? '?' : '&') + 'project_id=' + encodeURIComponent(projectId), {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(parseJson).then(function (data) {
            if (!data.ok || !data.tasks) { return; }
            data.tasks.forEach(function (task) {
                var opt = document.createElement('option');
                opt.value = String(task.id);
                opt.textContent = task.name;
                if (selectedId && String(selectedId) === String(task.id)) {
                    opt.selected = true;
                }
                select.appendChild(opt);
            });
        }).catch(function () { /* keep empty */ });
    }

    document.addEventListener('click', function (event) {
        var startEl = event.target.closest ? event.target.closest('[data-timer-start]') : null;
        if (startEl && startEl.tagName !== 'SPAN') {
            event.preventDefault();
            startFrom(startEl);
            return;
        }

        var toggleEl = event.target.closest ? event.target.closest('[data-timer-toggle]') : null;
        if (toggleEl) {
            event.preventDefault();
            togglePause();
            return;
        }

        var stopEl = event.target.closest ? event.target.closest('[data-timer-stop]') : null;
        if (stopEl) {
            event.preventDefault();
            stopTimer();
            return;
        }
        var trimEl = event.target.closest ? event.target.closest('[data-timer-trim]') : null;
        if (trimEl) {
            event.preventDefault();
            resolveStop('trim');
            return;
        }

        var discardEl = event.target.closest ? event.target.closest('[data-timer-discard]') : null;
        if (discardEl) {
            event.preventDefault();
            resolveStop('discard');
            return;
        }

        var pipOpenEl = event.target.closest ? event.target.closest('[data-timer-pip-open]') : null;
        if (pipOpenEl) {
            event.preventDefault();
            openPip();
            return;
        }

        var pipCloseEl = event.target.closest ? event.target.closest('[data-timer-pip-close]') : null;
        if (pipCloseEl) {
            event.preventDefault();
            closePip();
            return;
        }

        var pipToggleEl = event.target.closest ? event.target.closest('[data-timer-pip-toggle]') : null;
        if (pipToggleEl) {
            event.preventDefault();
            togglePause();
        }
    });

    document.querySelectorAll('[data-timer-project-select]').forEach(function (select) {
        var root = select.closest('form') || select.parentElement;
        var taskSelect = root ? root.querySelector('[data-timer-task-select]') : null;
        select.addEventListener('change', function () {
            var selected = taskSelect ? (taskSelect.getAttribute('data-selected-task') || '') : '';
            fillTasks(taskSelect, select.value, selected);
        });
        if (select.value) {
            var selected = taskSelect ? (taskSelect.getAttribute('data-selected-task') || '') : '';
            fillTasks(taskSelect, select.value, selected);
        }
    });

    var manualModal = document.getElementById('manualEntryModal');
    if (manualModal && manualModal.getAttribute('data-open') === '1' && window.bootstrap && window.bootstrap.Modal) {
        window.bootstrap.Modal.getOrCreateInstance(manualModal).show();
    }

    document.addEventListener('visibilitychange', function () {
        if (!document.hidden) {
            loadStatus();
        }
    });

    var barProject = bar.querySelector('[data-timer-project]');
    var barTask = bar.querySelector('[data-timer-task]');
    applyTimer(bar.classList.contains('is-idle') ? null : {
        paused: bar.classList.contains('is-paused'),
        elapsed_seconds: parseInt(bar.getAttribute('data-elapsed') || '0', 10) || 0,
        started_at_iso: bar.getAttribute('data-started-at') || '',
        project_name: barProject ? barProject.textContent : '',
        task_name: barTask && !barTask.classList.contains('d-none') ? barTask.textContent : ''
    });

    ensureTicker();
    loadStatus();
    window.setInterval(function () {
        if (document.hidden && !(pipWindow && !pipWindow.closed)) { return; }
        ping();
    }, 60000);
    window.setInterval(function () {
        if (document.hidden && !(pipWindow && !pipWindow.closed)) { return; }
        loadStatus();
    }, 15000);

    if (idleContinueBtn) idleContinueBtn.addEventListener('click', function () { respondToIdle('continued'); });
    if (idlePauseBtn) idlePauseBtn.addEventListener('click', function () { respondToIdle('manual_pause'); });
    if (idleResumeBtn) idleResumeBtn.addEventListener('click', function () { togglePause(); });
    if (idleStopBtn) idleStopBtn.addEventListener('click', function () { stopTimer(); });
})();
