(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var role = document.getElementById('role');
    var picker = document.getElementById('client-picker');
    if (!role || !picker) return;
    var sync = function () {
      picker.hidden = role.value !== 'client';
    };
    role.addEventListener('change', sync);
    sync();
  });
})();
