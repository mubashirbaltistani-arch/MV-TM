#!/usr/bin/env bash
# Build a clean TimeTrack release zip.
#
# Left OUT of the zip (runtime data and secrets that must never be uploaded to live):
#   storage/sessions/*, storage/logs/*, storage/idle_settings.cache, storage/maintenance.flag,
#   public/uploads/*, *.log, sess_*, database dumps (*u897128490*, *.sql.gz, *.dump), _dev/, *.zip, .git/
# Kept as placeholders so the folders exist after upload:
#   storage/sessions/.gitkeep, storage/logs/.gitkeep, public/uploads/.htaccess
#
# The script verifies the finished zip and exits with an error if anything above slipped in.

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date -u +%Y%m%d)"
OUT="${1:-$ROOT/../TimeTrack-release-$STAMP.zip}"

cd "$ROOT"
rm -f "$OUT"

zip -r -q "$OUT" . \
  -x '.git/*' \
  -x 'storage/sessions/*' \
  -x 'storage/logs/*' \
  -x 'storage/idle_settings.cache' \
  -x 'storage/maintenance.flag' \
  -x 'public/uploads/*' \
  -x '*.log' \
  -x 'sess_*' \
  -x '*u897128490*' \
  -x '*.sql.gz' \
  -x '*.dump' \
  -x '_dev/*' \
  -x '*.zip'

# Re-add the placeholders that keep the runtime directories in the tree.
for f in storage/sessions/.gitkeep storage/logs/.gitkeep public/uploads/.htaccess; do
  if [ -f "$f" ]; then
    zip -g -q "$OUT" "$f"
  fi
done

echo "Wrote $OUT"

# Verify: the release must not contain sessions, logs, caches, flags or dumps.
LIST="$(unzip -Z1 "$OUT")"
BAD="$(grep -E 'sess_|\.log$|storage/idle_settings\.cache|storage/maintenance\.flag|u897128490|\.sql\.gz$|\.dump$|(^|/)_dev/' <<<"$LIST" || true)"
LEFTOVER="$(grep -E '^storage/(sessions|logs)/' <<<"$LIST" | grep -v '\.gitkeep$' || true)"
if [ -n "$BAD$LEFTOVER" ]; then
  echo "FAIL: the release zip contains files that must not be uploaded:" >&2
  printf '%s\n%s\n' "$BAD" "$LEFTOVER" | sed '/^$/d' >&2
  exit 1
fi
grep -qE '^database/UPGRADE_LIVE\.sql$' <<<"$LIST" || { echo "FAIL: database/UPGRADE_LIVE.sql is missing from the zip" >&2; exit 1; }
grep -qE '^storage/sessions/\.gitkeep$' <<<"$LIST" || echo "NOTE: storage/sessions/.gitkeep is missing from the tree."
grep -qE '^storage/logs/\.gitkeep$' <<<"$LIST" || echo "NOTE: storage/logs/.gitkeep is missing from the tree."
echo "OK: no sessions, logs, caches, flags or dumps in the zip."
