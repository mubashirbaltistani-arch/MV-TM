TimeTrack Corrected Complete Package

Built from the uploaded Dev source.

Hierarchy:
- One Team Manager may manage any number of teams.
- Each team has its own Team Lead and members.
- Roles are resolved per team and project.

Submission email:
Each submitted-time event sends an individual email to every applicable active approver:
Team Lead -> Team Manager -> Project Manager -> all Admins.
Recipients are resolved from the projects/teams attached to the submitted entries. Duplicate
people are de-duplicated and the submitter is never included as an approver.

Time locking:
Only the selected submitted/approved time entries are locked. New entries in the same
approval period remain recordable.

Hostinger target:
/domains/akhoonzadaholdings.com/public_html/Dev/
