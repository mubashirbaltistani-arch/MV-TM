<?php
declare(strict_types=1);

/**
 * Reports. Who may open them is decided by the admin per person (ReportAccessHelper):
 * "own" sees only their own time, "all" sees everyone's. Every action re-checks access
 * here in the controller; hiding the menu is not the security boundary.
 *
 *   Time report : Summary, Detailed, Weekly
 *   Team report : Attendance, Assignments
 *   Admin only  : Access (who can see reports)
 */
final class ReportController extends Controller
{
    private const PALETTE = ['#03a9f4', '#8bc34a', '#795548', '#009688', '#689f38', '#5c6bc0', '#ab47bc', '#ff9800', '#e91e63', '#607d8b'];
    private const MAX_SPAN_DAYS = 366;

    private Report $reports;

    public function __construct()
    {
        parent::__construct(true);
        FeatureFlagsHelper::requireReports();
        ReportAccessHelper::requireView();
        $this->reports = new Report();
    }

    /** GET /reports */
    public function index(Request $request, array $params): void
    {
        $this->redirect('/reports/summary');
    }

    /* ------------------------------------------------------------------ Time report */

    /** GET /reports/summary */
    public function summary(Request $request, array $params): void
    {
        $c = $this->context($request);
        $rows = $this->reports->lean($c['filters'], $c['viewerId'], $c['role'], $c['canViewAll']);
        $tz = new DateTimeZone(FormatHelper::displayTimezone());

        $primary = $this->choice($request, 'group', ['project', 'user', 'client', 'task'], 'project');
        $secondary = $this->choice($request, 'then', ['description', 'task', 'user', 'none'], 'description');
        if ($secondary === $primary) { $secondary = 'none'; }

        $total = 0; $billable = 0;
        $perDay = [];
        $perDayBillable = [];
        foreach ($c['days'] as $d) { $perDay[$d] = 0; $perDayBillable[$d] = 0; }
        foreach ($rows as $row) {
            $total += (int) $row['seconds'];
            if ((int) $row['is_billable'] === 1) { $billable += (int) $row['seconds']; }
            $d = $this->localDate((string) $row['start_time'], $tz);
            if (isset($perDay[$d])) {
                $perDay[$d] += (int) $row['seconds'];
                if ((int) $row['is_billable'] === 1) { $perDayBillable[$d] += (int) $row['seconds']; }
            }
        }

        $groups = $this->group($rows, $primary, $secondary);
        $chartDays = [];
        foreach ($perDay as $d => $sec) {
            $chartDays[] = ['label' => (new DateTimeImmutable($d))->format('D, M j'), 'seconds' => $sec, 'billable' => $perDayBillable[$d]];
        }

        $this->render('reports/summary', $c + [
            'pageTitle' => 'Summary report',
            'tab' => 'summary',
            'primary' => $primary,
            'secondary' => $secondary,
            'total' => $total,
            'billableSeconds' => $billable,
            'groups' => $groups,
            'chart' => [
                'days' => $chartDays,
                'groups' => array_map(static fn(array $g): array => ['label' => $g['label'], 'seconds' => $g['seconds'], 'color' => $g['color']], $groups),
            ],
            'chartAssets' => true,
            'reportAssets' => true,
        ]);
    }

    /** GET /reports/detailed */
    public function detailed(Request $request, array $params): void
    {
        $c = $this->context($request);
        $all = $this->reports->detail($c['filters'], $c['viewerId'], $c['role'], $c['canViewAll'], 10000);
        $perPage = 50;
        $total = count($all);
        $pages = max(1, (int) ceil($total / $perPage));
        $page = max(1, min($pages, (int) $request->input('page', 1)));
        $seconds = 0;
        $amount = 0.0;
        foreach ($all as $row) {
            $seconds += (int) $row['duration_seconds'];
            $amount += (float) $row['billable_amount'];
        }

        $this->render('reports/detailed', $c + [
            'pageTitle' => 'Detailed report',
            'tab' => 'detailed',
            'rows' => array_slice($all, ($page - 1) * $perPage, $perPage),
            'total' => $total,
            'seconds' => $seconds,
            'amount' => $amount,
            'page' => $page,
            'pages' => $pages,
        ]);
    }

    /** GET /reports/weekly */
    public function weekly(Request $request, array $params): void
    {
        $c = $this->context($request);
        $rows = $this->reports->lean($c['filters'], $c['viewerId'], $c['role'], $c['canViewAll']);
        $tz = new DateTimeZone(FormatHelper::displayTimezone());
        $by = $this->choice($request, 'group', ['user', 'project', 'client'], $c['canViewAll'] ? 'user' : 'project');

        $days = array_slice($c['days'], 0, 31);
        $matrix = [];
        $dayTotals = array_fill_keys($days, 0);
        $grand = 0;
        foreach ($rows as $row) {
            $d = $this->localDate((string) $row['start_time'], $tz);
            if (!isset($dayTotals[$d])) { continue; }
            [$key, $label] = match ($by) {
                'project' => ['p' . $row['project_id'], (string) $row['project_name']],
                'client' => ['c' . $row['client_id'], (string) $row['client_name']],
                default => ['u' . $row['user_id'], (string) $row['user_name']],
            };
            $matrix[$key] ??= ['label' => $label, 'days' => array_fill_keys($days, 0), 'total' => 0];
            $matrix[$key]['days'][$d] += (int) $row['seconds'];
            $matrix[$key]['total'] += (int) $row['seconds'];
            $dayTotals[$d] += (int) $row['seconds'];
            $grand += (int) $row['seconds'];
        }
        uasort($matrix, static fn(array $a, array $b): int => [$b['total'], $a['label']] <=> [$a['total'], $b['label']]);

        $this->render('reports/weekly', $c + [
            'pageTitle' => 'Weekly report',
            'tab' => 'weekly',
            'by' => $by,
            'days' => $days,
            'clipped' => count($c['days']) > count($days),
            'matrix' => array_values($matrix),
            'dayTotals' => $dayTotals,
            'grand' => $grand,
        ]);
    }

    /* ------------------------------------------------------------------ Team report */

    /** GET /reports/attendance */
    public function attendance(Request $request, array $params): void
    {
        $this->denyClient();
        $c = $this->context($request);
        $days = array_slice($c['days'], -62); // newest 62 days of the range
        if ($days !== []) {
            $c['filters']['from'] = $days[0];
        }
        $rows = $this->reports->lean($c['filters'], $c['viewerId'], $c['role'], $c['canViewAll']);
        $tz = new DateTimeZone(FormatHelper::displayTimezone());
        $workingDays = $this->workingDays();
        $capacity = WorkspacePolicy::dailyCapacitySeconds();

        // [user_id][date] => start, end, work, break
        $cells = [];
        foreach ($rows as $row) {
            $uid = (int) $row['user_id'];
            $d = $this->localDate((string) $row['start_time'], $tz);
            $cell = &$cells[$uid][$d];
            $cell ??= ['start' => null, 'end' => null, 'work' => 0, 'break' => 0];
            $cell['work'] += (int) $row['seconds'];
            $cell['break'] += (int) $row['break_minutes'] * 60;
            $start = (string) $row['start_time'];
            $end = (string) ($row['end_time'] ?? '');
            if ($cell['start'] === null || $start < $cell['start']) { $cell['start'] = $start; }
            if ($end !== '' && ($cell['end'] === null || $end > $cell['end'])) { $cell['end'] = $end; }
            unset($cell);
        }

        $people = $this->staff($c, $rows);
        $lines = [];
        $totals = ['capacity' => 0, 'work' => 0, 'overtime' => 0, 'undertime' => 0, 'balance' => 0, 'break' => 0];
        foreach ($people as $person) {
            foreach (array_reverse($days) as $d) {
                $cap = in_array((new DateTimeImmutable($d))->format('D'), $workingDays, true) ? $capacity : 0;
                $cell = $cells[(int) $person['id']][$d] ?? null;
                $work = $cell['work'] ?? 0;
                $over = max(0, $work - $cap);
                $under = max(0, $cap - $work);
                $lines[] = [
                    'name' => (string) $person['name'],
                    'date' => $d,
                    'start' => $cell !== null ? FormatHelper::datetime($cell['start'], 'H:i') : '',
                    'end' => $cell !== null && $cell['end'] !== null ? FormatHelper::datetime($cell['end'], 'H:i') : '',
                    'capacity' => $cap, 'work' => $work, 'overtime' => $over, 'undertime' => $under,
                    'balance' => $work - $cap, 'break' => $cell['break'] ?? 0,
                ];
                $totals['capacity'] += $cap; $totals['work'] += $work; $totals['overtime'] += $over;
                $totals['undertime'] += $under; $totals['balance'] += $work - $cap; $totals['break'] += $cell['break'] ?? 0;
            }
        }

        $perPage = 50;
        $count = count($lines);
        $pages = max(1, (int) ceil($count / $perPage));
        $page = max(1, min($pages, (int) $request->input('page', 1)));

        $this->render('reports/attendance', $c + [
            'pageTitle' => 'Attendance report',
            'tab' => 'attendance',
            'lines' => array_slice($lines, ($page - 1) * $perPage, $perPage),
            'count' => $count,
            'totals' => $totals,
            'page' => $page,
            'pages' => $pages,
            'clipped' => count($c['days']) > count($days),
        ]);
    }

    /** GET /reports/assignments */
    public function assignments(Request $request, array $params): void
    {
        $this->denyClient();
        $c = $this->context($request);
        $f = $c['filters'];
        $rows = $this->reports->lean($f, $c['viewerId'], $c['role'], $c['canViewAll']);
        $planned = $this->reports->scheduled((string) $c['period']['from'], (string) $c['period']['to'], $c['viewerId'], $c['canViewAll'], (int) $f['user_id'], (int) $f['project_id']);

        $by = $this->choice($request, 'group', ['user', 'project'], 'user');
        $users = [];
        $touch = static function (array &$users, string $by, int $uid, string $name, int $pid, string $pname): void {
            [$k1, $n1, $k2, $n2] = $by === 'project' ? [$pid, $pname, $uid, $name] : [$uid, $name, $pid, $pname];
            $users[$k1] ??= ['name' => $n1, 'scheduled' => 0, 'tracked' => 0, 'projects' => []];
            $users[$k1]['projects'][$k2] ??= ['name' => $n2, 'scheduled' => 0, 'tracked' => 0];
        };
        $add = static function (array &$users, string $by, int $uid, int $pid, string $field, int $sec): void {
            [$k1, $k2] = $by === 'project' ? [$pid, $uid] : [$uid, $pid];
            $users[$k1][$field] += $sec;
            $users[$k1]['projects'][$k2][$field] += $sec;
        };
        foreach ($planned as $p) {
            $touch($users, $by, $p['user_id'], $p['user_name'], $p['project_id'], $p['project_name']);
            $add($users, $by, $p['user_id'], $p['project_id'], 'scheduled', $p['seconds']);
        }
        foreach ($rows as $r) {
            $touch($users, $by, (int) $r['user_id'], (string) $r['user_name'], (int) $r['project_id'], (string) $r['project_name']);
            $add($users, $by, (int) $r['user_id'], (int) $r['project_id'], 'tracked', (int) $r['seconds']);
        }
        if ($request->input('all') === '1' && $by === 'user') {
            foreach ($this->staff($c, []) as $person) {
                $users[(int) $person['id']] ??= ['name' => (string) $person['name'], 'scheduled' => 0, 'tracked' => 0, 'projects' => []];
            }
        }
        $i = 0;
        uasort($users, static fn(array $a, array $b): int => strcasecmp($a['name'], $b['name']));
        foreach ($users as &$u) {
            uasort($u['projects'], static fn(array $a, array $b): int => strcasecmp($a['name'], $b['name']));
            $u['color'] = self::PALETTE[$i++ % count(self::PALETTE)];
        }
        unset($u);

        $workingDays = $this->workingDays();
        $workable = 0;
        foreach ($c['days'] as $d) {
            if (in_array((new DateTimeImmutable($d))->format('D'), $workingDays, true)) { $workable++; }
        }

        $this->render('reports/assignments', $c + [
            'pageTitle' => 'Assignments report',
            'tab' => 'assignments',
            'users' => $users,
            'by' => $by,
            'capacity' => $workable * WorkspacePolicy::dailyCapacitySeconds(),
            'scheduledTotal' => array_sum(array_column($users, 'scheduled')),
            'trackedTotal' => array_sum(array_column($users, 'tracked')),
            'showAll' => $request->input('all') === '1',
        ]);
    }

    /* ------------------------------------------------------------------ Export */

    /** GET /reports/export.csv */
    public function exportCsv(Request $request, array $params): void
    {
        if (!ReportAccessHelper::canExport()) {
            throw new HttpException(403);
        }
        $c = $this->context($request);
        $rows = $this->reports->detail($c['filters'], $c['viewerId'], $c['role'], $c['canViewAll'], 10000);

        if (ob_get_length() !== false) { @ob_end_clean(); }
        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="timetrack-report-' . gmdate('Y-m-d-His') . '.csv"');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        echo "\xEF\xBB\xBF";

        $headers = ['Date', 'User', 'Client', 'Project', 'Task', 'Start', 'End', 'Hours', 'Billable', 'Status', 'Note'];
        if ($c['canBilling']) { $headers[] = 'Frozen Rate'; $headers[] = 'Billable Amount'; }
        CsvHelper::row($headers);

        foreach ($rows as $row) {
            $values = [
                FormatHelper::date((string) $row['start_time']),
                (string) $row['user_name'],
                (string) $row['client_name'],
                (string) $row['project_name'],
                (string) $row['task_name'],
                FormatHelper::datetime((string) $row['start_time']),
                FormatHelper::datetime((string) $row['end_time']),
                FormatHelper::hours((int) $row['duration_seconds']),
                (int) $row['is_billable'] === 1 ? 'Billable' : 'Non-billable',
                (string) $row['status'],
                (string) ($row['description'] ?? ''),
            ];
            if ($c['canBilling']) {
                $values[] = number_format((float) $row['billable_rate'], 2, '.', '');
                $values[] = number_format((float) $row['billable_amount'], 2, '.', '');
            }
            CsvHelper::row($values);
        }
        exit;
    }

    /* ------------------------------------------------------------------ Access (admin) */

    /** GET /reports/access */
    public function access(Request $request, array $params): void
    {
        ReportAccessHelper::requireAdmin();
        $ready = ReportAccessHelper::tableReady();
        $people = Database::fetchAll(
            "SELECT u.id, u.name, u.email, r.name AS role" . ($ready ? ', ra.access_level, ra.can_export, ra.can_billing' : ", NULL AS access_level, 0 AS can_export, 0 AS can_billing") . "
             FROM users u INNER JOIN roles r ON r.id = u.role_id " . ($ready ? 'LEFT JOIN report_access ra ON ra.user_id = u.id ' : '') . "
             WHERE u.status = 'active' AND r.name <> 'admin'
             ORDER BY FIELD(r.name,'manager','employee','client'), u.name ASC"
        );

        $this->render('reports/access', [
            'pageTitle' => 'Reports access',
            'tab' => 'access',
            'ready' => $ready,
            'people' => $people,
        ]);
    }

    /** POST /reports/access */
    public function saveAccess(Request $request, array $params): void
    {
        ReportAccessHelper::requireAdmin();
        if (!ReportAccessHelper::tableReady()) {
            $this->flash('danger', 'Run step 7 of database/UPGRADE_LIVE.sql first, then save again.');
            $this->redirect('/reports/access');
        }

        $levels = $request->input('level', []);
        $export = $request->input('export', []);
        $billing = $request->input('billing', []);
        $levels = is_array($levels) ? $levels : [];
        $export = is_array($export) ? $export : [];
        $billing = is_array($billing) ? $billing : [];

        $people = Database::fetchAll("SELECT u.id, r.name AS role FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE r.name <> 'admin'");
        $before = Database::fetchAll('SELECT user_id, access_level, can_export, can_billing FROM report_access');
        $adminId = (int) AuthHelper::id();
        $after = [];

        Database::transaction(function () use ($people, $levels, $export, $billing, $adminId, &$after): void {
            foreach ($people as $person) {
                $id = (int) $person['id'];
                $level = (string) ($levels[(string) $id] ?? 'none');
                if (!in_array($level, ['own', 'all'], true)) {
                    Database::execute('DELETE FROM report_access WHERE user_id = :id', ['id' => $id]);
                    continue;
                }
                if ($person['role'] === AuthHelper::ROLE_CLIENT) { $level = 'own'; } // clients are always limited to their own clients' projects
                $canExport = isset($export[(string) $id]) ? 1 : 0;
                $canBilling = isset($billing[(string) $id]) ? 1 : 0;
                Database::execute(
                    'INSERT INTO report_access (user_id, access_level, can_export, can_billing, updated_by)
                     VALUES (:id, :level, :ex, :bill, :by)
                     ON DUPLICATE KEY UPDATE access_level = VALUES(access_level), can_export = VALUES(can_export),
                                             can_billing = VALUES(can_billing), updated_by = VALUES(updated_by)',
                    ['id' => $id, 'level' => $level, 'ex' => $canExport, 'bill' => $canBilling, 'by' => $adminId]
                );
                $after[] = ['user_id' => $id, 'access_level' => $level, 'can_export' => $canExport, 'can_billing' => $canBilling];
            }
        });

        LoggerHelper::audit('reports.access_updated', 'reports', null, ['module' => 'reports', 'old' => $before, 'new' => $after]);
        $this->flash('success', 'Reports access was saved.');
        $this->redirect('/reports/access');
    }

    /* ------------------------------------------------------------------ helpers */

    private function denyClient(): void
    {
        if (AuthHelper::hasRole(AuthHelper::ROLE_CLIENT)) {
            throw new HttpException(403);
        }
    }

    /** @return array<string,mixed> everything the report pages share */
    private function context(Request $request): array
    {
        $viewerId = (int) AuthHelper::id();
        $role = (string) AuthHelper::role();
        $canViewAll = ReportAccessHelper::canViewAll();
        $period = $this->period($request);
        $filters = $this->filters($request, $canViewAll, $period);

        $people = $canViewAll ? Database::fetchAll(
            "SELECT u.id, u.name, u.email FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        ) : [];

        $days = [];
        $cursor = new DateTimeImmutable($period['from']);
        $end = new DateTimeImmutable($period['to']);
        while ($cursor <= $end && count($days) < self::MAX_SPAN_DAYS) {
            $days[] = $cursor->format('Y-m-d');
            $cursor = $cursor->modify('+1 day');
        }

        $current = $request->all();
        unset($current['page']);

        return [
            'reportAssets' => true,
            'viewerId' => $viewerId,
            'role' => $role,
            'canViewAll' => $canViewAll,
            'canBilling' => ReportAccessHelper::canBilling(),
            'canExport' => ReportAccessHelper::canExport(),
            'isAdmin' => AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            'filters' => $filters,
            'period' => $period,
            'days' => $days,
            'people' => $people,
            'clients' => $canViewAll ? Database::fetchAll("SELECT id, name FROM clients WHERE status='active' ORDER BY name ASC") : [],
            'projects' => $this->filterProjects($viewerId, $canViewAll),
            'tasks' => $this->filterTasks($filters['project_id'], $viewerId, $canViewAll),
            'query' => $current,
            'hms' => static fn(int $s): string => sprintf('%s%02d:%02d:%02d', $s < 0 ? '-' : '', intdiv(abs($s), 3600), intdiv(abs($s) % 3600, 60), abs($s) % 60),
        ];
    }

    /**
     * Local date range. Defaults to the current week (workspace week start).
     *
     * @return array{from:string,to:string,label:string,prev:array{from:string,to:string},next:array{from:string,to:string},presets:array<string,array{from:string,to:string}>}
     */
    private function period(Request $request): array
    {
        $tz = new DateTimeZone(FormatHelper::displayTimezone());
        $parse = static function (mixed $v) use ($tz): ?DateTimeImmutable {
            $v = trim((string) $v);
            $d = DateTimeImmutable::createFromFormat('!Y-m-d', $v, $tz);
            return $d !== false && $d->format('Y-m-d') === $v ? $d : null;
        };

        $today = new DateTimeImmutable('today', $tz);
        $offset = WorkspacePolicy::weekStart() === 'sunday' ? (int) $today->format('w') : ((int) $today->format('w') + 6) % 7;
        $weekStart = $today->modify('-' . $offset . ' days');
        $fmt = static fn(DateTimeImmutable $d): string => $d->format('Y-m-d');

        $presets = [
            'This week' => ['from' => $fmt($weekStart), 'to' => $fmt($weekStart->modify('+6 days'))],
            'Last week' => ['from' => $fmt($weekStart->modify('-7 days')), 'to' => $fmt($weekStart->modify('-1 day'))],
            'This month' => ['from' => $fmt($today->modify('first day of this month')), 'to' => $fmt($today->modify('last day of this month'))],
            'Last month' => ['from' => $fmt($today->modify('first day of last month')), 'to' => $fmt($today->modify('last day of last month'))],
            'Last 30 days' => ['from' => $fmt($today->modify('-29 days')), 'to' => $fmt($today)],
        ];

        $from = $parse($request->input('from', ''));
        $to = $parse($request->input('to', ''));
        if ($from === null || $to === null) {
            $from = $parse($presets['This week']['from']);
            $to = $parse($presets['This week']['to']);
        }
        if ($from > $to) { [$from, $to] = [$to, $from]; }
        if ($from->diff($to)->days >= self::MAX_SPAN_DAYS) { $to = $from->modify('+' . (self::MAX_SPAN_DAYS - 1) . ' days'); }

        $label = null;
        foreach ($presets as $name => $range) {
            if ($range['from'] === $fmt($from) && $range['to'] === $fmt($to)) { $label = $name; break; }
        }
        $label ??= $from->format('M j, Y') . ' – ' . $to->format('M j, Y');

        $isMonth = $from->format('j') === '1' && $to->format('Y-m-d') === $from->modify('last day of this month')->format('Y-m-d');
        if ($isMonth) {
            $prevFrom = $from->modify('first day of last month');
            $prev = ['from' => $fmt($prevFrom), 'to' => $fmt($prevFrom->modify('last day of this month'))];
            $nextFrom = $from->modify('first day of next month');
            $next = ['from' => $fmt($nextFrom), 'to' => $fmt($nextFrom->modify('last day of this month'))];
        } else {
            $span = $from->diff($to)->days + 1;
            $prev = ['from' => $fmt($from->modify('-' . $span . ' days')), 'to' => $fmt($from->modify('-1 day'))];
            $next = ['from' => $fmt($to->modify('+1 day')), 'to' => $fmt($to->modify('+' . $span . ' days'))];
        }

        return ['from' => $fmt($from), 'to' => $fmt($to), 'label' => $label, 'prev' => $prev, 'next' => $next, 'presets' => $presets];
    }

    /**
     * @param array{from:string,to:string} $period
     * @return array<string,mixed>
     */
    private function filters(Request $request, bool $canViewAll, array $period): array
    {
        return [
            'from' => $period['from'],
            'to' => $period['to'],
            'project_id' => (int) $request->input('project_id', 0),
            'task_id' => (int) $request->input('task_id', 0),
            'user_id' => $canViewAll ? (int) $request->input('user_id', 0) : 0,
            'client_id' => $canViewAll ? (int) $request->input('client_id', 0) : 0,
            'billable' => in_array((string) $request->input('billable', ''), ['0', '1'], true) ? (string) $request->input('billable', '') : '',
        ];
    }

    /** @param list<string> $allowed */
    private function choice(Request $request, string $key, array $allowed, string $default): string
    {
        $v = (string) $request->input($key, $default);
        return in_array($v, $allowed, true) ? $v : $default;
    }

    private function localDate(string $utc, DateTimeZone $tz): string
    {
        return (new DateTimeImmutable($utc, new DateTimeZone('UTC')))->setTimezone($tz)->format('Y-m-d');
    }

    /** @return list<string> e.g. ['Mon','Tue',...] */
    private function workingDays(): array
    {
        $list = array_filter(array_map('trim', explode(',', WorkspacePolicy::string('working_days', 'Mon,Tue,Wed,Thu,Fri'))));
        return $list !== [] ? array_values($list) : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    }

    /**
     * People shown on team reports: everyone for "all" access (respecting the user filter), otherwise only the viewer.
     *
     * @param array<string,mixed> $c
     * @param list<array<string,mixed>> $rows
     * @return list<array{id:int,name:string}>
     */
    private function staff(array $c, array $rows): array
    {
        if (!$c['canViewAll']) {
            return [['id' => $c['viewerId'], 'name' => (string) (AuthHelper::user()['name'] ?? '')]];
        }
        $out = [];
        foreach ($c['people'] as $p) {
            if ((int) $c['filters']['user_id'] > 0 && (int) $p['id'] !== (int) $c['filters']['user_id']) { continue; }
            $out[] = ['id' => (int) $p['id'], 'name' => (string) $p['name']];
        }
        return $out;
    }

    /**
     * Two-level grouping for the Summary report.
     *
     * @param list<array<string,mixed>> $rows
     * @return list<array<string,mixed>>
     */
    private function group(array $rows, string $primary, string $secondary): array
    {
        $describe = static function (array $r, string $by): array {
            return match ($by) {
                'user' => ['u' . $r['user_id'], (string) $r['user_name'], ''],
                'client' => ['c' . $r['client_id'], (string) $r['client_name'], ''],
                'task' => ['t' . (int) $r['task_id'], $r['task_name'] !== '' ? (string) $r['task_name'] : '(No task)', (string) $r['project_name']],
                'description' => ['d' . md5((string) $r['description']), trim((string) $r['description']) !== '' ? (string) $r['description'] : '(No description)', ''],
                default => ['p' . $r['project_id'], (string) $r['project_name'], (string) $r['client_name']],
            };
        };

        $groups = [];
        foreach ($rows as $r) {
            [$key, $label, $sub] = $describe($r, $primary);
            $g = &$groups[$key];
            $g ??= ['label' => $label, 'sub' => $sub, 'seconds' => 0, 'count' => 0, 'children' => []];
            $g['seconds'] += (int) $r['seconds'];
            $g['count']++;
            if ($secondary !== 'none') {
                [$ck, $cl] = $describe($r, $secondary);
                $child = &$g['children'][$ck];
                $child ??= ['label' => $cl, 'seconds' => 0, 'count' => 0];
                $child['seconds'] += (int) $r['seconds'];
                $child['count']++;
                unset($child);
            }
            unset($g);
        }

        uasort($groups, static fn(array $a, array $b): int => [$b['seconds'], $a['label']] <=> [$a['seconds'], $b['label']]);
        $out = [];
        $i = 0;
        foreach ($groups as $g) {
            uasort($g['children'], static fn(array $a, array $b): int => $b['seconds'] <=> $a['seconds']);
            $g['children'] = array_values($g['children']);
            $g['color'] = self::PALETTE[$i % count(self::PALETTE)];
            $out[] = $g;
            $i++;
        }

        return $out;
    }

    /** @return list<array<string,mixed>> */
    private function filterProjects(int $userId, bool $viewAll): array
    {
        if (ClientScope::isClient()) {
            [$clause, $params] = ClientScope::projectClause('p');
            return Database::fetchAll(
                "SELECT p.id,p.name,p.project_code FROM projects p WHERE p.status <> 'Archived' AND {$clause} ORDER BY p.name ASC",
                $params
            );
        }
        if ($viewAll) {
            return Database::fetchAll("SELECT id,name,project_code FROM projects WHERE status <> 'Archived' ORDER BY name ASC");
        }

        return Database::fetchAll(
            "SELECT DISTINCT p.id,p.name,p.project_code FROM projects p
             INNER JOIN project_members pm ON pm.project_id=p.id
             WHERE pm.user_id=:uid AND p.status <> 'Archived' ORDER BY p.name ASC",
            ['uid' => $userId]
        );
    }

    /** @return list<array<string,mixed>> */
    private function filterTasks(int $projectId, int $userId, bool $viewAll): array
    {
        if ($projectId < 1) { return []; }
        if ($viewAll) {
            return Database::fetchAll('SELECT id,name FROM tasks WHERE project_id=:pid ORDER BY name ASC', ['pid' => $projectId]);
        }

        return Database::fetchAll(
            'SELECT DISTINCT t.id,t.name FROM tasks t INNER JOIN task_assignees ta ON ta.task_id=t.id
             WHERE t.project_id=:pid AND ta.user_id=:uid ORDER BY t.name ASC',
            ['pid' => $projectId, 'uid' => $userId]
        );
    }
}
