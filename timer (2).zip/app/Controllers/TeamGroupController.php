<?php
/**
 * Team setup: which teams exist in a project, who manages each team, who leads it
 * and who its members are. This is the structure timesheet approval and tasks follow:
 *
 *   Admin > Project > Project Manager > Team Manager > Team > Team Lead + Members
 *
 * Admins see every project. A project manager sees and edits only teams where
 * projects.manager_id = self. The project manager is set on the project itself
 * (Projects > Edit). Admins still need settings.manage.
 */

declare(strict_types=1);

final class TeamGroupController extends Controller
{
    private TeamGroup $teams;

    public function __construct()
    {
        parent::__construct(true);
        $this->teams = new TeamGroup();
    }

    /** GET /teams */
    public function index(Request $request, array $params): void
    {
        $this->requireCanOpen();

        $ready     = TeamGroup::installed();
        $projectId = (int) $request->input('project_id', 0);
        $search    = trim((string) $request->input('q', ''));
        $allowed   = $this->allowedProjectIds();

        if ($projectId > 0 && $allowed !== null && !in_array($projectId, $allowed, true)) {
            $this->forbidden();
        }

        $rows = [];
        if ($ready) {
            $rows = $this->teams->all($projectId, $search);
            if ($allowed !== null) {
                $rows = array_values(array_filter(
                    $rows,
                    static fn (array $row): bool => in_array((int) $row['project_id'], $allowed, true)
                ));
            }
        }
        $members = $ready ? $this->teams->membersByTeam(array_map(static fn (array $r): int => (int) $r['id'], $rows)) : [];
        foreach ($rows as &$row) {
            $row['task_count'] = $ready ? $this->teams->taskCount((int) $row['id']) : 0;
        }
        unset($row);

        $this->render('teams/index', [
            'pageTitle' => 'Team setup',
            'ready'     => $ready,
            'rows'      => $rows,
            'members'   => $members,
            'projects'  => $this->projectOptions(),
            'projectId' => $projectId,
            'search'    => $search,
        ]);
    }

    /** GET /teams/create */
    public function create(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $projectId = (int) $request->input('project_id', 0);
        $this->assertCanManageProject($projectId > 0 ? $projectId : null);

        $this->renderForm(null, [], $projectId);
    }

    /** POST /teams */
    public function store(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        [$data, $memberIds] = $this->validated('/teams/create', 0);
        $this->assertCanManageProject((int) $data['project_id']);

        $id = $this->teams->create($data, $memberIds, (int) AuthHelper::id());
        ApprovalChainHelper::reset();

        $warnings = $this->teams->syncProjectMembers(
            (int) $data['project_id'],
            $data['manager_id'],
            $data['lead_id'],
            $memberIds
        );

        LoggerHelper::audit('team.created', 'team', $id, [
            'name' => $data['name'], 'project_id' => $data['project_id'],
            'manager_id' => $data['manager_id'], 'lead_id' => $data['lead_id'], 'members' => count($memberIds),
        ]);
        $this->flash('success', 'Team "' . $data['name'] . '" was created.');
        foreach ($warnings as $warning) {
            $this->flash('warning', $warning);
        }
        $this->redirect('/teams');
    }

    /** GET /teams/{id}/edit */
    public function edit(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $team = $this->teams->find((int) ($params['id'] ?? 0));
        if ($team === null) {
            $this->notFound();
        }
        $this->assertCanManageProject((int) $team['project_id']);

        $this->renderForm($team, $this->teams->memberIds((int) $team['id']), (int) $team['project_id']);
    }

    /** POST /teams/{id} */
    public function update(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $id   = (int) ($params['id'] ?? 0);
        $team = $this->teams->find($id);
        if ($team === null) {
            $this->notFound();
        }
        $this->assertCanManageProject((int) $team['project_id']);

        [$data, $memberIds] = $this->validated('/teams/' . $id . '/edit', $id);
        $this->assertCanManageProject((int) $data['project_id']);

        $this->teams->update($id, $data, $memberIds);
        ApprovalChainHelper::reset();

        $warnings = $this->teams->syncProjectMembers(
            (int) $data['project_id'],
            $data['manager_id'],
            $data['lead_id'],
            $memberIds
        );

        LoggerHelper::audit('team.updated', 'team', $id, [
            'name' => $data['name'], 'project_id' => $data['project_id'],
            'manager_id' => $data['manager_id'], 'lead_id' => $data['lead_id'], 'members' => count($memberIds),
        ]);
        $this->flash('success', 'Team "' . $data['name'] . '" was updated.');
        foreach ($warnings as $warning) {
            $this->flash('warning', $warning);
        }
        $this->redirect('/teams');
    }

    /** POST /teams/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        $this->requireCanOpen();
        $this->requireReady();

        $id   = (int) ($params['id'] ?? 0);
        $team = $this->teams->find($id);
        if ($team === null) {
            $this->notFound();
        }
        $this->assertCanManageProject((int) $team['project_id']);

        $taskCount = $this->teams->taskCount($id);
        $this->teams->delete($id);
        ApprovalChainHelper::reset();

        LoggerHelper::audit('team.deleted', 'team', $id, [
            'name'       => (string) $team['name'],
            'project_id' => (int) $team['project_id'],
            'task_count' => $taskCount,
        ]);
        $message = 'Team "' . (string) $team['name'] . '" was deleted. Its people keep their accounts and project access.';
        if ($taskCount > 0) {
            $message .= ' ' . $taskCount . ' task' . ($taskCount === 1 ? '' : 's') . ' became project-level.';
        }
        $this->flash('success', $message);
        $this->redirect('/teams');
    }

    /* ------------------------------------------------------------------ helpers */

    private function requireReady(): void
    {
        if (TeamGroup::installed()) {
            return;
        }

        $this->flash('warning', 'Team tables are not installed yet. Run database/UPGRADE_LIVE.sql.');
        $this->redirect('/teams');
    }

    /** Admins with settings.manage, or a PM of at least one project. */
    private function requireCanOpen(): void
    {
        if (ClientScope::isClient()) {
            $this->forbidden();
        }

        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            PermissionHelper::require('settings.manage');

            return;
        }

        if ($this->managedProjectIds() === []) {
            throw new HttpException(403, 'Only an administrator or a project manager can manage teams.');
        }
    }

    private function assertCanManageProject(?int $projectId): void
    {
        if ($projectId === null || $projectId < 1) {
            if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
                return;
            }
            throw new HttpException(403, 'Choose a project you manage.');
        }

        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            return;
        }

        if (!WorkspacePolicy::isProjectManagerOf($projectId)) {
            throw new HttpException(403, 'You can only manage teams of your own project.');
        }
    }

    /**
     * null = all projects (admin). Otherwise the PM's own project ids.
     *
     * @return list<int>|null
     */
    private function allowedProjectIds(): ?array
    {
        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            return null;
        }

        return $this->managedProjectIds();
    }

    /** @return list<int> */
    private function managedProjectIds(): array
    {
        $userId = (int) AuthHelper::id();
        if ($userId < 1) {
            return [];
        }

        $rows = Database::fetchAll(
            'SELECT id FROM projects WHERE manager_id = :id',
            ['id' => $userId]
        );

        return array_map(static fn (array $row): int => (int) $row['id'], $rows);
    }

    /**
     * @param array<string, mixed>|null $team
     * @param list<int> $memberIds
     */
    private function renderForm(?array $team, array $memberIds, int $projectId): void
    {
        $this->render('teams/form', [
            'pageTitle' => $team === null ? 'New team' : 'Edit team',
            'team'      => $team,
            'memberIds' => $memberIds,
            'projectId' => $projectId,
            'projects'  => $this->projectOptions(),
            'people'    => $this->peopleOptions(),
            'statuses'  => TeamGroup::STATUSES,
            'taskCount' => $team !== null ? $this->teams->taskCount((int) $team['id']) : 0,
        ]);
    }

    /** @return list<array<string, mixed>> */
    private function projectOptions(): array
    {
        $allowed = $this->allowedProjectIds();
        $sql     = 'SELECT p.id, p.name, p.project_code, p.status, p.manager_id, pm.name AS manager_name
             FROM projects p
             LEFT JOIN users pm ON pm.id = p.manager_id';
        $params  = [];
        if ($allowed !== null) {
            if ($allowed === []) {
                return [];
            }
            $placeholders = [];
            foreach ($allowed as $i => $id) {
                $key = 'p' . $i;
                $placeholders[] = ':' . $key;
                $params[$key] = $id;
            }
            $sql .= ' WHERE p.id IN (' . implode(',', $placeholders) . ')';
        }
        $sql .= ' ORDER BY p.name ASC';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    private function peopleOptions(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name, r.name AS role
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        );
    }

    /**
     * @return array{0: array{project_id: int, name: string, manager_id: ?int, lead_id: ?int, status: string}, 1: list<int>}
     */
    private function validated(string $failPath, int $exceptId): array
    {
        $request   = $this->request;
        $errors    = [];
        $name      = trim((string) $request->input('name', ''));
        $projectId = (int) $request->input('project_id', 0);
        $managerId = (int) $request->input('manager_id', 0);
        $leadId    = (int) $request->input('lead_id', 0);
        $status    = (string) $request->input('status', 'active');

        $raw = $request->input('member_ids', []);
        if (!is_array($raw)) {
            $raw = [$raw];
        }
        $memberIds = array_values(array_unique(array_filter(
            array_map('intval', $raw),
            static fn (int $id): bool => $id > 0
        )));

        if ($name === '') {
            $errors['name'] = 'Enter a team name.';
        } elseif (mb_strlen($name, 'UTF-8') > 120) {
            $errors['name'] = 'Use 120 characters or fewer.';
        }

        $allowed = $this->allowedProjectIds();
        if ($projectId < 1 || (int) Database::fetchValue('SELECT COUNT(*) FROM projects WHERE id = :id', ['id' => $projectId]) === 0) {
            $errors['project_id'] = 'Choose the project this team belongs to.';
        } elseif ($allowed !== null && !in_array($projectId, $allowed, true)) {
            $errors['project_id'] = 'You can only manage teams of your own project.';
        } elseif ($name !== '' && $this->teams->nameTaken($projectId, $name, $exceptId)) {
            $errors['name'] = 'This project already has a team with that name.';
        }

        if (!in_array($status, TeamGroup::STATUSES, true)) {
            $status = 'active';
        }

        $valid = [];
        foreach ($this->peopleOptions() as $person) {
            $valid[(int) $person['id']] = true;
        }

        if ($managerId > 0 && !isset($valid[$managerId])) {
            $errors['manager_id'] = 'Choose an active user as team manager.';
        }
        if ($leadId > 0 && !isset($valid[$leadId])) {
            $errors['lead_id'] = 'Choose an active user as team lead.';
        }
        if ($managerId > 0 && $managerId === $leadId) {
            $errors['lead_id'] = 'The team lead and the team manager must be different people.';
        }

        $memberIds = array_values(array_filter(
            $memberIds,
            static fn (int $id): bool => isset($valid[$id]) && $id !== $managerId && $id !== $leadId
        ));

        if ($errors !== []) {
            $this->backWithErrors($failPath, $errors);
        }

        return [[
            'project_id' => $projectId,
            'name'       => $name,
            'manager_id' => $managerId > 0 ? $managerId : null,
            'lead_id'    => $leadId > 0 ? $leadId : null,
            'status'     => $status,
        ], $memberIds];
    }
}
