<?php
/**
 * Session lifecycle and the "who is logged in" state.
 *
 * SECURITY decisions:
 *  - Session ID is regenerated on login (prevents session fixation).
 *  - Cookie is HttpOnly + SameSite=Lax (+ Secure on HTTPS); IDs only accepted from cookies.
 *  - Authenticated sessions expire after idle_timeout and absolute_timeout.
 *  - Sessions are bound to the browser family (security.bind_session_to_browser, default on).
 *  - Sessions are stored in a private directory (shared hosts share the default /tmp).
 *
 * Only identity lives in the session. AuthMiddleware re-reads role/status from the
 * database on every request, so demoting or deactivating a user takes effect immediately.
 */

declare(strict_types=1);

final class AuthHelper
{
    public const ROLE_ADMIN    = 'admin';
    public const ROLE_MANAGER  = 'manager';
    public const ROLE_EMPLOYEE = 'employee';
    public const ROLE_CLIENT   = 'client';

    public const ROLES = [self::ROLE_ADMIN, self::ROLE_MANAGER, self::ROLE_EMPLOYEE, self::ROLE_CLIENT];

    private const AUTH_KEY     = 'auth';
    private const INTENDED_KEY = '_intended';

    /** Start the session with hardened settings. Safe to call more than once. */
    public static function startSession(Request $request): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }

        $cfg = Config::get('session');

        $savePath = (string) ($cfg['save_path'] ?? '');
        if ($savePath !== '') {
            if (!is_dir($savePath)) {
                @mkdir($savePath, 0700, true);
            }
            if (is_dir($savePath) && is_writable($savePath)) {
                session_save_path($savePath);
            }
        }

        ini_set('session.use_strict_mode', '1');   // refuse session IDs the server did not create
        ini_set('session.use_only_cookies', '1');  // never accept IDs from the URL
        ini_set('session.use_trans_sid', '0');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.gc_probability', '1');    // custom save path is not covered by distro cron cleanup
        ini_set('session.gc_divisor', '100');
        ini_set('session.gc_maxlifetime', (string) ($cfg['absolute_timeout'] ?? 43200));

        session_name((string) ($cfg['name'] ?? 'TTSESSID'));
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $cfg['cookie_secure'] ?? $request->isHttps(),
            'httponly' => true,
            'samesite' => (string) ($cfg['cookie_samesite'] ?? 'Lax'),
        ]);

        session_start();

        self::enforceLifetimes($request);
    }

    /** Mark a user as authenticated. $user needs id, name, email, role (+ optional timezone). */
    public static function login(array $user): void
    {
        session_regenerate_id(true);

        $now = time();
        $_SESSION[self::AUTH_KEY] = [
            'id'       => (int) $user['id'],
            'name'     => (string) $user['name'],
            'email'    => (string) $user['email'],
            'role'     => (string) $user['role'],
            'timezone' => (string) ($user['timezone'] ?? SettingsService::systemTimezone()),
        ];
        $_SESSION['_created'] = $now;
        $_SESSION['_last']    = $now;
        // Same browser-family hash that enforceLifetimes() compares against on every request.
        $family               = self::uaFamily(Request::current()->userAgent());
        $_SESSION['_ua']      = hash('sha256', $family);
        $_SESSION['_ua_family'] = $family;  // readable name, only used for the "Session dropped" log line

        CsrfHelper::regenerate();
    }

    /** Refresh cached display fields from the authoritative DB row (called by AuthMiddleware). */
    public static function syncFromDatabase(array $row): void
    {
        $_SESSION[self::AUTH_KEY] = [
            'id'       => (int) $row['id'],
            'name'     => (string) $row['name'],
            'email'    => (string) $row['email'],
            'role'     => (string) $row['role'],
            'timezone' => (string) ($row['timezone'] ?? SettingsService::systemTimezone()),
        ];
    }

    /** Destroy the session completely, including the browser cookie. */
    public static function logout(): void
    {
        $_SESSION = [];

        if (session_status() === PHP_SESSION_ACTIVE) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', [
                'expires'  => time() - 3600,
                'path'     => $params['path'],
                'domain'   => $params['domain'],
                'secure'   => $params['secure'],
                'httponly' => true,
                'samesite' => $params['samesite'] ?: 'Lax',
            ]);
            session_destroy();
        }
    }

    public static function check(): bool
    {
        return isset($_SESSION[self::AUTH_KEY]['id']);
    }

    /** @return array{id: int, name: string, email: string, role: string, timezone: string}|null */
    public static function user(): ?array
    {
        return $_SESSION[self::AUTH_KEY] ?? null;
    }

    public static function id(): ?int
    {
        return self::check() ? (int) $_SESSION[self::AUTH_KEY]['id'] : null;
    }

    public static function role(): ?string
    {
        return self::check() ? (string) $_SESSION[self::AUTH_KEY]['role'] : null;
    }

    public static function hasRole(string ...$roles): bool
    {
        $role = self::role();

        return $role !== null && in_array($role, $roles, true);
    }

    /**
     * True when the logged-in user's role has ALL the given permissions.
     *
     * Convenience wrapper so callers can write AuthHelper::hasPermission('projects.edit').
     * The permission tables are read by PermissionHelper (cached once per request).
     * Like hasRole(), this is for showing or hiding UI; the controller must still enforce
     * access on the server with PermissionHelper::require().
     */
    public static function hasPermission(string ...$permissions): bool
    {
        return PermissionHelper::has(...$permissions);
    }

    /**
     * Release the session file lock for read-only requests (e.g. timer status polling) so
     * parallel AJAX calls are not serialized behind each other. Do not write to $_SESSION afterwards.
     */
    public static function releaseSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
    }

    /** Remember where an unauthenticated visitor was heading. Only internal paths are stored. */
    public static function rememberIntended(string $path): void
    {
        if ($path !== '' && $path[0] === '/' && !str_starts_with($path, '//') && !preg_match('/[\\\\\r\n]/', $path)) {
            $_SESSION[self::INTENDED_KEY] = $path;
        }
    }

    /** Read-and-clear the remembered destination, falling back to $default. */
    public static function pullIntended(string $default = '/dashboard'): string
    {
        $path = $_SESSION[self::INTENDED_KEY] ?? $default;
        unset($_SESSION[self::INTENDED_KEY]);

        return is_string($path) && $path !== '' && $path[0] === '/' && !str_starts_with($path, '//')
            ? $path
            : $default;
    }

    /**
     * Drop authenticated sessions that are idle, too old or (when security.bind_session_to_browser
     * is on) presented by a different browser family. Every drop is logged with the old and new family.
     */
    private static function enforceLifetimes(Request $request): void
    {
        $now     = time();
        $family  = self::uaFamily($request->userAgent());
        $ua      = hash('sha256', $family);
        $bind    = (bool) Config::get('security.bind_session_to_browser', true);

        if (!self::check()) {
            $_SESSION['_created'] ??= $now;
            $_SESSION['_last']    = $now;
            $_SESSION['_ua']      ??= $ua;
            $_SESSION['_ua_family'] ??= $family;
            return;
        }

        $idle     = $now - (int) ($_SESSION['_last'] ?? 0);
        $age      = $now - (int) ($_SESSION['_created'] ?? 0);
        $sameUa   = hash_equals((string) ($_SESSION['_ua'] ?? ''), $ua);
        $expired  = $idle > (int) Config::get('session.idle_timeout', 14400)
            || $age > (int) Config::get('session.absolute_timeout', 43200);
        $browserChanged = $bind && !$sameUa;

        if ($expired || $browserChanged) {
            LoggerHelper::info('Session dropped', [
                'user_id'            => self::id(),
                'reason'             => $expired ? 'expired' : 'browser family changed',
                'old_browser_family' => (string) ($_SESSION['_ua_family'] ?? 'unknown (session created before this was recorded)'),
                'new_browser_family' => $family,
                'new_user_agent'     => substr($request->userAgent(), 0, 200),
                'idle_seconds'       => $idle,
                'age_seconds'        => $age,
            ]);

            self::logout();
            // logout() destroyed the session; open a clean one so flash messages and CSRF still work.
            session_start();
            session_regenerate_id(true);
            $_SESSION['_created'] = $now;
            $_SESSION['_last']    = $now;
            $_SESSION['_ua']      = $ua;
            $_SESSION['_ua_family'] = $family;
            $_SESSION['_flash']['warning'][] = 'Your session has ended. Please sign in again.';
            return;
        }

        // Binding off: follow the browser instead of dropping the session, so switching it back on later
        // does not sign everybody out at once.
        $_SESSION['_ua']        = $ua;
        $_SESSION['_ua_family'] = $family;
        $_SESSION['_last']      = $now;
    }

    /** Bind sessions to the browser family, not the full UA (auto-updates change the patch version). */
    private static function uaFamily(string $ua): string
    {
        if (preg_match('/(Firefox|Edg|OPR|Chrome|Safari|MSIE|Trident)\//i', $ua, $m)) {
            return strtolower($m[1]);
        }
        return 'other';
    }
}