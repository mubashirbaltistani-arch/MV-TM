<?php
/**
 * Shared tracking business rules for timer start, manual add, entry edit, and import.
 *
 * Integrity: a viewer membership cannot mint billable hours; only Active projects
 * accept time; start_date is the earliest allowed local calendar day; closed tasks
 * cannot receive new or edited time.
 *
 * Access: the Admin role is exempt from every PERMISSION restriction (project
 * membership, viewer role, task assignment). Admins are still bound by the data
 * integrity rules above (Active status, start date, closed tasks), because those
 * protect the data rather than limit who may act.
 */

declare(strict_types=1);

final class TimeTrackingRules
{
    public const CONTEXT_START  = 'start';
    public const CONTEXT_MANUAL = 'manual';
    public const CONTEXT_EDIT   = 'edit';
    public const CONTEXT_IMPORT = 'import';

    /**
     * @return array{project: array<string, mixed>, task: array<string, mixed>|null}
     */
    public static function assertCanTrack(
        int $userId,
        int $projectId,
        ?int $taskId,
        string $startUtc,
        string $context = self::CONTEXT_START
    ): array {
        if ($userId < 1) {
            throw new HttpException(422, 'A valid user is required to track time.');
        }
        if ($projectId < 1) {
            throw new HttpException(422, 'Choose a project.');
        }

        $project = (new Project())->find($projectId);
        if ($project === null) {
            throw new HttpException(404, 'Project was not found.');
        }

        $viewAll = self::userHasViewAll($userId);
        // Project::userCanTrack() returns true for admins, so this only blocks non-admins.
        if (!(new Project())->userCanTrack($project, $userId, $viewAll)) {
            $role = (new ProjectMember())->roleFor($projectId, $userId);
            if ($role === ProjectMember::ROLE_VIEWER) {
                throw new HttpException(422, 'Viewers cannot track time on this project.');
            }
            throw new HttpException(403, 'You do not have permission to track time on this project.');
        }

        $status = (string) ($project['status'] ?? '');
        if ($status !== Project::STATUS_ACTIVE) {
            throw new HttpException(422, 'Time can only be tracked on Active projects.');
        }

        self::assertNotBeforeStartDate($project, $userId, $startUtc);

        $task = null;
        if ($taskId !== null && $taskId > 0) {
            $task = self::assertTrackableTask($taskId, $projectId, $userId, $viewAll, $context);
        }

        return ['project' => $project, 'task' => $task];
    }

    /**
     * @param array<string, mixed> $project
     */
    public static function assertNotBeforeStartDate(array $project, int $userId, string $startUtc): void
    {
        $startDate = trim((string) ($project['start_date'] ?? ''));
        if ($startDate === '' || $startUtc === '') {
            return;
        }

        try {
            $utc = new DateTimeImmutable($startUtc, new DateTimeZone('UTC'));
        } catch (Exception) {
            throw new HttpException(422, 'Start time is not a valid date.');
        }

        $zoneName = FormatHelper::timezoneForUser($userId);
        $localDate = $utc->setTimezone(new DateTimeZone($zoneName))->format('Y-m-d');
        if ($localDate < $startDate) {
            throw new HttpException(
                422,
                'Time cannot start before the project start date (' . $startDate . ').'
            );
        }
    }

    /**
     * @return array<string, mixed>
     */
    public static function assertTrackableTask(
        int $taskId,
        int $projectId,
        int $userId,
        bool $viewAll,
        string $context = self::CONTEXT_START
    ): array {
        if (!Task::installed()) {
            throw new HttpException(422, 'Tasks are not available.');
        }

        $task = (new Task())->find($taskId);
        if ($task === null || (int) $task['project_id'] !== $projectId) {
            throw new HttpException(422, 'That task does not belong to the selected project.');
        }

        if (!$viewAll) {
            $assigned = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM task_assignees WHERE task_id = :task_id AND user_id = :user_id',
                ['task_id' => $taskId, 'user_id' => $userId]
            ) > 0;
            $unassigned = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM task_assignees WHERE task_id = :task_id',
                ['task_id' => $taskId]
            ) === 0;
            if (!$assigned && !$unassigned) {
                throw new HttpException(403, 'You are not assigned to that task.');
            }
            if ($unassigned && !$assigned && TaskPolicy::isStrict()) {
                $teamId = isset($task['team_id']) && $task['team_id'] !== null && $task['team_id'] !== ''
                    ? (int) $task['team_id'] : null;
                if ($teamId !== null && $teamId > 0) {
                    $pos  = TaskPolicy::positionFor($userId, $projectId, $teamId);
                    $rank = match ($pos) {
                        TaskPolicy::POS_ADMIN, TaskPolicy::POS_PM, TaskPolicy::POS_TEAM_MANAGER, TaskPolicy::POS_TEAM_LEAD, TaskPolicy::POS_TEAM_MEMBER => 2,
                        default => 1,
                    };
                    if ($rank < 2) {
                        throw new HttpException(403, 'You are not on the team that owns this task.');
                    }
                }
            }
        }

        if (Task::isClosed((string) ($task['status'] ?? ''))) {
            $label = Task::isDone((string) ($task['status'] ?? '')) ? 'Completed' : 'Cancelled';
            throw new HttpException(422, $label . ' tasks cannot be used for time entries.');
        }

        return $task;
    }

    /**
     * Users who may be assigned work: members who are not viewers, plus the project manager.
     *
     * @param array<string, mixed> $project
     * @return list<int>
     */
    public static function assignableUserIds(array $project): array
    {
        $ids = (new ProjectMember())->trackableUserIds((int) $project['id']);
        $manager = (int) ($project['manager_id'] ?? 0);
        if ($manager > 0) {
            $ids[] = $manager;
        }

        return array_values(array_unique($ids));
    }

    public static function assertAssignable(array $project, array $userIds): void
    {
        if ($userIds === []) {
            return;
        }

        $allowed = self::assignableUserIds($project);
        foreach ($userIds as $uid) {
            $uid = (int) $uid;
            if ($uid < 1) {
                continue;
            }
            if (!in_array($uid, $allowed, true)) {
                throw new HttpException(422, 'Viewers cannot be assigned tasks.');
            }
        }
    }

    /**
     * True when the given user holds the Admin role. Admins bypass all permission
     * restrictions on tracking. The logged-in user is answered from the session
     * (refreshed from the database by AuthMiddleware); any other user is looked up.
     */
    public static function isAdmin(int $userId): bool
    {
        if ($userId < 1) {
            return false;
        }

        $current = AuthHelper::id();
        if ($current !== null && (int) $current === $userId) {
            return AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
        }

        $role = (string) Database::fetchValue(
            'SELECT r.name FROM users u INNER JOIN roles r ON r.id = u.role_id WHERE u.id = :id',
            ['id' => $userId]
        );

        return $role === AuthHelper::ROLE_ADMIN;
    }

    /** Admins always see everything; other roles depend on the projects.view_all permission. */
    private static function userHasViewAll(int $userId): bool
    {
        if (self::isAdmin($userId)) {
            return true;
        }

        $current = AuthHelper::id();
        if ($current !== null && (int) $current === $userId) {
            return PermissionHelper::has('projects.view_all');
        }

        return false;
    }
}