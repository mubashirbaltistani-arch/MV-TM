<?php
declare(strict_types=1);

/**
 * Clockify-style dashboard date picker.
 * Expected variables: $range, $anchor, $dashUrl, $who (optional), $dashboardRange.
 */
$who = isset($who) ? (string) $who : '';
$anchor = (string) ($anchor ?? date('Y-m-d'));
$range = (string) ($range ?? 'week');
$dashboardRange = $dashboardRange ?? ($week ?? []);

$tz = new DateTimeZone(FormatHelper::displayTimezone());
$anchorDate = DateTimeImmutable::createFromFormat('!Y-m-d', $anchor, $tz) ?: new DateTimeImmutable('today', $tz);
$periodStart = DateTimeImmutable::createFromFormat('!Y-m-d', (string) ($dashboardRange['week_start'] ?? $anchor), $tz) ?: $anchorDate;
$periodEnd = DateTimeImmutable::createFromFormat('!Y-m-d', (string) ($dashboardRange['week_end'] ?? $anchor), $tz) ?: $periodStart;
$todayDate = new DateTimeImmutable('today', $tz);

$pickerQuery = static function (string $newRange, string $date) use ($dashUrl, $who): string {
    $q = ['range' => $newRange, 'date' => $date];
    if ($who !== '') {
        $q['who'] = $who;
    }
    return $dashUrl($q);
};

$selectedStart = $periodStart;
$selectedEnd = $periodEnd;
if ($range === 'today') {
    $selectedStart = $anchorDate;
    $selectedEnd = $anchorDate;
} elseif ($range === 'month') {
    $selectedStart = $anchorDate->modify('first day of this month');
    $selectedEnd = $selectedStart->modify('last day of this month');
} elseif ($range === 'last30') {
    $selectedStart = $anchorDate->modify('-29 days');
    $selectedEnd = $anchorDate;
} elseif ($range === 'past2weeks') {
    $selectedStart = $anchorDate->modify('-13 days');
    $selectedEnd = $anchorDate;
} elseif ($range === 'year') {
    $selectedStart = $anchorDate->modify('first day of January');
    $selectedEnd = $selectedStart->modify('last day of December');
}

$headerLabel = match ($range) {
    'today' => $anchorDate->format('d/m/Y'),
    'month' => $selectedStart->format('F Y'),
    'last30', 'past2weeks' => $selectedStart->format('d/m/Y') . ' - ' . $selectedEnd->format('d/m/Y'),
    'year' => $selectedStart->format('Y'),
    default => $selectedStart->format('d/m/Y') . ' - ' . $selectedEnd->format('d/m/Y'),
};

$quick = [
    ['key' => 'today', 'label' => 'Today', 'date' => $todayDate->format('Y-m-d')],
    ['key' => 'today', 'label' => 'Yesterday', 'date' => $todayDate->modify('-1 day')->format('Y-m-d')],
    ['key' => 'week', 'label' => 'This week', 'date' => $todayDate->format('Y-m-d')],
    ['key' => 'week', 'label' => 'Last week', 'date' => $todayDate->modify('-7 days')->format('Y-m-d')],
    ['key' => 'past2weeks', 'label' => 'Past two weeks', 'date' => $todayDate->format('Y-m-d')],
    ['key' => 'month', 'label' => 'This month', 'date' => $todayDate->format('Y-m-d')],
    ['key' => 'month', 'label' => 'Last month', 'date' => $todayDate->modify('-1 month')->format('Y-m-d')],
    ['key' => 'year', 'label' => 'This year', 'date' => $todayDate->format('Y-m-d')],
];

$renderMonth = static function (DateTimeImmutable $month) use ($selectedStart, $selectedEnd, $todayDate, $pickerQuery): string {
    $first = $month->modify('first day of this month');
    $daysInMonth = (int) $first->format('t');
    $mondayIndex = ((int) $first->format('N')) - 1;
    $html = '<div class="tt-calendar-month">';
    $html .= '<div class="tt-calendar-month-title">' . e($first->format('M Y')) . '</div>';
    $html .= '<div class="tt-calendar-weekdays">';
    foreach (['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'] as $dayName) {
        $html .= '<span>' . $dayName . '</span>';
    }
    $html .= '</div><div class="tt-calendar-grid">';

    for ($i = 0; $i < $mondayIndex; $i++) {
        $html .= '<span class="tt-calendar-day is-empty"></span>';
    }

    for ($day = 1; $day <= $daysInMonth; $day++) {
        $date = $first->setDate((int) $first->format('Y'), (int) $first->format('m'), $day);
        $classes = ['tt-calendar-day'];
        if ($date->format('Y-m-d') === $todayDate->format('Y-m-d')) {
            $classes[] = 'is-today';
        }
        if ($date >= $selectedStart && $date <= $selectedEnd) {
            $classes[] = 'is-selected';
        }
        $classes[] = 'weekday-' . $date->format('N');
        $href = $pickerQuery('week', $date->format('Y-m-d'));
        $html .= '<a class="' . e(implode(' ', $classes)) . '" href="' . e($href) . '">' . (int) $day . '</a>';
    }

    $totalCells = $mondayIndex + $daysInMonth;
    $trailing = (7 - ($totalCells % 7)) % 7;
    for ($i = 0; $i < $trailing; $i++) {
        $html .= '<span class="tt-calendar-day is-empty"></span>';
    }

    $html .= '</div></div>';
    return $html;
};

$firstMonth = $anchorDate->modify('first day of this month');
$secondMonth = $firstMonth->modify('+1 month');
?>
<div class="tt-date-picker" data-dashboard-date-picker>
    <button type="button" class="tt-date-trigger" data-date-picker-trigger aria-expanded="false">
        <i class="fa-regular fa-calendar" aria-hidden="true"></i>
        <span><?= e($headerLabel) ?></span>
        <i class="fa-solid fa-chevron-down tt-date-trigger-chevron" aria-hidden="true"></i>
    </button>

    <div class="tt-date-popover" data-date-picker-popover hidden>
        <div class="tt-date-quick">
            <?php foreach ($quick as $item): ?>
                <?php
                $isActive = ($range === $item['key'] && ($item['label'] === 'This week' || $item['label'] === 'This month' || $item['label'] === 'This year' || $item['label'] === 'Today'));
                if ($item['label'] === 'Yesterday') $isActive = $range === 'today' && $anchor === $item['date'];
                if ($item['label'] === 'Last week') $isActive = $range === 'week' && $anchor === $item['date'];
                if ($item['label'] === 'Last month') $isActive = $range === 'month' && $anchor === $item['date'];
                ?>
                <a class="tt-date-quick-item<?= $isActive ? ' is-active' : '' ?>" href="<?= e($pickerQuery($item['key'], $item['date'])) ?>"><?= e($item['label']) ?></a>
            <?php endforeach; ?>
        </div>

        <div class="tt-calendar-area">
            <div class="tt-calendar-nav">
                <a href="<?= e($pickerQuery('week', $firstMonth->modify('-1 month')->format('Y-m-d'))) ?>" aria-label="Previous month"><i class="fa-solid fa-chevron-left"></i></a>
                <span></span>
                <a href="<?= e($pickerQuery('week', $secondMonth->modify('+1 month')->format('Y-m-d'))) ?>" aria-label="Next month"><i class="fa-solid fa-chevron-right"></i></a>
            </div>
            <div class="tt-calendar-months">
                <?= $renderMonth($firstMonth) ?>
                <?= $renderMonth($secondMonth) ?>
            </div>
        </div>
    </div>
</div>
