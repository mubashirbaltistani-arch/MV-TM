# TimeTrack hierarchy and submission notifications

## Multiple teams per Team Manager

A Team Manager is assigned on `teams.manager_id`. The same user may be the manager of any
number of team rows. Each team independently has `teams.lead_id` and its own `team_members`.

Example:
- Team A -> Manager Ahmed -> Lead Ali
- Team B -> Manager Ahmed -> Lead Bilal
- Team C -> Manager Ahmed -> Lead Hamza

Ahmed manages all three because all three team records explicitly name Ahmed as manager.
Ali/Bilal/Hamza only control their own teams.

## Time submission email chain

For submitted time entries, recipients are resolved from the actual project/team of those
entries:
1. Team Lead
2. Team Manager
3. Project Manager
4. All active Admin users

For submissions spanning multiple teams/projects, all distinct applicable leads/managers/PMs
are included. Duplicate recipients are removed and the submitter is excluded.

Admins submitting their own time are routed only to other active admins.

## Time locking

A submission creates a timesheet batch and links only the selected time entries. Existing
submitted/approved entries stay locked; new unsubmitted entries in the same week/month remain
recordable. This allows one task to remain active across multiple weeks with many time chunks.
